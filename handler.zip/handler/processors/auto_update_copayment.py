import asyncio
import datetime
import os
import sys
from build_config import CONFIG
from util.conn_util import MongoMixin
from util.fetch_data import fetchMongoData
from util.log_util import Log
from util.time_util import timeNow


async def updateStatus():
    loanApplication = MongoMixin.userDb[
        CONFIG['database'][0]['table'][13]['name']
    ]

    loanStatusLog = MongoMixin.userDb[
        CONFIG['database'][0]['table'][18]['name']
    ]
    
    try:
        xUpdated = False
        mFindApplications = loanApplication.find(
            {
                'data.currentStatus': 'Disbursed'
            },
            {
                '_id': 1,
                'applicantId': 1,
                'data.applicantName': 1
            }
        )
        findApplicationQ = await fetchMongoData(mFindApplications)
        
        if len(findApplicationQ):    
            mCurrentDate = datetime.datetime.fromtimestamp(timeNow() / 1000 / 1000)
            mFirstDisburseDate = 0
            for i in findApplicationQ:                
                mFindStatusLog = loanStatusLog.aggregate(
                    [
                        {
                            '$match': {
                                'loanApplicationId': i.get('_id')        
                            }
                        },
                        {
                            '$addFields': {
                                'firstDisbursement': {
                                    '$first': '$disbursed'
                                }
                            }
                        },
                        {
                            '$project': {
                                'disburseDate': {
                                    '$first': '$firstDisbursement.disbursedInfo'
                                }
                            }                     
                        }
                    ]
                )
                async for x in mFindStatusLog:
                    if x.get('disburseDate') and x.get('disburseDate').get('date'):
                        mFirstDisburseDate = datetime.datetime.fromtimestamp(x.get('disburseDate').get('date') / 1000 / 1000)

                if mFirstDisburseDate != 0:  
                    if (mCurrentDate - mFirstDisburseDate).days > 365:
                        mUpdateAppStatus = await loanApplication.update_one(
                            {
                                '_id': i.get('_id')
                            },
                            {
                                '$set': {
                                    'data.currentStatus': 'Copayment'
                                }
                            }
                        )
                        if mUpdateAppStatus.modified_count:
                            Log.i('Status of Application {} is changed to Copayment'.format(i.get('applicantId')))
                            xUpdated = True

        return xUpdated

    except Exception as e:
        status = False
        template = 'Exception: {0}. Argument: {1!r}'
        code = 5011
        # self.set_status(503)
        iMessage = template.format(type(e).__name__, e.args)
        message = 'Internal Error, Please Contact the Support Team.'
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = exc_tb.tb_frame.f_code.co_filename
        Log.w('EXC', iMessage)
        Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        Log.e(e)
        