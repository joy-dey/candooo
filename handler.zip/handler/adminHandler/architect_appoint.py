#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
    Description: AccommodationProviderGrievanceHandler
    Purpose: GET, POST Grievance
"""
import datetime
import json
import os
import sys

import tornado.web
from bson import ObjectId

from build_config import CONFIG
from handler.methods.max_architect_count import maxArchitectCount
from lib.element_mixer import ElementMixer
from lib.lib import Validate
from lib.xen_protocol import xenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log
from bson.json_util import dumps as bdumps

from util.time_util import timeNow


@xenSecureV2
class ArchitectAppointHandler(ElementMixer, MongoMixin):

    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]
    
    profile = MongoMixin.userDb[
        CONFIG['database'][0]['table'][2]['name']
    ]

    loanApplication = MongoMixin.userDb[
        CONFIG['database'][0]['table'][13]['name']
    ]
    
    dprFileDetails = MongoMixin.userDb[
        CONFIG['database'][0]['table'][24]['name']
    ]
    
    block = MongoMixin.userDb[
        CONFIG['database'][0]['table'][15]['name']
    ]

    district = MongoMixin.userDb[
        CONFIG['database'][0]['table'][14]['name']
    ]

    componentId = ObjectId('63d39988458b78fdf4cf6c0d')

    async def post(self):
        code = 4000
        message = ''
        status = False
        result = []

        try:
            selfAccountFind = await self.account.find_one(
                {
                    '_id': self.accountId
                },
                {
                    'role': 1,
                    'designation': 1
                }
            )
            if selfAccountFind.get('role') not in ['Admin', 'Auditor'] or selfAccountFind.get('designation') not in ['DIC', 'Tourist Officer', None]:
                code = 4061
                message =  'You are not Allowed'
                raise Exception
                
            try:
                self.request.arguments = json.loads(self.request.body.decode())
            except:
                code = 4056
                message = 'Expected data type JSON'
                raise Exception
            
            applicationIds = self.request.arguments.get('applicationIds')
            code, message = Validate.i(
                applicationIds,
                'applicationIds',
                dataType=list,
                notEmpty=True
            )
            if code != 4100:
                raise Exception
            
            applicationArray = []
            for value, id in enumerate(applicationIds):
                try:
                    id = ObjectId(id)
                except:
                    code = 4074
                    message = 'Invalid Argument - [ applicationIds ] of no {}'.format(value+1)
                    raise Exception

                applicationArray.append(id)

            architectId = self.request.arguments.get('architectId')
            code, message = Validate.i(
                architectId,
                'architectId',
                dataType=str,
                notEmpty=True
            )
            if code != 4100:
                raise Exception
            
            try:
                architectId = ObjectId(architectId)
            except:
                code = 4090
                message = 'Invalid Argument - [ architectId ]'
                raise Exception
            
            applicationFind = self.loanApplication.find(
                {
                    '_id': {
                        '$in': applicationArray
                    }
                },
                {
                    '_id': 1,
                    'data.currentStatus':  1,
                    'applicantId': 1,
                    'architectDetails': 1
                }
            )
            async for application in applicationFind:
                if application.get('data').get('currentStatus') not in ['Loan Sanctioned', 'Onhold/Discontinued', 'Disbursed', 'Copayment', 'Construction Completed']:
                    code = 4108
                    message = 'Current status of application {} is {}'.format(application.get('applicantId'), application.get('data').get('currentStatus'))
                    raise Exception
                if application.get('architectDetails'):
                    code = 4117
                    message = 'Architect is already assigned to {}'.format(application.get('applicantId'))
                    raise Exception

            architectAccFind = await self.account.find_one(
                {
                    '_id': architectId,
                    'designation': 'Architect'
                },
                {
                    '_id': 1
                }
            )
            if not architectAccFind:
                code = 4143
                message = 'Architect Account not Found'
                raise Exception

            architectFind = self.loanApplication.aggregate(
                [
                    {
                        '$group': {
                            '_id': '$architectDetails.architectAssigned',
                            'applicationCount': {
                                '$sum': 1
                            }
                        }
                    },
                    {
                        '$project': {
                            '_id': 1,
                            'applicationCount': 1
                        }
                    }
                ]
            )
            architectArray = []
            
            async for architect in architectFind:
                architectArray.append(architect)

            maxCount = await maxArchitectCount()
            for i in architectArray:
                if i.get('_id') == architectId and ((maxCount - i.get('applicationCount')) < len(applicationArray) or maxCount - i.get('applicationCount') <= 0):
                    code = 4215
                    message = 'You can assign upto {} applications for the Architect'.format(maxCount - i.get('applicationCount'))
                    raise Exception
                
            if maxCount < len(applicationArray):
                code = 4158
                message = 'You can only assign {} applications'.format(maxCount)
                raise Exception

            architectUpdate = await self.loanApplication.update_many(
                {
                    '_id': {
                        '$in': applicationArray
                    }
                },
                {
                    '$set': {
                        'architectDetails': {
                            'architectAssigned': architectId,
                            'assignedAt': timeNow(),
                            'assignedBy': self.accountId,
                            'dprSubmitted': False
                        }
                    }
                }
            )
            code = 2000
            status = True
            message = 'Total {} applications assigned with Architect'.format(len(applicationArray))

        except Exception as e:
            status = False
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(bdumps(response))
            await self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return
        
    async def get(self):
        code = 4000
        message = ''
        status = False
        result = []
    
        try:
            selfAccountFind = await self.account.find_one(
                {
                    '_id': self.accountId
                },
                {
                    'role': 1,
                    'designation': 1
                }
            )
            if selfAccountFind.get('role') not in ['Admin', 'Auditor'] or selfAccountFind.get('designation') not in ['DIC', 'Tourist Officer', 'Bank Officials', None]:
                code = 4261
                message =  'You are not Allowed'
                raise Exception
            
            try:
                vFilter = self.get_arguments('filter')[0]
            except:
                vFilter = self.get_arguments('filter')

            code, message = Validate.i(
                vFilter,
                'filter',
                dataType=str,
                enums = ['mapped', 'unmapped']
            )
            if code != 4100:
                raise Exception
            
            try:
                vSearchWith = self.get_argument('searchWith')
                if not vSearchWith:
                    raise Exception
                vSearchWith = vSearchWith
            except:
                vSearchWith = None

            filterObj = {}
            if vSearchWith:
                nApplicationId = {
                    'applicantId': {
                        '$regex': vSearchWith,
                        '$options': 'ism'
                    }
                }

                mApplicantName = {
                    'data.applicantName': {
                        '$regex': vSearchWith,
                        '$options': 'ism'
                    }
                }

                filterObj['$or'] = [nApplicationId, mApplicantName]
            
            try:
                mDistrict = str(self.get_argument('district'))
                if not mDistrict:
                    raise Exception
                mDistrict = ObjectId(mDistrict)
            except:
                mDistrict = None
            
            try:
                mBlock = str(self.get_argument('block'))
                if not mBlock:
                    raise Exception
                mBlock = ObjectId(mBlock)
            except:
                mBlock = None

            mLocfilter = {}
            if mDistrict:                
                mLocfilter['data.unitDistrict'] = mDistrict

            if mBlock:                
                mLocfilter['data.talukblock'] = mBlock

            
            pipeline = [
                    {
                        '$match': {
                            'data.currentStatus': {
                                '$in': ['Loan Sanctioned', 'Onhold/Discontinued', 'Disbursed', 'Copayment', 'Construction Completed']
                            }
                        }
                    },
                    {
                        '$lookup': {
                            'from': self.district.name,
                            'localField': 'data.unitDistrict',
                            'foreignField': '_id',
                            'as': 'districtInfo',
                            'pipeline': [
                                {
                                    '$project': {
                                        '_id': 1,
                                        'districtName': 1
                                    }
                                }
                            ]
                        }
                    },
                    {
                        '$lookup': {
                            'from': self.block.name,
                            'localField': 'data.talukblock',
                            'foreignField': '_id',
                            'as': 'blockInfo',
                            'pipeline': [
                                {
                                    '$project': {
                                        '_id': 1,
                                        'blockName': 1
                                    }
                                }
                            ]
                        }
                    },
                    {
                        '$unwind': '$districtInfo'
                    },
                    {
                        '$unwind': '$blockInfo'
                    },
                    {
                        '$lookup': {
                            'from': self.account.name,
                            'localField': 'architectDetails.architectAssigned',
                            'foreignField':'_id',
                            'as': 'architectAssignedInfo',
                            'pipeline': [
                                {
                                    '$project': {
                                        '_id': {
                                            '$toString': '$_id'
                                        },
                                        'firstName': 1,
                                        'lastName': 1
                                    }
                                }
                            ]
                        }
                    },
                    {
                        '$lookup': {
                            'from': self.dprFileDetails.name,
                            'localField': 'applicantId',
                            'foreignField':'applicantId',
                            'as': 'dprInfo',
                            'pipeline': [
                                {
                                    '$project': {
                                        '_id': {
                                            '$toString': '$_id'
                                        },
                                        'submittedAt': 1
                                    }
                                }
                            ]
                        }
                    }
                ]
            
            if filterObj:
                pipeline.append(
                    {
                        '$match': filterObj
                    }
                )
            if mLocfilter:
                pipeline.append(
                    {
                        '$match': mLocfilter
                    }
                )
            
            pipeline.append(
                {
                    '$project': {
                        '_id': {
                            '$toString': '$_id'
                        },
                        'applicantId': 1,
                        'applicantName': '$data.applicantName',
                        'architectFirstName': '$architectAssignedInfo.firstName',
                        'architectLastName': '$architectAssignedInfo.lastName',
                        'assignedAt' : '$architectDetails.assignedAt',
                        'dprSubmittedAt' : '$dprInfo.submittedAt',
                        'gender' : '$data.gender',
                        'age': '$data.age',
                        'address': '$data.unitAddress',
                        'district': '$districtInfo.districtName',
                        'block': '$blockInfo.blockName',
                        'proposedProjectCost' : '$data.proposedProjectCost',
                        'loanSanctionedAmount' : '$data.totalSanctionedAmountByBank',
                    }
                }
            ) 
            applicationFind = self.loanApplication.aggregate(pipeline)
            async for i in applicationFind:
                if i .get('assignedAt'):
                    aDate = i['assignedAt']/1000000
                    i['assignedAt'] = datetime.datetime.fromtimestamp(int(aDate)).strftime('%d-%m-%Y')
                if i .get('dprSubmittedAt'):
                    dDate = i['dprSubmittedAt'][0]/1000000
                    del i['dprSubmittedAt']
                    i['dprSubmittedAt'] = datetime.datetime.fromtimestamp(int(dDate)).strftime('%d-%m-%Y')
                else:
                    i['dprSubmittedAt'] = None
                if len(i.get('architectFirstName')) and vFilter == 'mapped': 
                    i['architectName'] = i.get('architectFirstName')[0] + ' ' + i.get('architectLastName')[0]
                    del i['architectFirstName']
                    del i['architectLastName']
                    result.append(i)
                elif not len(i.get('architectFirstName')) and vFilter == 'unmapped':
                    del i['architectFirstName']
                    del i['architectLastName']
                    result.append(i)

            if len(result):
                code = 2000
                message = 'Data Found' 
                status = True
            else:
                code = 4295
                message = 'Data not Found'
                raise Exception

        except Exception as e:
            status = False
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(response)
            await self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return