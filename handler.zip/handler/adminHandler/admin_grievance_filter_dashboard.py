#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
    Description: AdminDashboardForGrievanceHandler
    Purpose: Get Bookings
"""
import tornado.web
import sys
from datetime import datetime as dtime
from bson import ObjectId
from build_config import CONFIG
from lib.element_mixer import ElementMixer
from lib.lib import Validate
from lib.xen_protocol import xenSecureV2
from bson.json_util import dumps as bdumps
from util.conn_util import MongoMixin
from util.log_util import Log

@xenSecureV2
class AdminDashboardForGrievanceHandler(ElementMixer, MongoMixin):

    grConversation = MongoMixin.userDb[
        CONFIG['database'][0]['table'][17]['name']
    ]

    componentId = ObjectId('63d38614458b78fdf4cf6bfa')

    async def get(self):
        code = 4000
        status = False
        message = ''
        result = []

        try:
            mFromDate = self.get_arguments('fromDate')[0]
            code, message = Validate.i(
                mFromDate,
                'fromDate',
                notNull=True,
                notEmpty=True,
                dataType=str,
                minLength=10,
                maxLength=10
            )
            if code != 4100:
                raise Exception

            mToDate = self.get_arguments('toDate')[0]
            code, message = Validate.i(
                mToDate,
                'toDate',
                notNull=True,
                notEmpty=True,
                dataType=str,
                minLength=10,
                maxLength=10
            )
            if code != 4100:
                raise Exception

            dateFormat = '%d-%m-%Y'

            try:
                fDate = dtime.strptime(mFromDate, dateFormat)
                fDate = dtime.timestamp(fDate) * 1000 * 1000
            except Exception as e:
                code = 4262
                message = 'Invalid Argument - [ fromDate ].'
                raise Exception

            try:
                tDate = dtime.strptime(mToDate, dateFormat)
                tDate = dtime.timestamp(tDate) * 1000 * 1000
                if tDate <= fDate:
                    raise Exception
            except:
                code = 4262
                message = 'Invalid Argument - [ toDate ].'
                raise Exception

            Log.d('From Date', dtime.strptime(mFromDate, dateFormat))
            Log.d('To Date', dtime.strptime(mToDate, dateFormat))

            diffTime = int((tDate - fDate) / (3600 * 24 * 1000 * 1000))
            Log.i(diffTime)
            for t in range(0, diffTime + 1):
                xRange = fDate + (t * (3600 * 24 * 1000 * 1000))
                yRange = (xRange + (3600 * 24 * 1000 * 1000))
                Log.i(xRange, yRange)
                openGr = await self.grConversation.count_documents(
                    {
                        'activity': {
                            '$elemMatch': {
                                'id': 0,
                                'time': {
                                    '$gte': xRange,
                                    '$lt': yRange
                                }
                            }
                        }
                    }
                )
                closeGr = await self.grConversation.count_documents(
                    {
                        'activity': {
                            '$elemMatch': {
                                'id': 1,
                                'time': {
                                    '$gte': xRange,
                                    '$lt': yRange
                                }
                            }
                        }
                    }
                )
                reOpenGr = await self.grConversation.count_documents(
                    {
                        'activity': {
                            '$elemMatch': {
                                'id': 2,
                                'time': {
                                    '$gte': xRange,
                                    '$lt': yRange
                                }
                            }
                        }
                    }
                )

                v = {
                    'from': xRange,
                    'to': yRange,
                    'openGrievance': openGr,
                    'closeGrievance': closeGr,
                    'reOpenGrievance': reOpenGr
                }
                result.append(v)

            if len(result):
                message = 'Data found.'
                code = 2000
                status = True
            else:
                message = 'No data found.'
                code = 4001
                status = False

        except Exception as e:
            status = False
            if not len(message):
                # self.set_status(503)
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(bdumps(response))
            await self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            # self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return
