import datetime
import json
import os
import re
import sys
import mimetypes
import requests
import pandas as pd
import io

from datetime import datetime as dtime
import tornado.web
from abc import ABCMeta
from bson import ObjectId
from build_config import CONFIG
from lib.lib import Validate
from lib.xen_protocol import xenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log
from util.time_util import timeNow
from bson.json_util import dumps as bdumps
from lib.element_mixer import ElementMixer
from util.file_util import FileUtil


@xenSecureV2
class RecommendationLoanApplicationHandler(ElementMixer,  MongoMixin, metaclass=ABCMeta):

    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]

    loanApplication = MongoMixin.userDb[
        CONFIG['database'][0]['table'][13]['name']
    ]

    loanStatusLog = MongoMixin.userDb[
        CONFIG['database'][0]['table'][18]['name']
    ]

    componentId = ObjectId('63d39988458b78fdf4cf6c0d')

    async def post(self):
        code = 4000
        message = ''
        status = False
        result = []
        try:
            
            self.request.arguments = json.loads(self.request.body.decode())

            mAccountInfo = await self.account.find_one(
                {
                    '_id': self.accountId
                },
                {
                    'role': 1,
                    'designation': 1
                }
            )
            if mAccountInfo:
                if mAccountInfo.get('role') == 'Admin' or mAccountInfo.get('designation') == 'DIC':
            
                    mEffDate = self.request.arguments.get('effectiveDate')
                    code, message = Validate.i(
                        mEffDate,
                        'effectiveDate',
                        dataType=str,
                        notNull=True
                    )
                    if code != 4100:
                        raise Exception
                    
                    try:
                        mEffDate = int(datetime.datetime.strptime(mEffDate, '%Y-%m-%d').timestamp() * 1000 * 1000)
                    except:
                        code = 4076
                        message = 'Invalid argument - [ effectiveDate ]'
                        raise Exception
                    
                    try:
                        mLoanAppId = self.request.arguments.get('loanApplicationId')
                        code, message = Validate.i(
                            mLoanAppId,
                            'loanApplicationId',
                            dataType=str,
                            notNull=True
                        )
                        if code != 4100:
                            raise Exception
                        if not mLoanAppId:
                            raise Exception
                        mLoanAppId = ObjectId(mLoanAppId)
                    except:
                        code = 4086
                        message = 'Invalid argument - [ loanApplicationId ]'
                        raise Exception
                    
                    mApplicantId = self.request.arguments.get('applicantId')
                    code, message = Validate.i(
                        mApplicantId,
                        'applicantId',
                        dataType=str,
                        notNull=True
                    )
                    if code != 4100:
                        raise Exception
                    
                    try:
                        mComment = self.request.arguments.get('comment')
                        if not mComment:
                            raise Exception
                        code, message = Validate.i(
                            mComment,
                            'comment',
                            dataType=str,
                            notEmpty=True
                        )
                        if code != 4100:
                            raise Exception
                    except:
                        mComment = None

                    loanAppFind = await self.loanApplication.find_one(
                        {
                            '_id': mLoanAppId
                        },
                        {
                            'data.currentStatus': 1
                        }
                    )
                    if not loanAppFind:
                        code = 4118
                        message = 'Loan application not found'
                        raise Exception
                    else:
                        if loanAppFind.get('data').get('currentStatus') == 'Rejected/Returned':
                            statusFind = self.loanStatusLog.aggregate(
                                [
                                    {
                                        '$match': {
                                            'loanApplicationId': mLoanAppId,
                                            'applicantId': mApplicantId
                                        }
                                    },
                                    {
                                    '$addFields': {
                                        'recommendationInfo': {
                                                '$last': '$recommendation'
                                            }
                                    } 
                                    },
                                    {
                                        '$project': {
                                            'recommendationInfo': 1
                                        }
                                    }
                                ]
                            )
                            try:
                                async for i in statusFind:
                                    mSlno = i.get('recommendationInfo').get('slNo')
                                if not mSlno:
                                    raise Exception
                            except:
                                mSlno = 0

                            recomObj = {
                                'recommendation': {
                                    'slNo': mSlno+1,
                                    'effectiveDate': mEffDate,
                                    'comment': mComment,
                                    'modifiedBy': self.accountId,
                                    'modifiedAt': timeNow(),
                                    'modifiedTo': mLoanAppId
                                }
                            }
                            await self.loanApplication.update_one(
                                {
                                    '_id': mLoanAppId
                                },
                                {
                                    '$set': {
                                        'data.isRecommended': True
                                    }
                                }
                            )

                            updateStatus = await self.loanStatusLog.update_one(
                                {
                                    'loanApplicationId': mLoanAppId,
                                    'applicantId': mApplicantId
                                },
                                {
                                    '$push': recomObj
                                }
                            )

                            if updateStatus.modified_count:
                                code = 2000
                                message = 'Recommendation updated'
                                status = True
                            else:
                                code = 4147
                                message = 'Recommendation not updated'
                                raise Exception  

                        else:
                            code = 4187
                            message = 'Recommendation possible for Rejected status'
                            raise Exception

                else:
                    code = 4204
                    message = 'Only Admin and DIC officer can add recommendation'
                    raise Exception
            else:
                code = 4208
                message = 'Account not found'
                raise Exception          

        except Exception as e:
            status = False
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(response)
            await self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            # self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return