import datetime
import json
import os
import re
import sys
import mimetypes
import requests
import pandas as pd
import io

from datetime import datetime as dtime
import tornado.web
from abc import ABCMeta
from bson import ObjectId
from build_config import CONFIG
from lib.lib import Validate
from lib.xen_protocol import xenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log
from util.time_util import timeNow
from bson.json_util import dumps as bdumps
from lib.element_mixer import ElementMixer
from util.file_util import FileUtil


@xenSecureV2
class LoanApplicationStatusHistoryHandler(ElementMixer,  MongoMixin, metaclass=ABCMeta):

    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]

    loanApplication = MongoMixin.userDb[
        CONFIG['database'][0]['table'][13]['name']
    ]

    loanStatusLog = MongoMixin.userDb[
        CONFIG['database'][0]['table'][18]['name']
    ]

    trainingStatus = MongoMixin.userDb[
        CONFIG['database'][0]['table'][21]['name']
    ]

    rejectionReasons = MongoMixin.userDb[
        CONFIG['database'][0]['table'][11]['name']
    ]

    componentId = ObjectId('63d39988458b78fdf4cf6c0d')

    async def post(self):
        code = 4000
        message = ''
        status = False
        result = []
        try:
            
            try:
                self.request.arguments = json.loads(self.request.body.decode())
            except:
                code = 4057
                message = 'Invalid JSON in body'
                raise Exception

            try:
                mLoanAppId = self.request.arguments.get('loanApplicationId')
                code, message = Validate.i(
                    mLoanAppId,
                    'loanApplicationId',
                    dataType=str,
                    notNull=True
                )
                if code != 4100:
                    raise Exception
                if not mLoanAppId:
                    raise Exception
                mLoanAppId = ObjectId(mLoanAppId)
            except:
                code = 4086
                message = 'Invalid argument - [ loanApplicationId ]'
                raise Exception
            
            mApplicantId = self.request.arguments.get('applicantId')
            code, message = Validate.i(
                mApplicantId,
                'applicantId',
                dataType=str,
                notNull=True
            )
            if code != 4100:
                raise Exception
            
            mStatus = self.request.arguments.get('status')
            code, message = Validate.i(
                mStatus,
                'status',
                dataType=str,
                notNull=True
            )
            if code != 4100:
                raise Exception
            if mStatus != 'Disbursed':
                mEffDate = self.request.arguments.get('effectiveDate')
                code, message = Validate.i(
                    mEffDate,
                    'effectiveDate',
                    dataType=str,
                    notNull=True
                )
                if code != 4100:
                    raise Exception
                
                try:
                    mEffDate = int(datetime.datetime.strptime(mEffDate, '%Y-%m-%d').timestamp() * 1000 * 1000)
                except:
                    code = 4076
                    message = 'Invalid argument - [ effectiveDate ]'
                    raise Exception
            else:
                mEffDate = None
            
            mApplicationInfo = await self.loanApplication.find_one(
                {
                    '_id': mLoanAppId,
                    'applicantId': mApplicantId
                }
            )
            if not mApplicationInfo:
                message = 'Application not found.'
                code = 4116
                raise Exception
            
            vCurrentStatus = mApplicationInfo.get('data').get('currentStatus')
            mAccountFind = await self.account.find_one(
                {
                    '_id': self.accountId
                },
                {
                    'role': 1,
                    'designation': 1
                }
            )

            trainingObj = {}
            mSlno = 0
            if mStatus in ['Rejected By Bank', 'Rejected By DIC']:
                if vCurrentStatus in ['Loan Sanctioned', 'Disbursed', 'Construction Completed', 'Copayment', 'Onhold/Discontinued', 'Under Process (At Agency)']:
                    code = 4144
                    message = f'Application Status is already {vCurrentStatus}'
                    raise Exception
                else:
                    rejByBank = mApplicationInfo.get('data').get('rejectedByBank')
                    if mAccountFind.get('role') == 'Admin' or mAccountFind.get('designation') == 'DIC' or mAccountFind.get('designation') == 'Bank Officials' or mAccountFind.get('designation') == 'Tourist Officer':
                        statusLogFind = self.loanStatusLog.aggregate(
                            [
                                {
                                    '$match': {
                                        'loanApplicationId': mLoanAppId,
                                        'applicantId': mApplicantId
                                    }
                                },
                                {
                                    '$addFields': {
                                        'rejectedInfo': {
                                            '$last': '$rejected'
                                        }
                                    }
                                },
                                {
                                    '$project': {
                                        'rejectedInfo': 1
                                    }
                                }
                            ]
                        )
                        try:
                            async for i in statusLogFind:
                                mSlno = i.get('rejectedInfo').get('slNo')
                        except:
                            mSlno = 0

                        mReasonId = self.request.arguments.get('reason')
                        code, message = Validate.i(
                            mReasonId,
                            'reason',
                            dataType=str,
                            notEmpty=True,
                            notNull=True
                        )
                        if code != 4100:
                            raise Exception
                        
                        try:
                            mReasonId = ObjectId(mReasonId)
                        except:
                            code = 4191
                            message = 'Invalid Argument - [ reason ]'
                            raise Exception
                        
                        xReasonFind = await self.rejectionReasons.find_one(
                            {
                                '_id': mReasonId
                            },
                            {
                                'reason': 1,
                                'rejectedBy': 1
                            }
                        )
                        if not xReasonFind:
                            code = 4208
                            message = 'No Such Reason Found'
                            raise Exception
                        else:
                            mReason = xReasonFind.get('reason')
                        if mStatus == 'Rejected By Bank' and rejByBank == False:
                            code = 8664
                            message = 'Application Status cannot be changed'
                            raise Exception
                        
                        elif mStatus == 'Rejected By DIC' and rejByBank == True:
                            code = 7554
                            message = 'Application Status cannot be changed'
                            raise Exception
                        
                        if mReason == 'Other':
                            mComment = self.request.arguments.get('comment')
                            code, message = Validate.i(
                                mComment,
                                'comment',
                                dataType=str,
                                notEmpty=True
                            )
                            if code != 4100:
                                raise Exception
                        else:
                            mComment = self.request.arguments.get('comment')
                            if mComment:
                                code, message = Validate.i(
                                    mComment,
                                    'comment',
                                    dataType=str,
                                    notEmpty=True
                                )
                                if code != 4100:
                                    raise Exception
                            else:
                                mComment = None

                        if vCurrentStatus == 'Rejected/Returned' and not mReason:
                            code = 2212
                            message = 'Application status is already Rejected/Returned'
                            raise Exception
                        
                        statusObj = {
                            'rejected': {
                                'slNo': mSlno+1,
                                'currentStatus': mStatus,
                                'reason': mReason,
                                'comment': mComment,
                                'modifiedBy': self.accountId,
                                'modifiedAt': timeNow(),
                                'effectiveDate': mEffDate
                            }
                        }
                    else:
                        code = 4204
                        message = 'Only Admin, Bank Official, Tourist Officer and DIC officer can Reject the application'
                        raise Exception
                
            elif mStatus == 'Onhold/Discontinued':
                if vCurrentStatus in ['Under Process (At Agency)']:
                    code = 4229
                    message = f'Application Status is already {vCurrentStatus}'
                    raise Exception
                else:
                    if mAccountFind.get('role') == 'Admin' or mAccountFind.get('designation') == 'DIC' or mAccountFind.get('designation') == 'Tourist Officer':
                        statusLogFind = self.loanStatusLog.aggregate(
                            [
                                {
                                    '$match': {
                                        'loanApplicationId': mLoanAppId,
                                        'applicantId': mApplicantId
                                    }
                                },
                                {
                                    '$addFields': {
                                        'onHoldInfo': {
                                            '$last': '$onHold'
                                        }
                                    }
                                },
                                {
                                    '$project': {
                                        'onHoldInfo': 1
                                    }
                                }
                            ]
                        )
                        try:
                            async for i in statusLogFind:
                                mSlno = i.get('onHoldInfo').get('slNo')
                        except:
                            mSlno = 0

                        mReason = self.request.arguments.get('reason')
                        code, message = Validate.i(
                            mReason,
                            'reason',
                            dataType=str,
                            notNull=True,
                            notEmpty=True
                        )
                        if code != 4100:
                            raise Exception
                        
                        mComment = self.request.arguments.get('comment')
                        if mComment:
                            code, message = Validate.i(
                                mComment,
                                'comment',
                                dataType=str,
                                notEmpty=True
                            )
                            if code != 4100:
                                raise Exception
                        else:
                            mComment = None
                        
                        statusObj = {
                            'onHold': {
                                'slNo': mSlno+1,
                                'currentStatus': mStatus,
                                'reason': mReason,
                                'comment': mComment,
                                'modifiedBy': self.accountId,
                                'modifiedAt': timeNow(),
                                'effectiveDate': mEffDate
                            }
                        }
                        trainingObj = {
                            'applicantId': mApplicantId,
                            'applicantName': mApplicationInfo.get('data').get('applicantName'),
                            'talukblock': mApplicationInfo.get('data').get('talukblock'),
                            'unitDistrict': mApplicationInfo.get('data').get('unitDistrict'),
                            'uploadMedium': 'Portal',
                            'trainingStatus': 'Pending',
                            'loanApplicationId': mLoanAppId,
                            'createdAt': timeNow(),
                            'createdBy': self.accountId
                        }
                
                    else:
                        code = 4273
                        message = 'Only Admin, Tourist Officer and DIC Officer can set Onhold status'
                        raise Exception
                
            elif mStatus == 'Disbursed':
                if vCurrentStatus in ['Construction Completed', 'Copayment', 'Onhold/Discontinued', 'Under Process (At Agency)']:
                    code = 4305
                    message = f'Application Status is already {vCurrentStatus}'
                    raise Exception
                else:                    
                    if mAccountFind.get('role') == 'Admin' or mAccountFind.get('designation') == 'Bank Officials':
                        if type(mApplicationInfo.get('data').get('sanctionedDateByBank')) == str or mApplicationInfo.get('data').get('sanctionedDateByBank') <= 0:
                            code = 4316
                            message = 'Please Enter Sanctioned Date By Bank before Disbursement'
                            raise Exception
                        elif mApplicationInfo.get('data').get('totalSanctionedAmountByBank') == 0:
                            code = 4367
                            message = 'Please Sanction Some Amount Before Disbursement'
                            raise Exception
                        mDisbursedCount = 0
                        statusLogFind = self.loanStatusLog.aggregate(
                            [
                                {
                                    '$match': {
                                        'loanApplicationId': mLoanAppId,
                                        'applicantId': mApplicantId
                                    }
                                },
                                {
                                    '$addFields': {
                                        'disbursedAmounts': '$disbursed.disbursedInfo.amount'
                                    }
                                },
                                {
                                    '$addFields': {
                                        'disbursedInfo': {
                                            '$last': '$disbursed'
                                        }
                                    }
                                },
                                {
                                    '$addFields': {
                                        'firstDisbursedInfo': {
                                            '$first': '$disbursed'
                                        }
                                    }
                                },
                                {
                                    '$addFields': {
                                        'firstDisbursedDate': {
                                            '$first': '$firstDisbursedInfo.disbursedInfo'
                                        }
                                    }
                                },
                                {
                                    '$project': {
                                        '_id': {
                                            '$toString': '$_id'
                                        },
                                        'disbursedInfo': 1,
                                        'disbursedAmounts': 1,
                                        'firstDisbursedDate': 1
                                    }
                                }
                                
                            ]
                        )
                        try:
                            mTotalDisbursedAmount = 0
                            async for i in statusLogFind:
                                print(i['disbursedInfo'])
                                for amountArrays in i.get('disbursedAmounts'):
                                    mDisbursedCount += len(amountArrays)
                                    for amounts in amountArrays:                                 
                                        mTotalDisbursedAmount += amounts
                                mEffDate = i.get('firstDisbursedDate').get('date')
                                mSlno = i.get('disbursedInfo').get('slNo')
                        except:
                            mSlno = 0
                            mEffDate = 0

                        if mApplicationInfo:
                            mDisbInfo = self.request.arguments.get('disbursedInfo')
                            code, message = Validate.i(
                                mDisbInfo,
                                'disbursedInfo',
                                dataType=list,
                                notNull=True,
                                notEmpty=True
                            )
                            if code != 4100:
                                raise Exception
                            
                            mCurrentDisbursementCount = len(mDisbInfo)
                            if mDisbursedCount + mCurrentDisbursementCount > 6:
                                if 6 - mDisbursedCount < 0:
                                    code = 4437
                                    message = 'You can not Disburse Any more'
                                    raise Exception
                                else:
                                    code = 4441
                                    message = 'You can only add {} Disbursements out of 6'.format(6 - mDisbursedCount)
                                    raise Exception
                            
                            xCurrentDisbursedAmount = 0
                            for i, value in enumerate(mDisbInfo):
                                mDisbAmount = value.get('amount')
                                code, message = Validate.i(
                                    mDisbAmount,
                                    'amount of record {}'.format(i+1),
                                    dataTypes=[float, int],
                                    notNull=True
                                )
                                if code != 4100:
                                    raise Exception
                                
                                if mDisbAmount <= 0:
                                    code = 4356
                                    message = 'Invalid amount in record {}'.format(i+1)
                                    raise Exception
                                
                                xCurrentDisbursedAmount = xCurrentDisbursedAmount + mDisbAmount                        
                                
                                mDisbDate = value.get('date')
                                code, message = Validate.i(
                                    mDisbDate,
                                    'date of record {}'.format(i+1),
                                    dataType=str,
                                    notNull=True
                                )
                                if code != 4100:
                                    raise Exception
                                try:
                                    mDisbDate = int(datetime.datetime.strptime(mDisbDate, '%Y-%m-%d').timestamp() * 1000 * 1000)
                                    value['date'] = mDisbDate
                                except:
                                    code = 4271
                                    message = 'Invalid argument - [ date of record {} ]'.format(i+1)
                                    raise Exception
                                
                                if mDisbDate > timeNow():
                                    code = 4401
                                    message = 'Disburse Date of Record {} should be Subsequent of Current Date'.format(i+1)
                                    raise Exception
                                
                                if not mEffDate:
                                    if i == 0:
                                        mEffDate = mDisbDate

                                if mDisbDate < mApplicationInfo.get('data').get('sanctionedDateByBank'):
                                    code = 4398
                                    message = 'Disbursed Date should be After Sanctioned Date of record {}'.format(i+1)
                                    raise Exception
                                
                                
                            if xCurrentDisbursedAmount > float(mApplicationInfo.get('data').get('totalSanctionedAmountByBank') - mTotalDisbursedAmount):
                                code = 4310
                                message = 'Amount is greater than sanctioned amount'
                                raise Exception
                            
                            mComment = self.request.arguments.get('comment')
                            if mComment:
                                code, message = Validate.i(
                                    mComment,
                                    'comment',
                                    dataType=str,
                                    notEmpty=True
                                )
                                if code != 4100:
                                    raise Exception
                            else:
                                mComment = None
                                
                            statusObj = {
                                'disbursed': {
                                    'slNo': mSlno+1,
                                    'currentStatus': mStatus,
                                    'disbursedInfo': mDisbInfo,
                                    'comment': mComment,
                                    'modifiedBy': self.accountId,
                                    'modifiedAt': timeNow(),
                                    'effectiveDate': mEffDate
                                }
                            }
                            trainingObj = {
                                'applicantId': mApplicantId,
                                'applicantName': mApplicationInfo.get('data').get('applicantName'),
                                'talukblock': mApplicationInfo.get('data').get('talukblock'),
                                'unitDistrict': mApplicationInfo.get('data').get('unitDistrict'),
                                'uploadMedium': 'Portal',
                                'trainingStatus': 'Pending',
                                'loanApplicationId': mLoanAppId,
                                'createdAt': timeNow(),
                                'createdBy': self.accountId
                            }
                
                    
                    else:
                        code = 4389
                        message = 'Only Admin and Bank Official can Disburse an amount'
                        raise Exception

            elif mStatus == 'Copayment':
                if vCurrentStatus in ['Onhold/Discontinued', 'Under Process (At Agency)']:
                    code = 4445
                    message = f'Application Status is already {vCurrentStatus}'
                    raise Exception
                else:
                    if mAccountFind.get('role') == 'Admin' or mAccountFind.get('designation') == 'Bank Officials':
                        if mApplicationInfo.get('data').get('totalSanctionedAmountByBank') == 0:
                            code = 4547
                            message = 'Please Sanction Some Amount Before Copayment'
                            raise Exception
                        xCopaymentCount = 0
                        xPreviousLoanPaid = 0
                        statusLogFind = self.loanStatusLog.aggregate(
                            [
                                {
                                    '$match': {
                                        'loanApplicationId': mLoanAppId,
                                        'applicantId': mApplicantId
                                    }
                                },
                                {
                                    '$addFields': {
                                        'copaymentInfo': {
                                            '$last': '$copayment'
                                        }
                                    }
                                },
                                {
                                    '$project': {
                                        'copaymentInfo': 1,
                                        'copayment': 1
                                    }
                                }
                            ]
                        )
                        try:
                            async for i in statusLogFind:
                                for copayments in i.get('copayment'):
                                    xPreviousLoanPaid += copayments.get('loanPaid')
                                xCopaymentCount = len(i.get('copayment'))
                                mSlno = i.get('copaymentInfo').get('slNo')
                        except:
                            mSlno = 0

                        if xCopaymentCount >= 3:
                            code = 4572
                            message = 'You have already Completed 3 Copayments'
                            raise Exception
                        
                        mLoanPaid = self.request.arguments.get('loanPaid')
                        code, message = Validate.i(
                            mLoanPaid,
                            'loanPaid',
                            dataTypes=[float, int],
                            notNull=True
                        ) 
                        if code != 4100:
                            raise Exception

                        if mLoanPaid <= 0:
                            code = 4597
                            message = 'Invalid Argument - [loanPaid ]'
                            raise Exception
                        
                        if mLoanPaid + xPreviousLoanPaid > float(mApplicationInfo.get('data').get('totalSanctionedAmountByBank')):
                            code = 4488
                            message = 'Copayment Amount is greater than Sanctioned Amount'
                            raise Exception

                        mPayDate  = self.request.arguments.get('paymentDate')
                        code, message = Validate.i(
                            mPayDate,
                            'paymentDate',
                            dataType=str,
                            notNull=True
                        )
                        if code !=4100:
                            raise Exception
                        
                        try:
                            mPayDate = int(datetime.datetime.strptime(mPayDate, '%Y-%m-%d').timestamp() * 1000 * 1000)
                        except:
                            code = 4076
                            message = 'Invalid argument - [ paymentDate ]'
                            raise Exception
                        
                        mComment = self.request.arguments.get('comment')
                        if mComment:
                            code, message = Validate.i(
                                mComment,
                                'comment',
                                dataType=str,
                                notEmpty=True
                            )
                            if code != 4100:
                                raise Exception
                        else:
                            mComment = None

                        statusObj = {
                            'copayment': {
                                'slNo': mSlno+1,
                                'currentStatus': mStatus,
                                'loanPaid': mLoanPaid,
                                'paymentDate': mPayDate,
                                'comment': mComment,
                                'modifiedBy': self.accountId,
                                'modifiedAt': timeNow(),
                                'effectiveDate': mEffDate
                            }
                        }
                        trainingObj = {
                            'applicantId': mApplicantId,
                            'applicantName': mApplicationInfo.get('data').get('applicantName'),
                            'talukblock': mApplicationInfo.get('data').get('talukblock'),
                            'unitDistrict': mApplicationInfo.get('data').get('unitDistrict'),
                            'uploadMedium': 'Portal',
                            'trainingStatus': 'Pending',
                            'loanApplicationId': mLoanAppId,
                            'createdAt': timeNow(),
                            'createdBy': self.accountId
                        }
                
                    else:
                        code = 4475
                        message = 'Only Admin and Bank Official  can add Copayment Details'
                        raise Exception
                
            elif mStatus == 'Online Submitted':
                if vCurrentStatus in ['Onhold/Discontinued', 'Disbursed', 'Copayment', 'Loan Sanctioned', 'Construction Completed', 'Under Process (At Agency)', 'Under Process (At Bank)', 'Online Submitted']:
                    code = 4456
                    message = f'Application status is already {vCurrentStatus}'
                    raise Exception       
                else:
                    statusLogFind = self.loanStatusLog.aggregate(
                        [
                            {
                                '$match': {
                                    'loanApplicationId': mLoanAppId,
                                    'applicantId': mApplicantId
                                }
                            },
                            {
                                '$addFields': {
                                    'onlineSubmittedInfo': {
                                        '$last': '$onlineSubmitted'
                                    }
                                }
                            },
                            {
                                '$project': {
                                    'onlineSubmittedInfo': 1
                                }
                            }
                        ]
                    )
                    try:
                        async for i in statusLogFind:
                            mSlno = i.get('onlineSubmittedInfo').get('slNo')
                    except:
                        mSlno = 0

                    mComment = self.request.arguments.get('comment')
                    if mComment:
                        code, message = Validate.i(
                            mComment,
                            'comment',
                            dataType=str,
                            notEmpty=True
                        )
                        if code != 4100:
                            raise Exception
                    else:
                        mComment = None

                    statusObj = {
                        'onlineSubmitted': {
                            'slNo': mSlno+1,
                            'currentStatus': mStatus,
                            'comment': mComment,
                            'modifiedBy': self.accountId,
                            'modifiedAt': timeNow(),
                            'effectiveDate': mEffDate
                        }
                    }

            elif mStatus == 'Under Process (At Bank)':
                if vCurrentStatus in ['Onhold/Discontinued', 'Disbursed', 'Copayment', 'Loan Sanctioned', 'Construction Completed', 'Under Process (At Agency)', 'Under Process (At Bank)']:
                    code = 4456
                    message = f'Application status is already {vCurrentStatus}'
                    raise Exception         
                else:                
                    statusLogFind = self.loanStatusLog.aggregate(
                        [
                            {
                                '$match': {
                                    'loanApplicationId': mLoanAppId,
                                    'applicantId': mApplicantId
                                }
                            },
                            {
                                '$addFields': {
                                    'processedInfo': {
                                        '$last': '$processedAtBank'
                                    }
                                }
                            },
                            {
                                '$project': {
                                    'processedInfo': 1
                                }
                            }
                        ]
                    )
                    try:
                        async for i in statusLogFind:
                            mSlno = i.get('processedInfo').get('slNo')
                    except:
                        mSlno = 0

                    mComment = self.request.arguments.get('comment')
                    if mComment:
                        code, message = Validate.i(
                            mComment,
                            'comment',
                            dataType=str,
                            notEmpty=True
                        )
                        if code != 4100:
                            raise Exception
                    else:
                        mComment = None
                    
                    statusObj = {
                        'processedAtBank': {
                            'slNo': mSlno+1,
                            'currentStatus': mStatus,
                            'comment': mComment,
                            'modifiedBy': self.accountId,
                            'modifiedAt': timeNow(),
                            'effectiveDate': mEffDate
                        }
                    }
            
            elif mStatus == 'Loan Sanctioned':
                if vCurrentStatus in ['Onhold/Discontinued', 'Disbursed', 'Copayment', 'Construction Completed', 'Under Process (At Agency)']:
                    code = 4456
                    message = f'Application status is already {vCurrentStatus}'
                    raise Exception 
                else:
                    statusLogFind = self.loanStatusLog.aggregate(
                        [
                            {
                                '$match': {
                                    'loanApplicationId': mLoanAppId,
                                    'applicantId': mApplicantId
                                }
                            },
                            {
                                '$addFields': {
                                    'sanctionedInfo': {
                                        '$last': '$sanctioned'
                                    }
                                }
                            },
                            {
                                '$project': {
                                    'sanctionedInfo': 1
                                }
                            }
                        ]
                    )
                    try:
                        async for i in statusLogFind:
                            mSlno = i.get('sanctionedInfo').get('slNo')
                    except:
                        mSlno = 0

                    if mApplicationInfo.get('data').get('totalSanctionedAmountByBank') == 0:
                        mSanctionedAmount = self.request.arguments.get('sanctionedAmount')
                        code, message = Validate.i(
                            mSanctionedAmount,
                            'sanctionedAmount',
                            dataTypes=[float, int],
                            notEmpty=True
                        )
                        if code != 4100:
                            raise Exception
                        if mSanctionedAmount <= 0:
                            code = 4828
                            message = 'Please Enter a valid Amount to Sanction'
                            raise Exception
                        
                        mSanctionedAmountupdate = await self.loanApplication.update_one(
                            {
                                '_id': mLoanAppId
                            },
                            {
                                '$set': {
                                    'data.totalSanctionedAmountByBank': mSanctionedAmount,
                                    'data.sanctionedDateByBank': mEffDate
                                }
                            }
                        )
                        if mSanctionedAmountupdate.modified_count:
                            code = 2000
                            status = True
                            message = 'Total Sanctioned Amount Updated'
                        else:
                            code = 4702
                            message = 'Total Sanctioned Amount not Updated'
                            raise Exception
                    if vCurrentStatus == 'Loan Sanctioned' and mApplicationInfo.get('data').get('totalSanctionedAmountByBank') > 0:
                        code = 4750
                        message = 'Application status is already Loan Sanctioned with Sanctioned Amount'
                        raise Exception
                    
                    mComment = self.request.arguments.get('comment')
                    if mComment:
                        code, message = Validate.i(
                            mComment,
                            'comment',
                            dataType=str,
                            notEmpty=True
                        )
                        if code != 4100:
                            raise Exception
                    else:
                        mComment = None
                    
                    statusObj = {
                        'sanctioned': {
                            'slNo': mSlno+1,
                            'currentStatus': mStatus,
                            'comment': mComment,
                            'modifiedBy': self.accountId,
                            'modifiedAt': timeNow(),
                            'effectiveDate': mEffDate
                        }
                    }

                    trainingObj = {
                        'applicantId': mApplicantId,
                        'applicantName': mApplicationInfo.get('data').get('applicantName'),
                        'talukblock': mApplicationInfo.get('data').get('talukblock'),
                        'unitDistrict': mApplicationInfo.get('data').get('unitDistrict'),
                        'uploadMedium': 'Portal',
                        'trainingStatus': 'Pending',
                        'loanApplicationId': mLoanAppId,
                        'createdAt': timeNow(),
                        'createdBy': self.accountId
                    }
                
            elif mStatus == 'Construction Completed':
                if vCurrentStatus in ['Onhold/Discontinued', 'Copayment', 'Construction Completed', 'Under Process (At Agency)']:
                    code = 4456
                    message = f'Application status is already {vCurrentStatus}'
                    raise Exception 
                else:
                    statusLogFind = self.loanStatusLog.aggregate(
                        [
                            {
                                '$match': {
                                    'loanApplicationId': mLoanAppId,
                                    'applicantId': mApplicantId
                                }
                            },
                            {
                                '$addFields': {
                                    'constCompletedInfo': {
                                        '$last': '$constCompleted'
                                    }
                                }
                            },
                            {
                                '$project': {
                                    'constCompletedInfo': 1
                                }
                            }
                        ]
                    )
                    try:
                        async for i in statusLogFind:
                            mSlno = i.get('constCompletedInfo').get('slNo')
                    except:
                        mSlno = 0

                    mComment = self.request.arguments.get('comment')
                    if mComment:
                        code, message = Validate.i(
                            mComment,
                            'comment',
                            dataType=str,
                            notEmpty=True
                        )
                        if code != 4100:
                            raise Exception
                    else:
                        mComment = None

                    statusObj = {
                        'constCompleted': {
                            'slNo': mSlno+1,
                            'currentStatus': mStatus,
                            'comment': mComment,
                            'modifiedBy': self.accountId,
                            'modifiedAt': timeNow(),
                            'effectiveDate': mEffDate
                        }
                    }
                    trainingObj = {
                        'applicantId': mApplicantId,
                        'applicantName': mApplicationInfo.get('data').get('applicantName'),
                        'talukblock': mApplicationInfo.get('data').get('talukblock'),
                        'unitDistrict': mApplicationInfo.get('data').get('unitDistrict'),
                        'uploadMedium': 'Portal',
                        'trainingStatus': 'Pending',
                        'loanApplicationId': mLoanAppId,
                        'createdAt': timeNow(),
                        'createdBy': self.accountId
                    }
                 
          
            else:
                code = 4514
                message = 'Invalid status input'
                raise Exception
                              
            statusUpdate = await self.loanStatusLog.update_one(
                        {
                            'loanApplicationId': mLoanAppId,
                            'applicantId': mApplicantId
                        },
                        {
                            '$push': statusObj
                        }
                    )
            print("Status : ",statusObj)
            update = {
                        'data.currentStatus': mStatus
                            
                        }
            if mStatus in ['Rejected By Bank', 'Rejected By DIC']:
                update['data.currentStatus'] = 'Rejected/Returned'  
                update['data.bankRemarks'] = mReasonId
            loanAppUpdate = await self.loanApplication.update_one(
                        {
                            '_id': mLoanAppId,
                            'applicantId': mApplicantId
                        },
                        {
                            '$set': update
                        }
                    )
            if trainingObj:
                mFindTraining = await self.trainingStatus.find_one(
                    {
                        'loanApplicationId': mLoanAppId
                    }
                )
                if not mFindTraining:
                    mInsertTraining = await self.trainingStatus.insert_one(trainingObj)

                    if mInsertTraining.inserted_id:
                        code = 2000
                        status = True
                        message = 'Training details inserted'
                    else:
                        code = 4497
                        message = 'Training details not inserted'
                        raise Exception
                    
            if statusUpdate.modified_count or loanAppUpdate.modified_count:
                code = 2000
                status = True
                message = 'Status updated successfully'
            else:
                code = 4520
                message = 'Status not updated'


        except Exception as e:
            status = False
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(response)
            await self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            # self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return
        
    async def get(self):
        code = 4000
        message = ''
        status = False
        result = []
        try:
            try:
                mLoanApplicationId = self.get_argument('loanApplicationId')
                if not mLoanApplicationId:
                    raise Exception
                code, message = Validate.i(
                    mLoanApplicationId,
                    'loanApplicationId',
                    dataType=str,
                    notEmpty=True
                )
                if code != 4100:
                    raise Exception
                mLoanApplicationId = ObjectId(mLoanApplicationId)
            except:
                code = 4734
                message = 'Invalid argument - [ loanApplicationId ]'
                raise Exception
            
            try:
                mApplicantId = self.get_argument('applicantId')
                code, message = Validate.i(
                    mApplicantId,
                    'applicantId',
                    dataType=str,
                    notEmpty=True
                )
                if code != 4100:
                    raise Exception
            except:
                code = 4750
                message = 'Invalid argument - [ applicantId ]'
                raise Exception

            mStatusFind = self.loanStatusLog.aggregate(
                [
                    {
                        '$match': {
                            'loanApplicationId': mLoanApplicationId,
                            'applicantId': mApplicantId
                        }
                    },
                    {
                        '$lookup': {
                            'from': self.account.name,
                            'localField': 'others.modifiedBy',
                            'foreignField': '_id',
                            'as': 'othersAccountDetails',
                            'pipeline': [
                                {
                                    '$project': {
                                        '_id': {
                                            '$toString': '$_id'
                                        },
                                        'firstName': 1,
                                        'lastName': 1
                                    }
                                }
                            ]
                        }
                    },
                    {
                        '$lookup': {
                            'from': self.account.name,
                            'localField': 'rejected.modifiedBy',
                            'foreignField': '_id',
                            'as': 'rejectedAccountDetails',
                            'pipeline': [
                                {
                                    '$project': {
                                        '_id': {
                                            '$toString': '$_id'
                                        },
                                        'firstName': 1,
                                        'lastName': 1
                                    }
                                }
                            ]
                        }
                    },
                    {
                        '$lookup': {
                            'from': self.account.name,
                            'localField': 'onHold.modifiedBy',
                            'foreignField': '_id',
                            'as': 'onHoldAccountDetails',
                            'pipeline': [
                                {
                                    '$project': {
                                        '_id': {
                                            '$toString': '$_id'
                                        },
                                        'firstName': 1,
                                        'lastName': 1
                                    }
                                }
                            ]
                        }
                    },
                    {
                        '$lookup': {
                            'from': self.account.name,
                            'localField': 'disbursed.modifiedBy',
                            'foreignField': '_id',
                            'as': 'disbursedAccountDetails',
                            'pipeline': [
                                {
                                    '$project': {
                                        '_id': {
                                            '$toString': '$_id'
                                        },
                                        'firstName': 1,
                                        'lastName': 1
                                    }
                                }
                            ]
                        }
                    },
                    {
                        '$lookup': {
                            'from': self.account.name,
                            'localField': 'copayment.modifiedBy',
                            'foreignField': '_id',
                            'as': 'copaymentAccountDetails',
                            'pipeline': [
                                {
                                    '$project': {
                                        '_id': {
                                            '$toString': '$_id'
                                        },
                                        'firstName': 1,
                                        'lastName': 1
                                    }
                                }
                            ]
                        }
                    },
                    {
                        '$lookup': {
                            'from': self.account.name,
                            'localField': 'onlineSubmitted.modifiedBy',
                            'foreignField': '_id',
                            'as': 'onlineSubmittedAccountDetails',
                            'pipeline': [
                                {
                                    '$project': {
                                        '_id': {
                                            '$toString': '$_id'
                                        },
                                        'firstName': 1,
                                        'lastName': 1
                                    }
                                }
                            ]
                        }
                    },
                    {
                        '$lookup': {
                            'from': self.account.name,
                            'localField': 'processedAtAgency.modifiedBy',
                            'foreignField': '_id',
                            'as': 'processedAtAgencyAccountDetails',
                            'pipeline': [
                                {
                                    '$project': {
                                        '_id': {
                                            '$toString': '$_id'
                                        },
                                        'firstName': 1,
                                        'lastName': 1
                                    }
                                }
                            ]
                        }
                    },
                    {
                        '$lookup': {
                            'from': self.account.name,
                            'localField': 'processedAtBank.modifiedBy',
                            'foreignField': '_id',
                            'as': 'processedAtBankAccountDetails',
                            'pipeline': [
                                {
                                    '$project': {
                                        '_id': {
                                            '$toString': '$_id'
                                        },
                                        'firstName': 1,
                                        'lastName': 1
                                    }
                                }
                            ]
                        }
                    },
                    {
                        '$lookup': {
                            'from': self.account.name,
                            'localField': 'sanctioned.modifiedBy',
                            'foreignField': '_id',
                            'as': 'sanctionedAccountDetails',
                            'pipeline': [
                                {
                                    '$project': {
                                        '_id': {
                                            '$toString': '$_id'
                                        },
                                        'firstName': 1,
                                        'lastName': 1
                                    }
                                }
                            ]
                        }
                    },
                    {
                        '$lookup': {
                            'from': self.account.name,
                            'localField': 'constCompleted.modifiedBy',
                            'foreignField': '_id',
                            'as': 'constCompletedAccountDetails',
                            'pipeline': [
                                {
                                    '$project': {
                                        '_id': {
                                            '$toString': '$_id'
                                        },
                                        'firstName': 1,
                                        'lastName': 1
                                    }
                                }
                            ]
                        }
                    },
                    {
                        '$lookup': {
                            'from': self.account.name,
                            'localField': 'recommendation.modifiedBy',
                            'foreignField': '_id',
                            'as': 'recommendationAccountDetails',
                            'pipeline': [
                                {
                                    '$project': {
                                        '_id': {
                                            '$toString': '$_id'
                                        },
                                        'firstName': 1,
                                        'lastName': 1
                                    }
                                }
                            ]
                        }
                    },
                    {
                        '$project': {
                            '_id': {
                                '$toString': '$_id'
                            },
                            ''
                            'others': 1,
                            'rejected': 1,
                            'onHold': 1,
                            'disbursed': 1,
                            'copayment': 1,
                            'onlineSubmitted': 1,
                            'processedAtAgency': 1,
                            'processedAtBank': 1,
                            'sanctioned': 1,
                            'constCompleted': 1,
                            'recommendation': 1,
                            'applicantId': 1,
                            'othersAccountDetails': 1,
                            'rejectedAccountDetails': 1,
                            'onHoldAccountDetails': 1,
                            'disbursedAccountDetails': 1,
                            'copaymentAccountDetails': 1,
                            'onlineSubmittedAccountDetails': 1,
                            'processedAtAgencyAccountDetails': 1,
                            'processedAtBankAccountDetails': 1,
                            'sanctionedAccountDetails': 1,
                            'constCompletedAccountDetails': 1,
                            'recommendationAccountDetails': 1,

                            'loanApplicationId': {
                                '$toString': '$loanApplicationId'
                            }
                        }
                    },
                    
                ]
            )
            async for i in mStatusFind:
                if i.get('others'):
                    for j, other in enumerate(i.get('others')):
                        i['others'][j]['modifiedBy'] = str(other.get('modifiedBy'))
                        for k, account in enumerate(i.get('othersAccountDetails')):
                            if i['others'][j]['modifiedBy'] == account.get('_id'):
                                i['others'][j]['accountInfo'] = account
                del i['othersAccountDetails']
                
                if i.get('rejected'):
                    for j, reject in enumerate(i.get('rejected')):
                        i['rejected'][j]['modifiedBy'] = str(reject.get('modifiedBy'))
                        for k, account in enumerate(i.get('rejectedAccountDetails')):
                            if i['rejected'][j]['modifiedBy'] == account.get('_id'):
                                i['rejected'][j]['accountInfo'] = account
                del i['rejectedAccountDetails']

                if i.get('onHold'):
                    for j, onhold in enumerate(i.get('onHold')):
                        i['onHold'][j]['modifiedBy'] = str(onhold.get('modifiedBy'))
                        for k, account in enumerate(i.get('onHoldAccountDetails')):
                            if i['onHold'][j]['modifiedBy'] == account.get('_id'):
                                i['onHold'][j]['accountInfo'] = account
                del i['onHoldAccountDetails']

                if i.get('disbursed'):
                    for j, disburse in enumerate(i.get('disbursed')):
                        i['disbursed'][j]['modifiedBy'] = str(disburse.get('modifiedBy'))
                        for k, account in enumerate(i.get('disbursedAccountDetails')):
                            if i['disbursed'][j]['modifiedBy'] == account.get('_id'):
                                i['disbursed'][j]['accountInfo'] = account
                del i['disbursedAccountDetails']
                
                if i.get('copayment'):
                    for j, copayment in enumerate(i.get('copayment')):
                        i['copayment'][j]['modifiedBy'] = str(copayment.get('modifiedBy'))
                        for k, account in enumerate(i.get('copaymentAccountDetails')):
                            if i['copayment'][j]['modifiedBy'] == account.get('_id'):
                                i['copayment'][j]['accountInfo'] = account
                del i['copaymentAccountDetails']

                if i.get('onlineSubmitted'):
                    for j, onlineSubmitted in enumerate(i.get('onlineSubmitted')):
                        i['onlineSubmitted'][j]['modifiedBy'] = str(onlineSubmitted.get('modifiedBy'))
                        for k, account in enumerate(i.get('onlineSubmittedAccountDetails')):
                            if i['onlineSubmitted'][j]['modifiedBy'] == account.get('_id'):
                                i['onlineSubmitted'][j]['accountInfo'] = account
                del i['onlineSubmittedAccountDetails']
                
                if i.get('processedAtAgency'):
                    for j, processAtAgency in enumerate(i.get('processedAtAgency')):
                        i['processedAtAgency'][j]['modifiedBy'] = str(processAtAgency.get('modifiedBy'))
                        for k, account in enumerate(i.get('processedAtAgencyAccountDetails')):
                            if i['processedAtAgency'][j]['modifiedBy'] == account.get('_id'):
                                i['processedAtAgency'][j]['accountInfo'] = account
                del i['processedAtAgencyAccountDetails']

                if i.get('processedAtBank'):
                    for j, processAtBank in enumerate(i.get('processedAtBank')):
                        i['processedAtBank'][j]['modifiedBy'] = str(processAtBank.get('modifiedBy'))
                        for k, account in enumerate(i.get('processedAtBankAccountDetails')):
                            if i['processedAtBank'][j]['modifiedBy'] == account.get('_id'):
                                i['processedAtBank'][j]['accountInfo'] = account
                del i['processedAtBankAccountDetails']

                if i.get('sanctioned'):
                    for j, sanction in enumerate(i.get('sanctioned')):
                        i['sanctioned'][j]['modifiedBy'] = str(sanction.get('modifiedBy'))
                        for k, account in enumerate(i.get('sanctionedAccountDetails')):
                            if i['sanctioned'][j]['modifiedBy'] == account.get('_id'):
                                i['sanctioned'][j]['accountInfo'] = account
                del i['sanctionedAccountDetails']

                if i.get('constCompleted'):
                    for j, construction in enumerate(i.get('constCompleted')):
                        i['constCompleted'][j]['modifiedBy'] = str(construction.get('modifiedBy'))
                        for k, account in enumerate(i.get('constCompletedAccountDetails')):
                            if i['constCompleted'][j]['modifiedBy'] == account.get('_id'):
                                i['constCompleted'][j]['accountInfo'] = account
                del i['constCompletedAccountDetails']

                if i.get('recommendation'):
                    for j, recommendations in enumerate(i.get('recommendation')):
                        i['recommendation'][j]['modifiedBy'] = str(recommendations.get('modifiedBy'))
                        i['recommendation'][j]['modifiedTo'] = str(recommendations.get('modifiedTo'))
                        for k, account in enumerate(i.get('recommendationAccountDetails')):
                            if i['recommendation'][j]['modifiedBy'] == account.get('_id'):
                                i['recommendation'][j]['accountInfo'] = account
                del i['recommendationAccountDetails']
                    

                result.append(i)

            if result:
                code = 2000
                status = True
            else:
                code = 4760
                message = 'Data not found'
                raise Exception
            

        except Exception as e:
            status = False
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(response)
            await self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            # self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return