#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
    Description: AccommodationProviderGrievanceHandler
    Purpose: GET, POST Grievance
"""

import sys
import tornado.web
from bson import ObjectId

from build_config import CONFIG
from handler.methods.max_architect_count import maxArchitectCount
from lib.element_mixer import ElementMixer
from lib.xen_protocol import xenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log
from bson.json_util import dumps as bdumps


@xenSecureV2
class ArchitectListHandler(ElementMixer, MongoMixin):

    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]
    
    profile = MongoMixin.userDb[
        CONFIG['database'][0]['table'][2]['name']
    ]

    loanApplication = MongoMixin.userDb[
        CONFIG['database'][0]['table'][13]['name']
    ]

    componentId = ObjectId('63d39988458b78fdf4cf6c0d')

    async def get(self):
        code = 4000
        message = ''
        status = False
        result = []
    
        try:
            maxArchitect = await maxArchitectCount()
            loanApplicationFind = self.account.aggregate(
                [
                    {
                        '$match': {
                            'designation': 'Architect'
                        }
                    },
                    {
                        '$lookup': {
                            'from': self.profile.name,
                            'localField': '_id',
                            'foreignField':'accountId',
                            'as': 'profileInfo',
                            'pipeline': [
                                {
                                    '$project': {
                                        'status': 1
                                    }
                                }
                            ]
                        }
                    },
                    {
                        '$match': {
                            'profileInfo.status': 1
                        }
                    },
                    {
                        '$project': {
                            '_id': 1,
                            'firstName': 1,
                            'lastName': 1
                        }
                    },
                    {
                        '$lookup': {
                            'from': self.loanApplication.name,
                            'localField': '_id',
                            'foreignField': 'architectDetails.architectAssigned',
                            'as': 'assignedArchitectInfo',
                            'pipeline': [
                                {
                                    '$group': {
                                        '_id': '$architectDetails.architectAssigned',
                                        'applicationCount': {
                                            '$sum': 1
                                        }
                                    }
                                },
                                {
                                    '$project': {
                                        '_id': {
                                            '$toString': '$_id'
                                        },
                                        'applicationCount': 1
                                    }
                                }
                            ]
                        }
                    },
                    {
                        '$addFields': {
                            'architectInfoSize': {
                                '$size': '$assignedArchitectInfo'
                            }
                        }
                    },
                    {
                        '$match': {
                            '$or': [
                                {
                                    'assignedArchitectInfo.applicationCount': {
                                        '$lt': maxArchitect
                                    }
                                },
                                {
                                    'architectInfoSize': {
                                        '$eq': 0
                                    }
                                }
                            ]
                        }
                    },
                    {
                        '$project': {
                            '_id': {
                                '$toString': '$_id'
                            },
                            'firstName': 1,
                            'lastName': 1
                        }
                    }
                ]
            )
            async for i in loanApplicationFind:
                i['name'] = i.get('firstName') + ' ' + i.get('lastName')
                del i['firstName']
                del i['lastName']
                result.append(i)

            if len(result):
                code = 2000
                status = True
                message = 'Data Found'
            else:
                code = 4125
                message = 'Data not Found'

        except Exception as e:
            status = False
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(bdumps(response))
            await self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return