import datetime
import json
import sys
import io

from abc import ABCMeta
from bson import ObjectId
from build_config import CONFIG
from lib.lib import Validate
from lib.xen_protocol import xenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log
from bson.json_util import dumps as bdumps
from lib.element_mixer import ElementMixer
from util.time_util import timeNow
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment


@xenSecureV2
class DefaultersDataExcelGenerateHandler(ElementMixer, MongoMixin, metaclass=ABCMeta):

    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]

    loanApplication = MongoMixin.userDb[
        CONFIG['database'][0]['table'][13]['name']
    ]

    state = MongoMixin.userDb[
        CONFIG['database'][0]['table'][6]['name']
    ]

    block = MongoMixin.userDb[
        CONFIG['database'][0]['table'][15]['name']
    ]

    district = MongoMixin.userDb[
        CONFIG['database'][0]['table'][14]['name']
    ]

    loanStatusLog = MongoMixin.userDb[
        CONFIG['database'][0]['table'][18]['name']
    ]
    
    auditInfo = MongoMixin.userDb[
        CONFIG['database'][0]['table'][19]['name']
    ]

    trainingStatus = MongoMixin.userDb[
        CONFIG['database'][0]['table'][21]['name']
    ]

    rejectionReasons = MongoMixin.userDb[
        CONFIG['database'][0]['table'][11]['name']
    ]

    componentId = ObjectId('63d39988458b78fdf4cf6c0d')

    async def get(self):
        code = 4000
        message = ''
        status = False
        result = []
        try:
            try:
                year = self.get_argument('year')
                code, message = Validate.i(
                    year,
                    'year',
                    notNull=True,
                    dataType=str
                )
                if code != 4100:
                    raise Exception

            except Exception as e:
                year = None
            if year:
                try:
                    sYear = year.split('-')[0]
                    code, message = Validate.i(
                        sYear,
                        'Start Year',
                        datType=int,
                        notEmpty=True
                    )
                    if code != 4100:
                        raise Exception
                except:
                    code = 7656
                    message = 'Start Year Required'
                    raise Exception

                try:
                    eYear = year.split('-')[1]
                    code, message = Validate.i(
                        eYear,
                        'End Year',
                        datType=int,
                        notEmpty=True
                    )
                    if code != 4100:
                        raise Exception
                except:
                    code = 7657
                    message = 'End Year Required'
                    raise Exception

                sYear = datetime.datetime(int(sYear), 4, 1, 0, 0, 0)
                sYear = sYear.strftime("%Y-%m-%d")

                eYear = datetime.datetime(int(eYear), 3, 31, 23, 59, 59)
                eYear = eYear.strftime("%Y-%m-%d")

                sYear = int(datetime.datetime.strptime(sYear, "%Y-%m-%d").timestamp()) * 1000000
                eYear = int(datetime.datetime.strptime(eYear, "%Y-%m-%d").timestamp()) * 1000000

                if sYear > eYear:
                    code = 5643
                    message = 'End Year Should Be Greater Than Start Year'
                    raise Exception
            
            distQ = await self.account.find_one(
                {
                    '_id': self.accountId
                }
            )

            if not distQ:
                code = 3523
                message = 'Account Not Found'
                raise Exception
                 
            pipelineQ = [
                {                
                    '$match': {
                        'data.onlineSubmissionDate': {'$gte': sYear, '$lte': eYear} if year else {'$exists': True},
                        'isDefaulter': True
                    }
                },
                {
                    '$lookup': {
                        'from': self.state.name,
                        'localField': 'data.state',
                        'foreignField': '_id',
                        'as': 'stateInfo',
                        'pipeline': [
                            {
                                '$project': {
                                    '_id': {
                                        '$toString': '$_id'
                                    },
                                    'name': 1
                                }
                            }
                        ]
                    }
                },
                {
                    '$lookup': {
                        'from': self.district.name,
                        'localField': 'data.unitDistrict',
                        'foreignField': '_id',
                        'as': 'districtInfo',
                        'pipeline': [
                            {
                                '$project': {
                                    '_id': {
                                        '$toString': '$_id'
                                    },
                                    'districtName': 1
                                }
                            }
                        ]
                    }
                },
                {
                    '$lookup': {
                        'from': self.block.name,
                        'localField': 'data.talukblock',
                        'foreignField': '_id',
                        'as': 'blockInfo',
                        'pipeline': [
                            {
                                '$project': {
                                    '_id': {
                                        '$toString': '$_id'
                                    },
                                    'blockName': 1
                                }
                            }
                        ]
                    }
                },
                {
                    '$lookup': {
                        'from': self.loanStatusLog.name,
                        'localField': '_id',
                        'foreignField': 'loanApplicationId',
                        'as': 'statusInfo',
                        'pipeline': [
                            {
                                '$lookup': {
                                    'from': self.account.name,
                                    'localField': 'recommendation.modifiedBy',
                                    'foreignField': '_id',
                                    'as': 'recommendationAccountInfo',
                                    'pipeline': [
                                        {
                                            '$project': {
                                                '_id': {
                                                    '$toString': '$_id'
                                                },
                                                'firstName': 1,
                                                'lastName': 1
                                            }
                                        }
                                    ]
                                }
                            }
                        ]
                    }
                },
                {
                    '$lookup': {
                        'from': self.loanStatusLog.name,
                        'localField': '_id',
                        'foreignField': 'loanApplicationId',
                        'as': 'disbursementInfo',
                        'pipeline': [
                            {
                                '$addFields': {
                                    'disbursementDetails': {
                                        '$first': '$disbursed'
                                    }
                                }
                            },
                            {
                                '$addFields': {
                                    'disbursedDate': {
                                        '$first': '$disbursementDetails.disbursedInfo.date'
                                    }
                                }
                            },
                            {
                                '$addFields': {
                                    'disbursedAmounts': '$disbursed.disbursedInfo.amount'
                                }
                            },
                            {
                                '$project': {
                                    '_id': {
                                        '$toString': '$_id'
                                    },
                                    'disbursedDate': 1,
                                    'disbursedAmounts': 1,
                                    "rejected.reason": 1
                                }
                            }
                        ]
                    }
                },
                {
                    '$unwind': {
                        'path': '$disbursementInfo',
                        'preserveNullAndEmptyArrays': True
                    }
                },
                {
                    '$unwind': {
                        'path': '$statusInfo',
                        'preserveNullAndEmptyArrays': True
                    }
                },
                {
                    '$unwind': {
                        'path': '$stateInfo',
                        'preserveNullAndEmptyArrays': True
                    }
                },
                {
                    '$unwind': {
                        'path': '$blockInfo',
                        'preserveNullAndEmptyArrays': True
                    }
                },
                {
                    '$unwind': {
                        'path': '$districtInfo',
                        'preserveNullAndEmptyArrays': True
                    }
                },
                {
                    '$unwind': {
                        'path': '$statusInfo',
                        'preserveNullAndEmptyArrays': True
                    }
                },
                {
                    '$project': {
                        'applicantId': 1, 
                        'applicantName': '$data.applicantName', 
                        'mobileNo': '$data.mobileNo', 
                        'sanctionedDate': '$data.sanctionedDateByBank', 
                        'alternativeMobileNo': '$data.alternativeMobileNo', 
                        'gender': '$data.gender', 
                        'category': '$data.category', 
                        'totalSanctionedAmountByBank': '$data.totalSanctionedAmountByBank', 
                        'isUnknownBlock': '$data.isUnknownBlock', 
                        'isUnknownBranch': '$data.isUnknownBranch', 
                        'isRecommended': '$data.isRecommended', 
                        'accountNumber': '$defaulter.accountNumber', 
                        'overdueAmount': '$defaulter.overdueAmount', 
                        'defaulterRemarks': '$defaulter.remarks', 
                        'defaulterDate': '$defaulter.date', 
                        'createdAt': 1, 
                        'disbursementInfo': 1, 
                        'inspectionReportSubmitted': 1, 
                        'sanctionedDateByBank': '$data.sanctionedDateByBank'
                    }
                },
                # {
                #     '$sort': {
                #         '_id': -1
                #     }
                # }
            ]

            fileQ = self.loanApplication.aggregate(pipelineQ)
            dataArray = []
            async for i in fileQ:
                for key, value in i.items():
                    if not value:
                        i[key] = '-'
                    if key in ['forwardingDateToBank', 'onlineSubmissionDate', 'dateOfDocumentReceivedAtBank', 'sanctionedDateByBank', 'dateOfDepositOwnContribution', 'dateOfLoanRelease', 'mmReleaseDate', 'trainingStartDate', 'trainingEndDate', 'certificateIssueDate', 'physicalVerificationConductedDate']:
                        if type(value) != str:
                            xDateStr = datetime.datetime.fromtimestamp(value / 1000 / 1000)
                            xDateStr = datetime.datetime.strftime(xDateStr, '%d-%m-%Y')
                            i[key] = xDateStr
                if not i.get('rejectionInfo'):
                    i['rejectionInfo'] = 'NA'
                if not i.get('isDefaulter'):
                    i['isDefaulter'] = False
                if not i.get('mobileNo'):
                    i['mobileNo'] = 'NA'

                dataArray.append(i)
            data = [
                {
                    'Application ID': i.get('applicantId'),
                    'Applicant Name': i.get('applicantName'),
                    'Phone Number': i.get('mobileNo'),
                    'Account Number': i.get('accountNumber'),
                    'Loan Sanctioned Amount': i.get('totalSanctionedAmountByBank'),
                    'Sanction Date': i.get('sanctionedDateByBank'),
                    'Overdue Amount': i.get('overdueAmount'),
                    'Defaulter Remarks': i.get('defaulterRemarks')
                }
                for i in dataArray
            ]

            if data:
                headers = [
                    'Application ID', 'Applicant Name', 'Phone Number', 'Account Number', 'Loan Sanctioned Amount', 'Sanction Date', 'Overdue Amount', 'Defaulter Remarks'
                ]

                workbook = Workbook()
                worksheet = workbook.active
                worksheet.append(headers)

                for col_num, header in enumerate(headers, 1):
                    cell = worksheet.cell(row=1, column=col_num, value=header)
                    cell.font = Font(bold=True)
                    cell.alignment = Alignment(horizontal='center', vertical='center')

                for row_num, row_data in enumerate(data, 2):
                    for col_num, key in enumerate(headers, 1):
                        value = row_data.get(key, "")
                        cell = worksheet.cell(row=row_num, column=col_num, value=value)
                        cell.alignment = Alignment(horizontal='center', vertical='center')

                for column in worksheet.columns:
                    max_length = 0
                    column = [cell for cell in column]
                    for cell in column:
                        try:
                            if len(str(cell.value)) > max_length:
                                max_length = len(cell.value)
                        except:
                            pass
                    adjusted_width = (max_length + 5)
                    worksheet.column_dimensions[column[0].column_letter].width = adjusted_width

                xBuffer = io.BytesIO()
                workbook.save(xBuffer)

                self.set_header('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
                self.set_header('Content-Disposition', 'attachment; filename=loan_applicants.xlsx')
                self.write(xBuffer.getvalue())
                xBuffer.close()

                code = 200
                status = True
                message = 'File Generated Successfully'
                print("length", len(dataArray))
        except Exception as e:
            status = False
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                    str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(bdumps(response))
            await self.finish()
            return

        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return
