import asyncio
import datetime
import json
import os
import re
import sys
import io

from datetime import datetime as dtime
from handler.methods.trainging_certificate_pdf import insert_training_details
import tornado.web
from abc import ABCMeta
from bson import ObjectId
from build_config import CONFIG
from lib.lib import Validate
from lib.xen_protocol import xenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log
from bson.json_util import dumps as bdumps
from lib.element_mixer import ElementMixer
from util.time_util import timeNow


@xenSecureV2
class TrainingCertificateHandler(ElementMixer,  MongoMixin, metaclass=ABCMeta):

    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]

    trainingStatus = MongoMixin.userDb[
        CONFIG['database'][0]['table'][21]['name']
    ]

    auditInfo = MongoMixin.userDb[
        CONFIG['database'][0]['table'][19]['name']
    ]

    componentId = ObjectId('63d39988458b78fdf4cf6c0d')

    async def get(self):
        code = 4000
        message = ''
        status = False
        result = []
        try:                       
            mApplicantId = self.get_argument('applicantId')         
            code, message = Validate.i(
                mApplicantId,
                'applicantId',
                dataType=str,
                notEmpty=True
            )
            if code != 4100:
                raise Exception
            try:
                mApplicantId = ObjectId(mApplicantId)
            except:
                code = 4056
                message = 'Invalid Argument - [ applicantId ]'
                raise Exception
            
            mFindApplicant = await self.trainingStatus.find_one(
                {
                    '_id': mApplicantId
                }
            )
            if not mFindApplicant:
                code = 4066
                message = 'Applicant not Found'
                raise Exception
            
            else:
                mFindAuditInfo  = await self.auditInfo.find_one(
                    {
                        'loanId': mFindApplicant.get('loanApplicationId')
                    }
                )
                if not mFindAuditInfo:
                    code = 4077
                    message = 'Audit Info not Found'
                    raise Exception
                else:
                    vName = mFindApplicant.get('applicantName')
                    vTrainingStatus = mFindApplicant.get('trainingStatus')
                    vConstructionStatus = mFindAuditInfo.get('constructionStatus')
                    vIssueDate = mFindApplicant.get('certificateIssueDate')

                    if vTrainingStatus == 'Completed':
                        if vConstructionStatus == 'complete':
                            pdfPath = insert_training_details('../uploads/rc-homestay/certificates/Certificate.pdf', vName, int(vIssueDate))
                            
                            self.set_header('Content-Type', 'application/pdf')
                            self.set_header('Content-Disposition', f'attachment; filename={vName}_Training_Certificate.pdf')
                            self.write(pdfPath.getvalue())

                            if pdfPath:
                                status = True
                                code = 2000
                            else:
                                code = 4098
                                message = 'PDF not Generated'
                                raise Exception
                        else:
                            code = 4102
                            message = 'Construction Status is not Completed'
                            raise Exception
                    else:
                        code = 4106
                        message = 'Training is not Completed'
                        raise Exception

        except Exception as e:
            status = False
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'    
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(bdumps(response))
            await self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            # self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return
