#!/usr/bin/VtsAdminSignInHandler
# -*- coding: utf-8 -*-

import base64
import json
import os
import re
import sys
import mimetypes
import requests
import pandas as pd
import io

import datetime
from handler.methods.age_calculator import age_calculate
from handler.methods.find_one_data import findData

import tornado.web
from abc import ABCMeta
from bson import ObjectId
from build_config import CONFIG
from lib.lib import Validate
from lib.xen_protocol import xenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log
from util.time_util import timeNow
from bson.json_util import dumps as bdumps
from lib.element_mixer import ElementMixer
from util.file_util import FileUtil
import matplotlib.pyplot as plt
from weasyprint import HTML
import numpy as np

from util.get_pdf_values import * 
import reportlab


# @xenSecureV2
class PerformancePdfHandler(ElementMixer, MongoMixin, metaclass=ABCMeta):

    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]

    componentId = ObjectId('63d38614458b78fdf4cf6bfa')

    async def get(self):
        code = 4000
        status = False
        message = ''
        result = []
        try:
            try:
                year = self.get_argument('year')
                if year:
                    code, message = Validate.i(
                        year,
                        'Year',
                        datType=str,
                        notEmpty=True
                    )
                    if code != 4100:
                        raise Exception
                else:
                    raise Exception
            except:
                year = None
            
            sYear = None
            eYear = None
            if year:
                try:
                    sYear = year.split('-')[0]
                    code, message = Validate.i(
                        sYear,
                        'Start Year',
                        datType=int,
                        notEmpty=True
                    )
                    if code != 4100:
                        raise Exception
                except:
                    code = 7656
                    message = 'Start Year Required'
                    raise Exception

                try:
                    eYear = year.split('-')[1]
                    code, message = Validate.i(
                        eYear,
                        'End Year',
                        datType=int,
                        notEmpty=True
                    )
                    if code != 4100:
                        raise Exception
                except:
                    code = 7657
                    message = 'End Year Required'
                    raise Exception

                sYear = datetime(int(sYear), 4, 1, 0, 0, 0)
                sYear = sYear.strftime("%Y-%m-%d")

                eYear = datetime(int(eYear), 3, 31, 23, 59, 59)
                eYear = eYear.strftime("%Y-%m-%d")

                sYear = int(datetime.strptime(sYear, "%Y-%m-%d").timestamp()) * 1000000
                eYear = int(datetime.strptime(eYear, "%Y-%m-%d").timestamp()) * 1000000

                if sYear > eYear:
                    code = 5643
                    message = 'End Year Should Be Greater Than Start Year'
                    raise Exception

            firstName = ''
            lastName = ''

            # mAccountInfo = await self.account.find_one(
            #     {
            #         '_id': self.accountId
            #     }
            # )
            # if not mAccountInfo:
            #     code = 4057
            #     message = 'Account Not Found'
            #     raise Exception
            
            # if mAccountInfo:
            #     firstName = mAccountInfo.get('firstName')
            #     lastName = mAccountInfo.get('lastName')
            
            try:
                district = self.get_argument('district')
                if district:
                    code, message = Validate.i(
                        district,
                        'District',
                        datType=str,
                    )
                    if code != 4100:
                        raise Exception
                else:
                    raise Exception
                if district:
                    try:
                        district = ObjectId(district)
                    except:
                        message = 'Invalid district value.'
                        raise Exception
            except:
                district = None

            try:
                totalApplication = await getTotalApplications(year = year, sYear = sYear,eYear = eYear,district = district)

                loanSanctionedQ = await loanSanctionedF(year = year, sYear = sYear,eYear = eYear,district = district)
                loanSanctionedAmount = loanSanctionedQ.get('totalSanctionedAmount')
                if loanSanctionedAmount is None:
                    loanSanctionedAmount = 0

                loanSanctioned = loanSanctionedQ.get('totalApplications')
                if loanSanctioned is None:
                    loanSanctioned = 0

                disbursedQ = await disbursedF(year = year, sYear = sYear,eYear = eYear,district = district)
                disbursed = disbursedQ.get('totalDisbursedApplications')
                if disbursed is None:
                    disbursed = 0

                disbarmentAmount = disbursedQ.get('totalDisbursedAmount')
                if disbarmentAmount is None:
                    disbarmentAmount = 0

                defaultersQ = await defaultersF(year = year, sYear = sYear,eYear = eYear,district = district)
                defaulters = defaultersQ.get('defaulters')
                if defaulters is None:
                    defaulters = 0


                edpPending = await edpPendingF(year = year, sYear = sYear,eYear = eYear,district = district)
                edpPending = edpPending.get('edpPending')
                if edpPending is None:
                    edpPending = 0

                completedHomestayQ = await completedHomestayF(year = year, sYear = sYear,eYear = eYear,district = district)
                completedHomestay = completedHomestayQ.get('completedHomestay')
                if completedHomestay is None:
                    completedHomestay = 0
            

            # Homestay Performance
                data = await performanceWizeHomestays(year=year, sYear=sYear, eYear=eYear, district=district)
                totalHomestay = data[0].get('totalHomestay')
                colors = ['Green', 'Yellow', 'Red']
                x = [data[0].get(color) for color in colors]
                y = [data[0][color] for color in colors]

                fig, ax = plt.subplots(figsize=(10, 7))
                wedges, texts, autotexts = ax.pie(
                    y, labels=colors, autopct='%1.1f%%', textprops={'color': 'w'},
                    colors=['green', 'yellow', 'red']
                )
                plt.title("Homestay Performance")
                buf_pie = io.BytesIO()
                fig.savefig(buf_pie, format='png', bbox_inches='tight')
                buf_pie.seek(0)
                plt.close(fig)


                # Rejection Reasons 
                data = await rejectionWiseApplication(year = year, sYear = sYear,eYear = eYear,district = district)
                data = data[0].get('rejectedByBank')
                reasons = [d['_id'] for d in data]
                applications = [d['totalApplications'] for d in data]

                fig, ax = plt.subplots(figsize=(10,7))
                bars = ax.bar(reasons, applications)
                for i, (rect, val) in enumerate(zip(bars, applications)):
                    ax.text(rect.get_x() + rect.get_width()/2, val, f"{val}", ha="center", va="bottom")
                ax.set_title("Rejection Reasons")
                plt.xticks(rotation=90)

                buf_bar = io.BytesIO()
                fig.savefig(buf_bar, format='png', bbox_inches='tight')
                buf_bar.seek(0)
                plt.close(fig)

                # Districtwise Applications
                data = await districtWiseApplicationF(year = year, sYear = sYear,eYear = eYear,district = district)
                districtNames =[d['districtName'] for d in data]
                totalApplications = [d['totalApplications'] for d in data]

                fig, ax = plt.subplots(figsize=(10, 7))
                bars = ax.barh(districtNames, totalApplications)
                for i, (rect, val) in enumerate(zip(bars, totalApplications)):
                    rect.set_color('#eb984e')
                    ax.text(rect.get_x() + rect.get_width() + 0.1, rect.get_y() + rect.get_height() / 2, f"{val}", va='center')                    
                # ax.set_xlabel("Count")
                ax.set_title("Districtwise Applicants")
                plt.xticks([])

                buf_hBar = io.BytesIO()
                fig.savefig(buf_hBar, format='png', bbox_inches='tight')
                buf_hBar.seek(0)
                plt.close(fig)

                # Districtwise Applications (Loan Sanctioned)
                data  = await districtWiseSanctionedApplicationF(year = year, sYear = sYear,eYear = eYear,district = district)
                districtNames = [d['districtName'] for d in data]
                totalApplications = [d['totalApplications'] for d in data]

                fig, ax = plt.subplots(figsize=(10, 7))
                bars = ax.barh(districtNames, totalApplications)
                for i, (rect, val) in enumerate(zip(bars, totalApplications)):
                    rect.set_color('#eb984e')
                    ax.text(rect.get_x() + rect.get_width() + 0.1, rect.get_y() + rect.get_height() / 2, f"{val}", va='center')                    
                # ax.set_xlabel("Count")
                ax.set_title("Districtwise Applications (Loan Sanctioned)")
                plt.xticks([])

                buf_hBar_loanSanctioned = io.BytesIO()
                fig.savefig(buf_hBar_loanSanctioned, format='png', bbox_inches='tight')
                buf_hBar_loanSanctioned.seek(0)
                plt.close(fig)


                # Districtwise Rejected Applications
                data = await districtWiseRejectedApplicationF(year = year, sYear = sYear,eYear = eYear,district = district)
                districtNames = [d['districtName'] for d in data]
                totalApplications1 = [d['totalApplications'][0] if len(d['totalApplications']) > 0 else 0 for d in data]
                totalApplications2 = [d['totalApplications'][1] if len(d['totalApplications']) > 1 else 0 for d in data]

                fig, ax = plt.subplots(figsize=(10, 7))
                bar_width = 0.4
                opacity = 0.8

                rects1 = ax.barh(np.arange(len(districtNames)), totalApplications1, bar_width, alpha=opacity, color='#1a53ff', label='Total Applications 1')
                rects2 = ax.barh(np.arange(len(districtNames)) + bar_width, totalApplications2, bar_width, alpha=opacity, color='green', label='Total Applications 2')
                ax.set_yticks(np.arange(len(districtNames)) + bar_width)
                ax.set_yticklabels(districtNames)
                ax.set_xlabel("Count")
                ax.set_title("Districtwise Rejected Applicants")

                for rect in rects1:
                    ax.text(rect.get_width(), rect.get_y() + rect.get_height()/2, str(rect.get_width()), ha='left', va='center')
                for rect in rects2:
                    ax.text(rect.get_width(), rect.get_y() + rect.get_height()/2, str(rect.get_width()), ha='left', va='center')

                buf_stack = io.BytesIO()
                fig.savefig(buf_stack, format='png', bbox_inches='tight')
                buf_stack.seek(0)
                plt.close(fig)

                LOGO_PATH = './reportLogs/logo_v1.png'

                html_content =f'''
                    <!DOCTYPE html>
                <html lang="en" height="100%" width="100%">
                <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <title>Document</title>
                    <style>
                        body {{
                            font-family: Arial, Helvetica, sans-serif;
                            margin: 0;
                            padding: 0;
                            width: 100%;
                            height: 100%;
                        }}
                        .container {{
                            display: flex;
                            flex-wrap: wrap;
                            gap: 20px;
                            justify-content: center;
                        }}
                        .box {{
                            border: 1px solid black;
                            width: 115px;
                            height: 95px;
                            border-radius: 7%;
                            text-align: center;
                            margin: 10px;
                            padding: 10px;
                            display: flex;
                            flex-direction: column;
                            justify-content: center;
                            align-items: center;
                        }}
                        .box h4 {{
                            margin: 10px 0;
                        }}
                        .box span {{
                            margin-bottom: 5px;
                        }}
                        .chart {{
                            width: 300px;
                            margin: 10px;
                        }}
                        footer {{
                            text-align: center;
                            # padding: 1px;
                            position: fixed;
                            bottom: 0;
                            width: 100%;
                            background-color: #f1f1f1;
                        }}
                    </style>
                </head>
                <body>
                    <div>
                        <img style="display: block;margin-left: auto;margin-right: auto;width: 30%; margin: 0 auto;" src="https://rc-homestay.meghalayatourism.in/assets/img/Logo.png" alt="Logo">

                    </div>

                    <div class="container">
                        <div class="box">
                            <h4>Total Application</h4>
                            <span>{totalApplication}</span>
                        </div>
                        <div class="box">
                            <h4>Loan Sanctioned</h4>
                            <span>{loanSanctioned}</span>
                            <span>{loanSanctionedAmount}</span>
                        </div>
                        <div class="box">
                            <h4>Disbursed</h4>
                            <span>{disbursed}</span>
                            <span style="margin-top: 5px">{disbarmentAmount}</span>
                        </div>
                        <div class="box">
                            <h4>EDP Pending</h4>
                            <span>{edpPending}</span>
                        </div>
                        <div class="box">
                            <h4>Completed Homestays</h4>
                            <span>{completedHomestay}</span>
                        </div>
                        <div class="box">
                            <h4>Defaulters</h4>
                            <span>{defaulters}</span>
                        </div>
                    </div>

                    <div class="container">
                        <img class="chart" src="data:image/png;base64,{base64.b64encode(buf_pie.getvalue()).decode('utf-8')}" alt="Pie Chart">
                        <img class="chart" src="data:image/png;base64,{base64.b64encode(buf_stack.getvalue()).decode('utf-8')}" alt="Horizontal Bar Chart">
                    </div>
                    <div class="container">
                        <img class="chart" src="data:image/png;base64,{base64.b64encode(buf_hBar.getvalue()).decode('utf-8')}" alt="Horizontal Bar Chart">
                        <img class="chart" src="data:image/png;base64,{base64.b64encode(buf_hBar_loanSanctioned.getvalue()).decode('utf-8')}" alt="Horizontal Bar Chart">
                    </div>
                        <img style="  display: block;margin-left: auto;margin-right: auto; width: 80%;" src="data:image/png;base64,{base64.b64encode(buf_bar.getvalue()).decode('utf-8')}" alt="Bar Chart">

                    <footer>
                        <p>This is an auto-generated PDF. Downloaded by {firstName + ' ' + lastName}.</p>
                    </footer>
                    </html>
                    '''

                def html_to_pdf(html_content):
                    pdf_io = io.BytesIO()
                    HTML(string=html_content).write_pdf(pdf_io)
                    pdf_io.seek(0)
                    return pdf_io

                pdf_io = html_to_pdf(html_content)

                self.set_header('Content-Type', 'application/pdf')
                self.set_header('Content-Disposition', 'inline; filename="performance.pdf"')

                while True:
                    data = pdf_io.read(1024)
                    if not data:
                        break
                    self.write(data)
                await self.finish()
                return

            except Exception as e:
                self.set_status(500)
                message = f"Error generating PDF: {str(e)}"
                status = False
                code = 5000
                raise Exception

        except Exception as e:
            status = False
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(bdumps(response))
            await self.finish()
            return

        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return