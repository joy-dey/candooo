#!/usr/bin/VtsAdminSignInHandler
# -*- coding: utf-8 -*-

import json
import os
import re
import sys
import mimetypes
import requests
import pandas as pd
import io

import datetime
from handler.methods.age_calculator import age_calculate
from handler.methods.find_one_data import findData

import tornado.web
from abc import ABCMeta
from bson import ObjectId
from build_config import CONFIG
from lib.lib import Validate
from lib.xen_protocol import xenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log
from util.time_util import timeNow
from bson.json_util import dumps as bdumps
from lib.element_mixer import ElementMixer
from util.file_util import FileUtil


@xenSecureV2
class LoanApplicationDataHandler(ElementMixer, MongoMixin, metaclass=ABCMeta):

    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]

    profile = MongoMixin.userDb[
        CONFIG['database'][0]['table'][2]['name']
    ]

    uploadFileDetails = MongoMixin.userDb[
        CONFIG['database'][0]['table'][16]['name']
    ]

    loanApplication = MongoMixin.userDb[
        CONFIG['database'][0]['table'][13]['name']
    ]
    
    state = MongoMixin.userDb[
        CONFIG['database'][0]['table'][6]['name']
    ]

    block = MongoMixin.userDb[
        CONFIG['database'][0]['table'][15]['name']
    ]

    district = MongoMixin.userDb[
        CONFIG['database'][0]['table'][14]['name']
    ]

    loanStatusLog = MongoMixin.userDb[
        CONFIG['database'][0]['table'][18]['name']
    ]
    
    auditInfo = MongoMixin.userDb[
        CONFIG['database'][0]['table'][19]['name']
    ]

    trainingStatus = MongoMixin.userDb[
        CONFIG['database'][0]['table'][21]['name']
    ]

    rejectionReasons = MongoMixin.userDb[
        CONFIG['database'][0]['table'][11]['name']
    ]

    bankBranch = MongoMixin.userDb[
        CONFIG['database'][0]['table'][22]['name']
    ]

    jointApplication = MongoMixin.userDb[
        CONFIG['database'][0]['table'][23]['name']
    ]
    componentId = ObjectId('63d39988458b78fdf4cf6c0d')

    fu = FileUtil()

    async def get(self):
        code = 4000
        status = False
        message = ''
        result = []

        try:
            try:
                f_limit = int(self.get_argument('limit'))
                f_skip = int(self.get_argument('skip'))
            except:
                f_limit = 0
                f_skip = 0

            try:
                vFileDtlsId = str(self.get_argument('id'))
                vFileDtlsId = ObjectId(vFileDtlsId)
            except:
                vFileDtlsId = None
            
            try:
                vSearchWith = self.get_query_argument('searchWith')
                if not vSearchWith:
                    raise Exception
                vSearchWith = vSearchWith.lower()
            except:
                vSearchWith = None

            try:
                inspectionStatus = str(self.get_argument('InspectionStatus'))
            except:
                inspectionStatus = None
            
            matchFilter = {}
            if inspectionStatus:
                if inspectionStatus == "Not Submitted":
                    matchFilter = {
                        '$match':{
                             'inspectionReportSubmitted': { '$exists': False } 
                        }
                    }
                if inspectionStatus == "Completed":
                    matchFilter = {
                        "$match": {
                            "jointInspection": {
                            "$exists": True
                            },
                            "jointInspection.inspectedBy": {
                            "$not": {
                                "$elemMatch": {
                                "approved": False
                                }
                            }
                            }
                        }
                        }

                if inspectionStatus == "Pending Approval":
                    matchFilter = {
                        '$match': {
                                'jointInspection': {
                                    '$exists': True
                                },
                                'jointInspection.inspectedBy': {
                                    '$elemMatch': {
                                        'approved': False
                                    }
                                }
                        }
                    }
            filterObj = {}
            if vSearchWith:
                nApplicationId = {
                    'applicantId': {
                        '$regex': vSearchWith,
                        '$options': 'ism'
                    }
                }

                mApplicantName = {
                    'data.applicantName': {
                        '$regex': vSearchWith,
                        '$options': 'ism'
                    }
                }

                filterObj['$or'] = [nApplicationId, mApplicantName]
            
            try:
                mDistrict = str(self.get_argument('district'))
                if not mDistrict:
                    raise Exception
                mDistrict = ObjectId(mDistrict)
            except:
                mDistrict = None
            
            try:
                mBlock = str(self.get_argument('block'))
                if not mBlock:
                    raise Exception
                mBlock = ObjectId(mBlock)
            except:
                mBlock = None

            try:
                mState = str(self.get_argument('state'))
                if not mState:
                    raise Exception
                mState = ObjectId(mState)
            except:
                mState = ObjectId('5fda17c1adfeecf7e9dd96ce')

            mLocfilter = {}
            if mDistrict:                
                mLocfilter['data.unitDistrict'] = mDistrict

            if mBlock:                
                mLocfilter['data.talukblock'] = mBlock

            if mState:                
                mLocfilter['data.state'] = mState                  

            vLocfilter = {
                '$match': mLocfilter
            }

            try:
                vStatus = self.get_argument('status')
                code, message = Validate.i(
                    vStatus,
                    'status',
                    notEmpty=True,
                    dataType=str
                )
                if code != 4100:
                    raise Exception
            except:
                vStatus = None
            
            if vStatus in ['Rejected By Bank', 'Rejected By DIC']:
                try:
                    reason = self.get_argument('reason')
                    code, message = Validate.i(
                        reason,
                        'reason',
                        notEmpty=True,
                        dataType=str
                    )
                    if code != 4100:
                        raise Exception
                except:
                    reason = None
            
            if vStatus:
                if vStatus == 'Under Process (At Agency)':
                    vStatusFilter={
                        '$match': {
                            'data.currentStatus': 'Under Process (At Agency)', 
                        }
                    }
                    
                elif vStatus == 'LoanSanctionedDisbursed':
                    vStatusFilter = {
                        '$match': {
                            'data.currentStatus': {
                                '$in': ['Loan Sanctioned', 'Disbursed']
                            }
                        }
                    }
                elif vStatus == 'Rejected By Bank':
                    if reason != None:
                        if 'Interest' in str(reason):
                            reason = reason.replace('Interest', 'Intrest')

                        xReasonFind = await self.rejectionReasons.find_one(
                            {
                                'reason': reason
                            },
                            {
                                '_id': 1
                            }
                        )
                        if not xReasonFind:
                            code = 4208
                            message = 'No Such Reason Found'
                            raise Exception
                        else:
                            mReason = xReasonFind.get('_id')
                            
                        vStatusFilter = {
                            '$match': {
                                'data.rejectedByBank': True,
                                'data.currentStatus': 'Rejected/Returned',
                                'data.bankRemarks' : mReason
                            }
                        }
                    else:
                        vStatusFilter = {
                            '$match': {
                                'data.rejectedByBank': True,
                                'data.currentStatus': 'Rejected/Returned'
                            }
                        }
                elif vStatus == 'Rejected By DIC':
                    if reason != None:
                        xReasonFind = await self.rejectionReasons.find_one(
                            {
                                'reason': reason
                            },
                            {
                                '_id': 1
                            }
                        )
                        if not xReasonFind:
                            code = 4208
                            message = 'No Such Reason Found'
                            raise Exception
                        else:
                            mReason = xReasonFind.get('_id')
                            
                        vStatusFilter = {
                            '$match': {
                                'data.rejectedByBank': False,
                                'data.currentStatus': 'Rejected/Returned',
                                'data.bankRemarks' : mReason
                            }
                        }
                    else:
                        vStatusFilter = {
                        '$match': {
                            'data.rejectedByBank': False,
                            'data.currentStatus': 'Rejected/Returned'
                        }
                    }
                else:
                    vStatusFilter = {
                        '$match': {
                            'data.currentStatus': vStatus
                        }
                    }

            try:
                method = self.get_argument('method')
                if not method :
                    message = 'Invalid argument method.'
                    code = 5182
                    status = False
                    raise Exception
                
                else:
                   meth = int(method)
            except:
                method = None

            if method == None:
                meth = None
            
            try:
                mHomestayPerformance = self.get_argument('homestayPerformance')
                code, message = Validate.i(
                    mHomestayPerformance,
                    'homestayPerformance',
                    dataType = str,
                    notEmpty = True,
                    enums = ['Red', 'Yellow', 'Green']
                )
                if code != 4100:
                    raise Exception
            except:
                mHomestayPerformance = None

            try:
                mIsRecommended = self.get_argument('isRecommended')
                mIsRecommended = json.loads(mIsRecommended)
                code, message = Validate.i(
                    mIsRecommended,
                    'isRecommended',
                    dataType=bool
                )
                if code != 4100:
                    raise Exception
            except:
                mIsRecommended = False

            try:
                mIsCompleted = self.get_argument('isCompleted')
                mIsCompleted = json.loads(mIsCompleted)
                code, message = Validate.i(
                    mIsCompleted,
                    'isCompleted',
                    dataType=bool,
                    notEmpty=True,

                )
                if code != 4100:
                    raise Exception
            except:
                mIsCompleted = None

            try:
                trainningStatus = self.get_argument('trainningStatus')
                code, message = Validate.i(
                    trainningStatus,
                    'trainningStatus',
                    dataType=str,
                    notEmpty=True
                )
                if code != 4100:
                    raise Exception
            except:
                trainningStatus = None

            try:
                defaulters = self.get_argument('defaulters')
                code, message = Validate.i(
                    defaulters,
                    'defaulters',
                    datatype=bool,
                    notEmpty=True
                )
                if code != 4100:
                    raise Exception
            except:
                defaulters = None

            try:
                trainingStatus = self.get_argument('trainingStatus')
                code, message = Validate.i(
                    trainingStatus,
                    'trainingStatus',
                    datatype=str,
                    notEmpty=True
                )
                if code != 4100:
                    raise Exception
            except:
                trainingStatus = None

            filterQ = {
                '$match' : filterObj
            }   
            pipeline = [
                        {
                            '$lookup': {
                                'from': self.state.name,
                                'localField': 'data.state',
                                'foreignField': '_id',
                                'as': 'stateInfo',
                                'pipeline': [
                                    {
                                        '$project': {
                                            '_id': {
                                                '$toString': '$_id'
                                            },
                                            'name': 1
                                        }
                                    }
                                ]
                            }
                        },
                        {
                            '$lookup': {
                                'from': self.district.name,
                                'localField': 'data.unitDistrict',
                                'foreignField': '_id',
                                'as': 'districtInfo',
                                'pipeline': [
                                    {
                                        '$project': {
                                            '_id': {
                                                '$toString': '$_id'
                                            },
                                            'districtName': 1

                                        }
                                    }
                                ]
                            }
                        },
                        {
                            '$lookup': {
                                'from': self.block.name,
                                'localField': 'data.talukblock',
                                'foreignField': '_id',
                                'as': 'blockInfo',
                                'pipeline': [
                                    {
                                        '$project': {
                                            '_id': {
                                                '$toString': '$_id'
                                            },
                                            'blockName': 1
                                        }
                                    }
                                ]
                            }
                        },
                        {
                            '$lookup': {
                                'from': self.loanStatusLog.name,
                                'localField': '_id',
                                'foreignField': 'loanApplicationId',
                                'as': 'statusInfo',
                                'pipeline': [
                                    {
                                        '$lookup': {
                                            'from': self.account.name,
                                            'localField': 'recommendation.modifiedBy',
                                            'foreignField': '_id',
                                            'as': 'recommendationAccountInfo',
                                            'pipeline': [
                                                {
                                                    '$project': {
                                                        '_id': {
                                                            '$toString': '$_id'
                                                        },
                                                        'firstName': 1,
                                                        'lastName': 1
                                                    }
                                                }
                                            ]
                                        }
                                    }
                                ]
                            }
                        },
                        {
                            '$lookup': {
                                'from': self.rejectionReasons.name,
                                'localField': 'data.bankRemarks',
                                'foreignField': '_id',
                                'as': 'rejectionInfo',
                                'pipeline': [
                                    {
                                        '$project': {
                                            '_id': {
                                                '$toString': '$_id'
                                            },
                                            'reason': 1
                                        }
                                    }
                                ]
                            }
                        },
                        {
                            '$project': { 
                                '_id': {
                                    '$toString': '$_id'
                                },
                                'data.currentStatus' : 1, 
                                'data.underProcessRejectionByAgencyReason' : 1, 
                                'data.officeName':1, 
                                'data.agencyType':1,
                                'data.state': {
                                    '$toString': '$data.state'
                                }, 
                                'applicantId':1, 
                                'data.applicantName':1,	
                                'data.applicantAddress':1, 
                                'data.mobileNo':1,
                                'data.alternativeMobileNo':1,	
                                'data.email':1,
                                'data.legalStatus':1, 
                                'data.gender':1 , 
                                'data.category':1,	
                                'data.qualification':1,	
                                'data.dateOfBirth':1,	
                                'data.age':1,
                                'data.unitLocation':1,	
                                'data.unitAddress':1,	
                                'data.talukblock': {
                                    '$toString': '$data.talukblock'
                                }, 
                                'data.unitDistrict': {
                                    '$toString': '$data.unitDistrict'
                                },	
                                'data.productDescactivity':1,
                                'data.proposedProjectCost':1, 
                                'data.financingBranchIfscCode':1,	
                                'data.financingBranchAddress':1,	
                                'data.onlineSubmissionDate':1,
                                'data.forwardingDateToBank':1,	
                                'data.bankRemarks': {
                                    '$toString': '$data.bankRemarks'
                                },	
                                'data.dateOfDocumentReceivedAtBank':1,
                                'data.totalProjectCostApprovedByBank':1,	
                                'data.sanctionedDateByBank':1,	
                                'data.totalSanctionedAmountByBank':1,	
                                'data.dateOfDepositOwnContribution':1, 
                                'data.ownContributionAmountDeposited':1, 
                                'data.coveredUnderCgtsi':1,	
                                'data.dateOfLoanRelease':1,	
                                'data.loanReleaseAmount':1,	
                                'data.remarksForMmProcessAtPmegpcomumbai':1,
                                'data.mmReleaseAmount':1, 
                                'data.edpTrainingCenterName':1,	
                                'data.trainingStartDate':1,
                                'data.trainingEndDate':1,	
                                'data.durationOfTraining':1,	
                                'data.certificateIssueDate':1,
                                'data.physicalVerificationConductedDate': 1,
                                'data.physicalVerificationStatus': 1,
                                'data.isUnknownBlock': 1,
                                'data.trainingMode': 1,
                                'data.trainingRemarks': 1,
                                'createdAt':1, 
                                'createdBy':{
                                    '$toString': '$createdBy'
                                }, 
                                'modifiedBy': {
                                    '$toString': '$modifiedBy'
                                }, 
                                'modifiedAt':1,
                                'blockInfo' : {
                                    '$last': '$blockInfo'
                                },
                                'districtInfo' : {
                                    '$last': '$districtInfo'
                                },
                                'stateInfo' : {
                                    '$last': '$stateInfo'
                                },
                                'statusInfo': {
                                    'recommendation': 1,
                                    'recommendationAccountInfo': 1
                                },
                                'rejectionInfo': 1
                            }
                        }
                    ]

            
            pipelineQ = [
                        {
                            '$lookup': {
                                'from': self.state.name,
                                'localField': 'data.state',
                                'foreignField': '_id',
                                'as': 'stateInfo',
                                'pipeline': [
                                        {
                                            '$project': {
                                                '_id': {
                                                    '$toString': '$_id'
                                                },
                                                'name': 1
                                            }
                                        }
                                    ]
                            }
                        },
                        {
                            '$lookup': {
                                'from': self.district.name,
                                'localField': 'data.unitDistrict',
                                'foreignField': '_id',
                                'as': 'districtInfo',
                                'pipeline': [
                                    {
                                        '$project': {
                                            '_id': {
                                                '$toString': '$_id'
                                            },
                                            'districtName': 1

                                        }
                                    }
                                ]
                            }
                        },
                        {
                            '$lookup': {
                                'from': self.block.name,
                                'localField': 'data.talukblock',
                                'foreignField': '_id',
                                'as': 'blockInfo',
                                'pipeline': [
                                    {
                                        '$project': {
                                            '_id': {
                                                '$toString': '$_id'
                                            },
                                            'blockName': 1
                                        }
                                    }
                                ]
                            }
                        },
                        {
                            '$lookup': {
                                'from': self.auditInfo.name,
                                'localField': '_id',
                                'foreignField': 'loanId',
                                'as': 'auditInfo',
                                'pipeline': [
                                    {
                                        '$addFields': {
                                            'stage1': '$auditData.stage1.stageStatus',
                                            'stage2': '$auditData.stage2.stageStatus',
                                            'stage3': '$auditData.stage3.stageStatus',
                                            'stage4': '$auditData.stage4.stageStatus',
                                            'stage5': '$auditData.stage5.stageStatus',
                                            'stage6': '$auditData.stage6.stageStatus'
                                        }
                                    },
                                    {
                                        '$addFields': {
                                            'stageOne': {
                                                '$cond': {
                                                    'if': {
                                                        '$eq': ['$stage1', 'complete']
                                                    },
                                                    'then': 1,
                                                    'else': 0
                                                }
                                            },
                                            'stageTwo': {
                                                '$cond': {
                                                    'if': {
                                                        '$eq': ['$stage2', 'complete']
                                                    },
                                                    'then': 1,
                                                    'else': 0
                                                }
                                            },
                                            'stageThree': {
                                                '$cond': {
                                                    'if': {
                                                        '$eq': ['$stage3', 'complete']
                                                    },
                                                    'then': 1,
                                                    'else': 0
                                                }
                                            },
                                            'stageFour': {
                                                '$cond': {
                                                    'if': {
                                                        '$eq': ['$stage4', 'complete']
                                                    },
                                                    'then': 1,
                                                    'else': 0
                                                }
                                            },
                                            'stageFive': {
                                                '$cond': {
                                                    'if': {
                                                        '$eq': ['$stage5', 'complete']
                                                    },
                                                    'then': 1,
                                                    'else': 0
                                                }
                                            },
                                            'stageSix': {
                                                '$cond': {
                                                    'if': {
                                                        '$eq': ['$stage6', 'complete']
                                                    },
                                                    'then': 1,
                                                    'else': 0
                                                }
                                            },
                                        }
                                    },
                                    {
                                        '$addFields': {
                                            'completedStages': {
                                                '$sum': [
                                                    '$stageOne', '$stageTwo', '$stageThree', '$stageFour', '$stageFive', '$stageSix'
                                                ]
                                            }
                                        }
                                    },
                                    {
                                        '$addFields':
                                            {
                                                'lastModifiedAt':
                                                {
                                                    '$ifNull': [
                                                        '$modifiedAt',
                                                        '$createdAt'
                                                        ]
                                                } 
                                            }  
                                    },
                                    {
                                        '$project': {
                                            '_id': {
                                                '$toString': '$_id'
                                            },
                                            'stageOne': 1,
                                            'stageTwo': 1,
                                            'stageThree': 1,
                                            'stageFour': 1,
                                            'stageFive': 1,
                                            'stageSix': 1,
                                            'lastModifiedAt': 1,
                                            'completedStages': 1,
                                            'auditInfo': 1,
                                            'constructionStatus': 1,
                                        }
                                    }
                                ]   
                                
                            }
                        },
                        {
                            '$lookup': {
                                'from': self.loanStatusLog.name,
                                'localField': '_id',
                                'foreignField': 'loanApplicationId',
                                'as': 'statusInfo',
                                'pipeline': [
                                    {
                                        '$lookup': {
                                            'from': self.account.name,
                                            'localField': 'recommendation.modifiedBy',
                                            'foreignField': '_id',
                                            'as': 'recommendationAccountInfo',
                                            'pipeline': [
                                                {
                                                    '$project': {
                                                        '_id': {
                                                            '$toString': '$_id'
                                                        },
                                                        'firstName': 1,
                                                        'lastName': 1
                                                    }
                                                }
                                            ]
                                        }
                                    }
                                ]
                            }
                        },
                        {
                            '$lookup': {
                                'from': self.loanStatusLog.name,
                                'localField': '_id',
                                'foreignField': 'loanApplicationId',
                                'as': 'disbursementInfo',
                                'pipeline': [
                                    {
                                        '$addFields': {
                                            'disbursementDetails': {
                                                '$first': '$disbursed'
                                            }
                                        }
                                    },
                                    {
                                        '$addFields': {
                                            'disbursementDetails_info': {
                                                '$last': '$disbursed'
                                            }
                                        }
                                    },
                                    {
                                        '$addFields': {
                                            'disbursedDate': {
                                                '$first': '$disbursementDetails_info.disbursedInfo.date'
                                            }
                                        }
                                    },
                                    {
                                    '$addFields': {
                                        'disbursedAmounts': '$disbursed.disbursedInfo.amount'
                                    }
                                },
                                    {
                                        '$project': {
                                            '_id': {
                                                '$toString': '$_id'
                                            },
                                            'disbursedDate': 1,
                                            'disbursedAmounts': 1,
                                            "rejected.reason":1
                                        }
                                    }
                                ]
                            }
                        },
                        {
                            '$unwind': '$disbursementInfo'
                        },
                        {
                            '$lookup': {
                                'from': self.auditInfo.name,
                                'localField': '_id',
                                'foreignField': 'loanApplicationId',
                                'as': 'auditArray'
                            }
                        },
                        {
                            '$project': { 
                                '_id': {
                                    '$toString': '$_id'
                                },
                                'totalCount': 1,
                                'data.currentStatus' : 1,  
                                'data.rejectedByBank' : 1,
                                'applicantId':1, 
                                'data.applicantName':1,	
                                'data.mobileNo':1,
                                'data.alternativeMobileNo':1,	
                                'data.gender':1 , 
                                'data.category':1,
                                'data.totalSanctionedAmountByBank':1,
                                'data.isUnknownBlock': 1,
                                'data.isUnknownBranch': 1,
                                'data.isRecommended': 1,
                                'data.trainingMode': 1,
                                'data.trainingRemarks': 1,
                                'isDefaulter': 1,
                                'createdAt':1, 
                                'disbursementInfo': 1,
                                'inspectionReportSubmitted':1,
                                'data.sanctionedDateByBank':1,
                                'auditInfo': 1,
                                'createdBy':{
                                    '$toString': '$createdBy'
                                }, 
                                'modifiedBy': {
                                    '$toString': '$modifiedBy'
                                }, 
                                'modifiedAt':1,
                                'blockInfo' : {
                                    '$last': '$blockInfo'
                                },
                                'districtInfo' : {
                                    '$last': '$districtInfo'
                                },
                                'stateInfo' : {
                                    '$last': '$stateInfo'
                                },
                                'statusInfo': {
                                    'recommendation': 1,
                                    'recommendationAccountInfo': 1
                                },
                                'disbursedAmounts': 1,
                                'auditArray': 1   
                            }
                        },
                        {
                            '$sort': {
                                '_id': -1
                            }
                        }
                    ]
            
            pipelineD = [
                {
                    '$lookup': {
                        'from': 'state', 
                        'localField': 'data.state', 
                        'foreignField': '_id', 
                        'as': 'stateInfo', 
                        'pipeline': [
                            {
                                '$project': {
                                    '_id': {
                                        '$toString': '$_id'
                                    }, 
                                    'name': 1
                                }
                            }
                        ]
                    }
                },
                {
                    '$lookup': {
                        'from': 'block', 
                        'localField': 'data.talukblock', 
                        'foreignField': '_id', 
                        'as': 'blockInfo', 
                        'pipeline': [
                            {
                                '$project': {
                                    '_id': {
                                        '$toString': '$_id'
                                    }, 
                                    'name': 1
                                }
                            }
                        ]
                    }
                },
                {
                    '$lookup': {
                        'from': 'district', 
                        'localField': 'data.unitDistrict', 
                        'foreignField': '_id', 
                        'as': 'districtInfo', 
                        'pipeline': [
                            {
                                '$project': {
                                    '_id': {
                                        '$toString': '$_id'
                                    }, 
                                    'districtName': 1
                                }
                            }
                        ]
                    }
                },
                {
                    '$addFields': {
                        'epdCompleted': {
                            '$cond': {
                                'if': {
                                    '$eq': [
                                        {
                                            '$type': '$data.certificateIssueDate'
                                        }, 'long'
                                    ]
                                }, 
                                'then': True, 
                                'else': False
                            }
                        }, 
                        'edpPending': {
                            '$cond': {
                                'if': {
                                    '$and': [
                                        {
                                            '$in': [
                                                '$data.currentStatus', [
                                                    'Loan Sanctioned', 'Disbursed'
                                                ]
                                            ]
                                        }, 
                                        {
                                            '$ne': [
                                                {
                                                    '$type': '$data.certificateIssueDate'
                                                }, 'long'
                                            ]
                                        }
                                    ]
                                }, 
                                'then': True, 
                                'else': False
                            }
                        }
                    }
                },
                {
                    '$lookup': {
                        'from': 'loanStatusLog', 
                        'localField': '_id', 
                        'foreignField': 'loanApplicationId', 
                        'as': 'statusInfo', 
                        'pipeline': [
                            {
                                '$lookup': {
                                    'from': 'account', 
                                    'localField': 'recommendation.modifiedBy', 
                                    'foreignField': '_id', 
                                    'as': 'recommendationAccountInfo', 
                                    'pipeline': [
                                        {
                                            '$project': {
                                                '_id': {
                                                    '$toString': '$_id'
                                                }, 
                                                'firstName': 1, 
                                                'lastName': 1
                                            }
                                        }
                                    ]
                                }
                            }
                        ]
                    }
                },
                {
                    '$lookup': {
                        'from': 'rejectionReasons', 
                        'localField': 'data.bankRemarks', 
                        'foreignField': '_id', 
                        'as': 'rejectionInfo', 
                        'pipeline': [
                            {
                                '$project': {
                                    '_id': {
                                        '$toString': '$_id'
                                    }, 
                                    'reason': 1
                                }
                            }
                        ]
                    }
                },
                {
                    '$lookup': {
                        'from': self.loanStatusLog.name,
                        'localField': '_id',
                        'foreignField': 'loanApplicationId',
                        'as': 'disbursementInfo',
                        'pipeline': [
                            {
                                '$addFields': {
                                    'disbursementDetails': {
                                        '$first': '$disbursed'
                                    }
                                }
                            },
                            {
                                '$addFields': {
                                    'disbursedDate': {
                                        '$first': '$disbursementDetails.disbursedInfo.date'
                                    }
                                }
                            },
                            {
                            '$addFields': {
                                'disbursedAmounts': '$disbursed.disbursedInfo.amount'
                            }
                        },
                            {
                                '$project': {
                                    '_id': {
                                        '$toString': '$_id'
                                    },
                                    'disbursedDate': 1,
                                    'disbursedAmounts': 1,
                                    "rejected.reason":1
                                }
                            }
                        ]
                    }
                },
                {
                    '$unwind': '$disbursementInfo'
                },
                {
                    '$lookup': {
                        'from': self.jointApplication.name, 
                        'localField': 'applicantId', 
                        'foreignField': 'applicantId', 
                        'as': 'jointInspection'
                    }
                }, {
                    '$unwind': {
                        'path': '$jointInspection', 
                        'preserveNullAndEmptyArrays': True
                    }
                }, 
                {
                    '$project': {
                        '_id': {
                            '$toString': '$_id'
                        }, 
                        'totalCount': 1, 
                        'data.currentStatus': 1, 
                        'data.rejectedByBank': 1, 
                        'applicantId': 1, 
                        'data.applicantName': 1, 
                        'data.mobileNo': 1, 
                        'data.alternativeMobileNo': 1, 
                        'data.gender': 1, 
                        'data.category': 1, 
                        'data.totalSanctionedAmountByBank': 1, 
                        'data.isUnknownBlock': 1, 
                        'data.isUnknownBranch': 1, 
                        'data.isRecommended': 1, 
                        'data.trainingMode':1,
                        'data.trainingRemarks':1,
                        'isDefaulter': 1, 
                        'createdAt': 1, 
                        'disbursementInfo': 1, 
                        'inspectionReportSubmitted': 1, 
                        'data.sanctionedDateByBank': 1, 
                        'auditInfo': 1, 
                        'createdBy': {
                            '$toString': '$createdBy'
                        }, 
                        'modifiedBy': {
                            '$toString': '$modifiedBy'
                        }, 
                        'modifiedAt': 1, 
                        'blockInfo': {
                            '$last': '$blockInfo'
                        }, 
                        'districtInfo': {
                            '$last': '$districtInfo'
                        }, 
                        'stateInfo': {
                            '$last': '$stateInfo'
                        }, 
                        'statusInfo': {
                            'recommendation': 1, 
                            'recommendationAccountInfo': 1
                        }, 
                        'disbursedAmounts': 1, 
                        'epdCompleted': 1, 
                        'edpPending': 1,
                        'disbursementInfo':1,
                        'jointInspection': 1
                    }
                }
            ]
            # vSkip = {
            #     '$skip': f_skip
            # }
            # vLimit = {
            #     '$limit': f_limit
            # }

            if meth is not None and meth == 1:
                
                # if vStatus == 'Under Process (At Agency)':
                #     pipelineQ.insert(0,  {
                #         '$match': {
                #             'data.currentStatus': 'Under Process (At Agency)', 
                #         }
                #     }
                # )
                #     vStatus = None
                
                if defaulters:
                    pipelineQ.insert(0, {
                            '$match':{
                                'isDefaulter':True
                            }
                        }
                    )

                if mIsCompleted is not None:
                    if mIsCompleted:
                        pipelineQ.insert(4, {
                            '$match': {
                                'auditInfo.completedStages': {
                                    '$gte': 6
                                }
                            }
                        })
                        pipelineQ.insert(5,{
                            '$match': {
                                'auditInfo.constructionStatus': 'complete'
                            }
                        })
                    else:
                        pipelineQ.insert(4, {
                            '$match': {
                                'auditInfo.completedStages': {
                                    '$lt': 6,
                                    '$gte': 0
                                }
                            }
                        })
                        pipelineQ.insert(5,{
                            '$match': {
                                'auditInfo.constructionStatus': 'Incomplete'
                            }
                        })
                        
                if mHomestayPerformance:
                    pipelineQ.insert(0, {
                        '$match': {
                            'data.currentStatus': 'Disbursed'
                        }
                    })


                if vFileDtlsId is not None:
                    matchQ = {
                        '$match' : {
                            '_id' : vFileDtlsId
                        }
                    }
                    pipelineQ.insert(0,matchQ)
                if filterObj:
                    pipelineQ.insert(1, filterQ)
                if mIsRecommended:
                    pipelineQ.insert(2, {
                        '$match': {
                            'data.isRecommended': mIsRecommended
                        }
                    })
                pipelineQ.insert(4, vLocfilter)
                if vStatus:
                    pipelineQ.insert(5, vStatusFilter)               
                pipelineQ.insert(0, {
                    '$match': {
                    'data.onlineSubmissionDate': {
                        '$exists': True
                    }}
                }   )
                # pipelineQ.append(vSkip)
                # pipelineQ.append(vLimit)
                fileQ = self.loanApplication.aggregate(pipelineQ)

            elif meth is not None and meth == 0:
                if trainningStatus is not None and trainningStatus == 'completed':
                    pipelineD.insert(4, {
                        "$match": {
                            "epdCompleted": True
                        }
                    })
                elif trainningStatus is not None and trainningStatus == 'pending':
                    pipelineD.insert(4, {
                        "$match": {
                            "edpPending": True,
                            'epdCompleted': False
                        }
                    })
                else:
                    code = 4325
                    message = 'Invalid Training Status'
                    raise Exception
                pipelineD.insert(0, {
                        '$match': {
                            'data.onlineSubmissionDate': {
                                '$exists': True
                            }
                        }
                }   )

                # pipelineD.append(vSkip)
                # pipelineD.append(vLimit)
                epdTrainningData = self.loanApplication.aggregate(pipelineD)

                            
            elif meth is not None and meth != 1 and meth != 0 and meth != 2:
                message = 'Invalid method.'
                code = 7182
                status = False
                raise Exception
            
            elif meth is None:
                if vFileDtlsId is not None:
                    matchQ = {
                        '$match' : {
                            '_id' : vFileDtlsId
                        }
                    }
                    pipeline.insert(0,matchQ)
                if filterObj:
                    pipeline.insert(1, filterQ)
                pipeline.insert(4, vLocfilter)
                if vStatus:
                    pipeline.insert(5, vStatusFilter)               
                pipeline.insert(0, {
                        '$match': {
                            'data.onlineSubmissionDate': {
                                '$exists': True
                            }
                        }
                }   )
                # pipeline.append(vSkip)
                # pipeline.append(vLimit)
                fileQ = self.loanApplication.aggregate(pipeline)

            xCurrentDate = datetime.datetime.fromtimestamp(timeNow() / 1000 / 1000)
            xCurrentDate = xCurrentDate.strftime('%Y-%m-%d')
            xCurrentDate = datetime.datetime.strptime(xCurrentDate, '%Y-%m-%d')

            
            if meth == None:
                async for i in fileQ:
                    if i.get('statusInfo')[0].get('recommendation'):
                        for j, recommendation in enumerate(i.get('statusInfo')[0].get('recommendation')):
                            i['statusInfo'][0]['recommendation'][j]['modifiedBy'] = str(recommendation.get('modifiedBy'))
                            i['statusInfo'][0]['recommendation'][j]['modifiedTo'] = str(recommendation.get('modifiedTo'))
                            for k, account in enumerate(i.get('statusInfo')[0].get('recommendationAccountInfo')):
                                if i['statusInfo'][0]['recommendation'][j]['modifiedBy'] == account.get('_id'):
                                    i['statusInfo'][0]['recommendation'][j]['accountInfo'] = account
                    del i['statusInfo'][0]['recommendationAccountInfo']
                    if not i.get('statusInfo')[0].get('recommendation'):
                        i['statusInfo'] = 'NA'
                    if not i.get('rejectionInfo'):
                        i['rejectionInfo'] = 'NA'
                    if not i.get('isDefaulter'):
                        i['isDefaulter'] = False
                    result.append(i)

            elif meth == 0:
                if epdTrainningData:
                    async for i in epdTrainningData:
                        if not i.get('statusInfo')[0].get('recommendation'):
                            i['statusInfo'] = 'NA'
                        if not i.get('rejectionInfo'):
                            i['rejectionInfo'] = 'NA'
                        if not i.get('isDefaulter'):
                            i['isDefaulter'] = False
                        result.append(i)

            elif meth == 1:
                if mHomestayPerformance:
                    async for i in fileQ:
                        if i['disbursementInfo'].get('rejected'):
                            i['disbursementInfo']['rejected'] = i['disbursementInfo'].get('rejected')[-1]['reason']
                        mCompletedStages = []
                        if i.get('statusInfo')[0].get('recommendation'):
                            for j, recommendation in enumerate(i.get('statusInfo')[0].get('recommendation')):
                                i['statusInfo'][0]['recommendation'][j]['modifiedBy'] = str(recommendation.get('modifiedBy'))
                                i['statusInfo'][0]['recommendation'][j]['modifiedTo'] = str(recommendation.get('modifiedTo'))
                                for k, account in enumerate(i.get('statusInfo')[0].get('recommendationAccountInfo')):
                                    if i['statusInfo'][0]['recommendation'][j]['modifiedBy'] == account.get('_id'):
                                        i['statusInfo'][0]['recommendation'][j]['accountInfo'] = account
                        del i['statusInfo'][0]['recommendationAccountInfo']
                        if not i.get('statusInfo')[0].get('recommendation'):
                            i['statusInfo'] = 'NA'
                        if not i.get('isDefaulter'):
                            i['isDefaulter'] = False

                        if i.get('auditInfo') and i.get('disbursementInfo').get('disbursedDate'):
                            xTotalStages = i.get('auditInfo')[0].get('stageOne') + i.get('auditInfo')[0].get('stageTwo') + i.get('auditInfo')[0].get('stageThree') + i.get('auditInfo')[0].get('stageFour') + i.get('auditInfo')[0].get('stageFive') + i.get('auditInfo')[0].get('stageSix')
                            
                            xDisbursedDate = datetime.datetime.fromtimestamp(i.get('disbursementInfo').get('disbursedDate') / 1000 / 1000)
                            xDisbursedDate = xDisbursedDate.strftime('%Y-%m-%d')
                            xDisbursedDate = datetime.datetime.strptime(xDisbursedDate, '%Y-%m-%d')
                            year_diff = xCurrentDate.year - xDisbursedDate.year
                            month_diff = xCurrentDate.month - xDisbursedDate.month

                            if xCurrentDate.day < xDisbursedDate.day:
                                month_diff -= 1
                            xMonthDifference = year_diff * 12 + month_diff

                            if len(i.get('auditInfo')):
                                if i.get('auditInfo')[0].get('stageOne') == 1:
                                    mCompletedStages.append('Stage 1')
                                if i.get('auditInfo')[0].get('stageTwo') == 1:
                                    mCompletedStages.append('Stage 2')
                                if i.get('auditInfo')[0].get('stageThree') == 1:
                                    mCompletedStages.append('Stage 3')
                                if i.get('auditInfo')[0].get('stageFour') == 1:
                                    mCompletedStages.append('Stage 4')
                                if i.get('auditInfo')[0].get('stageFive') == 1:
                                    mCompletedStages.append('Stage 5')
                                if i.get('auditInfo')[0].get('stageSix') == 1:
                                    mCompletedStages.append('Stage 6')
                                mLastModifiedAudit = i.get('auditInfo')[0].get('lastModifiedAt')
                                del i['auditInfo']
                                i['auditInfo'] = {
                                    'stagesCompleted': mCompletedStages,
                                    'lastModifiedAt': mLastModifiedAudit
                                }
                            if xTotalStages:
                                if mHomestayPerformance == 'Green':
                                    if xMonthDifference <= xTotalStages * 2 or xTotalStages == 6:
                                        result.append(i)
                                elif mHomestayPerformance == 'Yellow':
                                    if xMonthDifference > xTotalStages * 2 and xMonthDifference <= xTotalStages * 2 + 2 and xTotalStages != 6:
                                        result.append(i)
                                elif mHomestayPerformance == 'Red':
                                    if xMonthDifference > xTotalStages * 2 + 2 and xTotalStages != 6:
                                        result.append(i)
                else:
                    mTotalDisbursedAmount = 0
                    async for i in fileQ:
                        if i['disbursementInfo']['disbursedDate']:
                            i['disbursementInfo']['disbursedDate'] = datetime.datetime.fromtimestamp(i['disbursementInfo']['disbursedDate'] / 1000 / 1000).strftime('%d-%m-%Y')
                        if i['disbursementInfo'].get('rejected'):
                            i['disbursementInfo']['rejected'] = i['disbursementInfo'].get('rejected')[-1]['reason']
                        if i.get('data').get('sanctionedDateByBank'):
                            i['data']['sanctionedDateByBank'] = datetime.datetime.fromtimestamp(i.get('data').get('sanctionedDateByBank') / 1000 / 1000).strftime('%d-%m-%Y')
                        if not i.get('isDefaulter'):
                            i['isDefaulter'] = False
                        stat = i['data'].get('currentStatus')
                        stat = stat.lower()
                        if stat == 'disbursed':
                            mTotalDisbursedAmount = 0
                            if (i['disbursementInfo'].get('disbursedAmounts')):
                                amounts = i['disbursementInfo'].get('disbursedAmounts')
                                for a in amounts:
                                    for amount in a:                                 
                                        mTotalDisbursedAmount = mTotalDisbursedAmount + amount
                                del i['disbursementInfo']['disbursedAmounts']
                                i['disbursedAmount'] = mTotalDisbursedAmount
                        if stat in ["online submitted", "rejected/returned", "under process (at agency)","under process (at bank)"]:
                            i['inspectionReportSubmitted'] = i.get('inspectionReportSubmitted',False)
                            if i.get('inspectionReportSubmitted',False) == True:
                                approveQ = await self.jointApplication.find_one(
                                    {
                                        'applicantId' : i['applicantId']
                                    },
                                    {
                                        'inspectedBy': 1
                                    }
                                )
                                if approveQ:
                                    inspectors = approveQ.get('inspectedBy')    
                                    appCount = 0
                                    totCount = 0
                                    if inspectors is not None:
                                        for inspector in inspectors:
                                            totCount += 1
                                            if inspector.get('approved') == True:
                                                appCount += 1 
                                        if appCount != totCount:
                                            i['inspectionReportApproved'] = False
                                        else:
                                            i['inspectionReportApproved'] = True
                                    else:
                                        i['inspectionReportApproved'] = True
                                        i['inspectionReportSubmitted'] = True
                                else:
                                    i['inspectionReportSubmitted'] = False
                                    i['inspectionReportApproved'] = None

                            if i.get('inspectionReportSubmitted',False) == False:
                                i['inspectionReportApproved'] = None
                                
                            if i['inspectionReportApproved'] == True and i['inspectionReportSubmitted'] == True:
                                i['inspectionStatus'] = 'Completed'
                            elif i['inspectionReportApproved'] == False and i['inspectionReportSubmitted'] == True:
                                i['inspectionStatus'] = 'Pending'
                            else:
                                i['inspectionStatus'] = 'Incomplete'
                        else:
                            i['inspectionStatus'] = 'Not Applicable'
                        if stat == 'rejected/returned':
                            rejByBank = i['data'].get('rejectedByBank')
                            if rejByBank == True:
                                i['data']['currentStatus'] = 'Rejected By Bank'
                            else:
                                i['data']['currentStatus'] = 'Rejected By DIC'
                        mCompletedStages = []
                        if i.get('statusInfo')[0].get('recommendation'):
                            for j, recommendation in enumerate(i.get('statusInfo')[0].get('recommendation')):
                                i['statusInfo'][0]['recommendation'][j]['modifiedBy'] = str(recommendation.get('modifiedBy'))
                                i['statusInfo'][0]['recommendation'][j]['modifiedTo'] = str(recommendation.get('modifiedTo'))
                        if not i.get('statusInfo')[0].get('recommendation'):
                            i['statusInfo'] = 'NA'
                        if len(i.get('auditInfo')):
                            if i.get('auditInfo')[0].get('stageOne') == 1:
                                mCompletedStages.append('Stage 1')
                            if i.get('auditInfo')[0].get('stageTwo') == 1:
                                mCompletedStages.append('Stage 2')
                            if i.get('auditInfo')[0].get('stageThree') == 1:
                                mCompletedStages.append('Stage 3')
                            if i.get('auditInfo')[0].get('stageFour') == 1:
                                mCompletedStages.append('Stage 4')
                            if i.get('auditInfo')[0].get('stageFive') == 1:
                                mCompletedStages.append('Stage 5')
                            if i.get('auditInfo')[0].get('stageSix') == 1:
                                mCompletedStages.append('Stage 6')
                            mLastModifiedAudit = i.get('auditInfo')[0].get('lastModifiedAt')
                            del i['auditInfo']
                            i['auditInfo'] = {
                                'stagesCompleted': mCompletedStages,
                                'lastModifiedAt': mLastModifiedAudit
                            }

                            if i['auditInfo']['stagesCompleted'] == []:
                                i['auditInfo']['stagesCompleted'] = ['In Progress']
                            
                        result.append(i)
            elif meth is not None and meth == 2:
                if matchFilter:
                    pipelineD.insert(10,matchFilter)
                if filterObj:
                    pipelineD.insert(5, filterQ)
                if vStatus:
                    pipelineD.insert(4, vStatusFilter)
                if trainingStatus:
                    if trainingStatus == 'complete':
                        pipelineD.insert(4, {
                            '$match': {
                                'epdCompleted': True
                            }
                        })
                    elif trainingStatus == 'pending':
                        pipelineD.insert(4, {
                            '$match': {
                                'edpPending': True
                            }
                        })
                    else:
                        message = 'Invalid Training Status.'
                        code = 4548
                        raise Exception(message)
                if mDistrict:
                    pipelineD.insert(4, {
                        '$match': {
                            'data.unitDistrict': ObjectId(mDistrict)
                        }
                    })
                
                if mBlock:
                    pipelineD.insert(4, {
                        '$match': {
                            'data.talukblock': ObjectId(mBlock)
                        }
                    })

                try:
                    # pipelineD.append(f_limit)
                    # pipelineD.append(f_skip)
                    fileD = self.loanApplication.aggregate(pipelineD)
                    async for i in fileD:
                        stat = i['data'].get('currentStatus')
                        stat = stat.lower()
                        if stat in ["online submitted", "rejected/returned", "under process (at agency)","under process (at bank)"]:
                            approveQ = await self.jointApplication.find_one(
                                {
                                    'applicantId': i['applicantId']
                                },
                                {
                                    'inspectedBy': 1
                                }
                            )
                            if approveQ:
                                inspectors = approveQ.get('inspectedBy')
                                appCount = 0
                                totCount = 0
                                if inspectors is not None:
                                    for inspector in inspectors:
                                        totCount += 1
                                        if inspector.get('approved') == True:
                                            appCount += 1 
                                    if appCount != totCount:
                                        i['inspectionReportApproved'] = False
                                    else:
                                        i['inspectionReportApproved'] = True
                                else:
                                    i['inspectionReportApproved'] = True
                                    i['inspectionReportSubmitted'] = True
                            else:
                                i['inspectionReportSubmitted'] = False
                                i['inspectionReportApproved'] = None

                            if i.get('inspectionReportSubmitted', False) == False:
                                i['inspectionReportApproved'] = None

                            if i['inspectionReportApproved'] == True and i['inspectionReportSubmitted'] == True:
                                i['inspectionStatus'] = 'Completed'
                            elif i['inspectionReportApproved'] == False and i['inspectionReportSubmitted'] == True:
                                i['inspectionStatus'] = 'Pending'
                            else:
                                i['inspectionStatus'] = 'Incomplete'
                        else:
                            i['inspectionStatus'] = 'Not Applicable'

                        if i.get('statusInfo') and i.get('statusInfo')[0].get('recommendation'):
                            for j, recommendation in enumerate(i.get('statusInfo')[0].get('recommendation')):
                                i['statusInfo'][0]['recommendation'][j]['modifiedBy'] = str(recommendation.get('modifiedBy'))
                                i['statusInfo'][0]['recommendation'][j]['modifiedTo'] = str(recommendation.get('modifiedTo'))
                                for k, account in enumerate(i.get('statusInfo')[0].get('recommendationAccountInfo')):
                                    if i['statusInfo'][0]['recommendation'][j]['modifiedBy'] == account.get('_id'):
                                        i['statusInfo'][0]['recommendation'][j]['accountInfo'] = account
                            del i['statusInfo'][0]['recommendationAccountInfo']
                        else:
                            i['statusInfo'] = 'NA'
                        if not i.get('rejectionInfo'):
                            i['rejectionInfo'] = 'NA'
                        if not i.get('isDefaulter'):
                            i['isDefaulter'] = False
                        if not i.get('trainingMode'):
                            i['trainingMode'] = 'NA'
                        if not i.get('trainingRemarks'):
                            i['trainingRemarks'] = 'NA'
                        if i['data']['sanctionedDateByBank']:
                            i['data']['sanctionedDateByBank'] = datetime.datetime.fromtimestamp(i['data']['sanctionedDateByBank'] / 1000 / 1000).strftime('%d-%m-%Y')
                        
                        if i.get('disbursementInfo'):
                            if i.get('disbursementInfo').get('disbursedDate'):
                                i['disbursementInfo']['disbursedDate'] = datetime.datetime.fromtimestamp(i['disbursementInfo']['disbursedDate'] / 1000 / 1000).strftime('%d-%m-%Y')
                            if i.get('disbursementInfo').get('disbursedDate') == None:
                                i['disbursementInfo']['disbursedDate']  = 'Not Applicable'
                            if not i.get('disbursementInfo').get('disbursedAmounts'):
                                i['disbursementInfo']['disbursedAmounts'] = [['Not Applicable']]
                        disbursedAmounts = list(i['disbursementInfo'].get('disbursedAmounts'))
                        i['disbursedAmount'] = disbursedAmounts[-1][0]
                        if stat == 'rejected/returned':
                            rejByBank = i['data'].get('rejectedByBank')
                            if rejByBank == True:
                                i['data']['currentStatus'] = 'Rejected By Bank'
                            else:
                                i['data']['currentStatus'] = 'Rejected By DIC'
                        result.append(i)
                except Exception as e:
                    Log.e(e)

            if not len(result):
                message = 'No data found.'
                code = 4082
                raise Exception(message)
            else:
                message = 'Data found.'
                code = 2000
                status = True
        except Exception as e:
            status = False
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(bdumps(response))
            await self.finish()
            return

        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return

    async def post(self):
        code = 4000
        message = ''
        status = False
        result = []
        try:
            try:
                file_dic = {}
                arg_dic = {}
                b = self.request.headers.get('Content-Type')
                tornado.httputil.parse_body_arguments(b, self.request.body, arg_dic, file_dic)
                file_data = file_dic.get('excelFile')
                meth = json.loads(arg_dic['method'][0])
            except:
                code = 4323
                message = 'Invalid body arguments.'
                raise Exception
            

            _Id = self.accountId
            admin = await self.account.find_one(
                {'_id': ObjectId(_Id)}
            )
            method = meth.get('method')
            code, message = Validate.i(
                method,
                'method',
                notNull=True,
                notEmpty=True,
                dataType=int
            )
            if code != 4100:
                raise Exception

            if admin:
                if method == 1:
                    try:
                        data_array = []
                        error_list = []
                        if 'excelFile' not in file_dic:
                            code = 4325
                            message = 'Excel file is missing in the request.'
                            raise Exception

                        file_data = file_dic['excelFile'][0]

                        allowed_extensions = ['.xlsx', '.xlsm', '.xlsb', '.xltx']
                        file_name = file_data.filename
                        file_extension = os.path.splitext(file_name)[1].lower()

                        if file_extension not in allowed_extensions:
                            code = 4324
                            message = 'Invalid file format. Please upload an Excel file.'
                            raise Exception
                        
                        try:
                            df = pd.read_excel(io.BytesIO(file_data.body), engine='openpyxl')
                        except TypeError as te:
                            print(f"TypeError occurred: {te}")

                        expected_columns = ['Current Status', 'Under Process /Rejection by Agency Reason', 'Office Name', 'Agency Type',
                                            'State', 'Applicant ID', 'Applicant Name',	'Applicant Address', 'Mobile No.',
                                            'Alternative Mobile No',	'eMail','Legal Status', 'Gender' , 'Category',	'Qualification',	'Date of Birth',	'Age',
                                            'Unit Location',	'Unit Address',	'Taluk/block', 'Unit District',	'Product Desc/Activity',
                                            'Proposed Project Cost', 'Financing Branch IFSC CODE',	'Financing Branch Address',	'Online Submission Date',
                                            'Forwarding Date to Bank',	'Bank Remarks',	'Date of Document Received at Bank',
                                            'Total Project Cost Approved by Bank',	'Sanctioned Date by Bank',	'Total Sanctioned Amount by Bank',	'Date of Deposit Own Contribution', 
                                            'Own Contribution amount Deposited', 'Covered Under CGTSI',	'Date of Loan Release',	'Loan Release Amount',	
                                            'Remarks for MM Process at PMEGP,CO,Mumbai','MM Release Amount', 'EDP Training Center Name',	'Training Start Date',
                                            'Training End Date',	'Duration of Training',	'Certificate Issue Date'
                                            ]
                        
                        missing_columns = [col for col in expected_columns if col not in df.columns]
                        if missing_columns:
                            code = 4324
                            message = "The following columns are missing in the Excel file"
                            result.append(missing_columns)
                            raise Exception
                        
                        string_column = [
                            'Current Status', 'Under Process /Rejection by Agency Reason', 'Office Name', 'Agency Type',
                            'State', 'Applicant ID', 'Applicant Name',	'Applicant Address', 'eMail','Legal Status', 'Gender' , 'Category',	
                            'Qualification', 'Unit Location',	'Unit Address',	'Taluk/block', 'Unit District',	'Product Desc/Activity',
                            'Financing Branch IFSC CODE',	'Financing Branch Address',	
                            'Bank Remarks',	'Covered Under CGTSI',	
                            'Remarks for MM Process at PMEGP,CO,Mumbai','EDP Training Center Name'
                            ]
                        
                        int_columns = [
                            'Mobile No.', 'Alternative Mobile No', 'Age', 'Proposed Project Cost', 'Total Project Cost Approved by Bank', 
                            'Own Contribution amount Deposited', 'Loan Release Amount',	'MM Release Amount', 'Duration of Training', 'Total Sanctioned Amount by Bank'
                            ]    
                        
                        date_columns = [
                            'Date of Birth', 'Online Submission Date', 'Forwarding Date to Bank', 'Date of Document Received at Bank',
                            'Date of Deposit Own Contribution', 'Date of Loan Release',	'Training Start Date', 'Training End Date',
                            'Certificate Issue Date', 'Sanctioned Date by Bank'
                            ]
                        
                        data_dict = {}
                        date_format = "%Y-%m-%d %H:%M:%S"
                        for index, row in df.iterrows():
                            data_dict = {} 
                            xSanctionedAmount = 0
                            xSanctionedDate = 0
                            xLoanReleaseAmount = 0
                            xLoanReleaseDate = 0
                            mLoanAppDetails = None
                            xTotalDisbursedAmount = 0
                            xBranchId = None
                            xActualLoanReleaseAmt = 0
                            for column in df.columns:        
                                value = row[column]
                                xApplicationId = row['Applicant ID']
                                if column in [
                                    'AADHAAR', 'Special Category', 'Industry Type', 'DLTFC Meeting Place', 'Payment Status (Fail/Sucess)',
                                    'MM disbursement Transaction id', 'Fail Reason', 'MM Claim Date', 'DLTFC Meeting','MM Involve',
                                    'Project Cost Approved by Bank 1', 'Project Cost Approved by Bank 2', 'Sanctioned by Bank 1', 'Sanctioned by Bank 2',
                                    'MM Final Adjustment Date', 'MM Final Adjustment Amount', 'TDR Account No', 'TDR Date']:
                                        continue
                                if column in string_column:
                                    if type(value) == float or not value:
                                        value = '-'
                                    if column not in ['Current Status', 'Under Process /Rejection by Agency Reason', 'Physical Verification Conducted Date', 'Physical Verification Status']:
                                        if not isinstance(value, str) or not value:
                                            status = False
                                            code = 4111
                                            message = f"Value at row {index + 2} is '{value}' in '{column}' column is not of non empty string data type."
                                            error_list.append(message)
                                        
                                    elif column in ['Current Status', 'Under Process /Rejection by Agency Reason', 'Physical Verification Conducted Date', 'Physical Verification Status']:
                                        if column == 'Current Status':
                                            try:
                                                value = ' '.join([x for x in value.split(' ') if x != ''])
                                                pattern = re.compile(r'(?<=\() | (?=\))')
                                                value = re.sub(pattern, '', value).strip()                                              
                                                value = value.replace('at', 'At')
                                                value = value.replace('Process(', 'Process (')
                                                value = value.replace(' /', '/')
                                                value = value.replace(' / ', '/')
                                                value = value.replace('/ ', '/')
                                            except Exception as e: 
                                                Log.i(e)
                                            if value not in ['Online Submitted', 'Rejected/Returned', 'Onhold/Discontinued', 'Disbursed', 'Copayment', 'Loan Sanctioned', 'Construction Completed', 'Under Process (At Agency)', 'Under Process (At Bank)', '-']:
                                                code = 4807
                                                message = 'Current Status of row {} is not valid'.format(index+2)
                                                error_list.append(message)

                                        if not isinstance(value, str):
                                            status = False
                                            code = 4331
                                            message = f"Value at row {index + 2} is '{value}' in '{column}' column is not of non empty string data type."
                                            error_list.append(message)
                                    
                                    if column == 'Bank Remarks':
                                        value = ('/').join(value.split('/')[1:]).strip()
                                        value = ' '.join([x for x in value.split(' ') if x != ''])
                                        value1 = None
                                        if not value:
                                            value = ''
                                            data_dict['rejectedByBank'] = False
                                        else:
                                            parts = value.split('/')
                                            if len(parts) > 2:
                                                value1 = ('/').join(parts[1:]).strip()
                                            elif len(parts) == 2:
                                                value1 = parts[1].strip()
                                            else:
                                                value1 = None
                                            data_dict['rejectedByBank'] = True

                                        pipeline = [
                                            {
                                                '$addFields': {
                                                    'lowerReason': {
                                                        '$toLower': '$reason'
                                                    }
                                                }
                                            },
                                            {
                                                '$match': {
                                                    'lowerReason': {'$in': [value.lower()]}
                                                }
                                            },
                                            {
                                                '$project': {
                                                    'reason': 1
                                                }
                                            }
                                        ]
                                        if value1 is not None:
                                            pipeline[1]['$match']['lowerReason']['$in'].append(value1.lower())

                                        mFindReasonsX = self.rejectionReasons.aggregate(pipeline)
                                        mReasonFind = None
                                        async for i in mFindReasonsX:
                                            mReasonFind = i

                                        if not mReasonFind:
                                            if value == '':
                                                mOtherReasonFind = await self.rejectionReasons.find_one(
                                                    {
                                                        'reason': 'Other', 'rejectedBy': 'dic'
                                                    }
                                                )
                                            else:
                                                mOtherReasonFind = await self.rejectionReasons.find_one(
                                                    {
                                                        'reason': 'Other', 'rejectedBy': 'bank'
                                                    }
                                                )
                                            xReason = mOtherReasonFind.get('_id')

                                            mUploadedReasonFind = False
                                            if mOtherReasonFind.get('uploaded'):
                                                for i in mOtherReasonFind.get('uploaded'):
                                                    if i.get('reason').lower() == value.lower():
                                                        mbankRemarkNo = i.get('slNo')
                                                        mUploadedReasonFind = True
                                            if not mUploadedReasonFind:
                                                if value == '':
                                                    mFindReason = self.rejectionReasons.aggregate(
                                                        [
                                                            {
                                                                '$match': {
                                                                    'reason': 'Other',
                                                                    'rejectedBy': 'dic'
                                                                }
                                                            },
                                                            {
                                                                '$addFields': {
                                                                    'lastUploadedReason': {
                                                                        '$last': '$uploaded'
                                                                    }
                                                                }       
                                                            },
                                                            {
                                                                '$project': {
                                                                    'lastUploadedReason': 1
                                                                }
                                                            }
                                                        ]
                                                    )
                                                else:
                                                    mFindReason = self.rejectionReasons.aggregate(
                                                        [
                                                            {
                                                                '$match': {
                                                                    'reason': 'Other',
                                                                    'rejectedBy': 'bank'
                                                                }
                                                            },
                                                            {
                                                                '$addFields': {
                                                                    'lastUploadedReason': {
                                                                        '$last': '$uploaded'
                                                                    }
                                                                }       
                                                            },
                                                            {
                                                                '$project': {
                                                                    'lastUploadedReason': 1
                                                                }
                                                            }
                                                        ]
                                                    )
                                                async for i in mFindReason:
                                                    try:
                                                        mSlNo = i.get('lastUploadedReason').get('slNo')
                                                    except:
                                                        mSlNo = 0

                                                mbankRemarkNo = mSlNo+1
                                                if value == '':
                                                    await self.rejectionReasons.update_one(
                                                        {
                                                            'reason': 'Other',
                                                            'rejectedBy': 'dic'
                                                        },
                                                        {
                                                            '$push':
                                                            {
                                                                'uploaded':{
                                                                    'slNo': mbankRemarkNo,
                                                                    'reason': value
                                                                }
                                                            }
                                                        }
                                                    )
                                                else:
                                                    await self.rejectionReasons.update_one(
                                                        {
                                                            'reason': 'Other',
                                                            'rejectedBy': 'bank'
                                                        },
                                                        {
                                                            '$push':
                                                            {
                                                                'uploaded':{
                                                                    'slNo': mbankRemarkNo,
                                                                    'reason': value
                                                                }
                                                            }
                                                        }
                                                    )
                                            else:
                                                mbankRemarkNo = mbankRemarkNo
                                                
                                            if mbankRemarkNo:
                                                data_dict['bankRemarkNo'] = mbankRemarkNo

                                        else:
                                            xReason = mReasonFind.get('_id')

                                        value = xReason

                                    if column in ['State']:
                                        stateQ = await self.state.find_one(
                                                {
                                                    'name': str(value).strip().title()
                                                },
                                                {
                                                    '_id':1
                                                }
                                            )
                                        if not stateQ:
                                            code = 4552
                                            message = '{} of row {} is not available'.format(column,index+2)
                                            error_list.append(message)

                                        else:
                                            value = stateQ['_id']
                                    
                                    if column in ['Taluk/block']:
                                        blockQ = await self.block.find_one(
                                                {
                                                    'blockName': str(value).strip().title()
                                                },
                                                {
                                                    '_id':1
                                                }
                                            )
                                        if not blockQ:
                                            mUnknownBlock = await self.block.find_one(
                                                {
                                                    'blockName': 'Unknown Block'
                                                }
                                            )
                                            value = mUnknownBlock['_id']
                                            data_dict['isUnknownBlock'] = True

                                        else:
                                            value = blockQ['_id']
                                            data_dict['isUnknownBlock'] = False
                                        

                                    if column in ['Unit District']:
                                        districtQ = await self.district.find_one(
                                                {
                                                    'districtName': str(value).strip().title()
                                                },
                                                {
                                                    '_id':1
                                                }
                                            )
                                        if not districtQ:
                                            code = 4578
                                            message = '{} of row {} is not available'.format(column,index+2)
                                            error_list.append(message)

                                        else:
                                            value = districtQ['_id']
                                        
                                elif column in date_columns:
                                    try:
                                        if column == 'Date of Birth':
                                            if pd.isna(value):
                                                value = '-'
                                        if column == 'Forwarding Date to Bank':
                                            if pd.isna(value):
                                                value = '-'
                                        if pd.isna(value) or (isinstance(value, str) and not value.strip()):
                                            continue
                                        if column in ['Online Submission Date', 'Date of Birth']:  
                                            if pd.isna(value) or (isinstance(value, str) and not value.strip()): 
                                                status = False
                                                code = 4811
                                                message = f"Value at row {index + 2} is '{value}' in '{column}' column is not of a non-empty string data type."
                                                error_list.append(message)

                                            if column not in ['Date of Birth']:
                                                value = int(datetime.datetime.strptime(str(value), date_format).timestamp() * 1000 * 1000)
                                        elif value == '-':
                                            value = value   
                                        else:
                                            if not isinstance(value, str):
                                                value = value.strftime(date_format)
                                            value = int(datetime.datetime.strptime(str(value), date_format).timestamp() * 1000 * 1000)
                                            if column == 'Sanctioned Date by Bank':
                                                xSanctionedDate = value
                                            elif column == 'Date of Loan Release':
                                                xLoanReleaseDate = value

                                        if column in ['Date of Birth']:
                                            if not value or value == '-':
                                                value = value
                                            else:
                                                value = str(value)
                                                try:
                                                    dateObj = datetime.datetime.strptime(value, date_format)
                                                    value = dateObj.strftime('%Y-%m-%d')
                                                except:
                                                    code = 4597
                                                    message = 'Invalid Date of Birth in row {}'.format(index+2)
                                                    error_list.append(message)
                                        
                                    except ValueError as e:
                                        status = False
                                        code = 3071
                                        message = f"Value at row {index + 2} is '{value}' in '{column}' column is not in the expected format."
                                        error_list.append(message)
                                    
                                elif column in int_columns:
                                    if column in ['Proposed Project Cost']:
                                        if not (isinstance(value, int) or isinstance(value, float)) or value is None:
                                            status = False
                                            code = 3571
                                            message = (f"Value at row '{index + 2}' is '{value}' in '{column}' column which is not of non empty string data type")
                                            error_list.append(message)
                                        
                                    elif column in ['Mobile No.', 'Alternative Mobile No']:
                                        continue
                                    elif column == 'MM Release Amount':
                                        if not isinstance(value, int):
                                            value = 0
                                    elif column not in ['Own Contribution amount Deposited', 'Loan Release Amount', 'Duration of Training', 'Age']:  
                                        if not (isinstance(value, int) or isinstance(value, float)) or value is None:
                                            status = False
                                            code = 4471
                                            message = (f"Value at row '{index + 2}' is '{value}' in '{column}' column which is not of non empty string data type")
                                            error_list.append(message)
                                    if value == '-':
                                        value = value
                                    if column == 'Loan Release Amount':
                                        if not (isinstance(value, int) or isinstance(value, float)) or value is None:
                                            xLoanReleaseAmount = 0
                                        else:
                                            xLoanReleaseAmount = value
                                    if column == 'Total Sanctioned Amount by Bank':
                                        if not (isinstance(value, int) or isinstance(value, float)) or value is None:
                                            xSanctionedAmount = 0
                                        else:
                                            xSanctionedAmount = value
                
                                rmSpcChar = re.sub(r'[^a-zA-Z0-9 ]', '', column)
                                words = rmSpcChar.split()
                                camelCaseStr = words[0].lower() + ''.join(word.title() for word in words[1:])

                                data_dict[camelCaseStr] = value
                            if not xSanctionedAmount:
                                if data_dict.get('currentStatus') in ['Onhold/Discontinued', 'Disbursed', 'Copayment', 'Construction Completed']:
                                    code = 4074
                                    message = 'Total Sanctioned Amount By Bank can not be Zero for row {} as the Current Status is already {}'.format(index+2, (data_dict.get('currentStatus')))
                                    error_list.append(message)
                            if xSanctionedAmount:                              
                                if not xSanctionedDate:
                                    code = 4223
                                    message = 'Sanctioned Date by Bank can not be empty for row {}'.format(index+2)
                                    error_list.append(message)

                            if xLoanReleaseAmount:
                                if xLoanReleaseDate <= 0:
                                    code = 4995
                                    message = f'Please Enter Date of Loan Release for row {index + 2}'
                                    error_list.append(message)
                            elif not xLoanReleaseAmount:
                                if xLoanReleaseDate > 0:
                                    code = 4109
                                    message = f'Please Enter Loan Release Amount for row {index + 2}'
                                    error_list.append(message)
                            
                            if xLoanReleaseAmount > xSanctionedAmount:
                                code = 4962
                                message = f'Total Sanctioned amount by Bank should be more than Loan Release Amount in row {index+2}'
                                error_list.append(message)

                            if xLoanReleaseDate != 0 and xLoanReleaseDate < xSanctionedDate:
                                code = 4993
                                message = f'Date of Loan Release should be After Total Sanctioned Date of row {index+2}'
                                error_list.append(message)
                            
                            if xLoanReleaseDate > timeNow():
                                code = 4352
                                message = f'Date of Loan Release should be Before Current Date of row {index+2}'
                                error_list.append(message)

                            statusLogFind = self.loanStatusLog.aggregate(
                                [
                                    {
                                        '$match': {
                                            'applicantId': xApplicationId
                                        }
                                    },
                                    {
                                        '$addFields': {
                                            'disbursedAmounts': '$disbursed.disbursedInfo.amount'
                                        }
                                    },
                                    {
                                        '$unwind': '$disbursedAmounts'
                                    },
                                    {
                                        '$unwind': '$disbursedAmounts'
                                    },
                                    {
                                        '$project': {
                                            'disbursedAmounts': 1
                                        }
                                    }
                                ]
                            )
                            try:
                                async for i in statusLogFind:
                                    xTotalDisbursedAmount += i.get('disbursedAmounts', 0)
                            except Exception as e:
                                # Log the exception if necessary
                                print(f"An error occurred while processing statusLogFind: {e}")
                                xTotalDisbursedAmount = 0

                            xActualLoanReleaseAmt = xLoanReleaseAmount - xTotalDisbursedAmount
                            
                            if xActualLoanReleaseAmt < 0:
                                code = 4356
                                message = f'Loan Release amount in row {index+2} should be greater than {xTotalDisbursedAmount} as it is already disbursed.'
                                error_list.append(message)

                            if xActualLoanReleaseAmt > (xSanctionedAmount - xTotalDisbursedAmount):
                                if xTotalDisbursedAmount > 0 and xSanctionedAmount <= 0:
                                    code = 4390
                                    message = f'Total Sanctioned Amount by Bank cannot be zero for row {index+2} as it has already disbursed some amount.'
                                    error_list.append(message)
                                else:
                                    code = 4310
                                    message = f'You can add Loan Release Amount up to {xSanctionedAmount - xTotalDisbursedAmount} for row {index+2}.'
                                    error_list.append(message)

                            if data_dict.get('legalStatus').strip().lower() == 'individual':
                                if not data_dict.get('dateOfBirth') or data_dict.get('dateOfBirth') == '-':
                                    code = 4392
                                    message = 'Date of Birth can not be empty for {}'.format(index+2)
                                    error_list.append(message)

                            if type(data_dict.get('age')) != int and data_dict.get('dateOfBirth') and data_dict.get('dateOfBirth') != '-':
                                mDOB = int(datetime.datetime.strptime(str(data_dict.get('dateOfBirth')), '%Y-%m-%d').timestamp() * 1000 * 1000)
                                mAge = age_calculate(mDOB)
                                data_dict['age'] = mAge
                            else:
                                if pd.isna(data_dict.get('age')):
                                    data_dict['age'] = '-'

                            xBankAddress = data_dict.get('financingBranchAddress')
                            xBankBranch = ('').join(xBankAddress.split(',')[1:2]).strip().title()
                            xFindBranch = await findData(self.bankBranch, 'branchName', xBankBranch)
                            if not xFindBranch:
                                xBankBranch = ('').join(xBankAddress.split(',')[2:3]).strip().title()
                                xFindBranch = await findData(self.bankBranch, 'branchName', xBankBranch)
                    
                            if xFindBranch:
                                xBranchId = xFindBranch.get('_id')
                                data_dict['isUnknownBranch'] = False
                            else:
                                xFindBranch = await findData(self.bankBranch, 'branchName', 'Unknown Branch')
                                xBranchId = xFindBranch.get('_id')
                                data_dict['isUnknownBranch'] = True
                            data_dict['bankBranch'] = xBranchId
                                                        
                            data_array.append(data_dict)

                        if len(error_list):
                            code = 4690
                            message = 'Please correct the following issues'
                            result.append(error_list)
                            raise Exception

                        uPath = self.fu.uploads
                        uPath =  uPath + 'rc-homestay' + '/excel/'
                        mTimeNow = str(timeNow())
                        mFileName, mExt = os.path.splitext(file_name)
                        mFileName = ''.join(e for e in mFileName if e.isalnum())
                        file_name = mFileName + '_' + mTimeNow + mExt

                        if not os.path.exists(uPath):
                            os.system('mkdir -p ' + uPath)
                            os.system('chmod 755 -R ' + uPath)
                            Log.i('File directory created {}'.format(uPath))
            
                        with open(uPath + file_name, 'wb') as f:
                            f.write(file_data.body)
                            f.close()

                        root_name, extension = os.path.splitext(file_name)                    
                        file_metadata = {
                            'createdBy': self.accountId,
                            'createdAt': timeNow(),
                            'fileName': root_name,
                            'extension': file_extension[1:]
                        }
                        update = True
                        inserted = True
                        xLoanReleaseDate = timeNow()
                        for record in data_array:
                            mTotalDisbursementCount = 0
                            xTotalDisbursedAmount = 0
                            applicant_id = str(record.get('applicantId'))
                            existing_record = await self.loanApplication.find_one({'applicantId': applicant_id})
                            del record['applicantId']
                            record['mobileNo'] = None
                            record['alternativeMobileNo'] = None
                            record['isRecommended'] = False
                            
                            if type(record.get('loanReleaseAmount')) == int and record.get('loanReleaseAmount') > 0:
                                record['currentStatus'] = 'Disbursed'
                                xLoanReleaseAmount = record.get('loanReleaseAmount')
                                xLoanReleaseDate = record.get('dateOfLoanRelease') 
                            xFirstDisbursedDate = xLoanReleaseDate
                            if record.get('currentStatus') in ['-']:
                                record['currentStatus'] = 'Online Submitted'

                            if existing_record:
                                record['unitDistrict'] = existing_record.get('data').get('unitDistrict')
                                record['talukblock'] = existing_record.get('data').get('talukblock')
                                record['isUnknownBlock'] = existing_record.get('data').get('isUnknownBlock')
                                record['isRecommended'] = existing_record.get('data').get('isRecommended')

                                if (existing_record.get('data').get('totalSanctionedAmountByBank',0) or 0) > 0:
                                    record['totalSanctionedAmountByBank'] = existing_record.get('data').get('totalSanctionedAmountByBank')
                                if (existing_record.get('data').get('sanctionedDateByBank') or 0) > 0:
                                    record['sanctionedDateByBank'] = existing_record.get('data').get('sanctionedDateByBank')
                                

                            if type(record.get('sanctionedDateByBank')) != int or record.get('sanctionedDateByBank') <= 0:
                                if existing_record:
                                    record['sanctionedDateByBank'] = existing_record.get('data').get('sanctionedDateByBank')
                                else:
                                    record['sanctionedDateByBank'] = timeNow()
                            
                            mStatus = record.get('currentStatus')
                            trainingObj = {}
                            mSlno = 0
                            disbHistory = []
                            if mStatus == 'Disbursed':
                                findAllDisbursements = self.loanStatusLog.aggregate(
                                    [
                                        {
                                            '$match': {
                                                'applicantId': applicant_id
                                            }
                                        },
                                        {
                                            '$addFields': {
                                                'date': '$disbursed.disbursedInfo.date',
                                                'amount': '$disbursed.disbursedInfo.amount'
                                            }
                                        },
                                        {
                                            '$project': {
                                                'amount': 1,
                                                'date': 1
                                            }
                                        }
                                    ]
                                )
                                async for i in findAllDisbursements:
                                    try:
                                        if i.get('date'):
                                            for x, eachDateArray in enumerate(i.get('date')):
                                                for no, recordDate in enumerate(eachDateArray):
                                                    disbHistory.append(
                                                        {
                                                            'date': recordDate,
                                                            'amount': i.get('amount')[x][no]
                                                        }
                                                    )
                                    except Exception as e:
                                        Log.i(e)
                                
                                alreadyDisbursed = False
                                if len(disbHistory):
                                    for i in disbHistory:
                                        if i.get('date') == xLoanReleaseDate:
                                            if i.get('amount') == xLoanReleaseAmount:
                                                alreadyDisbursed = True
                            if mStatus == 'Rejected/Returned':
                                statusLogFind = self.loanStatusLog.aggregate(
                                    [
                                        {
                                            '$match': {
                                                'applicantId': applicant_id
                                            }
                                        },
                                        {
                                            '$addFields': {
                                                'rejectedInfo': {
                                                    '$last': '$rejected'
                                                }
                                            }
                                        },
                                        {
                                            '$project': {
                                                'applicantId': 1,
                                                'rejectedInfo': 1
                                            }
                                        }
                                    ]
                                )
                                try:
                                    async for i in statusLogFind:
                                        mSlno = i.get('rejectedInfo').get('slNo')
                                except:
                                    mSlno = 0

                                xBankRemarkNo = None
                                # xReasonFind = self.rejectionReasons.aggregate(
                                #     [
                                #         {
                                #             '$addFields': {
                                #                 'lowerRemark': {
                                #                     '$toLower': '$_id'
                                #                 }
                                #             }
                                #         },
                                #         {
                                #             '$match': {
                                #                 'lowerRemark': record.get('bankRemarks').lower()
                                #             }
                                #         }
                                #     ]
                                # )
                                zReasonFind = await self.rejectionReasons.find_one(
                                    {
                                        '_id': record.get('bankRemarks')
                                    },
                                    {
                                        'reason': 1
                                    }
                                )
                                if zReasonFind:
                                    if zReasonFind.get('reason') == 'Other':
                                        xReason = 'Other'
                                        xBankRemarkNo = record.get('bankRemarkNo')
                                    else:
                                        xReason = zReasonFind.get('reason')                                   
                                    
                                if not existing_record:
                                    statusObj = {
                                        'applicantId': applicant_id,
                                        'rejected': [
                                                {
                                                'slNo': mSlno+1,
                                                'currentStatus': mStatus,
                                                'reason': xReason,
                                                'bankRemarkNo': xBankRemarkNo,
                                                'comment': 'Status changed during excel upload',
                                                'modifiedBy': self.accountId,
                                                'modifiedAt': timeNow()
                                            }
                                        ]
                                    }
                                else:
                                    if existing_record.get('data').get('currentStatus') in ['Onhold/Discontinued', 'Disbursed', 'Copayment', 'Construction Completed', 'Loan Sanctioned']:
                                        record['currentStatus'] = existing_record.get('data').get('currentStatus')
                                    statusObj = {
                                        'rejected': {
                                            'slNo': mSlno+1,
                                            'currentStatus': mStatus,
                                            'reason': xReason,
                                            'bankRemarkNo': xBankRemarkNo,
                                            'comment': 'Status changed during excel upload',
                                            'modifiedBy': self.accountId,
                                            'modifiedAt': timeNow()
                                        }
                                    }

                            elif mStatus == 'Onhold/Discontinued':
                                statusLogFind = self.loanStatusLog.aggregate(
                                    [
                                        {
                                            '$match': {
                                                'applicantId': applicant_id
                                            }
                                        },
                                        {
                                            '$addFields': {
                                                'onHoldInfo': {
                                                    '$last': '$onHold'
                                                }
                                            }
                                        },
                                        {
                                            '$project': {
                                                'onHoldInfo': 1
                                            }
                                        }
                                    ]
                                )
                                try:
                                    async for i in statusLogFind:
                                        mSlno = i.get('onHoldInfo').get('slNo')
                                except:
                                    mSlno = 0

                                if not existing_record:
                                    statusObj = {
                                        'applicantId': applicant_id,
                                        'onHold': [
                                                {
                                                'slNo': mSlno+1,
                                                'currentStatus': mStatus,
                                                'comment': 'Status changed during excel upload',
                                                'modifiedBy': self.accountId,
                                                'modifiedAt': timeNow()
                                            }
                                        ]
                                    }
                                else:
                                    statusObj = {
                                        'onHold': {
                                            'slNo': mSlno+1,
                                            'currentStatus': mStatus,
                                            'comment': 'Status changed during excel upload',
                                            'modifiedBy': self.accountId,
                                            'modifiedAt': timeNow()
                                        }
                                    }

                                trainingObj = {
                                    'applicantId': applicant_id,
                                    'applicantName': record.get('applicantName'),
                                    'talukblock': record.get('talukblock'),
                                    'unitDistrict': record.get('unitDistrict'),
                                    'uploadMedium': 'Excel',
                                    'trainingStatus': 'Pending',
                                    'createdAt': timeNow(),
                                    'createdBy': self.accountId
                                }
                                                                
                            elif mStatus == 'Disbursed':
                                statusLogFind = self.loanStatusLog.aggregate(
                                    [
                                        {
                                            '$match': {
                                                'applicantId': applicant_id
                                            }
                                        },
                                        {
                                            '$addFields': {
                                                'disbursedDates': '$disbursed.disbursedInfo.date'
                                            }
                                        },
                                        {
                                            '$addFields': {
                                                'lastDisbursedInfo': {
                                                    '$last': '$disbursed'
                                                }
                                            }
                                        },
                                        {
                                            '$addFields': {
                                                'firstDisbursedInfo': {
                                                    '$first': '$disbursed'
                                                }
                                            }
                                        },
                                        {
                                            '$addFields': {
                                                'firstDisbursedDate': {
                                                    '$first': '$firstDisbursedInfo.disbursedInfo'
                                                }
                                            }
                                        },
                                        {
                                            '$addFields': {
                                                'disbursedAmounts': '$disbursed.disbursedInfo.amount'
                                            }
                                        },
                                        {
                                            '$unwind': '$disbursedAmounts'
                                        },
                                        {
                                            '$unwind': '$disbursedAmounts'
                                        },
                                        {
                                            '$project': {
                                                'lastDisbursedInfo': 1,
                                                'firstDisbursedDate': 1,
                                                'disbursedDates': 1,
                                                'disbursedAmounts': 1
                                            }
                                        }
                                    ]
                                )
                                try:
                                    async for i in statusLogFind:
                                        xTotalDisbursedAmount += i.get('disbursedAmounts')
                                        mTotalDisbursementCount += 1
                                        xFirstDisbursedDate = i.get('firstDisbursedDate').get('date')
                                        mSlno = i.get('lastDisbursedInfo').get('slNo')
                                except:
                                    mSlno = 0
                                xActualLoanReleaseAmt = xLoanReleaseAmount - xTotalDisbursedAmount 
                                if not existing_record:
                                    statusObj = {
                                        'applicantId': applicant_id,
                                        'disbursed': [
                                                {
                                                'slNo': mSlno+1,
                                                'currentStatus': mStatus,
                                                'disbursedInfo': [
                                                    {
                                                        'amount': xLoanReleaseAmount,
                                                        'date': xLoanReleaseDate
                                                    }
                                                ],
                                                'effectiveDate': xFirstDisbursedDate,
                                                'comment': 'Status changed during excel upload',
                                                'modifiedBy': self.accountId,
                                                'modifiedAt': timeNow()
                                            }
                                        ]
                                    }
                                else:
                                    if existing_record.get('data').get('currentStatus') in ['Onhold/Discontinued', 'Disbursed', 'Copayment', 'Construction Completed']:
                                        record['currentStatus'] = existing_record.get('data').get('currentStatus')
                                    statusObj = {
                                        'disbursed': {
                                            'slNo': mSlno+1,
                                            'currentStatus': mStatus,
                                            'disbursedInfo': [
                                                {
                                                    'amount': xActualLoanReleaseAmt,
                                                    'date': xLoanReleaseDate
                                                }
                                            ],
                                            'effectiveDate': xFirstDisbursedDate,
                                            'comment': 'Status changed during excel upload',
                                            'modifiedBy': self.accountId,
                                            'modifiedAt': timeNow()
                                        }
                                    }
                                    if mTotalDisbursementCount == 5 and xActualLoanReleaseAmt + xTotalDisbursedAmount != xSanctionedAmount:
                                        code = 4543
                                        message = 'Total disbursed amount should be equal to Sanctioned amount.'
                                        raise Exception
                                    
                                    if alreadyDisbursed or mTotalDisbursementCount >= 6 or xActualLoanReleaseAmt <= 0:
                                        statusObj = {}
                                
                                trainingObj = {
                                    'applicantId': applicant_id,
                                    'applicantName': record.get('applicantName'),
                                    'talukblock': record.get('talukblock'),
                                    'unitDistrict': record.get('unitDistrict'),
                                    'uploadMedium': 'Excel',
                                    'trainingStatus': 'Pending',
                                    'createdAt': timeNow(),
                                    'createdBy': self.accountId
                                }

                            elif mStatus == 'Copayment':
                                statusLogFind = self.loanStatusLog.aggregate(
                                    [
                                        {
                                            '$match': {
                                                'applicantId': applicant_id
                                            }
                                        },
                                        {
                                            '$addFields': {
                                                'copaymentInfo': {
                                                    '$last': '$copayment'
                                                }
                                            }
                                        },
                                        {
                                            '$project': {
                                                'copaymentInfo': 1
                                            }
                                        }
                                    ]
                                )
                                try:
                                    async for i in statusLogFind:
                                        mSlno = i.get('copaymentInfo').get('slNo')
                                except:
                                    mSlno = 0
                                
                                if not existing_record:
                                    statusObj = {
                                        'applicantId': applicant_id,
                                        'copayment': [
                                                {
                                                'slNo': mSlno+1,
                                                'currentStatus': mStatus,
                                                'comment': 'Status changed during excel upload',
                                                'modifiedBy': self.accountId,
                                                'modifiedAt': timeNow()
                                            }
                                        ]
                                    }
                                else:
                                    if existing_record.get('data').get('currentStatus') in ['Onhold/Discontinued', 'Copayment']:
                                        record['currentStatus'] = existing_record.get('data').get('currentStatus')
                                    statusObj = {
                                        'copayment': {
                                            'slNo': mSlno+1,
                                            'currentStatus': mStatus,
                                            'comment': 'Status changed during excel upload',
                                            'modifiedBy': self.accountId,
                                            'modifiedAt': timeNow()
                                        }
                                    }
                                
                                trainingObj = {
                                    'applicantId': applicant_id,
                                    'applicantName': record.get('applicantName'),
                                    'talukblock': record.get('talukblock'),
                                    'unitDistrict': record.get('unitDistrict'),
                                    'uploadMedium': 'Excel',
                                    'trainingStatus': 'Pending',
                                    'createdAt': timeNow(),
                                    'createdBy': self.accountId
                                }
                            
                            elif mStatus == 'Online Submitted':
                                statusLogFind = self.loanStatusLog.aggregate(
                                    [
                                        {
                                            '$match': {
                                                'applicantId': applicant_id
                                            }
                                        },
                                        {
                                            '$addFields': {
                                                'onlineSubmittedInfo': {
                                                    '$last': '$onlineSubmitted'
                                                }
                                            }
                                        },
                                        {
                                            '$project': {
                                                'onlineSubmittedInfo': 1
                                            }
                                        }
                                    ]
                                )
                                try:
                                    async for i in statusLogFind:
                                        mSlno = i.get('onlineSubmittedInfo').get('slNo')
                                except:
                                    mSlno = 0
                                
                                if not existing_record:
                                    statusObj = {
                                        'applicantId': applicant_id,
                                        'onlineSubmitted': [
                                                {
                                                'slNo': mSlno+1,
                                                'currentStatus': mStatus,
                                                'comment': 'Status changed during excel upload',
                                                'modifiedBy': self.accountId,
                                                'modifiedAt': timeNow()
                                            }
                                        ]
                                    }
                                else:
                                    if existing_record.get('data').get('currentStatus') in ['Onhold/Discontinued', 'Disbursed', 'Copayment', 'Loan Sanctioned', 'Construction Completed', 'Under Process (At Agency)', 'Under Process (At Bank)']:
                                        record['currentStatus'] = existing_record.get('data').get('currentStatus')
                                    statusObj = {
                                        'onlineSubmitted': {
                                            'slNo': mSlno+1,
                                            'currentStatus': mStatus,
                                            'comment': 'Status changed during excel upload',
                                            'modifiedBy': self.accountId,
                                            'modifiedAt': timeNow()
                                        }
                                    }

                            elif mStatus == 'Under Process (At Agency)':

                                statusLogFind = self.loanStatusLog.aggregate(
                                    [
                                        {
                                            '$match': {
                                                'applicantId': applicant_id
                                            }
                                        },
                                        {
                                            '$addFields': {
                                                'processedInfo': {
                                                    '$last': '$processedAtAgency'
                                                }
                                            }
                                        },
                                        {
                                            '$project': {
                                                'processedInfo': 1
                                            }
                                        }
                                    ]
                                )
                                try:
                                    async for i in statusLogFind:
                                        mSlno = i.get('processedInfo').get('slNo')
                                except:
                                    mSlno = 0
                                if not existing_record:
                                    statusObj = {
                                        'applicantId': applicant_id,
                                        'processedAtAgency': [
                                                {
                                                'slNo': mSlno+1,
                                                'currentStatus': mStatus,
                                                'comment': 'Status changed during excel upload',
                                                'modifiedBy': self.accountId,
                                                'modifiedAt': timeNow()
                                            }
                                        ]
                                    }
                                else:
                                    if existing_record.get('data').get('currentStatus') in ['Onhold/Discontinued', 'Disbursed', 'Copayment', 'Loan Sanctioned', 'Construction Completed', 'Under Process (At Agency)', 'Under Process (At Bank)']:
                                        record['currentStatus'] = existing_record.get('data').get('currentStatus')
                                    statusObj = {
                                        'processedAtAgency': {
                                            'slNo': mSlno+1,
                                            'currentStatus': mStatus,
                                            'comment': 'Status changed during excel upload',
                                            'modifiedBy': self.accountId,
                                            'modifiedAt': timeNow()
                                        }
                                    }

                            elif mStatus == 'Under Process (At Bank)':

                                statusLogFind = self.loanStatusLog.aggregate(
                                    [
                                        {
                                            '$match': {
                                                'applicantId': applicant_id
                                            }
                                        },
                                        {
                                            '$addFields': {
                                                'processedInfo': {
                                                    '$last': '$processedAtBank'
                                                }
                                            }
                                        },
                                        {
                                            '$project': {
                                                'processedInfo': 1
                                            }
                                        }
                                    ]
                                )
                                try:
                                    async for i in statusLogFind:
                                        mSlno = i.get('processedInfo').get('slNo')
                                except:
                                    mSlno = 0
                                if not existing_record:
                                    statusObj = {
                                        'applicantId': applicant_id,
                                        'processedAtBank': [
                                                {
                                                'slNo': mSlno+1,
                                                'currentStatus': mStatus,
                                                'comment': 'Status changed during excel upload',
                                                'modifiedBy': self.accountId,
                                                'modifiedAt': timeNow()
                                            }
                                        ]
                                    }
                                else:
                                    if existing_record.get('data').get('currentStatus') in ['Onhold/Discontinued', 'Disbursed', 'Copayment', 'Loan Sanctioned', 'Construction Completed', 'Under Process (At Bank)']:
                                        record['currentStatus'] = existing_record.get('data').get('currentStatus')
                                    statusObj = {
                                        'processedAtBank': {
                                            'slNo': mSlno+1,
                                            'currentStatus': mStatus,
                                            'comment': 'Status changed during excel upload',
                                            'modifiedBy': self.accountId,
                                            'modifiedAt': timeNow()
                                        }
                                    }
                            
                            elif mStatus == 'Loan Sanctioned':

                                statusLogFind = self.loanStatusLog.aggregate(
                                    [
                                        {
                                            '$match': {
                                                'applicantId': applicant_id
                                            }
                                        },
                                        {
                                            '$addFields': {
                                                'sanctionedInfo': {
                                                    '$last': '$sanctioned'
                                                }
                                            }
                                        },
                                        {
                                            '$project': {
                                                'sanctionedInfo': 1
                                            }
                                        }
                                    ]
                                )
                                try:
                                    async for i in statusLogFind:
                                        mSlno = i.get('sanctionedInfo').get('slNo')
                                except:
                                    mSlno = 0
                                if not existing_record:
                                    statusObj = {
                                        'applicantId': applicant_id,
                                        'sanctioned': [
                                                {
                                                'slNo': mSlno+1,
                                                'currentStatus': mStatus,
                                                'comment': 'Status changed during excel upload',
                                                'modifiedBy': self.accountId,
                                                'modifiedAt': timeNow()
                                            }
                                        ]
                                    }
                                else:
                                    if existing_record.get('data').get('currentStatus') in ['Onhold/Discontinued', 'Disbursed', 'Copayment', 'Loan Sanctioned', 'Construction Completed']:
                                        record['currentStatus'] = existing_record.get('data').get('currentStatus')
                                    statusObj = {
                                        'sanctioned': {
                                            'slNo': mSlno+1,
                                            'currentStatus': mStatus,
                                            'comment': 'Status changed during excel upload',
                                            'modifiedBy': self.accountId,
                                            'modifiedAt': timeNow()
                                        }
                                    }    

                                trainingObj = {
                                    'applicantId': applicant_id,
                                    'applicantName': record.get('applicantName'),
                                    'talukblock': record.get('talukblock'),
                                    'unitDistrict': record.get('unitDistrict'),
                                    'uploadMedium': 'Excel',
                                    'trainingStatus': 'Pending',
                                    'createdAt': timeNow(),
                                    'createdBy': self.accountId
                                }                          
                                
                            elif mStatus == 'Construction Completed':

                                statusLogFind = self.loanStatusLog.aggregate(
                                    [
                                        {
                                            '$match': {
                                                'applicantId': applicant_id
                                            }
                                        },
                                        {
                                            '$addFields': {
                                                'constCompletedInfo': {
                                                    '$last': '$constCompleted'
                                                }
                                            }
                                        },
                                        {
                                            '$project': {
                                                'constCompletedInfo': 1
                                            }
                                        }
                                    ]
                                )
                                try:
                                    async for i in statusLogFind:
                                        mSlno = i.get('constCompletedInfo').get('slNo')
                                except:
                                    mSlno = 0

                                if not existing_record:
                                    statusObj = {
                                        'applicantId': applicant_id,
                                        'constCompleted': [
                                                {
                                                'slNo': mSlno+1,
                                                'currentStatus': mStatus,
                                                'comment': 'Status changed during excel upload',
                                                'modifiedBy': self.accountId,
                                                'modifiedAt': timeNow()
                                            }
                                        ]
                                    }
                                else:
                                    if existing_record.get('data').get('currentStatus') in ['Onhold/Discontinued', 'Copayment', 'Construction Completed']:
                                        record['currentStatus'] = existing_record.get('data').get('currentStatus')
                                    statusObj = {
                                        'constCompleted': {
                                            'slNo': mSlno+1,
                                            'currentStatus': mStatus,
                                            'comment': 'Status changed during excel upload',
                                            'modifiedBy': self.accountId,
                                            'modifiedAt': timeNow()
                                        }
                                    }

                                trainingObj = {
                                    'applicantId': applicant_id,
                                    'applicantName': record.get('applicantName'),
                                    'talukblock': record.get('talukblock'),
                                    'unitDistrict': record.get('unitDistrict'),
                                    'uploadMedium': 'Excel',
                                    'trainingStatus': 'Pending',
                                    'createdAt': timeNow(),
                                    'createdBy': self.accountId
                                }

                            else:
                                statusLogFind = self.loanStatusLog.aggregate(
                                    [
                                        {
                                            '$match': {
                                                'applicantId': applicant_id
                                            }
                                        },
                                        {
                                            '$addFields': {
                                                'othersInfo': {
                                                    '$last': '$others'
                                                }
                                            }
                                        },
                                        {
                                            '$project': {
                                                'othersInfo': 1
                                            }
                                        }
                                    ]
                                )
                                try:
                                    async for i in statusLogFind:
                                        mSlno = i.get('othersInfo').get('slNo')
                                except:
                                    mSlno = 0

                                if not existing_record:
                                    statusObj = {
                                        'applicantId': applicant_id,
                                        'others': [
                                                {
                                                'slNo': mSlno+1,
                                                'currentStatus': mStatus,
                                                'comment': 'Status changed during excel upload',
                                                'modifiedBy': self.accountId,
                                                'modifiedAt': timeNow()
                                            }
                                        ]
                                    }
                                else:
                                    statusObj = {
                                        'others': {
                                            'slNo': mSlno+1,
                                            'currentStatus': mStatus,
                                            'comment': 'Status changed during excel upload',
                                            'modifiedBy': self.accountId,
                                            'modifiedAt': timeNow()
                                        }
                                    }
                                    
                            if existing_record:
                                if update == True:
                                    fileQ = await self.uploadFileDetails.insert_one(file_metadata)
                                    if not fileQ.inserted_id:   
                                        message = "File could not be Submitted."
                                        code = 4987
                                        status = False
                                        raise Exception    
                                update = False
                                loanQ = await self.loanApplication.update_one(
                                    {'applicantId': applicant_id},
                                    {
                                        '$set': {
                                            'modifiedBy': self.accountId,
                                            'modifiedAt': timeNow(),
                                            'data': record
                                        }
                                    }
                                )
                                statusUpload = await self.loanStatusLog.update_one(
                                    {
                                        'applicantId': applicant_id
                                    },
                                    {
                                        '$push': statusObj
                                    }
                                )
                                if statusUpload.modified_count:
                                    code = 2000
                                    status = True
                                    message = 'Status updated'
                                else:
                                    code = 4015
                                    message = 'Status Could not updated'

                                if trainingObj:
                                    mFindTraining = await self.trainingStatus.find_one(
                                        {
                                            'loanApplicationId': existing_record.get('_id')
                                        }
                                    )
                                    if not mFindTraining:
                                        trainingObj['loanApplicationId'] = existing_record.get('_id')
                                        mInsertTraining = await self.trainingStatus.insert_one(trainingObj)

                                        if mInsertTraining.inserted_id:
                                            code = 2000
                                            status = True
                                            message = 'Training details inserted'
                                        else:
                                            code = 4497
                                            message = 'Training details not inserted'
                                            raise Exception
                                    else:
                                        mUpdateTrainingDetails = await self.trainingStatus.update_one(
                                            {
                                                '_id': mFindTraining.get('_id')
                                            },
                                            {
                                                '$set': {
                                                    'applicantName': record.get('applicantName'),
                                                    'talukblock': record.get('talukblock'),
                                                    'unitDistrict': record.get('unitDistrict')
                                                }
                                            }
                                        )
                                        if mUpdateTrainingDetails.modified_count:
                                            code = 2000
                                            status = True
                                        else:
                                            code = 4103
                                            message = 'Training details not updated'
                                if loanQ:
                                    message = "Data updated successfully."
                                    code = 2000
                                    status = True
                                else:
                                    message = "Data could not be updated."
                                    code = 4409
                                    status = False
                                    raise Exception
                                
                            else: 
                                new_record = {
                                    'applicantId': applicant_id,
                                    'createdBy': self.accountId,
                                    'createdAt': timeNow(),
                                    'data': record
                                }

                                if update == True:
                                    fileQ = await self.uploadFileDetails.insert_one(file_metadata)
                                    if not fileQ.inserted_id:   
                                        message = "File could not be Submitted."
                                        code = 4560
                                        status = False
                                        raise Exception    
                                update = False
                                if inserted == True:
                                    vLoan = await self.loanApplication.insert_one(new_record)
                                                            
                                    statusObj['loanApplicationId'] = vLoan.inserted_id
                                    statusUpload = await self.loanStatusLog.insert_one(statusObj)
                                    if statusUpload.inserted_id:
                                        code = 2000
                                        status = True
                                        message = 'Status inserted'
                                    else:
                                        code = 4001
                                        message = 'Status not inserted'
                                        raise Exception
                                    
                                    if trainingObj:
                                        trainingObj['loanApplicationId'] = vLoan.inserted_id
                                        insertTraining = await self.trainingStatus.insert_one(trainingObj)

                                        if insertTraining.inserted_id:
                                            code = 2000
                                            status = True
                                        else:
                                            code = 4151
                                            message = 'Training details not inserted'
                                            raise Exception
                                    
                                    if vLoan:
                                        message = "Data submitted successfully."
                                        code = 2000
                                        status = True
                                    else:
                                        message = "Data could not be submitted."
                                        code = 4620
                                        status = False  
                                        raise Exception 
                                    
                             
                    except Exception as e :
                        exc_type, exc_obj, exc_tb = sys.exc_info()
                        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                        Log.d('FILE: ' + str(fname), 'LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
                        if not len(message):
                            code = 4210
                            template = "Exception: {0}. Argument: {1!r}"
                            Log.d(template.format(type(e).__name__, e.args))
                            message = 'Internal Error, Please Contact the Support Team.'
                        raise Exception

                else:
                    code = 4110
                    message = 'Method not supported.'
                    raise Exception
            else:
                message = 'Admin not found'
                code = 4222
                raise Exception
        except Exception as e:
            status = False
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(response)
            await self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            # self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return

    async def delete(self):
        status = False
        code = 4000
        result = []
        message = ''
        try:            
            try:
                fileId = str(self.request.arguments.get('id')[0].decode())
                if not fileId:
                    message = 'Missing Argument - [ id ].'
                    code = 4047
                    raise Exception
                fileId = ObjectId(fileId)
            except Exception as e:
                message = 'Invalid Argument - [ id ].'
                code = 4052
                raise Exception

            fileId = ObjectId(fileId)

            finFileQ = await self.loanApplication.find_one(
                {
                    '_id': fileId
                }
            )
            if finFileQ:
                delFileQ = await self.loanApplication.delete_one(
                    {
                        '_id': fileId
                    }
                )
                if delFileQ.deleted_count:
                    message = 'Data has been deleted.'
                    code = 2000
                    status = True
                else:
                    message = 'Data could not be deleted.'
                    code = 4001
                    status = False
            else:
                message = 'Data not found.'
                code = 4001
                status = False

        except Exception as e:
            status = False
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(response)
            await self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return
        
    async def put(self):
        code = 4000
        message = ''
        status = False
        result = []
        try:            
            try:
                # CONVERTS BODY INTO JSON
                self.request.arguments = json.loads(self.request.body.decode())
            except Exception as e:
                code = 4002
                message = 'Expected Request Type JSON.'
                raise Exception
            
            mId = self.request.arguments.get('id')
            code, message = Validate.i(
                mId,
                'id',
                dataType=str,
                notEmpty=True
            )
            if code != 4100:
                raise Exception

            try:
                mId = ObjectId(mId)
            except:
                code = 4079
                message = 'Invalid Argument - [ id ]'
                raise Exception

            mFindApplication = await self.loanApplication.find_one(
                {
                    '_id': mId
                }
            )
            if not mFindApplication:
                code = 4028
                message = 'Application Not Found'
                raise Exception

            mMethod = self.request.arguments.get('method')
            if mMethod:
                code, message = Validate.i(
                    mMethod,
                    'method',
                    dataType=int,
                    notEmpty=True,
                    enums=[1, 2]
                )
                if code != 4100:
                    raise Exception
            else:
                raise Exception
            
            if mMethod:
                if mMethod == 1:
                    mBranchId = self.request.arguments.get('branchId')
                    code, message = Validate.i(
                        mBranchId,
                        'branchId',
                        dataType=str,
                        notEmpty=True
                    )
                    if code != 4100:
                        raise Exception
                    try:
                        mBranchId = ObjectId(mBranchId)
                    except:
                        code = 4297
                        message = 'Invalid Argument - [ branchId ]'
                        raise Exception
                    
                    mBranchFind = await self.bankBranch.find_one(
                        {
                            '_id': mBranchId
                        }
                    )
                    if not mBranchFind:
                        code = 4507
                        message = 'Bank Branch not Found'
                        raise Exception
                    
                    mBranchUpdate = await self.loanApplication.update_one(
                        {
                            '_id': mId
                        },
                        {
                            '$set': {
                                'data.bankBranch': mBranchId,
                                'data.isUnknownBranch': False
                            }
                        }
                    )
                    if mBranchUpdate.modified_count:
                        code = 2000
                        status = True
                        message = 'Branch Updated'
                    else:
                        code = 4526
                        message = 'Branch Not Updated'
                        raise Exception

                elif mMethod == 2:
                    mBlockId = self.request.arguments.get('blockId')
                    code, message = Validate.i(
                        mBlockId,
                        'blockId',
                        dataType=str,
                        notEmpty=True
                    )
                    if code != 4100:
                        raise Exception
                    try:
                        mBlockId = ObjectId(mBlockId)
                    except:
                        code = 4210
                        message = 'Invalid Argument - [ blockId ]'
                        raise Exception
                    
                    mBlockFind = await self.block.find_one(
                        {
                            '_id': mBlockId
                        }
                    )
                    if not mBlockFind:
                        code = 4115
                        message = 'Block Not Found'
                        raise Exception
                    
                    mBlockUpdate = await self.loanApplication.update_one(
                        {
                            '_id': mId
                        },
                        {
                            '$set': {
                                'data.talukblock': mBlockId,
                                'data.isUnknownBlock': False
                            }
                        }
                    )
                    if mBlockUpdate.modified_count:
                        code = 2000
                        status = True
                        message = 'Block Updated'
                    else:
                        code = 4133
                        message = 'Block Not Updated'
                        raise Exception

        except Exception as e:
            status = False
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(response)
            await self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            # self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return
