#!/usr/bin/AdminListHandler
# -*- coding: utf-8 -*-

"""
    Description: AdminHandler
    Purpose: Get user list, add new user
"""
import json
import sys
import tornado.web
from abc import ABCMeta

from bson import ObjectId
from bson.json_util import dumps as bdumps

from build_config import CONFIG
from lib.element_mixer import ElementMixer
from lib.lib import Validate
from lib.xen_protocol import noXenSecureV2, xenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log
from util.time_util import timeNow


@xenSecureV2
class AdminUserInfoHandler(ElementMixer, MongoMixin, metaclass=ABCMeta):

    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]

    applications = MongoMixin.userDb[
        CONFIG['database'][0]['table'][1]['name']
    ]

    profile = MongoMixin.userDb[
        CONFIG['database'][0]['table'][2]['name']
    ]

    state = MongoMixin.userDb[
        CONFIG['database'][0]['table'][6]['name']
    ]

    countries = MongoMixin.userDb[
        CONFIG['database'][0]['table'][7]['name']
    ]

    phoneCountry = MongoMixin.userDb[
        CONFIG['database'][0]['table'][6]['name']
    ]

    componentId = ObjectId('63d38614458b78fdf4cf6bfa')

    async def get(self):

        code = 4000
        status = False
        message = ''
        result = []

        try:
            try:
                userId = str(self.request.arguments.get('id')[0].decode())
                if not userId:
                    message = 'Missing Argument - [ id ].'
                    code = 4047
                userId = ObjectId(userId)
            except Exception as e:
                message = 'Invalid Argument - [ id ].'
                code = 4052
                raise Exception

            adminListQ = self.profile.aggregate(
                [
                    {
                        '$lookup': {
                            'from': CONFIG['database'][0]['table'][0]['name'],
                            'localField': 'accountId',
                            'foreignField': '_id',
                            'as': 'accountInfo'
                        }
                    },
                    {
                        '$lookup': {
                            'from': CONFIG['database'][0]['table'][1]['name'],
                            'localField': 'applicationId',
                            'foreignField': '_id',
                            'as': 'applicationInfo'
                        }
                    },
                    {
                        '$match': {
                            '_id': userId
                        }
                    },
                    {
                        '$project': {
                            '_id': 1,
                            'applicationId': 1,

                            'accountInfo': {
                                '_id': 1,
                                'firstName': 1,
                                'lastName': 1,
                                'contact': 1,
                                'country': {
                                    'name': 1
                                }
                            },
                            'applicationInfo': {
                                'title': 1
                            }
                        }
                    }
                ]
            )
            async for i in adminListQ:
                i['id'] = str(i.get('_id'))
                del i['_id']
                result.append(i)

            if len(result):
                message = 'Data found.'
                code = 2000
                status = True
            else:
                code = 4091
                message = 'Account not found.'

        except Exception as e:
            status = False

            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))

        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)

        try:
            response['result'] = result
            self.write(bdumps(response))
            await self.finish()
            return

        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return