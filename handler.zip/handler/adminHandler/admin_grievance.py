#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
    Description: AdminGrievanceHandler
    Purpose: GET, POST Grievance
"""
import base36
import json
import mimetypes
import os
import sys

import tornado.web
from bson import ObjectId

from build_config import CONFIG
from lib.element_mixer import ElementMixer
from lib.lib import Validate
from lib.xen_protocol import xenSecureV2
from util.conn_util import MongoMixin
from util.file_util import FileUtil
from util.log_util import Log
from bson.json_util import dumps as bdumps

from util.time_util import timeNow


@xenSecureV2
class AdminGrievanceHandler(ElementMixer, MongoMixin):
    fu = FileUtil()

    grConversation = MongoMixin.userDb[
        CONFIG['database'][0]['table'][17]['name']
    ]

    componentId = ObjectId('63d38614458b78fdf4cf6bfa')

    async def get(self):
        code = 4000
        message = ''
        status = False
        result = []
        count = 0

        try:
            try:
                f_limit = int(self.get_arguments('limit')[0])
                f_skip = int(self.get_arguments('skip')[0])
            except Exception as e:
                f_limit = 10
                f_skip = 0

            totalCountQ = self.grConversation.find({})
            async for i in totalCountQ:
                count = count + 1
            getIssueListQ = self.grConversation.aggregate(
                [
                    {
                        '$lookup': {
                            'from': CONFIG['database'][0]['table'][0]['name'],
                            'localField': 'createdBy',
                            'foreignField': '_id',
                            'as': 'accountInfo'
                        }
                    },
                    {
                        '$project': {
                            'title': 1,
                            'description': 1,
                            'time': 1,
                            'entityId': 1,
                            'comments': 1,
                            'activity': 1,
                            'totalAttachments': 1,
                            'accountInfo': {
                                'firstName': 1,
                                'lastName': 1
                            }
                        }
                    },
                    {
                        '$sort': {
                            '_id': -1
                        }
                    },
                    {
                        '$skip': f_skip
                    },
                    {
                        '$limit': f_limit
                    },
                ]
            )
            async for i in getIssueListQ:
                i['id'] = str(i.get('_id'))
                i['grivId'] = base36.dumps(i.get('time')).upper()
                del i['_id']
                i['entityId'] = str(i.get('entityId'))
                result.append(i)
            if len(result):
                message = 'Data found.'
                code = 2000
                status = True
            else:
                message = 'No data found.'
                code = 4001

        except Exception as e:
            status = False
            # self.set_status(503)
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message,
            'count': count
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(bdumps(response))
            await self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            # self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return

    async def post(self):
        code = 4000
        message = ''
        status = False
        result = []
        try:
            try:
                file_dic = {}
                arg_dic = {}
                b = self.request.headers.get('Content-Type')
                tornado.httputil.parse_body_arguments(b, self.request.body, arg_dic, file_dic)
            except:
                code = 4323
                message = 'Expected request type form-data.'
                raise Exception

            #convId - conversation Id
            vconvId = self.get_arguments('convId') 
            if not len(vconvId):
                message = 'Missing Argument - [ convId ].'
                code = 4138
                raise Exception
            vconvId = vconvId[0]
            code, message = Validate.i(
                vconvId,
                'convId',
                notNull=True,
                notEmpty=True,
                dataType=str
            )
            if code != 4100:
                raise Exception
            vconvId = ObjectId(vconvId)

            try:
                vstatus = self.get_arguments('status')[0]
                if vstatus == None:
                    raise Exception
                if vstatus != None:
                    vstatus = int(vstatus)
            except Exception as e:
                message = 'Invalid Argument - [ status ].'
                code = 4169
                raise Exception
            code, message = Validate.i(
                vstatus,
                'status',
                notNull=True,
                notEmpty=True,
                dataType=int,
                enums=[0, 1, 2]
            )
            if code != 4100:
                raise Exception

            if vstatus == 0:
                statusMsg = 'Open'
            elif vstatus == 1:
                statusMsg = 'Close'
            elif vstatus == 2:
                statusMsg = 'Re-Open'
            else:
                statusMsg = ''

            vcomment = self.get_arguments('comment')
            if not len(vcomment):
                message = 'Missing Argument - [ comment ].'
                code = 4176
                raise Exception

            vcomment = vcomment[0]
            code, message = Validate.i(
                vcomment,
                'comment',
                notNull=True,
                notEmpty=True,
                dataType=str,
                minLength=5,
                maxLength=500
            )
            if code != 4100:
                raise Exception

            modifiedAt = timeNow()
            try:
                vfile = file_dic.get('attachment')
            except:
                vfile = None

            if vfile != None:
                vfile = vfile[0]
                vfileExt = vfile['content_type']
                ext = mimetypes.guess_extension(vfileExt)
                if ext not in ['.jpg', '.jpeg', '.png']:
                    message = 'Image file should be in jpg or png or jpeg format.'
                    code = 6997
                    raise Exception

                vfileSize = len(vfile['body'])
                size = (vfileSize / (1024 * 1024))
                if size > 2:
                    message = 'Maximum size of the attachment should be 2Mb.'
                    code = 5433
                    raise Exception
                fileName = str(modifiedAt) + ext
                vfileList = [{
                    'time': modifiedAt,
                    'mimeType': ext,
                }]
                uPath = self.fu.uploads + '/' + 'rc-homestay'
                if not os.path.exists(uPath):
                    os.system('mkdir -p ' + uPath)
                    os.system('chmod 755 -R ' + uPath)

                uPath = uPath + '/grievance/'
                if not os.path.exists(uPath):
                    os.system('mkdir -p ' + uPath)
                    os.system('chmod 755 -R ' + uPath)

                uPath = uPath + str(vconvId) + '/'
                if not os.path.exists(uPath):
                    os.system('mkdir -p ' + uPath)
                    os.system('chmod 755 -R ' + uPath)

                orgFile = open(uPath + fileName, 'wb')
                orgFile.write(vfile['body'])
                orgFile.close()
            else:
                vfileList = []

            findMsg = await self.grConversation.find_one(
                {
                    '_id': vconvId
                },
                {
                    '_id': 1,
                    'activity': 1
                }
            )
            if findMsg:
                actLen = len(findMsg['activity'])
                if vstatus != 2:
                    if (findMsg['activity'][actLen - 1]['id']) == 1:
                        code = 4209
                        message = 'Grievance conversation is closed.'
                        raise Exception

                pushObject = {
                    'comments': {
                        'text': vcomment,
                        'time': modifiedAt,
                        'statusMsg': statusMsg,
                        'accountId': self.accountId,
                        'attachmentInfo': vfileList
                    }
                }
                if findMsg['activity'][actLen - 1]['id'] != vstatus:
                    pushObject['activity'] = {
                        'id': vstatus,
                        'time': timeNow()
                    }
                else:
                    status = 0

                updateMsgQ = await self.grConversation.update_one(
                    {
                        '_id': vconvId
                    },
                    {
                        '$set': {
                            'lastUpdatedTime': timeNow(),
                            'modifiedBy': self.accountId,
                            'modifiedAt': modifiedAt,
                            'status': status,
                        },
                        '$push': pushObject
                    }
                )
                if updateMsgQ.modified_count:
                    message = 'Comment has been posted.'
                    code = 2000
                    status = True
            else:
                message = 'Invalid Argument - [ convId ].'
                code = 4004

        except Exception as e:
            status = False
            if not len(message):
                # self.set_status(503)
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(response)
            await self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            # self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return
