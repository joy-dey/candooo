import datetime
import json
import os
import re
import sys
import mimetypes
import requests
import pandas as pd
import io

from datetime import datetime as dtime
import tornado.web
from abc import ABCMeta
from bson import ObjectId
from build_config import CONFIG
from lib.lib import Validate
from lib.xen_protocol import xenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log
from util.time_util import timeNow
from bson.json_util import dumps as bdumps
from lib.element_mixer import ElementMixer
from util.file_util import FileUtil


@xenSecureV2
class ManualLoanApplicationDataHandler(ElementMixer,  MongoMixin, metaclass=ABCMeta):

    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]

    uploadFileDetails = MongoMixin.userDb[
        CONFIG['database'][0]['table'][16]['name']
    ]

    loanApplication = MongoMixin.userDb[
        CONFIG['database'][0]['table'][13]['name']
    ]

    loanStatusLog = MongoMixin.userDb[
        CONFIG['database'][0]['table'][18]['name']
    ]

    state = MongoMixin.userDb[
        CONFIG['database'][0]['table'][6]['name']
    ]

    block = MongoMixin.userDb[
        CONFIG['database'][0]['table'][15]['name']
    ]

    district = MongoMixin.userDb[
        CONFIG['database'][0]['table'][14]['name']
    ]

    trainingStatus = MongoMixin.userDb[
        CONFIG['database'][0]['table'][21]['name']
    ]

    rejectionReasons = MongoMixin.userDb[
        CONFIG['database'][0]['table'][11]['name']
    ]

    componentId = ObjectId('63d38614458b78fdf4cf6bfa')

    async def post(self):
        code = 4000
        message = ''
        status = False
        result = []
        try:
            try:
                # CONVERTS BODY INTO JSON
                self.request.arguments = json.loads(self.request.body.decode())
            except Exception as e:
                code = 4002
                message = 'Expected Request Type JSON.'
                raise Exception
            
            _Id = self.accountId
            admin = await self.account.find_one(
                {'_id': ObjectId(_Id)}
            )
            
            file_id = self.request.arguments.get('locationId')
            if file_id is not None:
                if 'fileId' in file_id:
                    fileid = file_id['fileId']
                    try:
                        file_Id = ObjectId(fileid)
                    except:
                        code = 4169
                        message = 'Invalid Argument - [ fileId ].'
                        status = False  
                        raise Exception   
                else:
                    file_Id = 0
            else:
                file_Id = 0
            
            method = self.request.arguments.get('method')
            if method == None:
                code = 4130
                message = 'Missing Argument - [ method ].'
                raise Exception
            elif type(method) != int:
                code = 4131
                message = 'Invalid Argument - [ method ].'
                raise Exception

            excelData = self.request.arguments.get('excelData')
            if not excelData:
                code = 4031
                message = 'Invalid Argument - [ excelData ].'
                raise Exception    
            
            if admin:
                if method == 1:
                    
                    try:
                        expected_columns = [
                            'currentStatus', 'underProcessRejectionByAgencyReason', 'officeName', 'agencyType',
                            'state', 'applicantId', 'applicantName',	'applicantAddress', 'mobileNo',
                            'alternativeMobileNo',	'email','legalStatus', 'gender' , 'category',	'qualification',	'dateOfBirth',	'age',
                            'unitLocation',	'unitAddress',	'talukblock', 'unitDistrict',	'productDescactivity',
                            'proposedProjectCost', 'financingBranchIfscCode',	'financingBranchAddress',	'onlineSubmissionDate',
                            'forwardingDateToBank',	'bankRemarks',	'dateOfDocumentReceivedAtBank',
                            'totalProjectCostApprovedByBank',	'sanctionedDateByBank',	'totalSanctionedAmountByBank',	'dateOfDepositOwnContribution', 
                            'ownContributionAmountDeposited', 'coveredUnderCgtsi',	'coveredUnderCgtsi', 'loanReleaseAmount',	
                            'remarksForMmProcessAtPmegpcomumbai','mmReleaseAmount', 'edpTrainingCenterName',	'trainingStartDate',
                            'trainingEndDate',	'durationOfTraining',	'certificateIssueDate', 'dateOfLoanRelease', 'physicalVerificationConductedDate', 'physicalVerificationStatus'
                            ]
                        
                        missing_columns = []
                        if excelData is not None:
                            missing_columns = [col for col in expected_columns if col not in excelData]

                            if missing_columns:
                                code = 4325
                                message = f"The following columns are missing : {missing_columns}"
                                result.append(missing_columns)
                                raise Exception(message)
                        
                        data_arrays = []
                        date_format = "%Y-%m-%d"   
                        
                        string_column = [
                                'currentStatus', 'underProcessRejectionByAgencyReason', 'officeName', 'agencyType',
                                'state', 'applicantId', 'applicantName',	'applicantAddress', 'email','legalStatus', 'gender' , 'category',	
                                'qualification', 'unitLocation',	'unitAddress',	'talukblock', 'unitDistrict',	'productDescactivity',
                                'financingBranchIfscCode',	'financingBranchAddress',	
                                'bankRemarks',	'coveredUnderCgtsi',	
                                'remarksForMmProcessAtPmegpcomumbai','edpTrainingCenterName', 'physicalVerificationStatus'
                                ]
                            
                        int_columns = [
                            'mobileNo', 'alternativeMobileNo', 'age', 'proposedProjectCost', 'totalProjectCostApprovedByBank', 
                            'ownContributionAmountDeposited', 'loanReleaseAmount',	'mmReleaseAmount', 'durationOfTraining', 'totalSanctionedAmountByBank'
                            ]    
                        
                        date_columns = [
                            'dateOfBirth', 'onlineSubmissionDate', 'forwardingDateToBank', 'dateOfDocumentReceivedAtBank',
                            'dateOfDepositOwnContribution', 'dateOfLoanRelease',	'trainingStartDate', 'trainingEndDate',
                            'certificateIssueDate', 'sanctionedDateByBank', 'physicalVerificationConductedDate'
                            ]
                        

                            
                        data_dict = {}
                        for column, value in excelData.items():
                            if column in string_column:
                                if column not in ['currentStatus', 'underProcessRejectionByAgencyReason']:
                                    if not isinstance(value, str) or not value:
                                        code = 4156
                                        message = f"Value in '{column}' column is not a non-empty string."
                                        raise Exception
                                elif column in ['currentStatus', 'underProcessRejectionByAgencyReason']:
                                    if not isinstance(value, str):
                                        code = 4162
                                        message = f"Value in '{column}' column is not a non-empty string."
                                        raise Exception
                                    
                                if column in ['state', 'talukblock', 'unitDistrict']:
                                    try:
                                        value = ObjectId(value)
                                    except:
                                        code = 4162
                                        message = 'Inavlid {}'.format(column)
                                        raise Exception
                                    if column == 'state':
                                        mDataFind = await self.state.find_one(
                                            {
                                            '_id': value
                                            }
                                        )
                                    elif column == 'talukblock':
                                        mDataFind = await self.block.find_one(
                                            {
                                            '_id': value
                                            }
                                        )
                                    elif column == 'unitDistrict':
                                        mDataFind = await self.district.find_one(
                                            {
                                            '_id': value
                                            }
                                        )
                                if column in ['bankRemarks']:
                                    try:
                                        value = ObjectId(value)
                                        objId = True
                                    except:
                                        objId = False
                                    
                                    if objId:
                                        mRemarksFind = await self.rejectionReasons.find_one(
                                                {
                                                '_id': value
                                                }
                                            )
                                    else:
                                        mRemarksFind = await self.rejectionReasons.find_one(
                                                {
                                                'reason': value
                                                }
                                            )
                                    if not mRemarksFind:
                                        code = 4207
                                        message = '{} Not Found'.format(column)
                                        raise Exception
                                    
                            elif column in date_columns:
                                try:
                                    if column == 'dateOfBirth':
                                            value = datetime.datetime.strptime(str(value),date_format)
                                            value = value.strftime('%Y-%m-%d')
                                    else:
                                        if not isinstance(value, str):
                                            value = value.strftime(date_format)
                                        value = int(dtime.strptime(str(value), date_format).timestamp() * 1000 * 1000)
                                except ValueError as e:
                                    code = 4193
                                    message = f"Value in '{column}' column is not in the expected format: {e}"
                                    raise Exception
                                
                            elif column in int_columns:
                                if not (isinstance(value, int) or isinstance(value, float)) or value is None:
                                    code = 4205
                                    message = f"Value in '{column}' column is not a numeric type."
                                    raise Exception

                            data_dict[column] = value

                        mFindAccount = await self.loanApplication.find_one(
                            {
                                'applicantId': data_dict.get('applicantId')
                            }
                            )
                        if not mFindAccount:
                            code = 4220
                            message = 'Application Not Found'
                            raise Exception
                        
                        xSanctionedAmount = data_dict.get('totalSanctionedAmountByBank')
                        xLoanReleaseDate = data_dict.get('dateOfLoanRelease')
                        xLoanReleaseAmount = data_dict.get('loanReleaseAmount')
                        xFirstDisbursedDate = xLoanReleaseDate
                        xTotalDisbursedAmount = 0
                        xDisbursementCount = 0
                        if mFindAccount:
                            statusLogFind = self.loanStatusLog.aggregate(
                                [
                                    {
                                        '$match': {
                                            'applicantId': data_dict.get('applicantId')
                                        }
                                    },
                                    {
                                        '$addFields': {
                                            'disbursedAmounts': '$disbursed.disbursedInfo.amount'
                                        }
                                    },
                                    {
                                        '$unwind': '$disbursedAmounts'
                                    },
                                    {
                                        '$unwind': '$disbursedAmounts'
                                    },
                                    {
                                        '$project': {
                                            'disbursedAmounts': 1
                                        }
                                    }
                                ]
                            )
                            try:
                                async for i in statusLogFind:
                                    xDisbursementCount += 1
                                    xTotalDisbursedAmount += i.get('disbursedAmounts')
                            except:
                                xTotalDisbursedAmount = 0
                        if xDisbursementCount >= 6 and xLoanReleaseAmount > 0:
                            code = 4263
                            message = 'You have already completed 6 Disbursements'
                            raise Exception
                        
                        if xLoanReleaseAmount > (xSanctionedAmount - xTotalDisbursedAmount):
                            code = 4250
                            message = f'You can add Loan Release Amount upto {xSanctionedAmount - xTotalDisbursedAmount}'
                            raise Exception

                        
                        data_arrays.append(data_dict)
  
                        for data_array in data_arrays:
                            try:
                                data_array['_applicantId'] = data_array['applicantId']
                                del data_array['applicantId']
                            except:
                                Applicant = False
                            existing_record = await self.loanApplication.find_one(
                                {
                                    'applicantId': data_array['_applicantId']
                                }
                                )
                            
                            data_array['applicantId'] = data_array['_applicantId']
                            del data_array['_applicantId'] 

                            if existing_record:
                                vCurrentStatus = existing_record.get('data').get('currentStatus')
                            else:
                                vCurrentStatus = ''

                            zReasonFind = await self.rejectionReasons.find_one(
                                {
                                    '_id': data_array.get('bankRemarks')
                                },
                                {
                                    'reason': 1
                                }
                            )
                            if zReasonFind:
                                xReason = zReasonFind.get('reason')
                  
                            mStatus = data_array.get('currentStatus')
                            applicant_id = data_array['applicantId']
                            trainingObj = {}
                            mSlno = 0
                            if mStatus == 'Rejected/Returned':
                                if vCurrentStatus in ['Loan Sanctioned', 'Disbursed', 'Construction Completed', 'Copayment', 'Onhold/Discontinued', 'Under Process (At Agency)']:
                                    code = 4144
                                    message = f'Application Status is already {vCurrentStatus}'
                                    raise Exception
                                else:
                                    statusLogFind = self.loanStatusLog.aggregate(
                                        [
                                            {
                                                '$match': {
                                                    'applicantId': applicant_id
                                                }
                                            },
                                            {
                                                '$addFields': {
                                                    'rejectedInfo': {
                                                        '$last': '$rejected'
                                                    }
                                                }
                                            },
                                            {
                                                '$project': {
                                                    'applicantId': 1,
                                                    'rejectedInfo': 1
                                                }
                                            }
                                        ]
                                    )
                                    try:
                                        async for i in statusLogFind:
                                            mSlno = i.get('rejectedInfo').get('slNo')
                                    except:
                                        mSlno = 0
                                    if not existing_record:
                                        statusObj = {
                                            'applicantId': applicant_id,
                                            'rejected': [
                                                    {
                                                    'slNo': mSlno+1,
                                                    'currentStatus': mStatus,
                                                    'reason': xReason,
                                                    'comment': 'Status changed during manual upload',
                                                    'modifiedBy': self.accountId,
                                                    'modifiedAt': timeNow()
                                                }
                                            ]
                                        }
                                    else:
                                        statusObj = {
                                            'rejected': {
                                                'slNo': mSlno+1,
                                                'currentStatus': mStatus,
                                                'reason': xReason,
                                                'comment': 'Status changed during manual upload',
                                                'modifiedBy': self.accountId,
                                                'modifiedAt': timeNow()
                                            }
                                        }

                            elif mStatus == 'Onhold/Discontinued':
                                if vCurrentStatus in ['Under Process (At Agency)']:
                                    code = 4229
                                    message = f'Application Status is already {vCurrentStatus}'
                                    raise Exception
                                else:
                                    statusLogFind = self.loanStatusLog.aggregate(
                                        [
                                            {
                                                '$match': {
                                                    'applicantId': applicant_id
                                                }
                                            },
                                            {
                                                '$addFields': {
                                                    'onHoldInfo': {
                                                        '$last': '$onHold'
                                                    }
                                                }
                                            },
                                            {
                                                '$project': {
                                                    'onHoldInfo': 1
                                                }
                                            }
                                        ]
                                    )
                                    try:
                                        async for i in statusLogFind:
                                            mSlno = i.get('onHoldInfo').get('slNo')
                                    except:
                                        mSlno = 0

                                    if not existing_record:
                                        statusObj = {
                                            'applicantId': applicant_id,
                                            'onHold': [
                                                    {
                                                    'slNo': mSlno+1,
                                                    'currentStatus': mStatus,
                                                    'comment': 'Status changed during manual upload',
                                                    'modifiedBy': self.accountId,
                                                    'modifiedAt': timeNow()
                                                }
                                            ]
                                        }
                                    else:
                                        statusObj = {
                                            'onHold': {
                                                'slNo': mSlno+1,
                                                'currentStatus': mStatus,
                                                'comment': 'Status changed during manual upload',
                                                'modifiedBy': self.accountId,
                                                'modifiedAt': timeNow()
                                            }
                                        }

                                    trainingObj = {
                                        'applicantId': applicant_id,
                                        'applicantName': data_array.get('applicantName'),
                                        'talukblock': data_array.get('talukblock'),
                                        'unitDistrict': data_array.get('unitDistrict'),
                                        'uploadMedium': 'Portal',
                                        'trainingStatus': 'Pending',
                                        'createdAt': timeNow(),
                                        'createdBy': self.accountId
                                    } 
                                                                
                            elif mStatus == 'Disbursed':
                                if vCurrentStatus in ['Construction Completed', 'Copayment', 'Onhold/Discontinued', 'Under Process (At Agency)']:
                                    code = 4305
                                    message = f'Application Status is already {vCurrentStatus}'
                                    raise Exception
                                else:
                                    statusLogFind = self.loanStatusLog.aggregate(
                                        [
                                            {
                                                '$match': {
                                                    'applicantId': applicant_id
                                                }
                                            },
                                            {
                                                '$addFields': {
                                                    'lastDisbursedInfo': {
                                                        '$last': '$disbursed'
                                                    }
                                                }
                                            },
                                            {
                                                '$addFields': {
                                                    'firstDisbursedInfo': {
                                                        '$first': '$disbursed'
                                                    }
                                                }
                                            },
                                            {
                                                '$addFields': {
                                                    'firstDisbursedDate': {
                                                        '$first': '$firstDisbursedInfo.disbursedInfo'
                                                    }
                                                }
                                            },
                                            {
                                                '$project': {
                                                    'lastDisbursedInfo': 1,
                                                    'firstDisbursedDate': 1
                                                }
                                            }
                                        ]
                                    )
                                    try:
                                        async for i in statusLogFind:
                                            xFirstDisbursedDate = i.get('firstDisbursedDate').get('date')
                                            mSlno = i.get('lastDisbursedInfo').get('slNo')
                                    except:
                                        mSlno = 0                           
                                    if not existing_record:
                                        statusObj = {
                                            'applicantId': applicant_id,
                                            'disbursed': [
                                                    {
                                                    'slNo': mSlno+1,
                                                    'currentStatus': mStatus,
                                                    'disbursedInfo': [
                                                        {
                                                            'amount': xLoanReleaseAmount,
                                                            'date': xLoanReleaseDate
                                                        }
                                                    ],
                                                    'effectiveDate': xFirstDisbursedDate,
                                                    'comment': 'Status changed during manual upload',
                                                    'modifiedBy': self.accountId,
                                                    'modifiedAt': timeNow()
                                                }
                                            ]
                                        }
                                    else:
                                        statusObj = {
                                            'disbursed': {
                                                'slNo': mSlno+1,
                                                'currentStatus': mStatus,
                                                'disbursedInfo': [
                                                    {
                                                        'amount': xLoanReleaseAmount,
                                                        'date': xLoanReleaseDate
                                                    }
                                                ],
                                                'effectiveDate': xFirstDisbursedDate,
                                                'comment': 'Status changed during manual upload',
                                                'modifiedBy': self.accountId,
                                                'modifiedAt': timeNow()
                                            }
                                        }     

                                    trainingObj = {
                                        'applicantId': applicant_id,
                                        'applicantName': data_array.get('applicantName'),
                                        'talukblock': data_array.get('talukblock'),
                                        'unitDistrict': data_array.get('unitDistrict'),
                                        'uploadMedium': 'Portal',
                                        'trainingStatus': 'Pending',
                                        'createdAt': timeNow(),
                                        'createdBy': self.accountId
                                    } 

                            elif mStatus == 'Copayment':
                                if vCurrentStatus in ['Onhold/Discontinued', 'Under Process (At Agency)']:
                                    code = 4445
                                    message = f'Application Status is already {vCurrentStatus}'
                                    raise Exception
                                else:
                                    statusLogFind = self.loanStatusLog.aggregate(
                                        [
                                            {
                                                '$match': {
                                                    'applicantId': applicant_id
                                                }
                                            },
                                            {
                                                '$addFields': {
                                                    'copaymentInfo': {
                                                        '$last': '$copayment'
                                                    }
                                                }
                                            },
                                            {
                                                '$project': {
                                                    'copaymentInfo': 1
                                                }
                                            }
                                        ]
                                    )
                                    try:
                                        async for i in statusLogFind:
                                            mSlno = i.get('copaymentInfo').get('slNo')
                                    except:
                                        mSlno = 0
                                    
                                    if not existing_record:
                                        statusObj = {
                                            'applicantId': applicant_id,
                                            'copayment': [
                                                    {
                                                    'slNo': mSlno+1,
                                                    'currentStatus': mStatus,
                                                    'comment': 'Status changed during manual upload',
                                                    'modifiedBy': self.accountId,
                                                    'modifiedAt': timeNow()
                                                }
                                            ]
                                        }
                                    else:
                                        statusObj = {
                                            'copayment': {
                                                'slNo': mSlno+1,
                                                'currentStatus': mStatus,
                                                'comment': 'Status changed during manual upload',
                                                'modifiedBy': self.accountId,
                                                'modifiedAt': timeNow()
                                            }
                                        }
                                    
                                    trainingObj = {
                                        'applicantId': applicant_id,
                                        'applicantName': data_array.get('applicantName'),
                                        'talukblock': data_array.get('talukblock'),
                                        'unitDistrict': data_array.get('unitDistrict'),
                                        'uploadMedium': 'Portal',
                                        'trainingStatus': 'Pending',
                                        'createdAt': timeNow(),
                                        'createdBy': self.accountId
                                    } 
                            
                            elif mStatus == 'Online Submitted':
                                if vCurrentStatus in ['Onhold/Discontinued', 'Disbursed', 'Copayment', 'Loan Sanctioned', 'Construction Completed', 'Under Process (At Agency)', 'Under Process (At Bank)']:
                                    code = 4456
                                    message = f'Application status is already {vCurrentStatus}'
                                    raise Exception
                                else:
                                    statusLogFind = self.loanStatusLog.aggregate(
                                        [
                                            {
                                                '$match': {
                                                    'applicantId': applicant_id
                                                }
                                            },
                                            {
                                                '$addFields': {
                                                    'onlineSubmittedInfo': {
                                                        '$last': '$onlineSubmitted'
                                                    }
                                                }
                                            },
                                            {
                                                '$project': {
                                                    'onlineSubmittedInfo': 1
                                                }
                                            }
                                        ]
                                    )
                                    try:
                                        async for i in statusLogFind:
                                            mSlno = i.get('onlineSubmittedInfo').get('slNo')
                                    except:
                                        mSlno = 0
                                    
                                    if not existing_record:
                                        statusObj = {
                                            'applicantId': applicant_id,
                                            'onlineSubmitted': [
                                                    {
                                                    'slNo': mSlno+1,
                                                    'currentStatus': mStatus,
                                                    'comment': 'Status changed during manual upload',
                                                    'modifiedBy': self.accountId,
                                                    'modifiedAt': timeNow()
                                                }
                                            ]
                                        }
                                    else:
                                        statusObj = {
                                            'onlineSubmitted': {
                                                'slNo': mSlno+1,
                                                'currentStatus': mStatus,
                                                'comment': 'Status changed during manual upload',
                                                'modifiedBy': self.accountId,
                                                'modifiedAt': timeNow()
                                            }
                                        }

                            elif mStatus == 'Under Process (At Bank)':
                                if vCurrentStatus in ['Onhold/Discontinued', 'Disbursed', 'Copayment', 'Loan Sanctioned', 'Construction Completed', 'Under Process (At Agency)']:
                                    code = 4456
                                    message = f'Application status is already {vCurrentStatus}'
                                    raise Exception
                                else:
                                    statusLogFind = self.loanStatusLog.aggregate(
                                        [
                                            {
                                                '$match': {
                                                    'applicantId': applicant_id
                                                }
                                            },
                                            {
                                                '$addFields': {
                                                    'processedAtBankInfo': {
                                                        '$last': '$processedAtBank'
                                                    }
                                                }
                                            },
                                            {
                                                '$project': {
                                                    'processedAtBankInfo': 1
                                                }
                                            }
                                        ]
                                    )
                                    try:
                                        async for i in statusLogFind:
                                            mSlno = i.get('processedAtBankInfo').get('slNo')
                                    except:
                                        mSlno = 0
                                    if not existing_record:
                                        statusObj = {
                                            'applicantId': applicant_id,
                                            'processedAtBank': [
                                                    {
                                                    'slNo': mSlno+1,
                                                    'currentStatus': mStatus,
                                                    'comment': 'Status changed during manual upload',
                                                    'modifiedBy': self.accountId,
                                                    'modifiedAt': timeNow()
                                                }
                                            ]
                                        }
                                    else:
                                        statusObj = {
                                            'processedAtBank': {
                                                'slNo': mSlno+1,
                                                'currentStatus': mStatus,
                                                'comment': 'Status changed during manual upload',
                                                'modifiedBy': self.accountId,
                                                'modifiedAt': timeNow()
                                            }
                                        }
                            
                            elif mStatus == 'Loan Sanctioned':
                                if vCurrentStatus in ['Onhold/Discontinued', 'Disbursed', 'Copayment', 'Construction Completed', 'Under Process (At Agency)']:
                                    code = 4456
                                    message = f'Application status is already {vCurrentStatus}'
                                    raise Exception 
                                else:
                                    statusLogFind = self.loanStatusLog.aggregate(
                                        [
                                            {
                                                '$match': {
                                                    'applicantId': applicant_id
                                                }
                                            },
                                            {
                                                '$addFields': {
                                                    'sanctionedInfo': {
                                                        '$last': '$sanctioned'
                                                    }
                                                }
                                            },
                                            {
                                                '$project': {
                                                    'sanctionedInfo': 1
                                                }
                                            }
                                        ]
                                    )
                                    try:
                                        async for i in statusLogFind:
                                            mSlno = i.get('sanctionedInfo').get('slNo')
                                    except:
                                        mSlno = 0
                                    if not existing_record:
                                        statusObj = {
                                            'applicantId': applicant_id,
                                            'sanctioned': [
                                                    {
                                                    'slNo': mSlno+1,
                                                    'currentStatus': mStatus,
                                                    'comment': 'Status changed during manual upload',
                                                    'modifiedBy': self.accountId,
                                                    'modifiedAt': timeNow()
                                                }
                                            ]
                                        }
                                    else:
                                        statusObj = {
                                            'sanctioned': {
                                                'slNo': mSlno+1,
                                                'currentStatus': mStatus,
                                                'comment': 'Status changed during manual upload',
                                                'modifiedBy': self.accountId,
                                                'modifiedAt': timeNow()
                                            }
                                        }

                                    trainingObj = {
                                        'applicantId': applicant_id,
                                        'applicantName': data_array.get('applicantName'),
                                        'talukblock': data_array.get('talukblock'),
                                        'unitDistrict': data_array.get('unitDistrict'),
                                        'uploadMedium': 'Portal',
                                        'trainingStatus': 'Pending',
                                        'createdAt': timeNow(),
                                        'createdBy': self.accountId
                                    }   

                            elif mStatus == 'Construction Completed':
                                if vCurrentStatus in ['Onhold/Discontinued', 'Copayment', 'Under Process (At Agency)']:
                                    code = 4456
                                    message = f'Application status is already {vCurrentStatus}'
                                    raise Exception 
                                else:
                                    statusLogFind = self.loanStatusLog.aggregate(
                                        [
                                            {
                                                '$match': {
                                                    'applicantId': applicant_id
                                                }
                                            },
                                            {
                                                '$addFields': {
                                                    'constCompletedInfo': {
                                                        '$last': '$constCompleted'
                                                    }
                                                }
                                            },
                                            {
                                                '$project': {
                                                    'constCompletedInfo': 1
                                                }
                                            }
                                        ]
                                    )
                                    try:
                                        async for i in statusLogFind:
                                            mSlno = i.get('constCompletedInfo').get('slNo')
                                    except:
                                        mSlno = 0

                                    if not existing_record:
                                        statusObj = {
                                            'applicantId': applicant_id,
                                            'constCompleted': [
                                                    {
                                                    'slNo': mSlno+1,
                                                    'currentStatus': mStatus,
                                                    'comment': 'Status changed during manual upload',
                                                    'modifiedBy': self.accountId,
                                                    'modifiedAt': timeNow()
                                                }
                                            ]
                                        }
                                    else:
                                        statusObj = {
                                            'constCompleted': {
                                                'slNo': mSlno+1,
                                                'currentStatus': mStatus,
                                                'comment': 'Status changed during manual upload',
                                                'modifiedBy': self.accountId,
                                                'modifiedAt': timeNow()
                                            }
                                        }
                                    
                                    trainingObj = {
                                        'applicantId': applicant_id,
                                        'applicantName': data_array.get('applicantName'),
                                        'talukblock': data_array.get('talukblock'),
                                        'unitDistrict': data_array.get('unitDistrict'),
                                        'uploadMedium': 'Portal',
                                        'trainingStatus': 'Pending',
                                        'createdAt': timeNow(),
                                        'createdBy': self.accountId
                                    } 

                            else:
                                if not existing_record:
                                    statusObj = {
                                        'applicantId': applicant_id,
                                        'others': [
                                                {
                                                'slNo': mSlno+1,
                                                'currentStatus': mStatus,
                                                'comment': 'Status changed during manual upload',
                                                'modifiedBy': self.accountId,
                                                'modifiedAt': timeNow()
                                            }
                                        ]
                                    }
                                else:
                                    statusObj = {
                                        'others': {
                                            'slNo': mSlno+1,
                                            'currentStatus': mStatus,
                                            'comment': 'Status changed during manual upload',
                                            'modifiedBy': self.accountId,
                                            'modifiedAt': timeNow()
                                        }
                                    }
                            
                            if existing_record:
                                loanQ = await self.loanApplication.update_one(
                                    {'applicantId': data_array.get('applicantId')},
                                    {
                                        '$set': {
                                            'modifiedBy': self.accountId,
                                            'modifiedAt': timeNow(),
                                            'data': data_array
                                        }
                                    }
                                )
                                
                                statusUpload = await self.loanStatusLog.update_one(
                                    {
                                        'applicantId': applicant_id
                                    },
                                    {
                                        '$push': statusObj
                                    }
                                )

                                if statusUpload.modified_count:
                                    code = 2000
                                    status = True
                                    message = 'Status updated'
                                else:
                                    code = 4677
                                    message = 'Status Could not updated'
                                
                                if trainingObj:
                                    mFindTraining = await self.trainingStatus.find_one(
                                        {
                                            'loanApplicationId': existing_record.get('_id')
                                        }
                                    )
                                    if not mFindTraining:
                                        trainingObj['loanApplicationId'] = existing_record.get('_id')
                                        mInsertTraining = await self.trainingStatus.insert_one(trainingObj)

                                        if mInsertTraining.inserted_id:
                                            code = 2000
                                            status = True
                                            message = 'Training details inserted'
                                        else:
                                            code = 4497
                                            message = 'Training details not inserted'
                                            raise Exception
                                    else:
                                        mUpdateTrainingDetails = await self.trainingStatus.update_one(
                                            {
                                                '_id': mFindTraining.get('_id')
                                            },
                                            {
                                                '$set': {
                                                    'applicantName': data_array.get('applicantName'),
                                                    'talukblock': data_array.get('talukblock'),
                                                    'unitDistrict': data_array.get('unitDistrict')
                                                }
                                            }
                                        )
                                        if mUpdateTrainingDetails.modified_count:
                                            code = 2000
                                            status = True
                                        else:
                                            code = 4103
                                            message = 'Training details not updated'
                                
                                if loanQ:
                                    message = "Data updated successfully."
                                    code = 2000
                                    status = True
                                else:
                                    message = "Data could not be updated."
                                    code = 4409
                                    status = False
                                    raise Exception

                            else:
                                new_record = {
                                    'applicantId': data_array['applicantId'],
                                    'createdBy': self.accountId,
                                    'createdAt': timeNow(),
                                    'data': data_array
                                }
                                                  
                                vLoan = await self.loanApplication.insert_one(new_record)
                                                                
                                statusObj['loanApplicationId'] = vLoan.inserted_id
                                statusUpload = await self.loanStatusLog.insert_one(statusObj)
                                
                                if statusUpload.inserted_id:
                                    code = 2000
                                    status = True
                                    message = 'Status inserted'
                                else:
                                    code = 4717
                                    message = 'Status not inserted'
                                    raise Exception
                                
                                if trainingObj:
                                        trainingObj['loanApplicationId'] = vLoan.inserted_id
                                        insertTraining = await self.trainingStatus.insert_one(trainingObj)

                                        if insertTraining.inserted_id:
                                            code = 2000
                                            status = True
                                        else:
                                            code = 4151
                                            message = 'Training details not inserted'
                                            raise Exception  
                                        
                                if vLoan:
                                    message = "Data submitted successfully."
                                    code = 2000
                                    status = True
                                else:
                                    message = "Data could not be submitted."
                                    code = 4620
                                    status = False   
                                    raise Exception
                                    
                    except Exception as e :
                        exc_type, exc_obj, exc_tb = sys.exc_info()
                        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                        Log.d('FILE: ' + str(fname), 'LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
                        if not len(message):
                            code = 4210
                            template = "Exception: {0}. Argument: {1!r}"
                            Log.d(template.format(type(e).__name__, e.args))
                            message = 'Internal Error, Please Contact the Support Team.'
                        raise Exception
                else:
                    code = 4110
                    message = 'Method not supported.'
                    raise Exception
            else:
                message = 'Admin not found'
                code = 4222
                raise Exception

        except Exception as e:
            status = False
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(response)
            await self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            # self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return
        
    async def put(self):
        code = 4000
        message = ''
        status = False
        result = []
        try:
            try:
                # CONVERTS BODY INTO JSON
                self.request.arguments = json.loads(self.request.body.decode())
            except Exception as e:
                code = 4002
                message = 'Expected Request Type JSON.'
                raise Exception

            mId = self.request.arguments.get('id')
            code, message = Validate.i( 
                mId,
                'id',
                dataType=str,
                notEmpty=True
            )
            if code != 4100:
                raise Exception
            
            try:
                mId = ObjectId(mId)
            except:
                code = 4112
                message = 'Invalid Argument - [ id ]'
                raise Exception
            
            mApplicationFind = await self.loanApplication.find_one(
                {
                    '_id': mId
                }
            )
            if not mApplicationFind:
                code = 4122
                message = 'Application not Found'
                raise Exception

            excelData = self.request.arguments.get('excelData')
            if not excelData:
                code = 4031
                message = 'Invalid Argument - [ excelData ].'
                raise Exception    
            
            expected_columns = [ "currentStatus","underProcessRejectionByAgencyReason","officeName","agencyType","state","applicantId","applicantName",
                "applicantAddress","mobileNo","alternativeMobileNo","email","legalStatus","gender","category","qualification","dateOfBirth","age",
                "unitLocation","unitAddress","unitDistrict","talukblock"
                ]

            
            missing_columns = []
            if excelData is not None:
                missing_columns = [col for col in expected_columns if col not in excelData]

                if missing_columns:
                    code = 4325
                    message = "The following columns are missing"
                    result.append(missing_columns)
                    raise Exception
            
            data_arrays = []
            date_format = "%Y-%m-%d"   
            
            string_column = [
                    'currentStatus', 'underProcessRejectionByAgencyReason', 'officeName', 'agencyType',
                    'state', 'applicantId', 'applicantName',	'applicantAddress', 'email','legalStatus', 'gender' , 'category',	
                    'qualification', 'unitLocation',	'unitAddress',	'talukblock', 'unitDistrict'
                    ]
                
            int_columns = [
                'mobileNo', 'alternativeMobileNo', 'age',
                ]    
            
            date_columns = [
                'dateOfBirth'
                ]

            trainingModeQ = ''
            trainingRemarksQ = ''
            for data, value in excelData.items():
                if data == 'trainingMode':
                    trainingModeQ = value

                if data == 'trainingRemarks':
                    trainingRemarksQ = value  
            
            data_dict = {}
            for column, value in excelData.items():
                if column in string_column:
                    if column not in ['currentStatus', 'underProcessRejectionByAgencyReason']:
                        if not isinstance(value, str) or not value:
                            code = 4156
                            message = f"Value in '{column}' column is not a non-empty string."
                            raise Exception
                    elif column in ['currentStatus', 'underProcessRejectionByAgencyReason']:
                        if not isinstance(value, str):
                            code = 4162
                            message = f"Value in '{column}' column is not a non-empty string."
                            raise Exception
                    if column in ['state', 'talukblock', 'unitDistrict']:
                        try:
                            value = ObjectId(value)
                        except:
                            code = 4162
                            message = 'Inavlid {}'.format(column)
                            raise Exception
                        if column == 'state':
                            mDataFind = await self.state.find_one(
                                {
                                '_id': value
                                }
                            )
                        elif column == 'talukblock':
                            mDataFind = await self.block.find_one(
                                {
                                '_id': value
                                }
                            )
                        elif column == 'unitDistrict':
                            mDataFind = await self.district.find_one(
                                {
                                '_id': value
                                }
                            )
                    
                elif column in date_columns:
                    try:
                        if column == 'dateOfBirth':
                            value = datetime.datetime.strptime(str(value),date_format)
                            value = value.strftime('%Y-%m-%d')
                        else:
                            if not isinstance(value, str):
                                value = value.strftime(date_format)
                            value = int(dtime.strptime(str(value), date_format).timestamp() * 1000 * 1000)
                    except ValueError as e:
                        code = 4193
                        message = f"Value in '{column}' column is not in the expected format: {e}"
                        raise Exception
                    
                elif column in int_columns:
                    if not (isinstance(value, int) or isinstance(value, float)) or value is None:
                        code = 4205
                        message = f"Value in '{column}' column is not a numeric type."
                        raise Exception
                data_dict[column] = value             
            data_arrays.append(data_dict)

            mobileNoQ = data_arrays[0]['mobileNo']
            alternativeMobileNoQ = data_arrays[0]['alternativeMobileNo']
            emailQ = data_arrays[0]['email']
            

            loanQ = await self.loanApplication.update_one(
                {
                    '_id': mId
                },
                {
                    '$set': {
                        'modifiedBy': self.accountId,
                        'modifiedAt': timeNow(),
                        'data.mobileNo':mobileNoQ,
                        'data.alternativeMobileNo':alternativeMobileNoQ,
                        'data.email':emailQ,
                        'data.trainingMode':trainingModeQ,
                        'data.trainingRemarks':trainingRemarksQ,
                    }
                }
            )
            if loanQ.modified_count:
                message = "Data updated successfully."
                code = 2000
                status = True
            else:
                message = "Data could not be updated."
                code = 4267
                status = False
                raise Exception

        except Exception as e:
            status = False
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(response)
            await self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            # self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return
