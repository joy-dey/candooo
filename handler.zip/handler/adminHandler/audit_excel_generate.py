import asyncio
import datetime
import json
import os
import re
import sys
import io
import pandas as pd

from datetime import datetime as dtime
from handler.methods.trainging_certificate_pdf import insert_training_details
import tornado.web
from abc import ABCMeta
from bson import ObjectId
from build_config import CONFIG
from lib.lib import Validate
from lib.xen_protocol import xenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log
from bson.json_util import dumps as bdumps
from lib.element_mixer import ElementMixer
from util.time_util import timeNow
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment

@xenSecureV2
class AuditExcelGenerateHandler(ElementMixer,  MongoMixin, metaclass=ABCMeta):

    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]

    loanApplication = MongoMixin.userDb[
        CONFIG['database'][0]['table'][13]['name']
    ]

    state = MongoMixin.userDb[
        CONFIG['database'][0]['table'][6]['name']
    ]

    block = MongoMixin.userDb[
        CONFIG['database'][0]['table'][15]['name']
    ]

    district = MongoMixin.userDb[
        CONFIG['database'][0]['table'][14]['name']
    ]

    loanStatusLog = MongoMixin.userDb[
        CONFIG['database'][0]['table'][18]['name']
    ]
    
    auditInfo = MongoMixin.userDb[
        CONFIG['database'][0]['table'][19]['name']
    ]

    trainingStatus = MongoMixin.userDb[
        CONFIG['database'][0]['table'][21]['name']
    ]

    componentId = ObjectId('63d39988458b78fdf4cf6c0d')

    async def get(self):
        code = 4000
        message = ''
        status = False
        result = []
        try:
        #    try:
        #         vFileDtlsId = str(self.get_argument('id'))
        #         vFileDtlsId = ObjectId(vFileDtlsId)
        #     except:
        #         vFileDtlsId = None

            try:
                vSearchWith = self.get_query_argument('searchWith')
                if not vSearchWith:
                    raise Exception
                vSearchWith = vSearchWith.lower()
            except:
                vSearchWith = None

            try:
                isCompleted = self.get_argument('isCompleted','')
            except:
                isCompleted = ''

            if isCompleted is not '':
                if isCompleted == "true":
                    isCompleted = True
                elif isCompleted == "false":
                    isCompleted = False
                else:
                    code = 4353
                    message = 'isCompleted should be true or false'
                    raise Exception

            filterObj = {}
            if vSearchWith:
                nApplicationId = {
                    'applicantId': {
                        '$regex': vSearchWith,
                        '$options': 'ism'
                    }
                }

                mApplicantName = {
                    'data.applicantName': {
                        '$regex': vSearchWith,
                        '$options': 'ism'
                    }
                }

                filterObj['$or'] = [nApplicationId, mApplicantName]
            
            try:
                mDistrict = str(self.get_argument('district'))
                if not mDistrict:
                    raise Exception
                mDistrict = ObjectId(mDistrict)
            except:
                mDistrict = None
            
            try:
                mBlock = str(self.get_argument('block'))
                if not mBlock:
                    raise Exception
                mBlock = ObjectId(mBlock)
            except:
                mBlock = None

            try:
                mState = str(self.get_argument('state'))
                if not mState:
                    raise Exception
                mState = ObjectId(mState)
            except:
                mState = ObjectId('5fda17c1adfeecf7e9dd96ce')

            mLocfilter = {}
            if mDistrict:                
                mLocfilter['data.unitDistrict'] = mDistrict

            if mBlock:                
                mLocfilter['data.talukblock'] = mBlock

            if mState:                
                mLocfilter['data.state'] = mState                  

            vLocfilter = {
                '$match': mLocfilter
            }

            try:
                vStatus = self.get_argument('status')
                code, message = Validate.i(
                    vStatus,
                    'status',
                    notEmpty=True,
                    dataType=str
                )
                if code != 4100:
                    raise Exception
            except:
                vStatus = None
            
            if vStatus:
                if vStatus == 'LoanSanctionedDisbursed':
                    vStatusFilter = {
                        '$match': {
                            'data.currentStatus': {
                                '$in': ['Loan Sanctioned', 'Disbursed']
                            }
                        }
                    }
                elif vStatus == 'Rejected By Bank':
                    vStatusFilter = {
                        '$match': {
                            'data.currentStatus': 'Rejected/Returned',
                            'data.rejectedByBank': True
                        }
                    }
                elif vStatus == 'Rejected By DIC':
                    vStatusFilter = {
                        '$match': {
                            'data.currentStatus': 'Rejected/Returned',
                            'data.rejectedByBank': False
                        }
                    }
                else:
                    vStatusFilter = {
                        '$match': {
                            'data.currentStatus': vStatus
                        }
                    }

            try:
                method = self.get_argument('method')
                if not method :
                    message = 'Invalid argument method.'
                    code = 5182
                    status = False
                    raise Exception
                
                else:
                   meth = int(method)
            except:
                method = None

            if method == None:
                meth = None
            
            try:
                mHomestayPerformance = self.get_argument('homestayPerformance')
                code, message = Validate.i(
                    mHomestayPerformance,
                    'homestayPerformance',
                    dataType = str,
                    notEmpty = True,
                    enums = ['Red', 'Yellow', 'Green']
                )
                if code != 4100:
                    raise Exception
            except:
                mHomestayPerformance = None

            filterQ = {
                '$match' : filterObj
            }
            
            pipelineQ = [
                        {
                            '$lookup': {
                                'from': self.state.name,
                                'localField': 'data.state',
                                'foreignField': '_id',
                                'as': 'stateInfo',
                                'pipeline': [
                                        {
                                            '$project': {
                                                '_id': {
                                                    '$toString': '$_id'
                                                },
                                                'name': 1
                                            }
                                        }
                                    ]
                            }
                        },
                        {
                            '$lookup': {
                                'from': self.district.name,
                                'localField': 'data.unitDistrict',
                                'foreignField': '_id',
                                'as': 'districtInfo',
                                'pipeline': [
                                    {
                                        '$project': {
                                            '_id': {
                                                '$toString': '$_id'
                                            },
                                            'districtName': 1

                                        }
                                    }
                                ]
                            }
                        },
                        {
                            '$lookup': {
                                'from': self.block.name,
                                'localField': 'data.talukblock',
                                'foreignField': '_id',
                                'as': 'blockInfo',
                                'pipeline': [
                                    {
                                        '$project': {
                                            '_id': {
                                                '$toString': '$_id'
                                            },
                                            'blockName': 1
                                        }
                                    }
                                ]
                            }
                        },
                        {
                            '$lookup': {
                                'from': self.auditInfo.name,
                                'localField': '_id',
                                'foreignField': 'loanId',
                                'as': 'auditInfo',
                                'pipeline': [
                                    {
                                        '$addFields': {
                                            'stage1': '$auditData.stage1.stageStatus',
                                            'stage2': '$auditData.stage2.stageStatus',
                                            'stage3': '$auditData.stage3.stageStatus',
                                            'stage4': '$auditData.stage4.stageStatus',
                                            'stage5': '$auditData.stage5.stageStatus',
                                            'stage6': '$auditData.stage6.stageStatus',
                                            'constructionStatus': '$constructionStatus'
                                        }
                                    },
                                    {
                                        '$addFields': {
                                            'stageOne': {
                                                '$cond': {
                                                    'if': {
                                                        '$eq': ['$stage1', 'complete']
                                                    },
                                                    'then': 1,
                                                    'else': 0
                                                }
                                            },
                                            'stageTwo': {
                                                '$cond': {
                                                    'if': {
                                                        '$eq': ['$stage2', 'complete']
                                                    },
                                                    'then': 1,
                                                    'else': 0
                                                }
                                            },
                                            'stageThree': {
                                                '$cond': {
                                                    'if': {
                                                        '$eq': ['$stage3', 'complete']
                                                    },
                                                    'then': 1,
                                                    'else': 0
                                                }
                                            },
                                            'stageFour': {
                                                '$cond': {
                                                    'if': {
                                                        '$eq': ['$stage4', 'complete']
                                                    },
                                                    'then': 1,
                                                    'else': 0
                                                }
                                            },
                                            'stageFive': {
                                                '$cond': {
                                                    'if': {
                                                        '$eq': ['$stage5', 'complete']
                                                    },
                                                    'then': 1,
                                                    'else': 0
                                                }
                                            },
                                            'stageSix': {
                                                '$cond': {
                                                    'if': {
                                                        '$eq': ['$stage6', 'complete']
                                                    },
                                                    'then': 1,
                                                    'else': 0
                                                }
                                            }
                                        }
                                    },
                                    {
                                        '$addFields':
                                            {
                                                'lastModifiedAt':
                                                {
                                                    '$ifNull': [
                                                        '$modifiedAt',
                                                        '$createdAt'
                                                        ]
                                                } 
                                            }  
                                    },
                                    {
                                        '$project': {
                                            '_id': {
                                                '$toString': '$_id'
                                            },
                                            'stageOne': 1,
                                            'stageTwo': 1,
                                            'stageThree': 1,
                                            'stageFour': 1,
                                            'stageFive': 1,
                                            'stageSix': 1,
                                            'lastModifiedAt': 1,
                                            'constructionStatus': 1
                                            
                                        }
                                    }
                                ]   
                                
                            }
                        },
                        {
                            '$lookup': {
                                'from': self.loanStatusLog.name,
                                'localField': '_id',
                                'foreignField': 'loanApplicationId',
                                'as': 'statusInfo',
                                'pipeline': [
                                    {
                                        '$lookup': {
                                            'from': self.account.name,
                                            'localField': 'recommendation.modifiedBy',
                                            'foreignField': '_id',
                                            'as': 'recommendationAccountInfo',
                                            'pipeline': [
                                                {
                                                    '$project': {
                                                        '_id': {
                                                            '$toString': '$_id'
                                                        },
                                                        'firstName': 1,
                                                        'lastName': 1
                                                    }
                                                }
                                            ]
                                        }
                                    }
                                ]
                            }
                        },
                        {
                            '$lookup': {
                                'from': self.loanStatusLog.name,
                                'localField': '_id',
                                'foreignField': 'loanApplicationId',
                                'as': 'disbursementInfo',
                                'pipeline': [
                                    {
                                        '$addFields': {
                                            'disbursementDetails': {
                                                '$first': '$disbursed'
                                            }
                                        }
                                    },
                                    {
                                        '$addFields': {
                                            'disbursedDate': {
                                                '$first': '$disbursementDetails.disbursedInfo.date'
                                            }
                                        }
                                    },
                                    {
                                        '$project': {
                                            '_id': {
                                                '$toString': '$_id'
                                            },
                                            'disbursedDate': 1
                                        }
                                    }
                                ]
                            }
                        },
                        {
                            '$unwind': '$disbursementInfo'
                        },
                        {
                            '$project': { 
                                '_id': {
                                    '$toString': '$_id'
                                },
                                'totalCount': 1,
                                'data.currentStatus' : 1,  
                                'applicantId':1, 
                                'data.applicantName':1,	
                                'data.mobileNo':1,
                                'data.alternativeMobileNo':1,	
                                'data.gender':1 , 
                                'data.category':1,
                                'data.totalSanctionedAmountByBank':1,
                                'createdAt':1, 
                                'disbursementInfo': 1,
                                'auditInfo': 1,
                                'createdBy':{
                                    '$toString': '$createdBy'
                                }, 
                                'modifiedBy': {
                                    '$toString': '$modifiedBy'
                                }, 
                                'modifiedAt':1,
                                'blockInfo' : {
                                    '$last': '$blockInfo'
                                },
                                'districtInfo' : {
                                    '$last': '$districtInfo'
                                },
                                'stateInfo' : {
                                    '$last': '$stateInfo'
                                },
                                'statusInfo': {
                                    'recommendation': 1,
                                    'recommendationAccountInfo': 1
                                }                             
                            }
                        },
                        {
                            '$sort': {
                                '_id': -1
                            }
                        }
                        ]
            
            # vSkip = {
            #     '$skip': f_skip
            # }
            # vLimit = {
            #     '$limit': f_limit
            # }
            if meth == 1:
                if mHomestayPerformance:
                    pipelineQ.insert(0, {
                        '$match': {
                            'data.currentStatus': 'Disbursed'
                        }
                    })
                if isCompleted is not None and isCompleted == True:
                    pipelineQ.insert(5, {
                        '$match': {
                            'auditInfo.constructionStatus': 'complete'
                        }
                    })
                elif isCompleted is not None and isCompleted == False:
                    pipelineQ.insert(5, {
                        '$match': {
                            'auditInfo.constructionStatus': 'Incomplete'
                        }
                    })
                
                # if vFileDtlsId is not None:
                #     matchQ = {
                #         '$match' : {
                #             '_id' : vFileDtlsId
                #         }
                #     }
                #     pipelineQ.insert(0,matchQ)
                if filterObj:
                    pipelineQ.insert(1, filterQ)
                pipelineQ.insert(4, vLocfilter)
                if vStatus:
                    pipelineQ.insert(5, vStatusFilter)               
                # pipelineQ.append(vSkip)
                # pipelineQ.append(vLimit)
                fileQ = self.loanApplication.aggregate(pipelineQ)
            else:
                code = 4472
                message = 'Invalid Argument - [ method ]'
                raise Exception

            xCurrentDate = datetime.datetime.fromtimestamp(timeNow() / 1000 / 1000)
            xCurrentDate = xCurrentDate.strftime('%Y-%m-%d')
            xCurrentDate = datetime.datetime.strptime(xCurrentDate, '%Y-%m-%d')
            
            mDownloadableArray = []
            if meth == 1:
                if mHomestayPerformance:
                    async for i in fileQ:
                        mCompletedStages = 0
                        if i.get('auditInfo') and i.get('disbursementInfo').get('disbursedDate'):
                            xTotalStages = i.get('auditInfo')[0].get('stageOne') + i.get('auditInfo')[0].get('stageTwo') + i.get('auditInfo')[0].get('stageThree') + i.get('auditInfo')[0].get('stageFour') + i.get('auditInfo')[0].get('stageFive') + i.get('auditInfo')[0].get('stageSix')
                            
                            xDisbursedDate = datetime.datetime.fromtimestamp(i.get('disbursementInfo').get('disbursedDate') / 1000 / 1000)
                            xDisbursedDate = xDisbursedDate.strftime('%Y-%m-%d')
                            xDisbursedDate = datetime.datetime.strptime(xDisbursedDate, '%Y-%m-%d')
                            year_diff = xCurrentDate.year - xDisbursedDate.year
                            month_diff = xCurrentDate.month - xDisbursedDate.month

                            if xCurrentDate.day < xDisbursedDate.day:
                                month_diff -= 1
                            xMonthDifference = year_diff * 12 + month_diff

                            if len(i.get('auditInfo')):
                                if i.get('auditInfo')[0].get('stageOne') == 1:
                                    mCompletedStages += 1
                                if i.get('auditInfo')[0].get('stageTwo') == 1:
                                    mCompletedStages += 1
                                if i.get('auditInfo')[0].get('stageThree') == 1:
                                    mCompletedStages += 1
                                if i.get('auditInfo')[0].get('stageFour') == 1:
                                    mCompletedStages += 1
                                if i.get('auditInfo')[0].get('stageFive') == 1:
                                    mCompletedStages += 1
                                if i.get('auditInfo')[0].get('stageSix') == 1:
                                    mCompletedStages += 1
                 
                            del i['auditInfo']
                            i['auditInfo'] = mCompletedStages
                            if xTotalStages:            
                                if xMonthDifference <= xTotalStages * 2 and mHomestayPerformance == 'Green':
                                    mDownloadableArray.append(i)
                                elif xMonthDifference > xTotalStages * 2 and xMonthDifference <= xTotalStages * 2 + 2 and mHomestayPerformance == 'Yellow':
                                    mDownloadableArray.append(i)
                                elif xMonthDifference > xTotalStages * 2 + 2 and mHomestayPerformance == 'Red':
                                    mDownloadableArray.append(i)
                else:
                    async for i in fileQ:
                        mCompletedStages = 0                      
                        if len(i.get('auditInfo')):
                            if i.get('auditInfo')[0].get('stageOne') == 1:
                                mCompletedStages += 1
                            if i.get('auditInfo')[0].get('stageTwo') == 1:
                                mCompletedStages += 1
                            if i.get('auditInfo')[0].get('stageThree') == 1:
                                mCompletedStages += 1
                            if i.get('auditInfo')[0].get('stageFour') == 1:
                                mCompletedStages += 1
                            if i.get('auditInfo')[0].get('stageFive') == 1:
                                mCompletedStages += 1
                            if i.get('auditInfo')[0].get('stageSix') == 1:
                                mCompletedStages += 1

                        del i['auditInfo']
                        i['auditInfo'] = mCompletedStages
                        
                        mDownloadableArray.append(i)

            data = [ 
                {
                    'Applicant Id': x['applicantId'],
                    'Applicant Name': x['data']['applicantName'],
                    'Current Status': x['data']['currentStatus'],
                    'District Name': x['districtInfo']['districtName'],
                    'Block Name': x['blockInfo']['blockName'],
                    'State Name': x['stateInfo']['name'],
                    'Stages Completed': x['auditInfo'],
                } for x in mDownloadableArray
            ]

            workbook = Workbook()
            worksheet = workbook.active
            worksheet.title = "Sheet1"        
            header_font = Font(bold=True)
            header_alignment = Alignment(horizontal='center', vertical='center')

            headers = ['Applicant Id', 'Applicant Name', 'Current Status', 'District Name', 'Block Name', 'State Name', 'Stages Completed']
            worksheet.append(headers)
            for col_num, header in enumerate(headers, 1):
                cell = worksheet.cell(row=1, column=col_num, value=header)
                cell.font = header_font
                cell.alignment = header_alignment

            for row_num, row_data in enumerate(data, 2):
                for col_num, value in enumerate(row_data.values(), 1):
                    cell = worksheet.cell(row=row_num, column=col_num, value=value)
                    cell.alignment = Alignment(horizontal='center', vertical='center')

            for column in worksheet.columns:
                max_length = 0
                column = [cell for cell in column]
                for cell in column:
                    try:
                        if len(str(cell.value)) > max_length:
                            max_length = len(cell.value)
                    except:
                        pass
                adjusted_width = (max_length + 2)
                worksheet.column_dimensions[column[0].column_letter].width = adjusted_width

            xBuffer = io.BytesIO()
            workbook.save(xBuffer)

            self.set_header('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
            self.set_header('Content-Disposition', 'attachment; filename=loan_applicants.xlsx')
            self.write(xBuffer.getvalue())

            code = 2000
            message = 'Success'
            status = True

        except Exception as e:
            status = False
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'    
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            # self.write(response)
            await self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            # self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return
