#!/usr/bin/AdminListHandler
# -*- coding: utf-8 -*-

"""
    Description: AdminHandler
    Purpose: Get user list, add new user
"""
import datetime
import sys
from abc import ABCMeta
from bson import ObjectId
from bson.json_util import dumps as bdumps
from lib.lib import Validate
from build_config import CONFIG
from lib.element_mixer import ElementMixer
from lib.xen_protocol import xenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log


@xenSecureV2
class LocationHandler(ElementMixer, MongoMixin, metaclass=ABCMeta):
    
    auditInfo = MongoMixin.userDb[
        CONFIG['database'][0]['table'][19]['name']
    ]
    
    loanApplication = MongoMixin.userDb[
        CONFIG['database'][0]['table'][13]['name']
    ]

    loanStatusLog = MongoMixin.userDb[
        CONFIG['database'][0]['table'][18]['name']
    ]

    block = MongoMixin.userDb[
        CONFIG['database'][0]['table'][15]['name']
    ]

    district = MongoMixin.userDb[
        CONFIG['database'][0]['table'][14]['name']
    ]

    componentId = ObjectId('63d39988458b78fdf4cf6c0d')

    async def get(self):

        code = 4000
        status = False
        message = ''
        result = []

        try:
            try:
                year = self.get_argument('year')
                if year:
                    code, message = Validate.i(
                        year,
                        'Year',
                        datType=str,
                        notEmpty=True
                    )
                    if code != 4100:
                        raise Exception
                else:
                    raise Exception
            except:
                year = None

            if year:
                try:
                    sYear = year.split('-')[0]
                    code, message = Validate.i(
                        sYear,
                        'Start Year',
                        datType=int,
                        notEmpty=True
                    )
                    if code != 4100:
                        raise Exception
                except:
                    code = 7656
                    message = 'Start Year Required'
                    raise Exception

                try:
                    eYear = year.split('-')[1]
                    code, message = Validate.i(
                        eYear,
                        'End Year',
                        datType=int,
                        notEmpty=True
                    )
                    if code != 4100:
                        raise Exception
                except:
                    code = 7657
                    message = 'End Year Required'
                    raise Exception

                sYear = datetime.datetime(int(sYear), 4, 1, 0, 0, 0)
                sYear = sYear.strftime("%Y-%m-%d")

                eYear = datetime.datetime(int(eYear), 3, 31, 23, 59, 59)
                eYear = eYear.strftime("%Y-%m-%d")

                sYear = int(datetime.datetime.strptime(sYear, "%Y-%m-%d").timestamp()) * 1000000
                eYear = int(datetime.datetime.strptime(eYear, "%Y-%m-%d").timestamp()) * 1000000

                if sYear > eYear:
                    code = 5643
                    message = 'End Year Should Be Greater Than Start Year'
                    raise Exception
            try:
                vStatus = str(self.get_argument('status'))
            except :
                vStatus = None
                
            if vStatus != None:
                code, message = Validate.i(
                    vStatus,
                    'status',
                    dataType=str,
                )
                if code != 4100:
                    raise Exception
            
            try:
                loanId = str(self.get_argument('id'))  
                try:
                    loanId = ObjectId(loanId)
                except:
                    message = 'Invalid argument [id].'
                    code =  7098
                    raise Exception        
            except:
                loanId = None

            pipeline = [
                {
                    '$lookup': {
                        'from': self.loanApplication.name, 
                        'localField': 'loanId', 
                        'foreignField': '_id', 
                        'as': 'auditInfo',
                    }
                }, {
                    '$lookup': {
                        'from': self.district.name, 
                        'localField': 'auditInfo.data.unitDistrict', 
                        'foreignField': '_id', 
                        'as': 'districtInfo'
                    }
                }, {
                    '$unwind': {
                        'path': '$districtInfo', 
                        'preserveNullAndEmptyArrays': True
                    }
                }, {
                    '$lookup': {
                        'from': self.block.name, 
                        'localField': 'auditInfo.data.talukblock', 
                        'foreignField': '_id', 
                        'as': 'blockInfo'
                    }
                }, {
                    '$unwind': {
                        'path': '$blockInfo', 
                        'preserveNullAndEmptyArrays': True
                    }
                }, {
                    '$lookup': {
                        'from': self.loanStatusLog.name, 
                        'localField': 'loanId', 
                        'foreignField': 'loanApplicationId', 
                        'as': 'disbursementInfo'
                    }
                }, {
                    '$unwind': {
                        'path': '$disbursementInfo', 
                        'preserveNullAndEmptyArrays': True
                    }
                }, {
                    '$project': {
                        '_id': {
                            '$toString': '$_id'
                        }, 
                        'district': '$districtInfo.districtName', 
                        'block': '$blockInfo.blockName', 
                        'location': '$manualGis', 
                        'name': {
                            '$arrayElemAt': [
                                {
                                    '$ifNull': [
                                        '$auditInfo.data.applicantName', []
                                    ]
                                }, 0
                            ]
                        }, 
                        'applicantId': {
                            '$arrayElemAt': [
                                {
                                    '$ifNull': [
                                        '$auditInfo.applicantId', []
                                    ]
                                }, 0
                            ]
                        }, 
                        'auditData': '$auditData', 
                        'currentStatus': {
                            '$arrayElemAt': [
                                {
                                    '$ifNull': [
                                        '$auditInfo.data.currentStatus', []
                                    ]
                                }, 0
                            ]
                        }, 
                        'rejectedBy': {
                            '$arrayElemAt': [
                                {
                                    '$ifNull': [
                                        '$auditInfo.data.rejectedByBank', []
                                    ]
                                }, 0
                            ]
                        }, 
                        'totalSanctionedAmountByBank': {
                            '$arrayElemAt': [
                                {
                                    '$ifNull': [
                                        '$auditInfo.data.totalSanctionedAmountByBank', []
                                    ]
                                }, 0
                            ]
                        }, 
                        'totalDisbursedAmount': '$disbursementInfo.disbursed'
                    }
                }
            ]
            yearFilter = {}
            if year:
                yearFilter = {'$match': {'auditInfo.data.onlineSubmissionDate': {'$gte': sYear, '$lte': eYear}}}
            else:
                yearFilter = {'$match': {'auditInfo.data.onlineSubmissionDate': {'$exists': True}}}
            pipeline.insert(1, yearFilter)
            if vStatus is not None:
                pipeline.insert(1, {
                    '$match': {
                        'auditInfo.data.currentStatus': vStatus
                    }
                })

            if loanId is not None:
                pipeline.insert(0, {
                    '$match': {
                        'loanId': loanId
                    }
                })
            locInfo = self.auditInfo.aggregate(pipeline)
            result = []

            async for i in locInfo:
                try:
                    last_completed_stage = 0  
                    total_sanctioned_amount = 0
                    total_disbursed_amount = 0
                    stages = []  

                    for stage_num in range(1, 7):
                        stage_key = f'stage{stage_num}'
                        if stage_key in i['auditData']:
                            stage_data = i['auditData'][stage_key]
                            stage_images = []  

                            for sub_key, sub_data in stage_data.items():
                                if isinstance(sub_data, dict) and sub_data.get('images') is not None:
                                    stage_images.extend(sub_data['images'])  

                            if stage_images:
                                stages.append({
                                    'stageName': stage_key, 
                                    'images': stage_images 
                                })

                            if stage_data.get('stageStatus') == 'complete':
                                last_completed_stage = stage_num  

                    total_disbursed_amount = 0
                    if i.get('totalDisbursedAmount') is not None:
                        for disbursement in i['totalDisbursedAmount']:
                            if 'disbursedInfo' in disbursement:
                                total_disbursed_amount += sum(info.get('amount', 0) for info in disbursement['disbursedInfo'])

                    total_sanctioned_amount = 0
                    if i.get('totalSanctionedAmountByBank') is not None:
                        total_sanctioned_amount = i.get('totalSanctionedAmountByBank', 0)

                    currentStatus = ''
                    if i.get('currentStatus') is not None:
                        currentStatus = i['currentStatus']
                        if currentStatus == ['Rejected/Returned']:
                            rejectedByBank = i.get('rejectedBy', False)
                            if rejectedByBank:
                                currentStatus = 'Rejected By Bank'
                            else:
                                currentStatus = 'Rejected By DIC'

                    if i.get('location') is not None and currentStatus in ['Disbursed', 'Loan Sanctioned']:
                        result.append({
                            '_id': i['_id'],
                            'location': i.get('location', {}),
                            'block': i.get('block', ''),
                            'district': i.get('district', ''),
                            'name': i.get('name', ''),
                            'applicantId': i.get('applicantId', ''),
                            'stages': stages,
                            'lastCompletedStage': last_completed_stage, 
                            'totalSanctionedAmountByBank': total_sanctioned_amount,
                            'totalDisbursedAmount': total_disbursed_amount,
                            'currentStatus': currentStatus
                        })
                except KeyError as e:
                    # print(f"KeyError: {e} in dictionary {i}")
                    continue
            # Log.i('result', result)
            if len(result):
                message = 'Data found.'
                code = 2000
                status = True
            else:
                code = 4091
                message = 'Data not found.'
                result.append(
                    {
                        "_id": None,
                        "location": {
                            "latitude": "25.540013",
                            "longitude": "91.363274 ",
                            "address": "P1600 Amphitheatre Pkwy, , Mountain View, Santa Clara County, California 94043, United States"
                        },
                        "name": "Meghalaya",
                        "applicantId": None
                    },
                )

        except Exception as e:
            status = False
            self.set_status(503)

            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))

        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)

        try:
            response['result'] = result
            self.write(bdumps(response))
            await self.finish()
            return

        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return
