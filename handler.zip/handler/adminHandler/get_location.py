#!/usr/bin/AdminListHandler
# -*- coding: utf-8 -*-

"""
    Description: AdminHandler
    Purpose: Get user list, add new user
"""
import sys
from abc import ABCMeta
from bson import ObjectId
from bson.json_util import dumps as bdumps
from lib.lib import Validate
from build_config import CONFIG
from lib.element_mixer import ElementMixer
from lib.xen_protocol import xenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log


@xenSecureV2
class LocationHandler(ElementMixer, MongoMixin, metaclass=ABCMeta):
    
    auditInfo = MongoMixin.userDb[
        CONFIG['database'][0]['table'][19]['name']
    ]
    
    loanApplication = MongoMixin.userDb[
        CONFIG['database'][0]['table'][13]['name']
    ]

    componentId = ObjectId('63d39988458b78fdf4cf6c0d')

    async def get(self):

        code = 4000
        status = False
        message = ''
        result = []

        try:
            try:
                vStatus = str(self.get_argument('status'))
            except :
                vStatus = None
                
            if vStatus != None:
                code, message = Validate.i(
                    vStatus,
                    'status',
                    dataType=str,
                )
                if code != 4100:
                    raise Exception
            
            try:
                loanId = str(self.get_argument('id'))  
                try:
                    loanId = ObjectId(loanId)
                except:
                    message = 'Invalid argument [id].'
                    code =  7098
                    raise Exception        
            except:
                loanId = None

            pipeline = [
                {
                    '$lookup': {
                        'from': self.loanApplication.name,
                        'localField': 'loanId',
                        'foreignField': '_id',
                        'as': 'auditInfo',
                    }
                },
                {
                    '$project': {
                        '_id': {
                            '$toString': '$_id'
                        },
                        'location': '$manualGis',
                        'name': {
                            '$arrayElemAt': [
                                {'$ifNull': ['$auditInfo.data.applicantName', []]},
                                0
                            ]
                        },
                        'applicantId': {
                            '$arrayElemAt': [
                                {'$ifNull': ['$auditInfo.applicantId', []]},
                                0
                            ]
                        },
                        'auditData': '$auditData'  
                    }
                },
            ]

            if vStatus is not None:
                pipeline.insert(1, {
                    '$match': {
                        'auditInfo.data.currentStatus': vStatus
                    }
                })

            if loanId is not None:
                pipeline.insert(0, {
                    '$match': {
                        'loanId': loanId
                    }
                })

            locInfo = self.auditInfo.aggregate(pipeline)
            result = []

            async for i in locInfo:
                try:
                    last_completed_stage = 0  
                    
                    for stage_num in range(1, 7):  
                        stage_key = f'stage{stage_num}'
                        if stage_key in i['auditData']:
                            if i['auditData'][stage_key].get('stageStatus') == 'complete':
                                last_completed_stage = stage_num
                            else:
                                break  

                    if i['location'] is not None:
                        result.append({
                            '_id': i['_id'],
                            'location': i.get('location', {}),
                            'name': i.get('name', ''),
                            'applicantId': i.get('applicantId', ''),
                            'stage': last_completed_stage  
                        })
                
                except KeyError as e:
                    # print(f"KeyError: {e} in dictionary {i}")
                    continue
                
            # Log.i('result', result)
            if len(result):
                message = 'Data found.'
                code = 2000
                status = True
            else:
                code = 4091
                message = 'Data not found.'
                result.append(
                    {
                        "_id": None,
                        "location": {
                            "latitude": "25.540013",
                            "longitude": "91.363274 ",
                            "address": "P1600 Amphitheatre Pkwy, , Mountain View, Santa Clara County, California 94043, United States"
                        },
                        "name": "Meghalaya",
                        "applicantId": None
                    },
                )

        except Exception as e:
            status = False
            self.set_status(503)

            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))

        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)

        try:
            response['result'] = result
            self.write(bdumps(response))
            await self.finish()
            return

        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return
