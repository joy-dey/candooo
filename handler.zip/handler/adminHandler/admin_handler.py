#!/usr/bin/AdminListHandler
# -*- coding: utf-8 -*-

"""
    Description: AdminHandler
    Purpose: Get user list, add new user
"""
import json
import sys
import tornado.web
from abc import ABCMeta
from bson import ObjectId
from bson.json_util import dumps as bdumps
from build_config import CONFIG
from lib.element_mixer import ElementMixer
from lib.fernet_crypto import FN_DECRYPT, FN_ENCRYPT
from lib.lib import Validate
from lib.xen_protocol import noXenSecureV2, xenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log
from util.time_util import timeNow


@xenSecureV2
class AdminListHandler(ElementMixer, MongoMixin, metaclass=ABCMeta):

    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]

    applications = MongoMixin.userDb[
        CONFIG['database'][0]['table'][1]['name']
    ]

    profile = MongoMixin.userDb[
        CONFIG['database'][0]['table'][2]['name']
    ]

    state = MongoMixin.userDb[
        CONFIG['database'][0]['table'][6]['name']
    ]

    countries = MongoMixin.userDb[
        CONFIG['database'][0]['table'][7]['name']
    ]

    phoneCountry = MongoMixin.userDb[
        CONFIG['database'][0]['table'][5]['name']
    ]

    componentId = ObjectId('63d38614458b78fdf4cf6bfa')

    async def get(self):

        code = 4000
        status = False
        message = ''
        result = []

        try:
            try:
                f_limit = int(self.get_argument('limit'))
                f_skip = int(self.get_argument('skip'))
                
            except:
                f_limit = 10
                f_skip = 0
            
            try:
                isAllData = bool(self.request.arguments.get('isAllData'))
            except:
                isAllData = False

            try:
                vApplicationIds = json.loads(self.request.arguments.get('applicationId')[0].decode())

            except Exception as e:
                code = 4072
                message = 'Invalid Argument - [ applicationId ]'
                raise Exception
            
            vApplicationArray = []
            if type(vApplicationIds) == str:
                    vApplicationArray.append(vApplicationIds)
            code, message = Validate.i(
                vApplicationIds,
                'applicationId',
                dataType=list,
                notEmpty=True
            )
            if code != 4100:
                raise Exception
            
            for no, value in enumerate(vApplicationIds):
                try:
                    value = ObjectId(value)
                except:
                    code = 4098
                    message = 'Invalid Argument - [ applicationId ] of no {}'.format(no + 1)
                    raise Exception
                
                vApplicationArray.append(value)

            try: 
                vStatus = self.request.arguments.get('status')[0].decode()    
                vStatus = json.loads(vStatus)
            except:
                code = 4089
                message = 'Invalid Argument [ status ]'
                raise Exception
            code, message = Validate.i(
                vStatus,
                'status',
                notNull=True,
                dataType=list,
                notEmpty=True
            )
            if code != 4100:
                raise Exception
            
            for i, value in enumerate(vStatus):
                code,message = Validate.i(
                    value,
                    '{}. no status code is invalid'.format(i+1),
                    dataType=int,
                    enums = [0, 1]
                )
                if code != 4100:
                    raise Exception

            pipeline = [
                    {
                        '$match': {
                            'status': {
                                '$in': vStatus
                            }
                        }
                    },
                    {
                        '$lookup': {
                            'from': CONFIG['database'][0]['table'][0]['name'],
                            'localField': 'accountId',
                            'foreignField': '_id',
                            'as': 'accountInfo',
                            'pipeline': [
                                {
                                    '$lookup': {
                                        'from': CONFIG['database'][0]['table'][14]['name'],
                                        'localField': 'districts',
                                        'foreignField': '_id',
                                        'as': 'districtInfo',
                                        'pipeline': [
                                            {
                                                '$project': {
                                                    '_id': {
                                                        '$toString': '$_id'
                                                    },
                                                    'code': 1,
                                                    'districtName': 1,
                                                    'stateCode': 1
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    '$project': {
                                        '_id': {
                                            '$toString': '$_id'
                                        },
                                        'firstName': 1,
                                        'lastName': 1,
                                        'contact': {
                                            'phoneNumber': 1,
                                            'value': 1,
                                        },
                                        'role': 1,
                                        'privacy': {
                                            'value': 1
                                        },
                                        'designation': 1,
                                        'districtInfo': 1,
                                        'address': 1
                                    }
                                }
                            ]
                        }
                    },
                    {
                        '$lookup': {
                            'from': CONFIG['database'][0]['table'][1]['name'],
                            'localField': 'applicationId',
                            'foreignField': '_id',
                            'as': 'applicationInfo'
                        }
                    },
                    {
                        '$match': {
                            'applicationInfo._id': {
                                '$in': vApplicationArray
                            }
                        }
                    },
                    {
                        '$project': {
                            '_id': {
                                '$toString': '$_id'
                            },
                            'applicationId': 1,
                            'accountInfo': 1,
                            'applicationInfo': {
                                'title': 1
                            },
                            'status': 1,
                            'isSuperAdmin': 1,
                            'permissions': 1,
                            'createdBy': {
                                '$toString': '$createdBy'
                            },
                            'department': 1
                        }
                    },
                    {
                        '$sort': {
                            '_id': -1
                        }
                    },
                    {
                        '$skip': f_skip
                    },
                    {
                        '$limit': f_limit  
                    }
                ]

            if isAllData:
                pipeline.pop(7)

            adminListQ = self.profile.aggregate(pipeline)
            async for i in adminListQ:
                decryptPw = FN_DECRYPT(i.get('accountInfo')[0].get('privacy')[0].get('value'))
                if type(decryptPw) is bytes:
                    decryptPw = decryptPw.decode()
                i['accountInfo'][0]['privacy'][0]['value'] = decryptPw    
                i['department'] = i.get('department',None)       
                del i['applicationId']
                result.append(i)

            if len(result):
                message = 'Data found.'
                code = 2000
                status = True
            else:
                code = 4091
                message = 'Account not found.'

        except Exception as e:
            status = False
            self.set_status(503)

            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))

        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)

        try:
            response['result'] = result
            self.write(bdumps(response))
            await self.finish()
            return

        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return

    async def post(self):
        status = False
        code = 4000
        result = []
        message = ''
        try:
            try:
                self.request.arguments = json.loads(self.request.body.decode())
            except Exception as e:
                code = 4100
                message = 'Expected Request Type JSON.'
                raise Exception

            vfirstName = self.request.arguments.get('firstName')
            code, message = Validate.i(
                vfirstName,
                'firstName',
                notNull=True,
                notEmpty=True,
                dataType=str,
                maxLength=50,
                noSpecial=True,
                noSymbol=True
            )
            if code != 4100:
                raise Exception

            vlastName = self.request.arguments.get('lastName')
            code, message = Validate.i(
                vlastName,
                'lastName',
                notNull=True,
                notEmpty=True,
                dataType=str,
                maxLength=50,
                noSpecial=True,
                noSymbol=True
            )
            if code != 4100:
                raise Exception

            vapplicationId = self.request.arguments.get('applicationId')
            code, message = Validate.i(
                vapplicationId,
                'applicationId',
                notNull=True,
                notEmpty=True,
                dataType=str
            )
            if code != 4100:
                raise Exception

            vapplicationId = ObjectId(vapplicationId)

            application = await self.applications.find_one(
                {
                    '_id': vapplicationId
                }
            )
            if not application:
                message = '[ applicationId ] not found.'
                code = 4224
                raise Exception

            vphoneNumber = self.request.arguments.get('phoneNumber')
            code, message = Validate.i(
                vphoneNumber,
                'phoneNumber',
                notNull=True,
                notEmpty=True,
                dataType=int
            )
            if code != 4100:
                raise Exception
            
            if vphoneNumber < 0000000000 or vphoneNumber > 9999999999:
                code = 4352
                message = 'Please enter a valid phone number'
                raise Exception

            vcountryCode = self.request.arguments.get('countryCode')
            code, message = Validate.i(
                vcountryCode,
                'countryCode',
                notNull=True,
                notEmpty=True,
                dataType=int,
                minNumber=1,
                maxNumber=9999
            )
            if code != 4100:
                raise Exception
            countryCode = await self.phoneCountry.find_one(
                {
                    'code': vcountryCode
                }
            )
            if not countryCode:
                code = 4242
                message = 'Dial code does not exist.'
                raise Exception
            if len(str(vphoneNumber)) != countryCode['telMaxLength']:
                code = 4252
                message = 'Please enter a valid Phone Number.'
                raise Exception('phoneNumber')
            else:
                orgPhoneNumber = vphoneNumber
                phoneNumber = int(str(vcountryCode) + str(vphoneNumber))

            accountFind = await self.account.find_one(
                {
                    'contact.0.value': phoneNumber
                }
            )
            if accountFind:
                message = 'Phone number already exists.'
                code = 4256
                raise Exception

            vemailAdress = self.request.arguments.get('emailAddress')
            if vemailAdress:
                code, message = Validate.i(
                    vemailAdress,
                    'emailAddress',
                    dataType=str,
                    inputType='email',
                    maxLength=120
                )
                if code != 4100:
                    raise Exception
            else:
                vemailAdress = None
            
            vpassword = self.request.arguments.get('password')
            code, message = Validate.i(
                vpassword,
                'password',
                dataType=str,
                notNull=True
            )
            if code != 4100:
                raise Exception
            
            vpassword = FN_ENCRYPT(vpassword, encode=True)

            vRole = self.request.arguments.get('role')
            code, message = Validate.i(
                vRole,
                'role',
                dataType=str,
                enums = ['Auditor', 'Admin'],
                notEmpty=True
            )
            if code != 4100:
                raise Exception
            
            if vRole == 'Admin':
                department = self.request.arguments.get('department')
                code, message = Validate.i(
                    department,
                    'Department',
                    notEmpty=True,
                    notNull=True,
                    dataType=str,
                    enums = ['Tourism','Bank','DIC']
                )
                if code != 4100:
                    raise Exception
            
            mProfileFind = await self.profile.find_one(
                {
                    '_id': self.profileId
                }
            )
            if not mProfileFind:
                code = 4436
                message = 'Profile not found'
                raise Exception
            
            vPermissions = self.request.arguments.get('permissions')
            if vPermissions:
                code, message = Validate.i(
                    vPermissions,
                    'permissions',
                    dataType=list,
                    notEmpty=True
                )
                if code != 4100:
                    raise Exception
                
                # Module Permissions
                vModulePermissions =    [
                        {'id': '8b639fe0-3847-41b6-b3b5-4fce727fd4ea', 'name': 'Dashboard'},
                        {'id': 'b08353c1-4aee-4487-8067-99ad5a312259', 'name': 'Applications'},
                        {'id': '04d1c9ca-1262-436a-a600-317e9c2c6cda', 'name': 'Audit Info'},
                        {'id': '9fa2cfcd-02b9-49d2-8f5f-42626f09d246', 'name': 'Trainings'},
                        {'id': '672864de-03b2-45bd-9a50-e943675532ca', 'name': 'Admins'},
                        {'id': 'c10df772-8c71-4d47-b202-fb64db4dbb4c', 'name': 'Auditors'},
                        {'id': '1e275b90-f0b3-4b6c-8620-84f2a2e52d4c', 'name': 'Grievances'}, 
                        {'id': 'dab8d600-686a-4939-9401-c879022fdaaa', 'name': 'Banking'},
                        {'id': '547ee6a6-ab46-4e19-a67e-c7423aa0ad90', 'name': 'Architect Mapping'},
                        {'id': '3311872f-2dec-43ea-9a3e-2a423febd1f3', 'name': 'Defaulters'}
                        # {'id': '95ce77dc-e078-4f00-8cb8-308368fc11e1', 'name': 'Applicants'} # Architect Module
                    ]
                mPermissionIds = []
                for mIds in vModulePermissions:
                    mPermissionIds.append(mIds.get('id'))
                for permissions in vPermissions:
                    if permissions not in mPermissionIds:
                        code = 4443
                        message = 'Invalid Permission {}'.format(permissions)
                        raise Exception
                    if permissions not in mProfileFind.get('permissions'):
                        for i in vModulePermissions:
                            if permissions == i.get('id'):
                                permissions = i.get('name')
                        code = 4461
                        message = 'You can not give {} permission'.format(permissions)
                        raise Exception
            else:
                vPermissions = []
            
            vAddress = None
            if vRole == 'Auditor':
                vDesignation = self.request.arguments.get('designation')
                code, message = Validate.i(
                    vDesignation,
                    'designation',
                    notEmpty=True,
                    dataType=str,
                    enums = ['Tourist Officer', 'Bank Officials', 'DIC', 'Architect']
                )
                if code != 4100:
                    raise Exception

                vDistricts = self.request.arguments.get('districts')
                if vDistricts:
                    code, message = Validate.i(
                        vDistricts,
                        'districts',
                        dataType=list,
                        notEmpty=True
                    )
                    if code != 4100:
                        raise Exception
                    
                    vDistrictIds = []
                    for i, d in enumerate(vDistricts):
                        code, message = Validate.i(
                            d,
                            'Invalid district {}'.format(i+1),
                            dataType=str,
                            notEmpty=True
                        )
                        if code != 4100:
                            raise Exception
                        
                        try:
                            vDistrictIds.append(ObjectId(d))
                        except:
                            code = 4371
                            message = 'Invalid district id {}'.format(i+1)
                            raise Exception
                else:
                    vDistrictIds = None
                
                if vDesignation == 'Architect': 
                    if mProfileFind.get('isSuperAdmin') == False and mProfileFind.get('department') != 'Tourism':
                        code = 8392
                        message = 'You are not allowed to add Architect.'
                        raise Exception
                    
                    vAddress = self.request.arguments.get('address')
                    code, message = Validate.i(
                        vAddress,
                        'address',
                        dataType=str,
                        notEmpty=True
                    )
                    if code != 4100:
                        raise Exception
                    
                    if not vemailAdress:
                        code = 4536
                        message = 'Email can not be empty for Architect'
                        raise Exception
                    vPermissions = []
                else:
                    if not vDistrictIds:
                        code = 4542
                        message = 'Districts can not be empty'
                        raise Exception
                if vDesignation == 'Architect':
                        #Applicants Permission for Architect
                        vPermissions.append('95ce77dc-e078-4f00-8cb8-308368fc11e1')
                elif vDesignation == 'Tourist Officer':
                    if vPermissions == []:
                        vPermissions.append('8b639fe0-3847-41b6-b3b5-4fce727fd4ea')
                        vPermissions.append('9fa2cfcd-02b9-49d2-8f5f-42626f09d246')
                        vPermissions.append('547ee6a6-ab46-4e19-a67e-c7423aa0ad90')
                        vPermissions.append('3311872f-2dec-43ea-9a3e-2a423febd1f3')
                    elif '8b639fe0-3847-41b6-b3b5-4fce727fd4ea' not in vPermissions:
                        vPermissions.append('8b639fe0-3847-41b6-b3b5-4fce727fd4ea')
                    elif '9fa2cfcd-02b9-49d2-8f5f-42626f09d246' not in vPermissions:
                        vPermissions.append('9fa2cfcd-02b9-49d2-8f5f-42626f09d246')
                    elif '547ee6a6-ab46-4e19-a67e-c7423aa0ad90' not in vPermissions:
                        vPermissions.append('547ee6a6-ab46-4e19-a67e-c7423aa0ad90')
                    elif '3311872f-2dec-43ea-9a3e-2a423febd1f3' not in vPermissions:
                        vPermissions.append('3311872f-2dec-43ea-9a3e-2a423febd1f3')
                        
                elif vDesignation == 'Bank Officials':
                    if vPermissions == []:
                        vPermissions.append('8b639fe0-3847-41b6-b3b5-4fce727fd4ea')
                        vPermissions.append('547ee6a6-ab46-4e19-a67e-c7423aa0ad90')
                        vPermissions.append('3311872f-2dec-43ea-9a3e-2a423febd1f3')
                    elif '8b639fe0-3847-41b6-b3b5-4fce727fd4ea' not in vPermissions:
                        vPermissions.append('8b639fe0-3847-41b6-b3b5-4fce727fd4ea')
                    elif '547ee6a6-ab46-4e19-a67e-c7423aa0ad90' not in vPermissions:
                        vPermissions.append('547ee6a6-ab46-4e19-a67e-c7423aa0ad90')
                    elif '3311872f-2dec-43ea-9a3e-2a423febd1f3' not in vPermissions:
                        vPermissions.append('3311872f-2dec-43ea-9a3e-2a423febd1f3')
                else:
                    if vPermissions == []:
                        vPermissions.append('8b639fe0-3847-41b6-b3b5-4fce727fd4ea')
                        vPermissions.append('9fa2cfcd-02b9-49d2-8f5f-42626f09d246')
                        vPermissions.append('547ee6a6-ab46-4e19-a67e-c7423aa0ad90')
                    elif '8b639fe0-3847-41b6-b3b5-4fce727fd4ea' not in vPermissions:
                        vPermissions.append('8b639fe0-3847-41b6-b3b5-4fce727fd4ea')
                    elif '9fa2cfcd-02b9-49d2-8f5f-42626f09d246' not in vPermissions:
                        vPermissions.append('9fa2cfcd-02b9-49d2-8f5f-42626f09d246')
                    elif '547ee6a6-ab46-4e19-a67e-c7423aa0ad90' not in vPermissions:
                        vPermissions.append('547ee6a6-ab46-4e19-a67e-c7423aa0ad90')

            else:
                vDesignation = None
                vDistrictIds = None         
                # By Default Giving Dashboard Permission for Admin
                if '8b639fe0-3847-41b6-b3b5-4fce727fd4ea' not in vPermissions:
                    vPermissions.append('8b639fe0-3847-41b6-b3b5-4fce727fd4ea')
        
            vStatus = self.request.arguments.get('status')
            if vStatus == 0:
                vStatus = 0
            elif not vStatus:
                vStatus = 1
            code, message = Validate.i(
                vStatus,
                'status',
                notNull=True,
                notEmpty=True,
                enums = [0, 1]
            )
            if code != 4100:
                raise Exception

            vContact = [
                    {
                        'type': 0,
                        'value': phoneNumber,
                    },
                    {
                        'type': 1,
                        'verified': False,
                        'value': phoneNumber,
                        'dialCode': vcountryCode,
                        'sDialCode': countryCode['sCode'],
                        'phoneNumber': orgPhoneNumber,
                        'countryCode': countryCode['isoAlpha3Code']
                    }
                ]
            if vemailAdress:
                vContact.append(
                    {
                        'verified': False,
                        'value': vemailAdress,
                        'type': 2
                    }
                )

            accountData = {
                'firstName': vfirstName,
                'lastName': vlastName,
                'createdAt': timeNow(),
                'createdBy': self.accountId,
                'files': [],
                'time': timeNow(),
                'role': vRole,
                'districts': vDistrictIds,
                'designation': vDesignation,
                'address': vAddress,
                'privacy': [
                    {
                        'value': vpassword
                    }
                ],
                'contact': vContact
            }
            try:
                accountId = await self.account.insert_one(accountData)
            except Exception as e:
                exe = str(e).split(':')
                if len(exe) < 2:
                    status = False
                    code = 4280
                    message = 'Internal Error Please Contact the Support Team.'
                elif 'contact.0.value_1' in exe[2]:
                    status = False
                    code = 4281
                    message = 'This Username is already registered.'
                elif 'contact.1.value_1' in exe[2]:
                    status = False
                    code = 4281
                    message = 'This Phone Number is already registered.'
                elif 'contact.2.value_1' in exe[2]:
                    status = False
                    code = 4282
                    message = 'This email is already registered.'
                else:
                    status = False
                    code = 4283
                    message = 'Internal Error Please Contact the Support Team.'
                raise Exception
            try:
                accountId = accountId.inserted_id
                profileData = {
                        'active': True,
                        'locked': False,
                        'closed': False,
                        'time': timeNow(),
                        'accountId': accountId,
                        'applicationId': vapplicationId,
                        'entityId': self.entityId,
                        'permissions': vPermissions,
                        'status': vStatus,
                        'isSuperAdmin': False,
                        'data': [],
                        'organization': [],
                        'lastSignInRequest': 0,
                        'retrySignInRequest': 0,
                        'createdBy': self.accountId,
                        'createdAt': timeNow()
                    }
                if vRole == 'Admin':
                    profileData['department'] = department
                profileId = await self.profile.insert_one(profileData)
                profileId = profileId.inserted_id
                if profileId:
                    message = 'New account created successfully.'
                    code = 2000
                    status = True
                else:
                    message = 'Account not created.'
                    code = 4415
            except:
                code = 5830
                message = 'Internal Error Please Contact the Support Team.'
                raise Exception
        except Exception as e:
            status = False
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(response)
            await self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return

    async def put(self):
        status = False
        code = 4000
        result = []
        message = ''

        try:
            try:
                self.request.arguments = json.loads(self.request.body.decode())
            except:
                message = 'Expected request type JSON.'
                code = 4611
                raise Exception
            
            vapplicationId = self.request.arguments.get('applicationId')
            code, message = Validate.i(
                vapplicationId,
                'applicationId',
                notNull=True,
                notEmpty=True,
                dataType=str
            )
            if code != 4100:
                raise Exception

            vapplicationId = ObjectId(vapplicationId)

            application = await self.applications.find_one(
                {
                    '_id': vapplicationId
                }
            )
            if not application:
                message = 'ApplicationId not found.'
                code = 4224
                raise Exception
            
            acId = self.request.arguments.get('id')
            code, message = Validate.i(
                acId,
                'id',
                notNull=True,
                notEmpty=True,
                dataType=str
            )
            if code != 4100:
                raise Exception
            acId = ObjectId(acId)
            
            try:
                vMethod = self.request.arguments.get('method')
                if not vMethod:
                    raise Exception
                code, message = Validate.i(
                    vMethod,
                    'method',
                    dataType=int,
                    enums = [1]
                )
                if code != 4100:
                    raise Exception
            except:
                vMethod = None
            
            mFindSignedAccount = await self.account.find_one(
                    {
                        '_id': self.accountId
                    },
                    {
                        'role': 1
                    }
                )         
            mFindSignedProfile = await self.profile.find_one(
                            {
                                'accountId': self.accountId,
                                'status': 1
                            },
                            {   
                                'isSuperAdmin': 1,
                                'permissions': 1
                            }
                        )
            if not mFindSignedProfile:
                code = 4707
                message = 'Your account is deactive please contact with admin'
                raise Exception
            
            xProfileFind = await self.profile.find_one(
                {
                    'accountId': acId
                },
                {
                    'isSuperAdmin': 1,
                    'permissions': 1,
                    'createdBy': 1
                }
            )
            if not xProfileFind:
                code = 4834
                message = 'Invalid Argument - [ id ] Profile Not Found'
                raise Exception

            if vMethod == 1:                
                if mFindSignedAccount:
                    if mFindSignedAccount.get('role') == 'Admin':
                        vStatus = self.request.arguments.get('status')
                        if vStatus == 0:
                            vStatus = 0
                        elif not vStatus:
                            vStatus = 1
                        code, message = Validate.i(
                            vStatus,
                            'status',
                            notNull=True,
                            notEmpty=True,
                            enums = [0, 1]
                        )
                        if code != 4100:
                            raise Exception

                        xAllPermissions = ['3311872f-2dec-43ea-9a3e-2a423febd1f3','8b639fe0-3847-41b6-b3b5-4fce727fd4ea','b08353c1-4aee-4487-8067-99ad5a312259','04d1c9ca-1262-436a-a600-317e9c2c6cda','9fa2cfcd-02b9-49d2-8f5f-42626f09d246','672864de-03b2-45bd-9a50-e943675532ca','c10df772-8c71-4d47-b202-fb64db4dbb4c','1e275b90-f0b3-4b6c-8620-84f2a2e52d4c','dab8d600-686a-4939-9401-c879022fdaaa', '547ee6a6-ab46-4e19-a67e-c7423aa0ad90']
                        xAccountPermissions = xProfileFind.get('permissions')
                        if mFindSignedProfile.get('isSuperAdmin'):
                            if vStatus == 0:                                
                                if xProfileFind.get('isSuperAdmin'):
                                    try:
                                        mNewSuperAdmin = self.request.arguments.get('newSuperAdminId')
                                        if mNewSuperAdmin:
                                            code, message = Validate.i(
                                                mNewSuperAdmin,
                                                'newSuperAdminId',
                                                dataType=str,
                                                notEmpty=True
                                            )
                                            if code != 4100:
                                                raise Exception
                                            mNewSuperAdmin = ObjectId(mNewSuperAdmin)
                                        else:
                                            mNewSuperAdmin = None
                                    except:
                                        mNewSuperAdmin = None
                                        
                                    if not mNewSuperAdmin:
                                        code = 4767
                                        message = 'Please make another superadmin'
                                        raise Exception
                                    else:
                                        xAccountFind = await self.account.find_one(
                                            {
                                                '_id': mNewSuperAdmin
                                            },
                                            {
                                                'role': 1
                                            }
                                        )
                                        if not xAccountFind:
                                            code = 4875
                                            message = 'Invalid Argument - [ newSuperAdminId ] Account Not Found'
                                            raise Exception
                                
                                        if xAccountFind.get('role') == 'Admin':
                                            proupdateP = await self.profile.update_one(
                                                {
                                                    'accountId': mNewSuperAdmin
                                                },
                                                {
                                                    '$set': {
                                                        'active': True,
                                                        'locked': False,
                                                        'closed': False,
                                                        'time': timeNow(),
                                                        'accountId': mNewSuperAdmin,
                                                        'applicationId': vapplicationId,
                                                        'entityId': self.entityId,
                                                        'status': 1,
                                                        'permissions': xAllPermissions,
                                                        'isSuperAdmin': True,
                                                        'data': [],
                                                        'organization': [],
                                                        'lastSignInRequest': 0,
                                                        'retrySignInRequest': 0
                                                    }
                                                }
                                            )
                                            proupdateQ = await self.profile.update_one(
                                                {
                                                    'accountId': acId
                                                },
                                                {
                                                    '$set': {
                                                        'active': True,
                                                        'locked': False,
                                                        'closed': False,
                                                        'time': timeNow(),
                                                        'accountId': acId,
                                                        'applicationId': vapplicationId,
                                                        'entityId': self.entityId,
                                                        'permissions': xAccountPermissions,
                                                        'status': vStatus,
                                                        'isSuperAdmin': False,
                                                        'data': [],
                                                        'organization': [],
                                                        'lastSignInRequest': 0,
                                                        'retrySignInRequest': 0
                                                    }
                                                }
                                            )
                                            if vStatus == 0 and proupdateQ.modified_count:
                                                message = 'Account has been deactivated successfully'
                                                code = 2000
                                                status = True
                                            elif vStatus == 1 and proupdateQ.modified_count:
                                                message = 'Account has been activated successfully'
                                                code = 2000
                                                status = True
                                            else:
                                                message = 'Account has not deactivated'
                                                code = 4826
                                                raise Exception
                                        else:
                                            code = 4822
                                            message = 'Auditor can not be a Superadmin'
                                            raise Exception

                                elif not xProfileFind.get('isSuperAdmin'):
                                    proupdateQ = await self.profile.update_one(
                                            {
                                                'accountId': acId
                                            },
                                            {
                                                '$set': {
                                                    'active': True,
                                                    'locked': False,
                                                    'closed': False,
                                                    'time': timeNow(),
                                                    'accountId': acId,
                                                    'applicationId': vapplicationId,
                                                    'entityId': self.entityId,
                                                    'status': vStatus,
                                                    'isSuperAdmin': False,
                                                    'permissions': xAccountPermissions,
                                                    'data': [],
                                                    'organization': [],
                                                    'lastSignInRequest': 0,
                                                    'retrySignInRequest': 0
                                                }
                                            }
                                        )
                                    if vStatus == 0 and proupdateQ.modified_count:
                                        message = 'Account has been deactivated successfully'
                                        code = 2000
                                        status = True
                                    elif vStatus == 1 and proupdateQ.modified_count:
                                        message = 'Account has been activated successfully'
                                        code = 2000
                                        status = True
                                    else:
                                        message = 'Account has not deactivated'
                                        code = 4860
                                        raise Exception     
                                    
                            else:
                                proupdateQ = await self.profile.update_one(
                                        {
                                            'accountId': acId
                                        },
                                        {
                                            '$set': {
                                                'active': True,
                                                'locked': False,
                                                'closed': False,
                                                'time': timeNow(),
                                                'accountId': acId,
                                                'applicationId': vapplicationId,
                                                'entityId': self.entityId,
                                                'status': vStatus,
                                                'isSuperAdmin': False,
                                                'permissions': xAccountPermissions,
                                                'data': [],
                                                'organization': [],
                                                'lastSignInRequest': 0,
                                                'retrySignInRequest': 0
                                            }
                                        }
                                    )
                                if vStatus == 0 and proupdateQ.modified_count:
                                    message = 'Account has been deactivated successfully'
                                    code = 2000
                                    status = True
                                elif vStatus == 1 and proupdateQ.modified_count:
                                    message = 'Account has been activated successfully'
                                    code = 2000
                                    status = True
                                else:
                                    message = 'Account has not deactivated'
                                    code = 4860
                                    raise Exception
                    
                        else:
                            mFindAccount = await self.account.find_one(
                                {
                                    '_id': acId
                                },
                                {   
                                    'role': 1
                                }
                            )
                            if not mFindAccount:
                                code = 4027
                                message = 'Invalid Argument - [ id ] Account Not Found'
                                raise Exception
                            
                            if (mFindAccount.get('role') == 'Auditor' and xProfileFind.get('createdBy') == self.accountId) or (mFindAccount.get('designation') == 'Architect' and xProfileFind.get('createdBy') == self.accountId):
                                proupdateQ = await self.profile.update_one(
                                                {
                                                    'accountId': acId
                                                },
                                                {
                                                    '$set': {
                                                        'active': True,
                                                        'locked': False,
                                                        'closed': False,
                                                        'time': timeNow(),
                                                        'accountId': acId,
                                                        'applicationId': vapplicationId,
                                                        'entityId': self.entityId,
                                                        'status': vStatus,
                                                        'isSuperAdmin': False,
                                                        'permissions': xAccountPermissions,
                                                        'data': [],
                                                        'organization': [],
                                                        'lastSignInRequest': 0,
                                                        'retrySignInRequest': 0
                                                    }
                                                }
                                            )
                                if vStatus == 0 and proupdateQ.modified_count:
                                    message = 'Account has been deactivated successfully'
                                    code = 2000
                                    status = True
                                elif vStatus == 1 and proupdateQ.modified_count:
                                    message = 'Account has been activated successfully'
                                    code = 2000
                                    status = True
                                else:
                                    message = 'Account has not deactivated'
                                    code = 4882
                                    raise Exception
                                
                            elif acId == self.accountId:
                                xSignedAccountPermissions = mFindSignedProfile.get('permissions')
                                proupdateQ = await self.profile.update_one(
                                                {
                                                    'accountId': acId
                                                },
                                                {
                                                    '$set': {
                                                        'active': True,
                                                        'locked': False,
                                                        'closed': False,
                                                        'time': timeNow(),
                                                        'accountId': acId,
                                                        'applicationId': vapplicationId,
                                                        'entityId': self.entityId,
                                                        'status': vStatus,
                                                        'isSuperAdmin': False,
                                                        'permissions': xSignedAccountPermissions,
                                                        'data': [],
                                                        'organization': [],
                                                        'lastSignInRequest': 0,
                                                        'retrySignInRequest': 0
                                                    }
                                                }
                                            )
                                if vStatus == 0 and proupdateQ.modified_count:
                                    message = 'Account has been deactivated successfully'
                                    code = 2000
                                    status = True
                                elif vStatus == 1 and proupdateQ.modified_count:
                                    message = 'Account has been activated successfully'
                                    code = 2000
                                    status = True
                                else:
                                    message = 'Account has not deactivated'
                                    code = 4976
                                    raise Exception
                                
                            else:
                                code = 4943
                                message = 'You can not activete or deactivate this Profile'
                                raise Exception
                    else:
                        code = 4865
                        message = 'You are not authorized to deactivate an account'
                        raise Exception               
                else:
                    code = 4783
                    message = 'Account not found'
                    raise Exception
            else:
                mProfileFind = await self.profile.find_one(
                    {
                        'accountId': acId
                    },
                    {
                        'status': 1,
                        'department' : 1,
                        'isSuperAdmin' : 1,
                        'permissions' : 1
                    }
                )
                if not mProfileFind:
                    code = 4138
                    message = 'Account not found'
                    raise Exception
                else:
                    if mProfileFind.get('status') == 0 and not mFindSignedProfile.get('isSuperAdmin'):
                        code = 4143
                        message = 'Please activate the account to update'
                        raise Exception 
                    elif mFindSignedProfile.get('isSuperAdmin') or mProfileFind.get('status') == 1:
                        mAccountFind = await self.account.find_one(
                            {
                                '_id': acId
                            },
                            {
                                'role': 1
                            }
                        )                   

                        vfirstName = self.request.arguments.get('firstName')
                        code, message = Validate.i(
                            vfirstName,
                            'firstName',
                            dataType=str,
                            maxLength=50,
                            noSpecial=True,
                            noSymbol=True
                        )
                        if code != 4100:
                            raise Exception

                        if not mProfileFind.get('isSuperAdmin') and mFindSignedAccount.get('role') == 'Admin' and mAccountFind.get('role') == 'Admin':
                            department = self.request.arguments.get('department')
                            code, message = Validate.i(
                                department,
                                'Department',
                                notEmpty=True,
                                notNull=True,
                                dataType=str,
                                enums = ['Tourism','Bank','DIC']
                            )
                            if code != 4100:
                                raise Exception
                            
                            if mProfileFind.get('department',None) != None and mProfileFind.get('department',None) != department:
                                code = 8762
                                message = 'Department cannot be changed, once added.'
                                raise Exception
                        
                        else:
                            department = None
                        vlastName = self.request.arguments.get('lastName')
                        code, message = Validate.i(
                            vlastName,
                            'lastName',
                            dataType=str,
                            maxLength=50,
                            noSpecial=True,
                            noSymbol=True
                        )
                        if code != 4100:
                            raise Exception
                                    
                        vPassword = self.request.arguments.get('password')
                        code, message = Validate.i(
                            vPassword,
                            'password',
                            dataType=str,
                            notNull=True
                        )
                        if code != 4100:
                            raise Exception

                        vPassword = FN_ENCRYPT(vPassword, encode=True) 

                        vphoneNumber = int(self.request.arguments.get('phoneNumber'))
                        code, message = Validate.i(
                            vphoneNumber,
                            'phoneNumber',
                            notNull=True,
                            dataType=int,
                            maxLength=20
                        )
                        if code != 4100:
                            raise Exception

                        vcountryCode = self.request.arguments.get('countryCode')
                        code, message = Validate.i(
                            vcountryCode,
                            'countryCode',
                            dataType=int,
                            minNumber=1,
                            maxNumber=9999
                        )
                        if code != 4100:
                            raise Exception
                        countryCode = await self.phoneCountry.find_one(
                            {
                                'code': vcountryCode
                            },
                            limit=1
                        )
                        if not countryCode:
                            code = 4242
                            message = 'Dial code does not exist.'
                            raise Exception
                        if len(str(vphoneNumber)) != countryCode['telMaxLength']:
                            code = 4252
                            message = 'Please enter a valid Phone Number.'
                            raise Exception('phoneNumber')
                        else:
                            orgPhoneNumber = vphoneNumber
                            phoneNumber = int(str(vcountryCode) + str(vphoneNumber))

                        accountFind = await self.account.find_one(
                            {
                                'contact.0.value': phoneNumber
                            }
                        )
                        if accountFind and acId != accountFind.get('_id'):
                            message = 'Phone number already exists.'
                            code = 4119
                            raise Exception

                        vemailAdress = self.request.arguments.get('emailAddress')
                        if vemailAdress:
                            code, message = Validate.i(
                                vemailAdress,
                                'emailAddress',
                                dataType=str
                            )
                            if code != 4100:
                                raise Exception
                        else:
                            vemailAdress = None

                        vRole = self.request.arguments.get('role')
                        code, message = Validate.i(
                            vRole,
                            'role',
                            dataType=str,
                            enums = ['Auditor', 'Admin'],
                            notEmpty=True
                        )
                        if code != 4100:
                            raise Exception
                        
                        vPermissions = self.request.arguments.get('permissions')
                        if vPermissions:
                            code, message = Validate.i(
                                vPermissions,
                                'permissions',
                                dataType=list,
                                notEmpty=True
                            )
                            if code != 4100:
                                raise Exception
                            
                            # Module Permissions
                            vModulePermissions =    [
                                    {'id': '8b639fe0-3847-41b6-b3b5-4fce727fd4ea', 'name': 'Dashboard'},
                                    {'id': 'b08353c1-4aee-4487-8067-99ad5a312259', 'name': 'Applications'},
                                    {'id': '04d1c9ca-1262-436a-a600-317e9c2c6cda', 'name': 'Audit Info'},
                                    {'id': '9fa2cfcd-02b9-49d2-8f5f-42626f09d246', 'name': 'Trainings'},
                                    {'id': '672864de-03b2-45bd-9a50-e943675532ca', 'name': 'Admins'},
                                    {'id': 'c10df772-8c71-4d47-b202-fb64db4dbb4c', 'name': 'Auditors'},
                                    {'id': '1e275b90-f0b3-4b6c-8620-84f2a2e52d4c', 'name': 'Grievances'}, 
                                    {'id': 'dab8d600-686a-4939-9401-c879022fdaaa', 'name': 'Banking'},
                                    {'id': '547ee6a6-ab46-4e19-a67e-c7423aa0ad90', 'name': 'Architect Mapping'},
                                    {'id': '3311872f-2dec-43ea-9a3e-2a423febd1f3', 'name': 'Defaulters'}
                                    # {'id': '95ce77dc-e078-4f00-8cb8-308368fc11e1', 'name': 'Applicants'} # Architect Module
                                ]
                            mPermissionIds = []
                            for mIds in vModulePermissions:
                                mPermissionIds.append(mIds.get('id'))
                            for permissions in vPermissions:
                                if permissions not in mPermissionIds:
                                    code = 4443
                                    message = 'Invalid Permission {}'.format(permissions)
                                    raise Exception
                                if permissions not in mFindSignedProfile.get('permissions'):
                                    for i in vModulePermissions:
                                        if permissions == i.get('id'):
                                            permissions = i.get('name')
                                    code = 4461
                                    message = 'You can not give {} permission'.format(permissions)
                                    raise Exception
                        else:
                            vPermissions = []
                        
                        vAddress = None
                        if vRole == 'Auditor':
                            vDesignation = self.request.arguments.get('designation')
                            code, message = Validate.i(
                                vDesignation,
                                'designation',
                                notEmpty=True,
                                dataType=str,
                                enums = ['Tourist Officer', 'Bank Officials', 'DIC', 'Architect']
                            )
                            if code != 4100:
                                raise Exception

                            vDistricts = self.request.arguments.get('districts')
                            if vDistricts:
                                code, message = Validate.i(
                                    vDistricts,
                                    'districts',
                                    dataType=list,
                                    notEmpty=True
                                )
                                if code != 4100:
                                    raise Exception
                                
                                vDistrictIds = []
                                for i, d in enumerate(vDistricts):
                                    code, message = Validate.i(
                                        d,
                                        'Invalid district {}'.format(i+1),
                                        dataType=str,
                                        notEmpty=True
                                    )
                                    if code != 4100:
                                        raise Exception
                                    
                                    try:
                                        vDistrictIds.append(ObjectId(d))
                                    except:
                                        code = 4371
                                        message = 'Invalid district id {}'.format(i+1)
                                        raise Exception
                                    
                                vPermissions = []
                                vAddress = None
                            else:
                                vDistrictIds = None

                            if vDesignation == 'Architect':
                                vAddress = self.request.arguments.get('address')
                                code, message = Validate.i(
                                    vAddress,
                                    'address',
                                    dataType=str,
                                    notEmpty=True
                                )
                                if code != 4100:
                                    raise Exception
                                
                                if not vemailAdress:
                                    code = 4135
                                    message = 'Email can not be empty for Architect'
                                    raise Exception
                                
                            else:
                                if not vDistrictIds:
                                    code = 4136
                                    message = 'Districts can not be empty'
                                    raise Exception
                            vPermissions = []
                            perm = mProfileFind.get('permissions')
                            if vPermissions == []:
                                vPermissions=perm

                        else:
                            vDesignation = None
                            vDistrictIds = None
                            # By Default Giving Dashboard Permission for Admin
                            if '8b639fe0-3847-41b6-b3b5-4fce727fd4ea' not in vPermissions:
                                vPermissions.append('8b639fe0-3847-41b6-b3b5-4fce727fd4ea')

                        vContact = [
                                        {
                                            'type': 0,
                                            'value': phoneNumber,
                                        },
                                        {
                                            'type': 1,
                                            'verified': False,
                                            'value': phoneNumber,
                                            'dialCode': vcountryCode,
                                            'sDialCode': countryCode['sCode'],
                                            'phoneNumber': orgPhoneNumber,
                                            'countryCode': countryCode['isoAlpha3Code']
                                        }
                                    ]
                        if vemailAdress:
                            vContact.append(
                                {
                                    'verified': False,
                                    'value': vemailAdress,
                                    'type': 2
                                }
                            )
                        if mFindSignedProfile.get('isSuperAdmin') or self.accountId == acId or (self.accountId == xProfileFind.get('createdBy')):
                            if len(vPermissions):
                                updateQ = {
                                            'permissions': vPermissions,
                                        }
                                if department:
                                    updateQ['department'] = department
                                pfUpdateQ = await self.profile.update_one(
                                    {
                                        'accountId': acId
                                    },
                                    {
                                        '$set': updateQ
                                    }
                                )    
                            acUpdateQ = await self.account.update_one(
                                {
                                    '_id': acId
                                },
                                {
                                    '$set': {
                                        'firstName': vfirstName,
                                        'lastName': vlastName,
                                        'contact': vContact,
                                        'role': vRole,
                                        'districts': vDistrictIds,
                                        'designation': vDesignation,
                                        'address': vAddress,
                                        'privacy': [
                                            {
                                                'value': vPassword
                                            }
                                        ],
                                    }
                                }
                            )
                        else:
                            code = 4231
                            message = 'You are not allowed to update this profile'
                            raise Exception
                        if acUpdateQ.modified_count:
                            message = 'Account information updated successfully.'
                            code = 2000
                            status = True
                        else:
                            message = 'Account information could not updated.'
                            code = 4001

        except Exception as e:
            status = False
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(response)
            await self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return

    async def delete(self):
        status = False
        code = 4000
        result = []
        message = ''
        try:
            try:
                acId = str(self.request.arguments.get('id')[0].decode())
                if not acId:
                    message = 'Missing Argument - [ id ].'
                    code = 4047
                    raise Exception
                acId = ObjectId(acId)
            except Exception as e:
                message = 'Invalid Argument - [ id ].'
                code = 4052
                raise Exception

            acId = ObjectId(acId)

            finAcQ = await self.account.find_one(
                {
                    '_id': acId
                }
            )
            if finAcQ:
                delAcQ = await self.account.delete_one(
                    {
                        '_id': acId
                    }
                )
                if delAcQ.deleted_count:
                    delProQ = await self.profile.delete_one(
                        {
                            'accountId': acId
                        }
                    )
                    message = 'Account has been deleted.'
                    code = 2000
                    status = True
                else:
                    message = 'Account could not deleted.'
                    code = 4001
                    status = False
            else:
                message = 'Account not found.'
                code = 4001
                status = False
        except Exception as e:
            status = False
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(response)
            await self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return