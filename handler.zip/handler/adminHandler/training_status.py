import datetime
import json
import os
import re
import sys
import io

from datetime import datetime as dtime
import tornado.web
from abc import ABCMeta
from bson import ObjectId
from build_config import CONFIG
from lib.lib import Validate
from lib.xen_protocol import xenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log
from bson.json_util import dumps as bdumps
from lib.element_mixer import ElementMixer
from util.time_util import timeNow


@xenSecureV2
class LoanApplicationTrainingStatusHandler(ElementMixer,  MongoMixin, metaclass=ABCMeta):

    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]

    trainingStatus = MongoMixin.userDb[
        CONFIG['database'][0]['table'][21]['name']
    ]

    block = MongoMixin.userDb[
        CONFIG['database'][0]['table'][15]['name']
    ]

    district = MongoMixin.userDb[
        CONFIG['database'][0]['table'][14]['name']
    ]

    auditInfo = MongoMixin.userDb[
        CONFIG['database'][0]['table'][19]['name']
    ]

    componentId = ObjectId('63d39988458b78fdf4cf6c0d')

    async def get(self):
        code = 4000
        message = ''
        status = False
        result = []
        try:
            # try:
            #     f_limit = int(self.get_argument('limit'))
            #     f_skip = int(self.get_argument('skip'))
            # except:
            #     f_limit = 10
            #     f_skip = 0

            try:
                mDistrict = self.get_arguments('district')
                mDistrict = mDistrict[0]
                if mDistrict:
                    code, message = Validate.i(
                        mDistrict,
                        'district',
                        dataType=str,
                        notEmpty=True
                    )
                    if code != 4100:
                        raise Exception
                else:
                    raise Exception
                mDistrict = ObjectId(mDistrict)
            except:
                mDistrict = None

            try:
                mBlock = self.get_arguments('block')
                mBlock = mBlock[0]
                if mBlock:
                    code, message = Validate.i(
                        mBlock,
                        'block',
                        dataType=str,
                        notEmpty=True
                    )
                    if code != 4100:
                        raise Exception
                else:
                    raise Exception
                mBlock = ObjectId(mBlock)
            except:
                mBlock = None

            try:
                mTrainingStatus = self.get_argument('trainingStatus')
                if mTrainingStatus:
                    code, message = Validate.i(
                        mTrainingStatus,
                        'trainingStatus',
                        dataType=str,
                        notEmpty=True
                    )
                    if code != 4100:
                        raise Exception
                else:
                    mTrainingStatus = None
            except:
                mTrainingStatus = None

            try:
                mId = self.get_argument('id')
                if mId:
                    code, message = Validate.i(
                        mId,
                        'id',
                        dataType=str,
                        notEmpty=True
                    )
                    if code != 4100:
                        raise Exception
                    mId = ObjectId(mId)
                else:
                    mId = None
            except:
                mId = None

            try:
                vSearchWith = self.get_query_argument('searchWith')
                if not vSearchWith:
                    raise Exception
                vSearchWith = vSearchWith.lower()
            except:
                vSearchWith = None
            
            filterObj = {}    
            if vSearchWith:
                nApplicationId = {
                    'applicantId': {
                        '$regex': vSearchWith,
                        '$options': 'ism'
                    }
                }

                mApplicantName = {
                    'applicantName': {
                        '$regex': vSearchWith,
                        '$options': 'ism'
                    }
                }

                filterObj['$or'] = [nApplicationId, mApplicantName]

            filterQ = {
                '$match' : filterObj
            } 

            pipeline = [
                        {
                            '$lookup': {
                                'from': self.block.name,
                                'localField': 'talukblock',
                                'foreignField': '_id',
                                'as': 'blockInfo',
                                'pipeline': [
                                    {
                                        '$project': {
                                            '_id': {
                                                '$toString': '$_id'
                                            },
                                            'blockName': 1
                                        }
                                    }
                                ]
                            }
                        },
                        {
                            '$lookup': {
                            'from': 'loanApplication',
                            'localField': 'loanApplicationId',
                            'foreignField': '_id',
                            'as': 'loanAppInfo',
                            }
                        },
                        {
                            '$lookup': {
                                'from': self.district.name,
                                'localField': 'unitDistrict',
                                'foreignField': '_id',
                                'as': 'districtInfo',
                                'pipeline': [
                                    {
                                        '$project': {
                                            '_id': {
                                                '$toString': '$_id'
                                            },
                                            'districtName': 1
                                        }
                                    }
                                ]
                            }
                        },
                        {
                            '$lookup': {
                                'from': self.auditInfo.name,
                                'localField': 'loanApplicationId',
                                'foreignField': 'loanId',
                                'as': 'auditInfo',
                                'pipeline': [
                                    {
                                        '$project': {
                                            '_id': {
                                                '$toString': '$_id'
                                            },
                                            'constructionStatus': 1
                                        }
                                    }
                                ]
                            }
                        },
                        {
                            '$match': {
                                'loanAppInfo': {
                                    '$elemMatch': {
                                        'data.unitDistrict': {
                                            '$exists': True
                                        }
                                    }
                                }
                            }
                        },
                        {
                            '$project': {
                                '_id': {
                                    '$toString': '$_id'
                                },
                                'applicantId': 1,
                                'applicantName': 1,
                                'trainingStatus': 1,
                                'loanApplicationId': {
                                    '$toString': '$loanApplicationId'
                                },
                                'trainingStartDate': 1,
                                'trainingEndDate': 1,
                                'certificateIssueDate': 1,
                                'durationOfTraining': 1,
                                'trainingOrganizedBy': 1,
                                'blockInfo': 1,
                                'districtInfo': 1,
                                'auditInfo': 1,
                                'modifiedBy': {
                                    '$toString': '$modifiedBy'
                                },
                                'modifiedAt': 1                
                            }
                        } 
                    ]
            if mTrainingStatus:
                pipeline.append({
                    '$match': {
                        'trainingStatus': mTrainingStatus
                    }
                }) 
            
            if mBlock:
                filterBlock = {
                    '$match': {
                        'talukblock': mBlock
                    }
                }
                pipeline.insert(0, filterBlock)

            if mDistrict:
                filterDistrict = {
                    '$match': {
                        'unitDistrict': mDistrict
                    }
                }
                pipeline.insert(0, filterDistrict)
            
            if mId:
                pipeline.insert(0, {
                    '$match': {
                        '_id': mId
                    }
                })

            pipeline.insert(0, filterQ)
            # if f_limit:
            #     pipeline.append(
            #         {
            #             '$skip': f_skip
            #         }
            #     )
            #     pipeline.append(
            #         {
            #             '$limit': f_limit
            #         }
            #     )
            mFindApplication = self.trainingStatus.aggregate(pipeline)
            async for i in mFindApplication:
                if not i.get('modifiedBy'):
                    del i['modifiedBy']
                result.append(i)
            
            if len(result):
                code = 2000
                status = True
            else:
                code = 4058
                message = 'Data not found'
                raise Exception               

        except Exception as e:
            status = False
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(response)
            await self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            # self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return

    async def put(self):
        code = 4000
        message = ''
        status = False
        result = []
        try:         
            try:
                self.request.arguments = json.loads(self.request.body.decode())
            except:
                code = 4133
                message = 'Invalid data in body'
                raise Exception
                         
            mIds = self.request.arguments.get('ids')
            code, message = Validate.i(
                mIds,
                'ids',
                dataType=list,
                notEmpty=True
            )
            if code != 4100:
                raise Exception
            
            zAllIds = []
            for i, value in enumerate(mIds):
                try:
                    code, message = Validate.i(
                        value,
                        'id of no {}'.format(i+1),
                        dataType=str,
                        notEmpty=True
                    )
                    if code != 4100:
                        raise Exception
                    value = ObjectId(value)
                    zAllIds.append(value)
                except:
                    code = 4152
                    message = 'Invalid argument - [ ids ] no. {}'.format(i+1)
                    raise Exception

            mStartDate = self.request.arguments.get('trainingStartDate')
            code, message = Validate.i(
                mStartDate,
                'trainingStartDate',
                dataType=str,
                notEmpty=True
            )
            if code != 4100:
                raise Exception
            
            try:
                mStartDate = int(datetime.datetime.strptime(mStartDate, '%Y-%m-%d').timestamp() * 1000 * 1000)
            except:
                code = 4503
                message = 'Invalid argument - [ trainingStartDate ]'
                raise Exception

            mEndDate = self.request.arguments.get('trainingEndDate')
            code, message = Validate.i(
                mEndDate,
                'trainingEndDate',
                dataType=str,
                notEmpty=True
            )
            if code != 4100:
                raise Exception
            
            try:
                mEndDate = int(datetime.datetime.strptime(mEndDate, '%Y-%m-%d').timestamp() * 1000 * 1000)
            except:
                code = 4520
                message = 'Invalid argument - [ trainingEndDate ]'
                raise Exception

            mDuration = self.request.arguments.get('durationOfTraining')
            code, message = Validate.i(
                mDuration,
                'durationOfTraining',
                dataType=int,
                notEmpty=True
            )
            if code != 4100:
                raise Exception

            if mDuration <= 0 or mDuration > 99:
                code = 4406
                message = 'Please enter duration between 1 to 99 days'
                raise Exception
            
            mTrainingOrganizedBy = self.request.arguments.get('trainingOrganizedBy')
            code, message = Validate.i(
                mTrainingOrganizedBy,
                'trainingOrganizedBy',
                dataType=str,
                notEmpty=True
            )
            if code != 4100:
                raise Exception

            mCertificateIssueDate = self.request.arguments.get('certificateIssueDate')
            code, message = Validate.i(
                mCertificateIssueDate,
                'certificateIssueDate',
                dataType=str,
                notEmpty=True
            )
            if code != 4100:
                raise Exception
            
            try:
                mCertificateIssueDate = int(datetime.datetime.strptime(mCertificateIssueDate, '%Y-%m-%d').timestamp() * 1000 * 1000)
            except:
                code = 4520
                message = 'Invalid argument - [ certificateIssueDate ]'
                raise Exception
            
            if mStartDate > mEndDate:
                code = 4458
                message = 'Select Training Start Date before Training End Date'
                raise Exception
            if mCertificateIssueDate < mEndDate:
                code = 4458
                message = 'Please select Certificate Issue Date After Training End Date'
                raise Exception
                
            mTrainingStatus = self.request.arguments.get('trainingStatus')
            code, message = Validate.i(
                mTrainingStatus,
                'trainingStatus',
                dataType=str,
                notEmpty=True
            )
            if code != 4100:
                raise Exception
        
            statusUpdate = await self.trainingStatus.update_many(
                {
                    '_id': {
                        '$in': zAllIds
                    }
                },
                {
                    '$set': {
                        'trainingStartDate': mStartDate,
                        'trainingEndDate': mEndDate,
                        'durationOfTraining': mDuration,
                        'trainingOrganizedBy': mTrainingOrganizedBy,
                        'certificateIssueDate': mCertificateIssueDate,
                        'trainingStatus': mTrainingStatus,
                        'modifiedBy': self.accountId,
                        'modifiedAt': timeNow()
                    }
                }
            )
            if statusUpdate.modified_count:
                code = 2000
                status= True
                message = '{} Record updated'.format(statusUpdate.modified_count)
            else:
                code = 4196
                message = 'Record not updated'
                raise Exception
                
        except Exception as e:
            status = False
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(response)
            await self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            # self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return
        
    async def delete(self):
        code = 4000
        message = ''
        status = False
        result = []

        try:                                  
            try:
                mId = self.request.arguments.get('id')[0].decode()
                code, message = Validate.i(
                    mId,
                    'id',
                    dataType=str,
                    notEmpty=True
                )
                if code != 4100:
                    raise Exception
                mId = ObjectId(mId)
            except:
                code = 4511
                message = 'Invalid argument - [ id ]'
                raise Exception
            
            statusDelete = await self.trainingStatus.delete_one(
                {
                    '_id': mId
                }
            )
            if statusDelete.deleted_count:
                code = 2000
                status= True
                message = '{} Record Deleted'.format(statusDelete.deleted_count)
            else:
                code = 4534
                message = 'Record not Deleted'
                raise Exception
                
        except Exception as e:
            status = False
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(response)
            await self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            # self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return