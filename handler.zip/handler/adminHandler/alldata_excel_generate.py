
import datetime
import json
import sys
import io

from abc import ABCMeta
from bson import ObjectId
from build_config import CONFIG
from lib.lib import Validate
from lib.xen_protocol import xenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log
from bson.json_util import dumps as bdumps
from lib.element_mixer import ElementMixer
from util.time_util import timeNow
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment

@xenSecureV2
class AllDataExcelGenerateHandler(ElementMixer,  MongoMixin, metaclass=ABCMeta):

    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]

    loanApplication = MongoMixin.userDb[
        CONFIG['database'][0]['table'][13]['name']
    ]

    state = MongoMixin.userDb[
        CONFIG['database'][0]['table'][6]['name']
    ]

    block = MongoMixin.userDb[
        CONFIG['database'][0]['table'][15]['name']
    ]

    district = MongoMixin.userDb[
        CONFIG['database'][0]['table'][14]['name']
    ]

    loanStatusLog = MongoMixin.userDb[
        CONFIG['database'][0]['table'][18]['name']
    ]
    
    auditInfo = MongoMixin.userDb[
        CONFIG['database'][0]['table'][19]['name']
    ]

    trainingStatus = MongoMixin.userDb[
        CONFIG['database'][0]['table'][21]['name']
    ]

    rejectionReasons = MongoMixin.userDb[
        CONFIG['database'][0]['table'][11]['name']
    ]

    jointApplication = MongoMixin.userDb[
            CONFIG['database'][0]['table'][23]['name']
    ]
    componentId = ObjectId('63d39988458b78fdf4cf6c0d')

    async def get(self):
        code = 4000
        message = ''
        status = False
        result = []
        try:
            try:
                vSearchWith = self.get_query_argument('searchWith')
                if not vSearchWith:
                    raise Exception
                vSearchWith = vSearchWith.lower()
            except:
                vSearchWith = None

            filterObj = {}
            if vSearchWith:
                nApplicationId = {
                    'applicantId': {
                        '$regex': vSearchWith,
                        '$options': 'ism'
                    }
                }

                mApplicantName = {
                    'data.applicantName': {
                        '$regex': vSearchWith,
                        '$options': 'ism'
                    }
                }

                filterObj['$or'] = [nApplicationId, mApplicantName]
            
            try:
                mDistrict = str(self.get_argument('district'))
                if not mDistrict:
                    raise Exception
                mDistrict = ObjectId(mDistrict)
            except:
                mDistrict = None
            
            try:
                mBlock = str(self.get_argument('block'))
                if not mBlock:
                    raise Exception
                mBlock = ObjectId(mBlock)
            except:
                mBlock = None

            try:
                mState = str(self.get_argument('state'))
                if not mState:
                    raise Exception
                mState = ObjectId(mState)
            except:
                mState = ObjectId('5fda17c1adfeecf7e9dd96ce')

            mLocfilter = {}
            if mDistrict:                
                mLocfilter['data.unitDistrict'] = mDistrict

            if mBlock:                
                mLocfilter['data.talukblock'] = mBlock

            if mState:                
                mLocfilter['data.state'] = mState                  

            vLocfilter = {
                '$match': mLocfilter
            }

            try:
                vStatus = self.get_argument('status')
                code, message = Validate.i(
                    vStatus,
                    'status',
                    notEmpty=True,
                    dataType=str
                )
                if code != 4100:
                    raise Exception
            except:
                vStatus = None

            try:
                trianingStatus = self.get_argument('trainingStatus')
                code, message = Validate.i(
                    trianingStatus,
                    'trainingStatus',
                    notEmpty=True,
                    dataType=str
                )
                if code != 4100:
                    raise Exception
            except:
                trianingStatus = None
            
            if vStatus:
                if vStatus == 'LoanSanctionedDisbursed':
                    vStatusFilter = {
                        '$match': {
                            'data.currentStatus': {
                                '$in': ['Loan Sanctioned', 'Disbursed']
                            }
                        }
                    }
                elif vStatus == 'Rejected By Bank':
                    vStatusFilter = {
                        '$match': {
                            'data.currentStatus': 'Rejected/Returned',
                            'data.rejectedByBank': True
                        }
                    }
                elif vStatus == 'Rejected By DIC':
                    vStatusFilter = {
                        '$match': {
                            'data.currentStatus': 'Rejected/Returned',
                            'data.rejectedByBank': False
                        }
                    }
                else:
                    vStatusFilter = {
                        '$match': {
                            'data.currentStatus': vStatus
                        }
                    }

            if trianingStatus:
                if trianingStatus == 'complete':
                    trianingStatusFilter = {
                        '$match': {
                            'edpCompleted': True,
                        }
                    }
                elif trianingStatus == 'pending':
                    trianingStatusFilter = {
                        '$match': {
                            'edpPending': True,
                        }
                    }

            try:
                mIsRecommended = self.get_argument('isRecommended')
                mIsRecommended = json.loads(mIsRecommended)
                code, message = Validate.i(
                    mIsRecommended,
                    'isRecommended',
                    dataType=bool
                )
                if code != 4100:
                    raise Exception
            except:
                mIsRecommended = False

            filterQ = {
                '$match' : filterObj
            } 
            try:
                inspectionStatus = str(self.get_argument('InspectionStatus'))
            except:
                inspectionStatus = None
            matchFilter = {}
            if inspectionStatus:
                if inspectionStatus == "Not Submitted":
                    matchFilter = {
                        '$match': {
                            '$and': [
                                {
                                    'inspectionReportSubmitted': {
                                        '$exists': False
                                    }
                                }, 
                                {
                                    'jointInspection.inspectionInformaton': {
                                        '$exists': False
                                    }
                                }
                            ]
                        }
                    }
                if inspectionStatus == "Completed":
                    matchFilter = {
                        "$match": {
                                "$and": [
                                    {
                                        "inspectionReportSubmitted": {
                                        "$exists": True
                                        }
                                    },
                                    {
                                        "jointInspection.inspectionInformaton": {
                                        "$exists": True
                                        }
                                    },
                                    {
                                        "jointInspection.inspectedBy": {
                                        "$not": {
                                            "$elemMatch": {
                                            "approved": False
                                            }
                                        }
                                        }
                                    }
                                ]
                        }
                    }


                if inspectionStatus == "Pending Approval":
                    matchFilter = {
                        "$match": {
                                "$and": [
                                    {
                                        "inspectionReportSubmitted": {
                                        "$exists": True
                                        }
                                    },
                                    {
                                        "jointInspection.inspectionInformaton": {
                                        "$exists": True
                                        }
                                    },
                                    {
                                        "jointInspection.inspectedBy": {
                                        '$elemMatch': {
                                                    'approved': False
                                                }
                                        }
                                    }
                                ]
                        }
                    }  
            pipeline = [
                        {
                            '$lookup': {
                                'from': self.state.name,
                                'localField': 'data.state',
                                'foreignField': '_id',
                                'as': 'stateInfo',
                                'pipeline': [
                                    {
                                        '$project': {
                                            '_id': {
                                                '$toString': '$_id'
                                            },
                                            'name': 1
                                        }
                                    }
                                ]
                            }
                        },
                        {
                            '$lookup': {
                                'from': self.district.name,
                                'localField': 'data.unitDistrict',
                                'foreignField': '_id',
                                'as': 'districtInfo',
                                'pipeline': [
                                    {
                                        '$project': {
                                            '_id': {
                                                '$toString': '$_id'
                                            },
                                            'districtName': 1

                                        }
                                    }
                                ]
                            }
                        },
                        {
                            '$lookup': {
                                'from': self.block.name,
                                'localField': 'data.talukblock',
                                'foreignField': '_id',
                                'as': 'blockInfo',
                                'pipeline': [
                                    {
                                        '$project': {
                                            '_id': {
                                                '$toString': '$_id'
                                            },
                                            'blockName': 1
                                        }
                                    }
                                ]
                            }
                        },
                        {
                            '$lookup': {
                                'from': self.rejectionReasons.name,
                                'localField': 'data.bankRemarks',
                                'foreignField': '_id',
                                'as': 'bankRemarksInfo',
                                'pipeline': [
                                    {
                                        '$project': {
                                            '_id': {
                                                '$toString': '$_id'
                                            },
                                            'reason': 1
                                        }
                                    }
                                ]
                            }
                        },
                        {
                            '$lookup': {
                                'from': self.loanStatusLog.name,
                                'localField': '_id',
                                'foreignField': 'loanApplicationId',
                                'as': 'disbursementInfo',
                                'pipeline': [
                                    {
                                        '$addFields': {
                                            'disbursementDetails': {
                                                '$first': '$disbursed'
                                            }
                                        }
                                    },
                                    {
                                        '$addFields': {
                                            'disbursedDate': {
                                                '$first': '$disbursementDetails.disbursedInfo.date'
                                            }
                                        }
                                    },
                                    {
                                        '$project': {
                                            '_id': {
                                                '$toString': '$_id'
                                            },
                                            'disbursedDate': 1
                                        }
                                    }
                                ]
                            }
                        },
                        {
                            '$lookup': {
                                'from': self.jointApplication.name, 
                                'localField': 'applicantId', 
                                'foreignField': 'applicantId', 
                                'as': 'jointInspection'
                            }
                        },
                        {
                            '$unwind': '$disbursementInfo'
                        },
                        {
                            '$unwind': '$blockInfo'
                        },
                        {
                            '$unwind': '$districtInfo'
                        },
                        {
                            '$unwind': '$stateInfo'
                        },
                        {
                            '$unwind': '$bankRemarksInfo'
                        },
                        {
                            '$unwind': {
                                'path': '$jointInspection', 
                                'preserveNullAndEmptyArrays': True
                            }
                        }, 
                        {
                            '$project': { 
                                '_id': 0,
                                'data.srno': 1,
                                'applicantId': 1,
                                'data.currentStatus' : 1, 
                                'data.underProcessRejectionByAgencyReason' : 1, 
                                'data.officeName':1, 
                                'data.agencyType':1,
                                'data.state': '$stateInfo.name', 
                                'data.applicantName':1,	
                                'data.trainingMode':1,
                                'data.trainingRemarks':1,
                                'data.applicantAddress':1, 
                                'data.mobileNo':1,
                                'data.alternativeMobileNo':1,	
                                'data.email':1,
                                'data.legalStatus':1, 
                                'data.gender':1 , 
                                'data.category':1,	
                                'data.qualification':1,	
                                'data.dateOfBirth':1,	
                                'data.age':1,
                                'data.unitLocation':1,	
                                'data.unitAddress':1,	
                                'data.talukblock': '$blockInfo.blockName',
                                'data.unitDistrict': '$districtInfo.districtName',
                                'data.productDescactivity':1,
                                'data.proposedProjectCost':1, 
                                'data.financingBranchIfscCode':1,	
                                'data.financingBranchAddress':1,	
                                'data.onlineSubmissionDate':1,
                                'data.forwardingDateToBank':1,	
                                'data.bankRemarks': '$bankRemarksInfo.reason',	
                                'data.dateOfDocumentReceivedAtBank':1,
                                'data.totalProjectCostApprovedByBank':1,	
                                'data.sanctionedDateByBank':1,	
                                'data.totalSanctionedAmountByBank':1,	
                                'data.dateOfDepositOwnContribution':1, 
                                'data.ownContributionAmountDeposited':1, 
                                'data.coveredUnderCgtsi':1,	
                                'data.dateOfLoanRelease':1,	
                                'data.loanReleaseAmount':1,	
                                'data.remarksForMmProcessAtPmegpcomumbai':1,
                                'data.mmReleaseAmount':1, 
                                'data.edpTrainingCenterName':1,	
                                'data.trainingStartDate':1,
                                'data.trainingEndDate':1,	
                                'data.durationOfTraining':1,	
                                'data.certificateIssueDate':1,
                                'data.physicalVerificationConductedDate': 1,
                                'data.physicalVerificationStatus': 1,
                                'edpCompleted': 1,
                                'edpPending': 1,
                            }
                        }
                        ]
            if filterObj:
                pipeline.insert(1, filterQ)
            if mIsRecommended:
                pipeline.insert(2, {
                    '$match': {
                        'data.isRecommended': mIsRecommended
                    }
                })
            pipeline.insert(4, vLocfilter)
            if vStatus:
                pipeline.insert(5, vStatusFilter)
            if trianingStatus:
                pipeline.insert(6, trianingStatusFilter)
            if matchFilter:
                pipeline.insert(10,matchFilter)
            pipeline.insert(0,{
                '$addFields': {
                    'edpCompleted': {
                        '$cond': {
                            'if': {
                                '$eq': [
                                    {
                                        '$type': '$data.certificateIssueDate'
                                    }, 'long'
                                ]
                            }, 
                            'then': True, 
                            'else': False
                        }
                    }, 
                    'edpPending': {
                        '$cond': {
                            'if': {
                                '$and': [
                                    {
                                        '$in': [
                                            '$data.currentStatus', [
                                                'Loan Sanctioned', 'Disbursed'
                                            ]
                                        ]
                                    }, {
                                        '$ne': [
                                            {
                                                '$type': '$data.certificateIssueDate'
                                            }, 'long'
                                        ]
                                    }
                                ]
                            }, 
                            'then': True, 
                            'else': False
                        }
                    }
                }
            })
            try:
                fileQ = self.loanApplication.aggregate(pipeline)
            except Exception as e:
                Log.i("Error",e)
                raise e
            mDownloadableArray = []
            async for i in fileQ:
                if i.get('edpPending') == True:
                    i['data']['edpstatus'] = 'EDP Pending'
                elif i.get('edpCompleted') == True:
                    i['data']['edpstatus'] = 'EDP Completed'
                else:
                    i['data']['edpstatus'] = '-' 

                if not i['data'].get('trainingRemarks'):
                    i['data']['trainingRemarks'] = '-'
                if not i['data'].get('trainingMode'):
                    i['data']['trainingMode'] = '-'
                
                for key, value in i.get('data').items():
                    if not value:
                        i['data'][key] = '-'
                    if key in ['forwardingDateToBank', 'onlineSubmissionDate', 'dateOfDocumentReceivedAtBank', 'sanctionedDateByBank', 'dateOfDepositOwnContribution', 'dateOfLoanRelease', 'mmReleaseDate', 'trainingStartDate', 'trainingEndDate', 'certificateIssueDate', 'physicalVerificationConductedDate']:
                        if type(value) != str:
                            xDateStr = datetime.datetime.fromtimestamp(value / 1000 / 1000)
                            xDateStr = datetime.datetime.strftime(xDateStr, '%d-%m-%Y')
                            i['data'][key] = xDateStr

                    if key == 'dateOfBirth':
                        try:
                            xDateStr = datetime.datetime.strptime(value, '%Y-%m-%d')
                            xDateStr = xDateStr.strftime('%d-%m-%Y')
                        except:
                            xDateStr = value
                        i['data'][key] = xDateStr
            
                mDownloadableArray.append(i)
            data = [
                {
                    'SrNo': x['data']['srno'],
                    'Current Status': x['data']['currentStatus'],
                    'Office Name': x['data']['officeName'],
                    'Agency Type': x['data']['agencyType'],
                    'State': x['data']['state'],
                    'Applicant ID': x['applicantId'],
                    'Applicant Name': x['data']['applicantName'],
                    'Applicant Address': x['data']['applicantAddress'],
                    'Mobile No': x['data']['mobileNo'],
                    'Alternative Mobile No': x['data']['alternativeMobileNo'],
                    'eMail': x['data']['email'],
                    'Legal Status': x['data']['legalStatus'],
                    'Gender': x['data']['gender'],
                    'Category': x['data']['category'],
                    'Qualification': x['data']['qualification'],
                    'Date of Birth': x['data']['dateOfBirth'],
                    'Age': x['data']['age'],
                    'Unit Location': x['data']['unitLocation'],
                    'Unit Address': x['data']['unitAddress'],
                    'Taluk/block': x['data']['talukblock'],
                    'Unit District': x['data']['unitDistrict'],
                    'Product Desc/Activity': x['data']['productDescactivity'],
                    'Proposed Project Cost': x['data']['proposedProjectCost'],
                    'Financing Branch IFSC CODE': x['data']['financingBranchIfscCode'],
                    'Financing Branch Address': x['data']['financingBranchAddress'],
                    'Online Submission Date': x['data']['onlineSubmissionDate'],
                    'Forwarding Date to Bank': x['data']['forwardingDateToBank'],
                    'Bank Remarks': x['data']['bankRemarks'],
                    'Date of Document Received at Bank': x['data']['dateOfDocumentReceivedAtBank'],
                    'Total Project Cost Approved by Bank': x['data']['totalProjectCostApprovedByBank'],
                    'Sanctioned Date by Bank': x['data']['sanctionedDateByBank'],
                    'Total Sanctioned Amount by Bank': x['data']['totalSanctionedAmountByBank'],
                    'Date of Deposit Own Contribution': x['data']['dateOfDepositOwnContribution'],
                    'Own Contribution amount Deposited': x['data']['ownContributionAmountDeposited'],
                    'Covered Under CGTSI': x['data']['coveredUnderCgtsi'],
                    'Date of Loan Release': x['data']['dateOfLoanRelease'],
                    'Loan Release Amount': x['data']['loanReleaseAmount'],
                    'Remarks for MM Process at PMEGP,CO,Mumbai': x['data']['remarksForMmProcessAtPmegpcomumbai'],
                    'MM Release Amount': x['data']['mmReleaseAmount'],
                    'EDP Training Center Name': x['data']['edpTrainingCenterName'],
                    'Training Start Date': x['data']['trainingStartDate'],
                    'Training End Date': x['data']['trainingEndDate'],
                    'Duration of Training': x['data']['durationOfTraining'],
                    'Certificate Issue Date': x['data']['certificateIssueDate'],
                    'Physical Verification Conducted Date': x['data']['physicalVerificationConductedDate'],
                    'Physical Verification Status': x['data']['physicalVerificationStatus'],
                    'Training Mode': x['data']['trainingMode'],
                    'Training Remarks': x['data']['trainingRemarks'],
                    'EDP Training Status': x['data']['edpstatus'],
                } 
                for x in mDownloadableArray
            ]
            headers = ['SrNo', 'Current Status', 'Office Name', 'Agency Type', 'State', 'Applicant ID', 'Applicant Name', 'Applicant Address', 
                       'Mobile No', 'Alternative Mobile No', 'eMail', 'Legal Status', 'Gender', 'Category', 'Qualification', 'Date of Birth', 
                       'Age', 'Unit Location', 'Unit Address', 'Taluk/block', 'Unit District', 'Product Desc/Activity', 'Proposed Project Cost',
                       'Financing Branch IFSC CODE', 'Financing Branch Address', 'Online Submission Date', 'Forwarding Date to Bank', 'Bank Remarks',
                       'Date of Document Received at Bank', 'Total Project Cost Approved by Bank', 'Sanctioned Date by Bank', 
                       'Total Sanctioned Amount by Bank', 'Date of Deposit Own Contribution', 'Own Contribution amount Deposited', 'Covered Under CGTSI',
                       'Date of Loan Release', 'Loan Release Amount', 'Remarks for MM Process at PMEGP,CO,Mumbai', 'MM Release Amount', 'EDP Training Center Name',
                       'Training Start Date', 'Training End Date', 'Duration of Training', 'Certificate Issue Date', 'Physical Verification Conducted Date',
                       'Physical Verification Status', 'Training Mode', 'Training Remarks', 'EDP Training Status']

            workbook = Workbook()
            worksheet = workbook.active
            worksheet.title = "Sheet1"
            header_font = Font(bold=True)
            header_alignment = Alignment(horizontal='center', vertical='center')   

            worksheet.append(headers)
            for col_num, header in enumerate(headers, 1):
                cell = worksheet.cell(row=1, column=col_num, value=header)
                cell.font = header_font
                cell.alignment = header_alignment

            for row_num, row_data in enumerate(data, 2):
                for col_num, key in enumerate(headers, 1):
                    value = row_data.get(key, "")
                    cell = worksheet.cell(row=row_num, column=col_num, value=value)
                    cell.alignment = Alignment(horizontal='center', vertical='center')

            for column in worksheet.columns:
                max_length = 0
                column = [cell for cell in column]
                for cell in column:
                    try:
                        if len(str(cell.value)) > max_length:
                            max_length = len(cell.value)
                    except:
                        pass
                adjusted_width = (max_length + 5)
                worksheet.column_dimensions[column[0].column_letter].width = adjusted_width

            xBuffer = io.BytesIO()
            workbook.save(xBuffer)
            xBuffer.seek(0)
            xBuffer = io.BytesIO(xBuffer.getvalue())


            self.set_header('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
            self.set_header('Content-Disposition', 'attachment; filename=loan_applicants.xlsx')
            self.write(xBuffer.getvalue())
            xBuffer.close()

            code = 200
            status = True
            message = 'File Generated Successfully'
        except Exception as e:
            status = False
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'    
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            # self.write(response)
            await self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            # self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return