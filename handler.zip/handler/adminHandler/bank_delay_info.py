#!/usr/bin/VtsAdminSignInHandler
# -*- coding: utf-8 -*-

import json
import os
import re
import sys

import tornado.web
from abc import ABCMeta
from bson import ObjectId
from build_config import CONFIG
from lib.lib import Validate
from lib.xen_protocol import xenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log
from lib.element_mixer import ElementMixer


@xenSecureV2
class BankDelayInfoHandler(ElementMixer, MongoMixin, metaclass=ABCMeta):

    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]

    profile = MongoMixin.userDb[
        CONFIG['database'][0]['table'][2]['name']
    ]

    loanApplication = MongoMixin.userDb[
        CONFIG['database'][0]['table'][13]['name']
    ]
    
    bankBranch = MongoMixin.userDb[
        CONFIG['database'][0]['table'][22]['name']
    ]

    componentId = ObjectId('63d38614458b78fdf4cf6bfa')

    async def get(self):
        code = 4000
        status = False
        message = ''
        result = []

        try:
            try:
                mSearchWith = self.get_argument('searchWith')
                code, message = Validate.i(
                    mSearchWith,
                    'searchWith',
                    dataType=str
                )
                if code != 4100:
                    raise Exception
            except:
                mSearchWith = None

            if mSearchWith:
                mSearch = {
                    '$match': {
                        '$or': [
                            {
                                'ifscCode': {
                                    '$regex': mSearchWith,
                                    '$options': 'ism'
                                }
                            },
                            {
                                'branchInfo.branchName': {
                                    '$regex': mSearchWith,
                                    '$options': 'ism'
                                }
                            }
                        ]
                    }
                }

            try:
                mDistrict = self.get_argument('district')
                code, message = Validate.i(
                    mDistrict,
                    'district',
                    dataType=str
                )
                if code != 4100:
                    raise Exception
                mDistrict = ObjectId(mDistrict)
            except:
                mDistrict = None

            if mDistrict:
                xDistMatch = {
                    '$match': {
                        'data.unitDistrict': mDistrict
                    }
                }

            try:
                mBranch = self.get_argument('branch')
                code, message = Validate.i(
                    mBranch,
                    'branch',
                    dataType=str
                )
                if code != 4100:
                    raise Exception
                mBranch = ObjectId(mBranch)
            except:
                mBranch = None
            
            if mBranch:
                xBranchMatch = {
                    '$match': {
                        'data.bankBranch': mBranch
                    }
                }

            pipeline = []
            if mDistrict:
                pipeline.append(xDistMatch)
            if mBranch:
                pipeline.append(xBranchMatch)
            pipeline.append(
                {
                    '$match': {
                            'data.dateOfDocumentReceivedAtBank': {
                                '$gt': 0
                        },
                            'data.sanctionedDateByBank': {
                                '$gt': 0
                        }
                    }
                }
            )
            pipeline.append(
                {
                    '$group': {
                        '_id': {
                            'financingBranchIfscCode': '$data.financingBranchIfscCode',
                            'bankBranch': '$data.bankBranch'
                        },
                        'totalApplications': {
                            '$sum': 1
                        },
                        'totalRejectedApplications': {
                            '$sum': {
                                '$cond': [
                                    {
                                        '$eq': ['$data.currentStatus', 'Rejected/Returned']
                                    },
                                    1,
                                    0
                                ]
                            }
                        },
                        'totalSantionedApplications': {
                            '$sum': {
                                '$cond': [
                                    {
                                        '$or': [
                                            {'$eq': ['$data.currentStatus', 'Loan Sanctioned']},
                                            {'$eq': ['$data.currentStatus', 'Disbursed']}
                                        ]
                                    },
                                    1,
                                    0
                                ]
                            }
                        },
                        'applicantInfo': {
                            '$push': '$$ROOT'
                        }
                    }
                },
            )
            pipeline.append(
                {
                    '$unwind': '$applicantInfo'
                }
            )
            pipeline.append(
                {
                    '$addFields': {
                        'daysDiff': {
                            '$divide': [
                                    {
                                        '$subtract': [
                                            '$applicantInfo.data.sanctionedDateByBank',
                                            '$applicantInfo.data.dateOfDocumentReceivedAtBank'
                                        ]
                                    },
                                    1000 * 1000 * 60 * 60 * 24
                                ]
                            }
                        }
                }
            )
            pipeline.append(
                {
                    '$addFields': {
                        'financingBranchIfscCode': '$_id.financingBranchIfscCode',
                        'bankBranch': '$_id.bankBranch'
                    }
                }
            )
            pipeline.append(
                {
                    '$group': {
                        '_id': {
                            'financingBranchIfscCode': '$financingBranchIfscCode',
                            'bankBranch': '$bankBranch'
                        },
                        'totalDays': {
                            '$sum': '$daysDiff'
                        },
                        'applicationInfo': {
                            '$push': '$$ROOT'
                        }
                        
                    }
                }
            )
            pipeline.append(
                {
                    '$addFields': {
                        'financingBranchIfscCode': '$_id.financingBranchIfscCode',
                        'bankBranch': '$_id.bankBranch'
                    }
                }
            )
            pipeline.append(
                {
                    '$addFields': {
                        'financingBranchIfscCode': '$_id.financingBranchIfscCode',
                        'bankBranch': '$_id.bankBranch'
                    }
                }
            )
            pipeline.append(
                {
                    '$addFields': {
                        'totalApplications': {
                            '$last': '$applicationInfo.totalApplications'
                        },
                        'totalRejectedApplications': {
                            '$last': '$applicationInfo.totalRejectedApplications'
                        },
                        'totalSantionedApplications': {
                            '$last': '$applicationInfo.totalSantionedApplications'
                        }
                    }
                }
            )
            pipeline.append(
                {
                    '$lookup': {
                        'from': self.bankBranch.name,
                        'localField':'bankBranch',
                        'foreignField': '_id',
                        'as': 'branchInfo',
                        'pipeline': [
                            {
                                '$project': {
                                    '_id': {
                                        '$toString': '$_id'                                            
                                    },
                                    'branchName': 1
                                }
                            }
                        ]
                    }
                }
            )
            pipeline.append(
                {
                    '$unwind': '$branchInfo'
                }
            )
            pipeline.append(                     
                {
                    '$project': {
                        '_id': 0,
                        'bankBranch': {
                            '$toString':'$bankBranch' 
                        },
                        'ifscCode': '$financingBranchIfscCode',
                        'totalApplications': 1,
                        'totalRejectedApplications': 1,
                        'totalSantionedApplications': 1,
                        'branchInfo': 1,
                        'totalDays': {
                            '$round': ['$totalDays', 0]
                        },
                        'avgDays': {
                            '$round': [
                                {
                                    '$divide': [
                                        '$totalDays',
                                        '$totalApplications'
                                    ]
                                },
                                0
                            ]
                        }
                    }
                }
            )
            if mSearchWith:
                pipeline.append(mSearch)
            pipeline.append(
                {
                    '$sort': {
                        'ifscCode': 1
                    }
                }
            )
            mRejectedDataFind = self.loanApplication.aggregate(pipeline)
            async for i in mRejectedDataFind: 
                if i.get('avgDays') <= 14:
                    i['duration'] = 'Upto 14 Days'
                    i['durationInWeek'] = '2 Week'
                elif i.get('avgDays') > 14 and i.get('avgDays') <= 28:
                    i['duration'] = '14 to 28 Days'
                    i['durationInWeek'] = '4 Week'
                elif i.get('avgDays') > 28 and i.get('avgDays') <= 60:
                    i['duration'] = '28 to 60 Days'
                    i['durationInWeek'] = '2 Month'
                elif i.get('avgDays') > 60 and i.get('avgDays') <= 180:
                    i['duration'] = '60 to 180 Days'
                    i['durationInWeek'] = '3-6 Month'
                elif i.get('avgDays') > 180:
                    i['duration'] = '180+ Days'
                    i['durationInWeek'] = '>6 Month'

                result.append(i)

            if len(result):
                code = 2000
                status = True
            else:
                code = 4253
                message = 'Data not Found'
                raise Exception                   

        except Exception as e:
            status = False
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(response)
            await self.finish()
            return

        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return

