import datetime
import json
import os
import re
import sys
import mimetypes
import requests
import pandas as pd
import io

from datetime import datetime as dtime
import tornado.web
from abc import ABCMeta
from bson import ObjectId
from build_config import CONFIG
from lib.lib import Validate
from lib.xen_protocol import xenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log
from util.time_util import timeNow
from bson.json_util import dumps as bdumps
from lib.element_mixer import ElementMixer
from util.file_util import FileUtil


@xenSecureV2
class LoanApplicationFileHistoryHandler(ElementMixer,  MongoMixin, metaclass=ABCMeta):

    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]

    uploadFileDetails = MongoMixin.userDb[
        CONFIG['database'][0]['table'][16]['name']
    ]

    loanApplication = MongoMixin.userDb[
        CONFIG['database'][0]['table'][13]['name']
    ]

    componentId = ObjectId('63d38614458b78fdf4cf6bfa')

    async def get(self):
        code = 4000
        message = ''
        status = False
        result = []
        try:

                mUploadFileInfo = self.uploadFileDetails.aggregate(
                    [
                        {
                            '$lookup': {
                                'from': self.account.name,
                                'localField': 'createdBy',
                                'foreignField':'_id',
                                'as': 'accountDetails',
                                'pipeline': [
                                    {
                                        '$project': {
                                            '_id': {
                                                '$toString': '$_id'
                                            },
                                            'firstName': 1,
                                            'lastName': 1
                                        }
                                    }
                                ]
                            }
                        },
                        {
                            '$addFields': {
                                'accountInfo': {
                                     '$first': '$accountDetails'
                                }
                            }
                        },
                        {
                            '$project': {
                                '_id': {
                                        '$toString': '$_id'
                                },
                                'fileName': 1,
                                'extension': 1,
                                'createdAt': 1,
                                'accountInfo': 1
                            }
                        },
                        {
                             '$sort': {
                                  '_id': -1
                             }
                        }
                    ]
                )
                async for i in mUploadFileInfo:
                    dateObj = datetime.datetime.fromtimestamp(int(i.get('createdAt') / 1000 / 1000))
                    i['createdAt'] = dateObj.strftime('%d-%m-%Y')
                    result.append(i)
                if len(result):
                     status = True
                     code = 2000
                     message = 'Data found'

        except Exception as e:
            status = False
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(response)
            await self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return