
import os
import sys
import io

from abc import ABCMeta
from bson import ObjectId
from build_config import CONFIG
from lib.xen_protocol import xenSecureV2
from util.conn_util import MongoMixin
from util.file_util import FileUtil
from util.log_util import Log
from lib.element_mixer import ElementMixer

@xenSecureV2
class DPRFileDownloadHandler(ElementMixer,  MongoMixin, metaclass=ABCMeta):

    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]

    loanApplication = MongoMixin.userDb[
        CONFIG['database'][0]['table'][13]['name']
    ]
    
    dprFileDetails = MongoMixin.userDb[
        CONFIG['database'][0]['table'][24]['name']
    ]

    componentId = ObjectId('63d39988458b78fdf4cf6c0d')
    fu = FileUtil()
    
    async def get(self):
        code = 4000
        message = ''
        status = False
        result = []
        pdf = None
        try:
            
            try:
                applicantId = self.get_argument('id')
            except:
                code = 3482
                message = 'Missing argument - [ id ]'
                raise Exception
            
            try:
                applicantId = ObjectId(applicantId)
            except:
                code = 4101
                message = 'Invalid Argument - [ id ]'
                raise Exception
            
            xApplicationFind = await self.loanApplication.find_one(
                {
                    '_id': applicantId
                },
                {
                    'applicantId': 1
                }
            )
            if not xApplicationFind:
                code = 4112
                message = 'Application not found'
                raise Exception
            
            xDPRFileFind = await self.dprFileDetails.find_one(
                {
                    'loanApplicationId': applicantId
                }
            )   
            if not xDPRFileFind:
                code = 4130
                message = 'DPR not found'
                raise Exception
            
            fileName = xDPRFileFind.get('fileName')
            extension = xDPRFileFind.get('extension')
            uPath = self.fu.uploads + 'rc-homestay/' + '/DPRs/'+ str(fileName) + str(extension)
            if os.path.exists(uPath):
                self.set_header('Content-Type', 'application/pdf')
                self.set_header('Content-Disposition', f'attachment; filename={fileName}{extension}')
                
                with open(uPath, 'rb') as file:
                    buffer = io.BytesIO()
                    chunk_size = 64 * 1024
                    
                    while True:
                        data = file.read(chunk_size)
                        if not data:
                            break
                        buffer.write(data)
                    
                    pdf = buffer.getvalue()
                    
            else:
                self.set_status(500)
                message = 'File not found'
                code = 3839
                raise Exception

        except Exception as e:
            status = False
            self.set_status = 500
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'    
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            if self._status_code == 200:
                self.write(pdf)
            else:
                self.write(response)
            await self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            # self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return