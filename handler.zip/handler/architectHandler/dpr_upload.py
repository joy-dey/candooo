#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
    Description: AccommodationProviderGrievanceHandler
    Purpose: GET, POST Grievance
"""
import datetime
import json
import mimetypes
import os
import sys

import tornado.web
from bson import ObjectId

from build_config import CONFIG
from handler.methods.max_architect_count import maxArchitectCount
from lib.element_mixer import ElementMixer
from lib.lib import Validate
from lib.xen_protocol import xenSecureV2
from util.conn_util import MongoMixin
from util.file_util import FileUtil
from util.log_util import Log
from bson.json_util import dumps as bdumps

from util.time_util import timeNow


@xenSecureV2
class DPRUploadHandler(ElementMixer, MongoMixin):

    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]
    
    profile = MongoMixin.userDb[
        CONFIG['database'][0]['table'][2]['name']
    ]

    loanApplication = MongoMixin.userDb[
        CONFIG['database'][0]['table'][13]['name']
    ]

    dprFileDetails = MongoMixin.userDb[
        CONFIG['database'][0]['table'][24]['name']
    ]

    block = MongoMixin.userDb[
        CONFIG['database'][0]['table'][15]['name']
    ]

    district = MongoMixin.userDb[
        CONFIG['database'][0]['table'][14]['name']
    ]

    componentId = ObjectId('6631ff450b0ce3dd1c24e3c7')

    async def post(self):
        code = 4000
        message = ''
        status = False
        result = []
            
        try:
            try:
                file_dic = {}
                arg_dic = {}
                b = self.request.headers.get('Content-Type')    
                tornado.httputil.parse_body_arguments(b, self.request.body, arg_dic, file_dic)
                xFile = file_dic.get('file')
            except:
                code = 4058
                message = 'Invalid body arguments.'
                raise Exception
            
            xFileType = xFile[0].get('content_type')
            xFileType = mimetypes.guess_extension(xFileType)

            if xFileType != '.pdf':
                code = 4068
                message = 'Expected file type is PDF'
                raise Exception

            accQ = await self.account.find_one(
                {
                    '_id': self.accountId
                }
            )
            designationQ = accQ['designation']
            if designationQ != 'Architect':
                code = 3566
                message = 'Only Architect are allowed to access'
                raise Exception
            
            vApplicantId = arg_dic.get('applicantId')[0].decode()
            code, message = Validate.i(
                vApplicantId,
                'applicantId',
                dataType=str,
                notEmpty=True
            )
            if code != 4100:
                raise Exception
            
            try:
                vApplicantId = ObjectId(vApplicantId)
            except:
                code = 4101
                message = 'Invalid Argument - [ applicantId ]'
                raise Exception
            
            xApplicationFind = await self.loanApplication.find_one(
                {
                    '_id': vApplicantId,
                    'architectDetails.architectAssigned': self.accountId
                },
                {
                    'applicantId': 1
                }
            )
            if not xApplicationFind:
                code = 4112
                message = 'Application not found'
                raise Exception
            
            xFileName = xFile[0].get('filename').split('.pdf')[0]
            xFileName = xFileName + '_' + xApplicationFind.get('applicantId')
            
            fu = FileUtil()

            xDPRFileFind = await self.dprFileDetails.find_one(
                {
                    'loanApplicationId': vApplicantId,
                    'submittedBy': self.accountId
                }
            )   
            if xDPRFileFind:
                xDPRUpdate = await self.dprFileDetails.update_one(
                    {
                    'loanApplicationId': vApplicantId,
                    'submittedBy': self.accountId
                },
                   {'$set': {
                    'fileName': xFileName,
                    'extension': xFileType,
                    'modifiedBy': self.accountId,
                    'modifiedAt':timeNow()
                }})
                
                if xDPRUpdate.modified_count > 0:
                    xLoanAppUpdate = await self.loanApplication.update_one(
                    {
                        '_id': vApplicantId
                    },
                    {
                        '$set': {
                            'architectDetails.dprSubmitted': True
                        }
                    }
                    )
                    code = 2000
                    status = True
                    message = 'File Updated Successfully'
                else:
                    code = 4135
                    message = 'File Not Updated'
                    raise Exception
            else:    
                xDPRUpdate = await self.dprFileDetails.insert_one({
                    'loanApplicationId': vApplicantId,
                    'applicantId': xApplicationFind.get('applicantId'),
                    'fileName': xFileName,
                    'extension': xFileType,
                    'submittedBy': self.accountId,
                    'submittedAt':timeNow(),
                    'modifiedBy': self.accountId,
                    'modifiedAt':timeNow()
                })
                
                if xDPRUpdate.inserted_id:
                    xLoanAppUpdate = await self.loanApplication.update_one(
                    {
                        '_id': vApplicantId
                    },
                    {
                        '$set': {
                            'architectDetails.dprSubmitted': True
                        }
                    }
                    )
                    code = 2000
                    status = True
                    message = 'File Submitted'
                else:
                    code = 4135
                    message = 'File not Submitted'
                    raise Exception
                
            uPath = fu.uploads + 'rc-homestay/' + 'DPRs/'
            if xDPRFileFind:
                fileName = xDPRFileFind.get('fileName')
                extension = xDPRFileFind.get('extension')
                path = os.path.join(uPath, str(fileName) + str(extension))
                if os.path.exists(path):
                    os.remove(path)
                with open(uPath + xFileName + xFileType, 'wb') as f:
                    f.write(xFile[0]['body'])
                    f.close()
            else:
                if not os.path.exists(uPath):
                    os.system('mkdir -p ' + uPath)
                    os.system('chmod 755 -R ' + uPath)
                    Log.i('File directory created {}'.format(uPath))
                with open(uPath + xFileName + xFileType, 'wb') as f:
                    f.write(xFile[0]['body'])
                    f.close()
                
        except Exception as e:
            status = False
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(response)
            await self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return
        
    async def get(self):
        code = 4000
        message = ''
        status = False
        result = []
    
        try:
            accQ = await self.account.find_one(
                {
                    '_id': self.accountId
                }
            )
            designationQ = accQ['designation']
            if designationQ != 'Architect':
                code = 3566
                message = 'Only Architect are allowed to access'
                raise Exception
            
            pipeline = [
                {
                    '$match': {
                        'architectDetails.architectAssigned': self.accountId
                    }
                },
                {
                    '$lookup': {
                        'from': self.district.name,
                        'localField': 'data.unitDistrict',
                        'foreignField': '_id',
                        'as': 'districtInfo',
                        'pipeline': [
                            {
                                '$project': {
                                    '_id': 1,
                                    'districtName': 1
                                }
                            }
                        ]
                    }
                },
                {
                    '$lookup': {
                        'from': self.block.name,
                        'localField': 'data.talukblock',
                        'foreignField': '_id',
                        'as': 'blockInfo',
                        'pipeline': [
                            {
                                '$project': {
                                    '_id': 1,
                                    'blockName': 1
                                }
                            }
                        ]
                    }
                },
                {
                    '$unwind': '$districtInfo'
                },
                {
                    '$unwind': '$blockInfo'
                },
                {
                    '$project': {
                        '_id': {
                            '$toString': '$_id'
                        },
                        'applicantId': 1,
                        'applicantName': '$data.applicantName',
                        'age': '$data.age',
                        'address': '$data.unitAddress',
                        'district': '$districtInfo.districtName',
                        'block': '$blockInfo.blockName',
                        'assignedAt': '$architectDetails.assignedAt',
                        'gender': '$data.gender',
                        'dprSubmitted': '$architectDetails.dprSubmitted',
                        'proposedProjectCost' : '$data.proposedProjectCost',
                        'loanSanctionedAmount' : '$data.totalSanctionedAmountByBank',
                        }
                }
            ]     
            applicationFind = self.loanApplication.aggregate(pipeline)
            async for i in applicationFind:
                date = int(i['assignedAt']/1000000)
                i['assignedAt'] = datetime.datetime.fromtimestamp(int(date)).strftime('%d-%m-%Y')
                assignedAt = datetime.datetime.fromtimestamp(int(date))
                currDate = datetime.datetime.fromtimestamp(int(timeNow()/1000000))
                dayDiff = (currDate-assignedAt).days
                if dayDiff > 30:
                    i['allowSubmission'] = False
                else:
                    i['allowSubmission'] = True
                result.append(i)

            if len(result):
                code = 2000
                message = 'Data Found'
                status = True
            else:
                code = 4255
                message = 'Data not Found'
                raise Exception

        except Exception as e:
            status = False
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(response)
            await self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return