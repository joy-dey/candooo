import datetime
import json
import os
import re
import sys
import io

import tornado.web
from abc import ABCMeta
from bson import ObjectId
from build_config import CONFIG
from lib.lib import Validate
from lib.xen_protocol import xenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log
from util.time_util import timeNow
from bson.json_util import dumps as bdumps
from lib.element_mixer import ElementMixer
from util.file_util import FileUtil


@xenSecureV2
class DPRFileHistoryHandler(ElementMixer,  MongoMixin, metaclass=ABCMeta):

    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]

    dprFileDetails = MongoMixin.userDb[
        CONFIG['database'][0]['table'][24]['name']
    ]

    loanApplication = MongoMixin.userDb[
        CONFIG['database'][0]['table'][13]['name']
    ]

    componentId = ObjectId('63d39988458b78fdf4cf6c0d')

    async def get(self):
        code = 4000
        message = ''
        status = False
        result = []
        try:
            try:
                applicationId = self.get_argument('applicationId')
            except:
                applicationId = None
            code, message = Validate.i(
                applicationId,
                'applicationId',
                dataType=str,
                notEmpty=True,
                notNull=True
            )
            if code != 4100:
                raise Exception

            try:
                applicationId = ObjectId(applicationId)
            except:
                code = 4063
                message = 'Invalid Argument - [ applicationId ]'
                raise Exception

            accQ = await self.account.find_one(
                {
                    '_id': self.accountId
                }
            )
            designationQ = accQ['designation']
            if designationQ != 'Architect':
                code = 3566
                message = 'Only Architect are allowed to access'
                raise Exception
            
            mUploadFileInfo = self.dprFileDetails.aggregate(
                [
                    {
                        '$match': {
                            'loanApplicationId': applicationId
                        }
                    },
                    {
                        '$lookup': {
                            'from': self.account.name,
                            'localField': 'submittedBy',
                            'foreignField': '_id',
                            'as': 'architectAccountDetails',
                            'pipeline': [
                                {
                                    '$project': {
                                        '_id': {
                                            '$toString': '$_id'
                                        },
                                        'firstName': 1,
                                        'lastName': 1
                                    }
                                }
                            ]
                        }
                    },
                    {
                        '$project': {
                            '_id': {
                                '$toString': '$_id'
                            },
                            'fileName': 1,
                            'extension': 1,
                            'submittedAt': 1,
                            'architectAccountDetails': 1
                        }
                    },
                ]
            )
            async for i in mUploadFileInfo:
                dateObj = datetime.datetime.fromtimestamp(
                    int(i.get('submittedAt') / 1000 / 1000))
                i['submittedAt'] = dateObj.strftime('%d-%m-%Y')
                result.append(i)
            if len(result):
                status = True
                code = 2000
                message = 'Data found'

        except Exception as e:
            status = False
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(response)
            await self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return
