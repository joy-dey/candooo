#!/usr/bin/VtsAdminSignInHandler
# -*- coding: utf-8 -*-

import json
import os
import re
import sys
import mimetypes
import requests
from datetime import datetime as dtime
import tornado.web
from abc import ABCMeta
from bson import ObjectId
from build_config import CONFIG
from lib.fernet_crypto import FN_ENCRYPT
from lib.lib import Validate
from lib.xen_protocol import xenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log
from util.time_util import timeNow
from bson.json_util import dumps as bdumps
from lib.element_mixer import ElementMixer
from util.file_util import FileUtil

@xenSecureV2
class AdminNotificationDataHandler(ElementMixer,  MongoMixin, metaclass=ABCMeta):


    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]

    notification = MongoMixin.userDb[
        CONFIG['database'][0]['table'][26]['name']
    ]
    profile = MongoMixin.userDb[
        CONFIG['database'][0]['table'][2]['name']
    ]

    phoneCountry = MongoMixin.userDb[
        CONFIG['database'][0]['table'][6]['name']
    ]
    token = MongoMixin.userDb[
        CONFIG['database'][0]['table'][25]['name']
    ]

    componentId = ObjectId('63d38614458b78fdf4cf6bfa')

    async def post(self):
        code = 4000
        message = ''
        status = False
        result = []
        try:
            fcm_url = 'https://fcm.googleapis.com/fcm/send'
            fcm_server_key = 'AAAAbZeTBV8:APA91bHw8I4kg1ITfZAIKLL6zm8kbzNfXV5Jf9O02fF586guko6k7HByszYHZS8HsFYoaDISPwyuUc7t9fHGrgx7qyErvhZkuOiIXK6-J5OM4pqqHvrOoOELwsxN0IIoqu5PFbkN4Kir'  
                
            headers = {
                'Authorization': f'key={fcm_server_key}',
                'Content-Type': 'application/json',
            }
            
            try:
                self.request.arguments = json.loads(self.request.body.decode())
            except Exception as e:
                code = 4002
                message = 'Expected Request Type JSON.'
                raise Exception
            
            try:
                _Id = self.accountId   
            except:
                _Id = self.request.arguments.get("accountId")                  
            admin = await self.account.find_one(
                {'_id': ObjectId(_Id)}
                ) 
            
            method = self.request.arguments.get('method')
            if method == None:
                code = 4130
                message = 'Missing Argument - [ method ].'
                raise Exception
            elif type(method) != int:
                code = 4131
                message = 'Invalid Argument - [ method ].'
                raise Exception
            
            if admin :
                if method == 1:
                    inputData = []
                    recieverQ = self.request.arguments.get('reciever_Ids')
                    code, message = Validate.i(
                        recieverQ,
                        'Reciever Ids',
                        notEmpty=True,
                        notNull = True,
                        dataType=list
                    )
                    if code != 4100:
                        raise Exception
                    
                    applicantId = self.request.arguments.get('applicantId')
                    code, message = Validate.i(
                        applicantId,
                        'Applicant Id',
                        notEmpty=True,
                        notNull = True,
                        dataType=str,
                        noSpace=True
                    )
                    if code != 4100:
                        raise Exception
                    
                    try:
                        vStatus = self.request.arguments.get('status')
                    except:
                        vStatus = None
                    if vStatus != None:
                        code, message = Validate.i(
                            vStatus,
                            'Status',
                            notEmpty=True,
                            notNull = True,
                            noSpace=True,
                            noNumber=True,
                            noSpecial=True,
                            dataType=str
                        )
                        if code != 4100:
                            raise Exception
                        
                    
                    if len(recieverQ) > 0:
                        for reciever in recieverQ:
                            try:
                                reciever = ObjectId(reciever)
                            except Exception as e:
                                message = 'Invalid Argument - [ id ].'
                                code = 4052
                                raise Exception
                            
                            recieverQ = await self.account.find_one(
                                {'_id': reciever}
                                ) 
                            
                            if not recieverQ:
                                message = 'Reciever does not exist'
                                status = False
                                code = 4632
                                raise Exception
                            
                            token = await self.token.find_one({
                                'accountId' : reciever
                            },
                            {
                                'regToken' : 1  
                            })
                            if not token:
                                message = f'No registration token found for the auditor - {reciever}'
                                status = False
                                code = 4989
                                raise Exception
                            
                            notificationQ = self.request.arguments.get('notification')
                            title = notificationQ.get('title')
                            code, message = Validate.i(
                                title,
                                'title',
                                notEmpty=True,
                                notNull = True,
                                dataType=str
                            )
                            if code != 4100:
                                raise Exception
                            
                            body = notificationQ.get('body')
                            code, message = Validate.i(
                                body,
                                'body',
                                notEmpty=True,
                                notNull = True,
                                dataType=str
                            )
                            if code != 4100:
                                raise Exception
                            
                            notifiQ = {
                                'title' : title,
                                'body' : body
                            }
                            inputDataQ = {
                                'sentBy' : _Id,
                                'recievedBy' : reciever,
                                'sentDate' : timeNow(),
                                'notification' : notifiQ,
                                'applicantId' : applicantId,
                                'status' : vStatus
                            }       
                            inputData.append(inputDataQ)     
                        
                        for data in inputData:
                            insertnotificationDtlQ = await self.notification.insert_one(data)
                            tokenNotificationId = insertnotificationDtlQ.inserted_id
                            if tokenNotificationId:
                                message = 'Notification has been submitted.'
                                code = 2294
                                status = True
                            else:
                                message = 'Notification already submitted.'
                                code = 2298
                                status = False
                            
                            tokenV = await self.token.find_one({
                                'accountId' : data['recievedBy']
                            },
                            {
                                'regToken' : 1  
                            })
                            tokenS = tokenV.get('regToken')
                            notification_data = {
                                "notification": data['notification'],
                                "to": tokenS,
                                "data" : {"notificationId" : str(tokenNotificationId), "applicantId" : applicantId}
                            }   
                            responseQ = requests.post(fcm_url, json=notification_data, headers=headers)
                            if responseQ.status_code == 200:
                                message = "Notification Sent"
                                status = True
                                code = 4320
                                result.append(responseQ.json())
                            
                            else:
                                message = f"Notification could not be sent, Error : {responseQ.text}"
                                status = False
                                code = 4178
                                raise Exception   
                    else:
                        code = 3455
                        message = 'No recievers found.'
                        raise Exception
                else:
                    code = 4110
                    message = 'Method not supported.'
                    raise Exception 
                        
            else :
                message = 'Admin not found'
                code = 4222
                raise Exception
                
        except Exception as e:
            status = False
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(response)
            try:
                await self.finish()
                return response
            except:
                return response
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            # self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return
        