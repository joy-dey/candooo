#!/usr/bin/VtsAdminSignInHandler
# -*- coding: utf-8 -*-

import json
import os
import re
import sys
import mimetypes
import requests
from datetime import datetime as dtime
import tornado.web
from abc import ABCMeta
from bson import ObjectId
from build_config import CONFIG
from lib.fernet_crypto import FN_ENCRYPT
from lib.lib import Validate
from lib.xen_protocol import xenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log
from util.time_util import timeNow
from bson.json_util import dumps as bdumps
from lib.element_mixer import ElementMixer
from util.file_util import FileUtil
import google.auth.transport.requests
from google.oauth2 import service_account
from build_config import SERVICE_ACCOUNT_FILE_PATH

@xenSecureV2
class AdminNotificationDataHandler(ElementMixer,  MongoMixin, metaclass=ABCMeta):


    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]

    notification = MongoMixin.userDb[
        CONFIG['database'][0]['table'][26]['name']
    ]
    profile = MongoMixin.userDb[
        CONFIG['database'][0]['table'][2]['name']
    ]

    phoneCountry = MongoMixin.userDb[
        CONFIG['database'][0]['table'][6]['name']
    ]
    token = MongoMixin.userDb[
        CONFIG['database'][0]['table'][25]['name']
    ]

    componentId = ObjectId('63d38614458b78fdf4cf6bfa')
    PROJECT_ID = 'homestay-scheme'
    BASE_URL = 'https://fcm.googleapis.com'
    FCM_ENDPOINT = 'v1/projects/' + PROJECT_ID + '/messages:send'
    FCM_URL = BASE_URL + '/' + FCM_ENDPOINT
    SCOPES = ['https://www.googleapis.com/auth/firebase.messaging']

    def _get_access_token(self):
        try:
            credentials = service_account.Credentials.from_service_account_file(
                SERVICE_ACCOUNT_FILE_PATH, 
                scopes=self.SCOPES
            )
            request = google.auth.transport.requests.Request()
            credentials.refresh(request)
            return credentials.token
        except Exception as e:
            Log.i(f"Failed to refresh token: {e}")
            return None

    async def post(self):
        code = 4000
        message = ''
        status = False
        result = []
        try:
                
            headers = {
                'Authorization': 'Bearer ' + self._get_access_token(),
                'Content-Type': 'application/json; UTF-8',
            }
            
            try:
                self.request.arguments = json.loads(self.request.body.decode())
            except Exception as e:
                code = 4002
                message = 'Expected Request Type JSON.'
                raise Exception
            
            try:
                if isinstance(self.accountId, list):
                    _Id = self.accountId[0] 
                else:
                    _Id = self.accountId 
            except:
                _Id = self.request.arguments.get("accountId")

            if isinstance(_Id, list):
                _Id = _Id[0] 
            if _Id != None: 
                _Id = ObjectId(_Id)
            else:
                code = 4135
                message = 'Invalid Argument - [ accountId ].'
                raise Exception    
            admin = await self.account.find_one(
                {'_id': ObjectId(_Id)}
                ) 
            method = self.request.arguments.get('method')
            if method == None:
                code = 4130
                message = 'Missing Argument - [ method ].'
                raise Exception
            elif type(method) != int:
                code = 4131
                message = 'Invalid Argument - [ method ].'
                raise Exception
            try:
                notificationType = self.request.arguments.get('notificationType')
                if notificationType is None:
                    code = 4135
                    message = 'Missing Argument - [ notificationType ].'
                    raise Exception

                try:
                    notificationType = int(notificationType)
                except ValueError:
                    code = 4136
                    message = 'Invalid Argument - [ notificationType ]. Not an integer.'
                    raise Exception

            except Exception as e:
                code = 4137
                message = 'Invalid Argument - [ notificationType ].'
                raise Exception
            try:
                reason = self.request.arguments.get('reason')
            except:
                reason = None
            try:
                methodNotification = self.request.arguments.get('methodNotification')
                if methodNotification is None:
                    code = 4150
                    message = 'Missing Argument - [ methodNotification ].'
                    raise Exception
            except Exception as e:
                code = 4155
                message = 'Invalid Argument - [ methodNotification ].'
                raise Exception
            if admin :
                if method == 1:
                    inputData = []
                    recieverQ = self.request.arguments.get('reciever_Ids')
                    code, message = Validate.i(
                        recieverQ,
                        'Reciever Ids',
                        notEmpty=True,
                        notNull = True,
                        dataType=list
                    )
                    if code != 4100:
                        raise Exception
                    
                    rejectDetails = self.request.arguments.get('rejectDetails',None)
                    if rejectDetails != None:
                        code, message = Validate.i(
                            rejectDetails,
                            'rejectDetails',
                            notEmpty=True,
                            notNull = True,
                            dataType=dict
                        )
                        if code != 4100:
                            raise Exception
                        
                    applicantId = self.request.arguments.get('applicantId')
                    code, message = Validate.i(
                        applicantId,
                        'Applicant Id',
                        notEmpty=True,
                        notNull = True,
                        dataType=str,
                        noSpace=True
                    )
                    if code != 4100:
                        raise Exception
                    
                    try:
                        vStatus = self.request.arguments.get('status')
                    except:
                        vStatus = None
                    if vStatus != None:
                        code, message = Validate.i(
                            vStatus,
                            'Status',
                            notEmpty=True,
                            notNull = True,
                            noSpace=True,
                            noNumber=True,
                            noSpecial=True,
                            dataType=str
                        )
                        if code != 4100:
                            raise Exception
                        
                    try:
                        notificationStatus = self.request.arguments.get('notificationStatus')
                    except:
                        notificationStatus = None
                    if notificationStatus != None:
                        code, message = Validate.i(
                            notificationStatus,
                            'notificationStatus',
                            notEmpty=True,
                            notNull = True,
                            noSpace=True,
                            noNumber=True,
                            noSpecial=True,
                            dataType=str
                        )
                        if code != 4100:
                            raise Exception
                    
                    recievers = []
                    if len(recieverQ) > 0:
                        for reciever in recieverQ:
                            try:
                                reciever = ObjectId(reciever)
                                recievers.append(reciever)
                            except Exception as e:
                                message = 'Invalid Argument - [ id ].'
                                code = 4052
                                raise Exception
                            
                            recieverQ = await self.account.find_one(
                                {'_id': reciever}
                                ) 
                            
                            if not recieverQ:
                                message = 'Reciever does not exist'
                                status = False
                                code = 4632
                                raise Exception
                            
                            # token = await self.token.find_one({
                            #     'accountId' : reciever
                            # },
                            # {
                            #     'regToken' : 1  
                            # })
                            # if not token:
                            #     message = f'No registration token found for the auditor - {reciever}'
                            #     status = False
                            #     code = 4989
                            #     raise Exception
                            
                        notificationQ = self.request.arguments.get('notification')
                        title = notificationQ.get('title')
                        code, message = Validate.i(
                            title,
                            'title',
                            notEmpty=True,
                            notNull = True,
                            dataType=str
                        )
                        if code != 4100:
                            raise Exception
                        
                        
                        body = notificationQ.get('body')
                        code, message = Validate.i(
                            body,
                            'body',
                            notEmpty=True,
                            notNull = True,
                            dataType=str
                        )
                        if code != 4100:
                            raise Exception
                        
                        notifiQ = {
                            'title' : title,
                            'body' : body
                        }
                        inputDataQ = {
                            'sentBy': _Id,
                            'recievedBy': [{'reciever': rId, 'status': vStatus} for rId in recievers],
                            'notificationType': notificationType,
                            'sentDate': timeNow(),
                            'notification': notifiQ,
                            'applicantId': applicantId,
                        }
                        if rejectDetails != None:
                            inputDataQ['rejectDetails'] = rejectDetails
                        if reason != None:
                            inputDataQ['remarks'] = reason
                        inputData.append(inputDataQ)
                            
                        for data in inputData:
                            insertnotificationDtlQ = await self.notification.insert_one(data)
                            tokenNotificationId = insertnotificationDtlQ.inserted_id
                            if tokenNotificationId:
                                if methodNotification == 1 and notificationType == 2:
                                    await self.notification.update_one(
                                        {
                                            '_id': tokenNotificationId
                                        },
                                        {
                                            '$set': {
                                                'notificationStatus': 'Ok'
                                            }
                                        }
                                    )
                                elif methodNotification == 2 and notificationType == 2:
                                    await self.notification.update_one(
                                        {
                                            '_id': tokenNotificationId
                                        },
                                        {
                                            '$set': {
                                                'notificationStatus': 'Pending'
                                            }
                                        }
                                    )
                                message = 'Notification has been submitted.'
                                code = 2294
                                status = True
                            else:
                                message = 'Notification already submitted.'
                                code = 2298
                                status = False
                            for reciever in recievers:
                                tokenV = await self.token.find_one({
                                    'accountId' : reciever
                                },
                                {
                                    'regToken' : 1  
                                })
                                if tokenV:
                                    tokenS = tokenV.get('regToken', None)
                                    if tokenS != None:
                                        if tokenNotificationId != None:
                                            tokenNotificationId = str(tokenNotificationId)
                                        if notificationType is not None and notificationType in [1, 2]:
                                            notification_data = {
                                                "message": {
                                                    "token": tokenS,
                                                    "notification": {
                                                        "title": title,
                                                        "body": body
                                                    },
                                                    "data": {
                                                        "notificationId": tokenNotificationId,
                                                        "applicantId": applicantId,
                                                        'notificationType': str(notificationType), 
                                                        'notificationStatus':notificationStatus,
                                                        'reason': reason 
                                                    }
                                                }
                                            }
                                        else:
                                            message = "Incorrect Notification Type."
                                            status = False
                                            code = 4325
                                        responseQ = requests.post(self.FCM_URL, json=notification_data, headers=headers)
                                        if responseQ.status_code == 200:
                                            message = "Notification Sent"
                                            status = True
                                            code = 4320
                                        
                                        else:
                                            message = f"Notification could not be sent, Error : {responseQ.text}"
                                            status = False
                                            code = 4178
                                            continue
                                            # raise Exception 
                    else:
                        code = 3455
                        message = 'No recievers found.'
                        raise Exception
                else:
                    code = 4110
                    message = 'Method not supported.'
                    raise Exception 
                        
            else :
                message = 'Admin not found'
                code = 4222
                raise Exception
                
        except Exception as e:
            status = False
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(response)
            try:
                await self.finish()
                return response
            except:
                return response
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            # self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return
        