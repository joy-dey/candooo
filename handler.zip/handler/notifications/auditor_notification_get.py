#!/usr/bin/AdminListHandler
# -*- coding: utf-8 -*-

"""
    Description: AdminHandler
    Purpose: Get user list, add new user
"""
import json
import sys
import tornado.web
from abc import ABCMeta
from bson import ObjectId
from bson.json_util import dumps as bdumps
from build_config import CONFIG
from lib.element_mixer import ElementMixer
from lib.fernet_crypto import FN_ENCRYPT
from lib.lib import Validate
from lib.xen_protocol import noXenSecureV2, xenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log
from util.time_util import timeNow


@xenSecureV2
class AuditorNotificationInfoHandler(ElementMixer, MongoMixin, metaclass=ABCMeta):

    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]

    applications = MongoMixin.userDb[
        CONFIG['database'][0]['table'][1]['name']
    ]

    profile = MongoMixin.userDb[
        CONFIG['database'][0]['table'][2]['name']
    ]

    notification = MongoMixin.userDb[
        CONFIG['database'][0]['table'][26]['name']
    ]

    componentId = ObjectId('63d39988458b78fdf4cf6c0d')

    async def get(self):

        code = 4000
        status = False
        message = ''
        result = []

        try:
            try:
                f_limit = int(self.get_arguments('limit')[0])
            except:
                f_limit = 0
                
            
            vAccountId = (await self.account.find_one(
                {
                    '_id': ObjectId(self.accountId)
                },
                {
                    '_id': 1
                }
            ))['_id']
            
            if not vAccountId:
                message = 'You are not a valid User.'
                code = 4052
                raise Exception
                
            notificationListQ = [
                    {
                        '$match': {
                            'recievedBy': vAccountId
                        }
                    },
                    {
                        '$sort': {
                            'sentDate': -1 
                        }
                    },
                    {
                        '$project': {
                            'sentDate' : 1,
                            'notification' : 1,
                            'applicantId' : 1,
                            'status' : 1
                        }
                    },
                ]
            
            if f_limit:
                notificationListQ.append(
                    {
                        '$limit': f_limit
                    }
                )
                
            notificationList = self.notification.aggregate(notificationListQ)
            async for i in notificationList:
                i['_id'] = str(i['_id'])
                result.append(i)

            if len(result):
                message = 'Data found.'
                code = 2000
                status = True
            else:
                code = 4091
                message = 'Data not found.'

        except Exception as e:
            status = False
            self.set_status(503)

            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))

        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)

        try:
            response['result'] = result
            self.write(bdumps(response))
            await self.finish()
            return

        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return