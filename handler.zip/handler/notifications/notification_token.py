#!/usr/bin/VtsAdminSignInHandler
# -*- coding: utf-8 -*-

import json
import os
import re
import sys
import mimetypes
import requests
from datetime import datetime
import tornado.web
from abc import ABCMeta
from bson import ObjectId
from build_config import CONFIG
from lib.fernet_crypto import FN_ENCRYPT
from lib.lib import Validate
from lib.xen_protocol import xenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log
from util.time_util import timeNow
from bson.json_util import dumps as bdumps
from lib.element_mixer import ElementMixer
from util.file_util import FileUtil

@xenSecureV2
class NotificationDetailsHandler(ElementMixer,  MongoMixin, metaclass=ABCMeta):


    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]

    phoneCountry = MongoMixin.userDb[
        CONFIG['database'][0]['table'][5]['name']
    ]
    
    token = MongoMixin.userDb[
        CONFIG['database'][0]['table'][25]['name']
    ]


    componentId = ObjectId('63d39988458b78fdf4cf6c0d')

    async def post(self):
        code = 4000
        message = ''
        status = False
        result = []
        try:
                try:
                    # CONVERTS BODY INTO JSON
                    self.request.arguments = json.loads(self.request.body.decode())
                except Exception as e:
                    code = 4002
                    message = 'Expected Request Type JSON.'
                    raise Exception
                        
                _Id = self.accountId                     
                provider = await self.account.find_one(
                    {'_id': ObjectId(_Id)}
                    ) 
                
                method = self.request.arguments.get('method')
                if method == None:
                    code = 4130
                    message = 'Missing Argument - [ method ].'
                    raise Exception
                elif type(method) != int:
                    code = 4131
                    message = 'Invalid Argument - [ method ].'
                    raise Exception
                
                if provider :
                    appId = ObjectId(self.applicationId)

                    if method == 1:
                        try:
                            token = self.request.arguments.get('registrationToken')
                            code, message = Validate.i(
                                token,
                                'registrationToken',
                                notEmpty=True,
                                notNull = True,
                                dataType=str
                            )
                            if code != 4100:
                                raise Exception
                            
                        except : 
                            exc_type, exc_obj, exc_tb = sys.exc_info()
                            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                            Log.d('FILE: ' + str(fname), 'LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
                            if not len(message):
                                code = 4210
                                template = "Exception: {0}. Argument: {1!r}"
                                message = template.format(type(e).__name__, e.args)
                            raise Exception
                        
                        inputData = {
                            'accountId' : _Id,
                            'regToken' : token,
                            'applicationId' : appId
                        }
                        
                        findTokenDtlQ = self.token.find(
                                {
                                    'accountId': _Id,
                                }
                            )
                        
                        findtokenDetails = []
                        async for i in findTokenDtlQ:
                            findtokenDetails.append(i)

                        if len(findtokenDetails):
                            
                            updatetokenDtlQ = await self.token.update_one(
                                {
                                    'accountId': findtokenDetails[0]['accountId']
                                },
                                {
                                    '$set': {
                                        'regToken': token
                                        
                                    }
                                }
                            )
                            if updatetokenDtlQ.modified_count:
                                message = 'Token Details updated.'
                                code = 2215
                                status = True
                            else:
                                message = 'Token Details could not be updated.'
                                code = 4242
                                status = False
                        else:
                            inserttokenDtlQ = await self.token.insert_one(inputData)

                            tokenDetailsId = inserttokenDtlQ.inserted_id
                            if tokenDetailsId:
                                message = 'Token has been submitted.'
                                code = 2294
                                status = True
                            else:
                                message = 'Token already submitted.'
                                code = 2298
                                status = False
                    else:
                        code = 4110
                        message = 'Method not supported.'
                        raise Exception 
                          
                else :
                    message = 'Provider not found'
                    code = 4222
                    raise Exception
                
        except Exception as e:
            status = False
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(response)
            await self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            # self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return
        