
import json
import sys
import requests
import tornado.web
import os
import google.auth.transport.requests
from google.oauth2 import service_account
from abc import ABCMeta
from lib.lib import Validate
from build_config import CONFIG
from bson import ObjectId
from lib.fernet_crypto import FN_ENCRYPT
from lib.element_mixer import ElementMixer
from util.log_util import Log
from lib.xen_protocol import noXenSecureV2, xenSecureV2
from util.conn_util import MongoMixin
from build_config import SERVICE_ACCOUNT_FILE_PATH

@xenSecureV2
class AdminFCMHandler( ElementMixer, MongoMixin, metaclass=ABCMeta):
    
    token = MongoMixin.userDb[
        CONFIG['database'][0]['table'][25]['name']
    ]
    
    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]
    
    componentId = ObjectId('63d38614458b78fdf4cf6bfa')

    PROJECT_ID = 'homestay-scheme'
    BASE_URL = 'https://fcm.googleapis.com'
    FCM_ENDPOINT = 'v1/projects/' + PROJECT_ID + '/messages:send'
    FCM_URL = BASE_URL + '/' + FCM_ENDPOINT
    SCOPES = ['https://www.googleapis.com/auth/firebase.messaging']

    def _get_access_token(self):
        credentials = service_account.Credentials.from_service_account_file(
            SERVICE_ACCOUNT_FILE_PATH, scopes=self.SCOPES)
        request = google.auth.transport.requests.Request()
        credentials.refresh(request)
        return credentials.token

    async def post(self):
        code = 4000
        message = ''
        status = False
        result = []
        try:
            try:
                self.request.arguments = json.loads(self.request.body.decode())
            except Exception as e:
                code = 4002
                message = 'Expected Request Type JSON.'
                raise Exception
            
            headers = {
                'Authorization': 'Bearer ' + self._get_access_token(),
                'Content-Type': 'application/json; UTF-8',
            }
            
            method = self.request.arguments.get('method')
            if method == None:
                code = 4130
                message = 'Missing Argument - [ method ].'
                raise Exception
            elif type(method) != int:
                code = 4131
                message = 'Invalid Argument - [ method ].'
                raise Exception
            
            if method == 1:
                
                try:
                    notificationQ = self.request.arguments.get('notification')
                    recIds = self.request.arguments.get('reciever_Ids')
                    
                    if recIds is None:
                        message = 'No id found'
                        status = False
                        code = 5610
                        raise Exception
                    
                    elif len(recIds) == 0:
                        message = 'Empty id array found'
                        status = False
                        code = 5611
                        raise Exception
                    
                    for reciever_id in recIds:
                        try:
                            reciever_id = ObjectId(reciever_id)
                        except Exception as e:
                            message = 'Invalid Argument - [ reciever_Ids ].'
                            code = 4052
                            raise Exception
                        
                        recieverQ = await self.account.find_one(
                            {'_id': reciever_id}
                            ) 
                        
                        if not recieverQ:
                            message = 'Reciever does not exist'
                            status = False
                            code = 4632
                            raise Exception

                        token = await self.token.find_one({
                            'accountId' : reciever_id
                        },
                        {
                            'regToken' : 1  
                        })
                        if token:
                            tokenQ = token.get('regToken')
                            notification_data = {
                                "message":{
                                    "token": tokenQ,
                                    "notification": notificationQ
                                }
                            }      
                            
                            responseQ = requests.post(self.FCM_URL, json=notification_data, headers=headers)
                            if responseQ.status_code == 200:
                                message = "Notification Sent"
                                status = True
                                code = 4320
                                result.append(responseQ.json())
                            
                            else:
                                message = f"Notification could not be sent, Error : {responseQ.text}"
                                status = False
                                code = 4178
                                raise Exception   
                        else:
                            message = f'No registration token found for the provider - {reciever_id}'
                            status = False
                            code = 4989
                            raise Exception
                except : 
                    exc_type, exc_obj, exc_tb = sys.exc_info()
                    fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                    Log.d('FILE: ' + str(fname), 'LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
                    if not len(message):
                        code = 4210
                        template = "Exception: {0}. Argument: {1!r}"
                        message = template.format(type(e).__name__, e.args)
                    raise Exception       
                
        except Exception as e:
            status = False
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }  
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(response)
            await self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            # self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return

