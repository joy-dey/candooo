import json
import sys
import tornado.web
from abc import ABCMeta
from bson import ObjectId
from bson.json_util import dumps as bdumps
from build_config import CONFIG
from lib.element_mixer import ElementMixer
from lib.fernet_crypto import FN_DECRYPT, FN_ENCRYPT
from lib.lib import Validate
from lib.xen_protocol import noXenSecureV2, xenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log
from util.time_util import timeNow


@xenSecureV2
class AddPermissionHandler(ElementMixer, MongoMixin, metaclass=ABCMeta):

    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]

    applications = MongoMixin.userDb[
        CONFIG['database'][0]['table'][1]['name']
    ]

    profile = MongoMixin.userDb[
        CONFIG['database'][0]['table'][2]['name']
    ]

    state = MongoMixin.userDb[
        CONFIG['database'][0]['table'][6]['name']
    ]

    countries = MongoMixin.userDb[
        CONFIG['database'][0]['table'][7]['name']
    ]

    phoneCountry = MongoMixin.userDb[
        CONFIG['database'][0]['table'][5]['name']
    ]

    componentId = ObjectId('63d39988458b78fdf4cf6c0d')

    async def get(self):

        code = 4000
        status = False
        message = ''
        result = []

        try:
            try:
                # Converts the request body to JSON
                self.request.arguments = json.loads(self.request.body)
            except Exception as e:
                code = 4100
                message = 'Expected Request Type JSON.'
                raise Exception
            
            seach = self.request.arguments.get('search')
            code, message = Validate.i(
                seach,
                'search',
                notNull=True,
                notEmpty=True,
                dataType=str
            )
            if code != 4100:
                raise Exception
            
            seach = seach.strip().lower()

            pipeline = [
                        {
                            '$lookup': {
                                'from': 'profile', 
                                'localField': '_id', 
                                'foreignField': 'accountId', 
                                'as': 'profileInfo'
                            }
                        }, {
                            '$unwind': '$profileInfo'
                        }, {
                            '$project': {
                                '_id':{
                                    '$toString': '$_id'
                                },
                                'firstName': 1, 
                                'lastName': 1, 
                                'role': 1, 
                                'designation': 1, 
                                'profileInfo.permissions': 1, 
                                'profileInfo.department': 1
                            }
                        }
                    ]
            
            if seach:
                pipeline.append({
                    '$match': {
                        '$or': [
                            {
                                'firstName': {
                                    '$regex': seach, 
                                    '$options': 'i'
                                }
                            }, {
                                'lastName': {
                                    '$regex': seach, 
                                    '$options': 'i'
                                }
                            }, {
                                'role': {
                                    '$regex': seach, 
                                    '$options': 'i'
                                }
                            }, {
                                'designation': {
                                    '$regex': seach, 
                                    '$options': 'i'
                                }
                            }
                        ]
                    }
                })

            AccountDetails = self.account.aggregate(pipeline)
            async for account in AccountDetails:
                account['permissions'] = account.get('profileInfo').get('permissions')
                # Remove the account[profileInfo][permissions]
                account.pop('profileInfo', None)
                result.append(account)

            
            if not len(result):
                code = 4100
                message = 'Data not found.'
                status = False
                raise Exception
            else:
                code = 2000
                message = 'Data found.'
                status = True


        except Exception as e:
            status = False
            if not message:
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                        str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))

        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(response)
            await self.finish()
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                    str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()    


    async def put(self):
        code = 4000
        status = False
        message = ''
        result = []

        try:
            try:
                # Converts the request body to JSON
                self.request.arguments = json.loads(self.request.body)
            except Exception as e:
                code = 4100
                message = 'Expected Request Type JSON.'
                raise

            search = self.request.arguments.get('search') 
            code, message = Validate.i(
                search,  
                'search',
                notNull=True,
                notEmpty=True,
                dataType=str
            )
            if code != 4100:  
                raise Exception

            search = search.strip().lower()

            permission = self.request.arguments.get('permission')
            code, message = Validate.i(
                permission,
                'permission',
                notNull=True,
                notEmpty=True,
                dataType=str
            )
            if code != 4100:  
                raise Exception
            
            permission = permission.strip().lower()

            try:
                accounts = self.account.aggregate(
                [
                    {
                    '$match': {
                        '$or': [
                            {
                                'firstName': {
                                    '$regex': search, 
                                    '$options': 'i'
                                }
                            }, {
                                'lastName': {
                                    '$regex': search, 
                                    '$options': 'i'
                                }
                            }, {
                                'role': {
                                    '$regex': search, 
                                    '$options': 'i'
                                }
                            }, {
                                'designation': {
                                    '$regex': search, 
                                    '$options': 'i'
                                }
                            }
                        ]
                    }
                }
                ]
            )
            except Exception as e:
                code = 5102
                message = 'Internal Error, Please Contact the Support Team.'
                raise Exception

            matchedAccounts = []
            async for account in accounts:
                matchedAccounts.append(account.get('_id'))

            if not matchedAccounts:
                code = 4100
                message = 'No account found.'
                status = False
                raise Exception

            try:
                for account in matchedAccounts:
                    previousPermissions = await self.profile.find_one(
                        {'accountId': account},
                        {'permissions': 1}
                    )

                    if permission not in previousPermissions.get('permissions', []):
                        await self.profile.update_one(
                            {'accountId': account},
                            {'$push': {'permissions': permission}}
                        )

            except Exception as e:
                code = 5101
                message = 'Internal Error, Please Contact the Support Team.'
                raise Exception
            
            code = 2000
            message = 'Permission added successfully.'
            status = True

        except Exception as e:
            status = False
            if not message:
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                    str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))

        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(response)
            await self.finish()
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
