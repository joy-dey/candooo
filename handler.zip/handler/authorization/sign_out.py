#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
"""
import sys
from abc import ABCMeta
from bson import ObjectId
from build_config import CONFIG
from lib.element_mixer import ElementMixer
from lib.xen_protocol import xenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log



@xenSecureV2
class SignOutHandler(ElementMixer, MongoMixin, metaclass=ABCMeta):

    SUPPORTED_METHODS = ('DELETE')

    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]
    
    entity = MongoMixin.userDb[
        CONFIG['database'][0]['table'][4]['name']
    ]

    signedSession = MongoMixin.userDb[
        CONFIG['database'][0]['table'][8]['name']
    ]

    token = MongoMixin.userDb[
        CONFIG['database'][0]['table'][25]['name']
    ]
    componentId = ObjectId('63d39988458b78fdf4cf6c0d')
    async def delete(self):
        status = False
        code = 4000
        result = []
        message = ''
        try:

            entityQ = self.entity.find(
                {
                    '_id': self.entityId
                },
                limit=1
            )
            entity = []
            async for r in entityQ:
                entity.append(r)

            if not len(entity):
                code = 4003
                message = 'You are not Authorized.'
                self.set_status(401)
                raise Exception

            tokQ = await self.token.find_one(
                {
                    'accountId' : self.accountId
                }
            )
            if not tokQ:
                status = True
                code = 2000
                message = 'Sign Out Successful.'
                self.set_status(200)
                
            else:
                delTok = await self.token.delete_one(
                        {
                            'accountId' : self.accountId
                        }
                    )
                if delTok.deleted_count > 0:
                    status = True
                    code = 2000
                    message = 'Sign Out Successful.'
                    self.set_status(200)
                else:
                    code = 4004
                    message = 'Sign Out Failed.'
                    raise Exception

        except Exception as e:
            status = False
            # self.set_status(400)
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(response)
            await self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            
            