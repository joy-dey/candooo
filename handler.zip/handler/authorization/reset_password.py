#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
"""
import json
import random
import sys
from datetime import datetime as dtime
import tornado.web
from abc import ABCMeta
from bson import ObjectId
from build_config import CONFIG
from lib.fernet_crypto import FN_ENCRYPT, FN_DECRYPT
from lib.jwt_filter import JWT_ENCODE
from lib.lib import Validate
from lib.xen_protocol import noXenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log
from util.time_util import timeNow
from lib.sms_gw import SmsGW


@noXenSecureV2
class ResetPasswordHandler(tornado.web.RequestHandler, MongoMixin, metaclass=ABCMeta):

    SUPPORTED_METHODS = ('POST', 'PUT')

    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]

    applications = MongoMixin.userDb[
        CONFIG['database'][0]['table'][1]['name']
    ]

    profile = MongoMixin.userDb[
        CONFIG['database'][0]['table'][2]['name']
    ]

    oneTimePassword = MongoMixin.userDb[
        CONFIG['database'][0]['table'][3]['name']
    ]

    phoneCountry = MongoMixin.userDb[
        CONFIG['database'][0]['table'][5]['name']
    ]

    entity = MongoMixin.userDb[
        CONFIG['database'][0]['table'][4]['name']
    ]

    smsGw = SmsGW()

    async def post(self):
        status = False
        code = 4000
        result = []
        message = ''
        try:
            try:
                # CONVERTS BODY INTO JSON
                self.request.arguments = json.loads(self.request.body.decode())
            except Exception as e:
                Log.i(e)
                code = 4100
                message = 'Expected Request Type JSON.'
                raise Exception

            entityQ = self.entity.find(
                {
                    '_id': self.entityId
                },
                limit=1
            )
            entity = []
            async for r in entityQ:
                entity.append(r)
            if not len(entity):
                code = 4003
                message = 'You are not Authorized.'
                self.set_status(401)
                raise Exception

            vUsername = self.request.arguments.get('username')
            code, message = Validate.i(
                vUsername,
                'username',
                notNull=True,
                dataType=str,
                minLength=6,
                maxLength=40
            )
            if code != 4100:
                raise Exception

            try:
                usernamePhone = int(vUsername)
            except:
                usernamePhone = None

            account = await self.account.find_one(
                {
                    '$or': [
                        {
                            'contact.0.value': vUsername,
                        },
                        {
                            'contact.1.phoneNumber': usernamePhone,
                        },
                        {
                            'contact.2.value': vUsername,
                        }
                    ]
                },
                {
                    '_id': 1,
                    'contact': 1
                }
            )
            if not account:
                message = 'Username does not exists.'
                code = 4135

            phoneNumber = account.get('contact')[1].get('phoneNumber')

            profile = await self.profile.find_one(
                {
                    'accountId': account.get('_id'),
                },
                {
                    '_id': 1,
                    'lastSignInRequest': 1,
                    'retrySignInRequest': 1,
                }
            )
            if not len(profile):
                try:
                    profileId = await self.profile.insert_one(
                        {
                            'active': False,
                            'locked': False,
                            'closed': False,
                            'time': timeNow(),
                            'accountId': account.get('_id'),
                            'entityId': self.entityId,
                            'status': 1,
                            'isSuperAdmin': False,
                            'retrySignInRequest': 0,
                            'data': []
                        }
                    )
                except:
                    code = 5810
                    message = 'Internal Error, Please Contact the Support Team.'
                    raise Exception
            else:
                mDeactive = True
                profileId = profile.get('_id')
                if profile.get('status') == 0:
                        mDeactive = False
            if mDeactive:
                Log.i('last_sign_in_time', profile.get('lastSignInRequest'))
                Log.i('retry_sign_in_request', profile.get('retrySignInRequest'))
                if profile.get('retrySignInRequest') != None:
                    retrySignInRequest = profile.get('retrySignInRequest')
                else:
                    retrySignInRequest = 1

                if profile.get('lastSignInRequest') != None and profile.get('lastSignInRequest') > self.time - 1200000000:
                    try:
                        checkrequest = profile.get('retrySignInRequest')
                        if checkrequest == None:
                            checkrequest = 0
                    except:
                        checkrequest = 0
                    if checkrequest > 3:
                        self.write(
                            {
                                'status': False,
                                'message': 'Too many attemps, please try again later.',
                                'code': 4040,
                                'result': []
                            }
                        )
                        self.finish()
                        return
                    else:
                        retrySignInRequest = retrySignInRequest + 1
                else:
                    retrySignInRequest = 1

                oOtp = await self.oneTimePassword.find_one(
                    {
                        'profileId': profileId,
                    },
                    {
                        '_id': 1
                    }
                )

                nOtp = random.randint(100000, 999999)

                rOtpQ = await self.oneTimePassword.delete_one({'profileId': profileId})

                if (rOtpQ.deleted_count >= 0):
                    a = await self.oneTimePassword.insert_one(
                        {
                            'createdAt': dtime.now(),
                            'profileId': profileId,
                            'value': nOtp,
                            'phoneNumber': usernamePhone,
                            'accountId': account.get('_id')
                        }
                    )
                    '''
                    Saving the Last Sign In Reqested Time
                    '''
                    updateResult = await self.profile.update_one(
                        {
                            '_id': profileId
                        },
                        {
                            '$set':
                            {
                                'lastSignInRequest': self.time,
                                'retrySignInRequest': retrySignInRequest
                            }
                        }
                    )
                    if updateResult.modified_count:
                        phoneNumber = '91' + str(phoneNumber)
                        Log.i('Phone Number: ', phoneNumber + ' OTP: ' + str(nOtp))
                        gwResp = self.smsGw.sendOtp(phoneNumber, nOtp)
                        if gwResp:
                            # if True:
                            #     Log.i('MSG91 Gateway Response', gwResp)
                            resetHash = FN_ENCRYPT(str(a.inserted_id), encode=True)
                            if type(resetHash) is bytes:
                                result.append(resetHash.decode())
                            else:
                                result.append(resetHash)
                            status = True
                            code = 2000
                            message = 'A 6-digit One Time Password has been sent to your Phone Number.'
                        else:
                            code = 5030
                            self.set_status(503)
                            message = 'Internal Error, Please Contact the Support Team.'
                            raise Exception
                    else:
                        code = 5020
                        self.set_status(503)
                        message = 'Internal Error, Please Contact the Support Team.'
                        raise Exception
                else:
                    code = 50101
                    self.set_status(503)
                    message = 'Internal Error, Please Contact the Support Team.'
            else:
                code = 4205
                message = 'Account is deactive, Contact to admin for activation'
                raise Exception
            
        except Exception as e:
            status = False
            # self.set_status(400)
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(response)
            await self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()

    async def put(self):
        status = False
        code = 4000
        result = []
        message = ''
        try:
            try:
                # CONVERTS BODY INTO JSON
                self.request.arguments = json.loads(self.request.body.decode())
            except Exception as e:
                Log.i(e)
                code = 4100
                message = 'Expected Request Type JSON.'
                raise Exception

            entityQ = self.entity.find(
                {
                    '_id': self.entityId
                },
                limit=1
            )
            entity = []
            async for r in entityQ:
                entity.append(r)

            if not len(entity):
                code = 4003
                message = 'You are not Authorized.'
                self.set_status(401)
                raise Exception

            vResetHash = self.request.arguments.get('resetHash')
            code, message = Validate.i(
                vResetHash,
                'resetHash',
                notEmpty=True,
                datatype=str,
                minLength=50
            )
            if code != 4100:
                raise Exception

            vResetHash = FN_DECRYPT(vResetHash)
            if type(vResetHash) is bytes:
                vResetHash = vResetHash.decode('utf-8')
            if not vResetHash:
                code = 4102
                message = 'Invalid Argument - [ resetHash ].'
                raise Exception

            vOtp = self.request.arguments.get('otp')
            code, message = Validate.i(
                vOtp,
                'otp',
                notNull=True,
                dataType=int,
                minNumber=100000,
                maxNumber=999999
            )
            if code != 4100:
                raise Exception

            vNewPassword = self.request.arguments.get('password')
            code, message = Validate.i(
                vNewPassword,
                'newPassword',
                notEmpty=True,
                dataType=str,
                minLength=8,
                maxLength=50
            )
            if code != 4100:
                raise Exception
            vNewPassword = vNewPassword.strip()

            # Encrypting password:
            vNewPassword = FN_ENCRYPT(vNewPassword, encode=True)

            otpFind = await self.oneTimePassword.find_one(
                {
                    '_id': ObjectId(vResetHash),
                    'value': vOtp
                },
                {
                    '_id': 0,
                    'accountId': 1,
                    'profileId': 1
                }
            )
            if not otpFind:
                message = 'Session has been expired, please try again.'
                code = 4383
                raise Exception

            accUpdate = await self.account.update_one(
                {
                    '_id': otpFind.get('accountId')
                },
                {
                    '$set': {
                        'contact.0.verified': True,
                        'privacy.0.value': vNewPassword
                    }
                }
            )
            if accUpdate.modified_count:
                await self.profile.update_one(
                    {
                        '_id': otpFind.get('profileId')
                    },
                    {
                        '$set': {
                            'active': True,
                            'lastSignInRequest': self.time
                        }
                    }
                )
                message = 'Your password has been updated.'
                code = 2000
                status = True
            else:
                message = 'Falied to update your password.'
                code = 4414

        except Exception as e:
            status = False
            # self.set_status(400)
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(response)
            await self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
