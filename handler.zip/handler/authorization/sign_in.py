#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
"""
import json
import sys
from datetime import datetime
import random

import tornado.web
from abc import ABCMeta
from bson import ObjectId
from build_config import CONFIG
from lib.fernet_crypto import FN_ENCRYPT, FN_DECRYPT
from lib.jwt_filter import JWT_ENCODE
from lib.lib import Validate
from lib.xen_protocol import noXenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log
from util.time_util import timeNow
from lib.sms_gw import SmsGW
from bson.json_util import dumps as bdumps



@noXenSecureV2
class SignInHandler(tornado.web.RequestHandler, MongoMixin, metaclass=ABCMeta):

    SUPPORTED_METHODS = ('POST', 'PUT')

    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]

    applications = MongoMixin.userDb[
        CONFIG['database'][0]['table'][1]['name']
    ]

    profile = MongoMixin.userDb[
        CONFIG['database'][0]['table'][2]['name']
    ]

    oneTimePassword = MongoMixin.userDb[
        CONFIG['database'][0]['table'][3]['name']
    ]

    phoneCountry = MongoMixin.userDb[
        CONFIG['database'][0]['table'][5]['name']
    ]

    entity = MongoMixin.userDb[
        CONFIG['database'][0]['table'][4]['name']
    ]

    signedSession = MongoMixin.userDb[
        CONFIG['database'][0]['table'][8]['name']
    ]

    smsGw = SmsGW()
    
    async def post(self):
        status = False
        code = 4000
        result = []
        message = ''
        try:
            try:
                # CONVERTS BODY INTO JSON
                self.request.arguments = json.loads(self.request.body.decode())
            except Exception as e:
                Log.i(e)
                code = 4100
                message = 'Expected Request Type JSON.'
                raise Exception

            entityQ = self.entity.find(
                {
                    '_id': self.entityId
                },
                limit=1
            )
            entity = []
            async for r in entityQ:
                entity.append(r)

            if not len(entity):
                code = 4003
                message = 'You are not Authorized.'
                self.set_status(401)
                raise Exception


            method = self.request.arguments.get('method')
            if method == None:
                code = 4130
                message = 'Missing Argument - [ method ].'
                raise Exception
            
            elif method == 1:
                try:
                    phoneNumber = self.request.arguments.get('phoneNumber')
                    if phoneNumber == None:
                        code = 4241
                        message = 'Missing Argument - [ phoneNumber ].'
                        raise Exception
                    else:
                        phoneNumber = int(phoneNumber)
                    countryCode = self.request.arguments.get('countryCode')
                    if countryCode == None:
                        code = 4251
                        message = 'Missing Argument - [ countryCode ].'
                        raise Exception
                    else:
                        countryCode = int(countryCode)
                    countryQ = self.phoneCountry.find(
                        {
                            'code': countryCode
                        },
                        limit=1
                    )
                    country = []
                    async for r in countryQ:
                        country.append(r)
            
                    if not len(country):
                        code = 4242
                        message = 'Invalid Country Code.'
                        raise Exception
                    if len(str(phoneNumber)) != country[0]['telMaxLength']:
                        code = 4252
                        message = 'Invalid Phone Number.'
                        raise Exception('phoneNumber')
                    else:
                        phoneNumber = int(str(countryCode) + str(phoneNumber))
                except Exception as e:
                    if not len(message):
                        code = 4210
                        template = "Exception: {0}. Argument: {1!r}"
                        message = template.format(type(e).__name__, e.args)
                    raise Exception
                account = await self.account.find_one(
                    {
                        'contact.1.value': phoneNumber
                    },
                    {
                        '_id': 1
                    },
                    limit=1
                )
                if account:
                    '''
                        Searching for profile
                        Blocked for 20 sec ( in microseconds )
                    '''
                    profile = await self.profile.find_one(
                        {
                            'accountId': account.get('_id')
                        },
                        {
                            '_id': 1,
                            'lastSignInRequest': 1,
                            'retrySignInRequest': 1,
                            'status' : 1,
                            'applicationId': 1
                        },
                        limit=1
                    )
            
                    if not profile:
                        code = 4210
                        message = 'Profile not found.'
                        raise Exception
                    mDeactive = True   
                    profileId = profile.get('_id')
                    if profile.get('status') == 0:
                        mDeactive = False
                    if mDeactive:
                    # Sign in blocked for 20min based on phone number
            
                        Log.i('last_sign_in_time', profile.get('lastSignInRequest'))
                        Log.i('retry_sign_in_request', profile.get('retrySignInRequest'))
                
                        if profile.get('retrySignInRequest') != None:
                            retrySignInRequest = profile.get('retrySignInRequest')
                        else:
                            retrySignInRequest = 1
                
                        if profile.get('lastSignInRequest') != None and profile.get(
                                'lastSignInRequest') > self.time - 1200000000:
                
                            try:
                                checkrequest = profile.get('retrySignInRequest')
                                if checkrequest == None:
                                    checkrequest = 0
                            except:
                                checkrequest = 0
                
                            if checkrequest > 2:
                
                                self.write(
                                    {
                                        'status': False,
                                        'message': 'Too many attemps, please try again later.',
                                        'code': 4040,
                                        'result': []
                                    }
                                )
                                self.finish()
                                return
                            else:
                                retrySignInRequest = retrySignInRequest + 1
                        else:
                            retrySignInRequest = 1
                
                        oOtpQ = self.oneTimePassword.find(
                            {
                                'profileId': profileId,
                            },
                            {
                                '_id': 1
                            },
                            limit=1
                        )
                        oOtp = []
                        async for r in oOtpQ:
                            oOtp.append(r)
                
                        nOtp = random.randint(100000, 999999)
                
                        rOtpQ = await self.oneTimePassword.delete_one({'profileId': profileId})
                        if (rOtpQ.deleted_count >= 0):
                            a = await self.oneTimePassword.insert_one(
                                {
                                    'createdAt': datetime.now(),
                                    'profileId': profileId,
                                    'value': nOtp,
                                    'phoneNumber': phoneNumber,
                                }
                            )
                
                            '''
                                Saving the Last Sign In Reqested Time
                            '''
                
                            updateResult = await self.profile.update_one(
                                {
                                    '_id': profileId
                                },
                                {
                                    '$set':
                                        {
                                            'lastSignInRequest': self.time,
                                            'retrySignInRequest': retrySignInRequest
                                        }
                                }
                            )
                            if updateResult.modified_count:
                                Log.i('Phone Number: ', str(phoneNumber) + ' OTP: ' + str(nOtp))
                                # TODO: this need to be chaged to http client
                                gwResp = self.smsGw.sendOtp(str(phoneNumber), nOtp)
                                if gwResp:
                                    otpHash = FN_ENCRYPT(str(a.inserted_id), encode=True)
                                    if type(otpHash) is bytes:
                                        result.append(otpHash.decode())
                                    else:
                                        result.append(otpHash)
                                    status = True
                                    code = 2000
                                    message = 'A 6-digit One Time Password has been sent to your Phone Number.'
                                else:
                                    code = 5030
                                    message = 'Internal Error, Please Contact the Support Team.'
                                    raise Exception
                            else:
                                code = 5020
                                message = 'Internal Error, Please Contact the Support Team.'
                                raise Exception
                        else:
                            code = 50101
                            message = 'Internal Error, Please Contact the Support Team.'
                            raise Exception
                    else:
                        code = 4205
                        message = 'Account is deactive, Contact to admin for activation'
                        raise Exception
                else:
                    code = 4210
                    message = 'Phone Number is not registered.'
                    raise Exception
                    
            elif method == 2:
                username = self.request.arguments.get('username')
                code, message = Validate.i(
                    username,
                    'Username',
                    dataType=str,
                    maxLength=40,
                    minLength=6
                )
                if code != 4100:
                    raise Exception
                else:
                    username = str(username).replace(' ', '')

                rawPassword = self.request.arguments.get('password')
                code, message = Validate.i(
                    rawPassword,
                    'Password',
                    dataType=str,
                    maxLength=120
                )
                if code != 4100:
                    raise Exception

                try:
                    usernamePhone = int(username)
                except:
                    usernamePhone = 0

                try:
                    usernamePhone = int(username)
                    match = {
                            '$or': [
                                {
                                    'contact.0.value': username,
                                },
                                {
                                    'contact.1.phoneNumber': usernamePhone,
                                }
                            ]
                        }
                except:
                    usernamePhone = None
                    match = {
                                'contact.2.value': username,
                            }
                try:
                    account = await self.account.find_one(
                        match,
                        {
                            '_id': 1,
                            'privacy': {
                                'value': 1
                            },
                            'status' : 1,
                            'designation': 1
                        }
                    )

                    if account:
                        agent = self.request.headers.get('User-Agent')
                        if account.get('designation') == 'Architect' and 'Dart' in agent:
                            code = 3990
                            message = 'You are not Authorized.'
                            raise Exception
                            
                        enPassword = FN_DECRYPT(account['privacy'][0]['value'])
                        if type(enPassword) is bytes:
                            enPassword = enPassword.decode()
                        if enPassword == rawPassword:

                            '''
                                Saving the Last Sign In Requested Time
                            '''
                            profile = []
                            profileQ = self.profile.find(
                                {
                                    'accountId': account['_id'],
                                    'entityId': self.entityId
                                },
                                {
                                    '_id': 1,
                                    'entityId': 1,
                                    'lastSignInRequest': 1,
                                    'status': 1,
                                    'permissions': 1,
                                    'applicationId': 1
                                }
                            )
                            async for p in profileQ:
                                profile.append(p)

                            Log.i("profiles", len(profile))
                            mDeactive = True
                            mPermissions = None
                            if not len(profile):
                                message = 'No profiles found.'
                                code = 9292
                                raise Exception
                            else:
                                if len(profile):
                                    for p in profile:
                                        if p.get('status') == 0:
                                            mDeactive = False
                                        mPermissions = p.get('permissions')
                                if mDeactive:
                                    self.profileId = profile[0]['_id']
                                    profileU = await self.profile.update_one(
                                        {
                                            '_id': self.profileId
                                        },
                                        {
                                            '$set':
                                                {
                                                    'lastSignInRequest': self.time
                                                }
                                        }
                                    )

                                    createSession = await self.signedSession.insert_one(
                                        {
                                            'createdOn': datetime.now(),
                                            'accountId': account['_id'],
                                            'profileId': profile[0]['_id'],
                                            'entityId': entity[0]['_id'],
                                            'applicationId': profile[0]['applicationId'],
                                            'createdAt': timeNow(),
                                            'createdBy': profile[0]['_id'],
                                            'clientHeaders': self.request.headers
                                        },
                                    )
                                    if createSession.inserted_id is not None:
                                        xToken = FN_ENCRYPT(str(createSession.inserted_id), encode=True)
                                        if type(xToken) is bytes:
                                            xToken = xToken.decode()
                                        result.append(xToken)
                                        result.append(mPermissions)
                                        status = True
                                        code = 2000
                                        message = 'Sign In Successful, Welcome Back to {}.'.format(
                                            CONFIG['name']
                                        )
                                    else:
                                        code = 5020
                                        message = 'Internal Error, Please Contact the Support Team.'
                                        raise Exception
                                
                                else:
                                    code = 4205
                                    message = 'Account is deactive, Contact to admin for activation'
                        
                        else:
                            code = 4311
                            message = 'Wrong Username or Password.'
                    else:
                        code = 4700
                        message = 'Account not found.'
                        
                except Exception as e:
                    if not len(message):
                        exc_type, exc_obj, exc_tb = sys.exc_info()
                        fname = exc_tb.tb_frame.f_code.co_filename
                        Log.d('EX2',
                            'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
                        code = 5210
                        message = 'Internal Error, Please Contact the Support Team.'
                        # TODO: for sign in with email
                        raise Exception
            else:
                code = 4110
                message = 'Sign In method not supported.'
                
        except Exception as e:
            status = False
            # self.set_status(400)
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(response)
            await self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            
            
    async def put(self):
        status = False
        code = 4000
        result = []
        message = ''
        try:
            try:
                # CONVERTS BODY INTO JSON
                self.request.arguments = json.loads(self.request.body.decode())
            except:
                code = 4100
                message = 'Expected Request Type JSON.'
                raise Exception
            
            entityQ = self.entity.find(
                {
                    '_id': self.entityId
                },
                limit=1
            )
            entity = []
            async for r in entityQ:
                entity.append(r)

            if not len(entity):
                code = 4003
                message = 'You are not Authorized.'
                self.set_status(401)
                raise Exception

            method = self.request.arguments.get('method')
            if method == None:
                code = 4130
                message = 'Missing Argument - [ method ].'
                raise Exception
            elif method == 1:
                try:
                    phoneNumber = self.request.arguments.get('phoneNumber')
                    if phoneNumber == None:
                        code = 4241
                        message = 'Missing Argument - [ phoneNumber ].'
                        raise Exception
                    else:
                        phoneNumber = int(phoneNumber)
                    countryCode = self.request.arguments.get('countryCode')
                    if countryCode == None:
                        code = 4251
                        message = 'Missing Argument - [ countryCode ].'
                        raise Exception
                    else:
                        countryCode = int(countryCode)
                    countryQ = self.phoneCountry.find(
                        {
                            'code': countryCode
                        },
                        limit=1
                    )
                    country = []
                    async for r in countryQ:
                        country.append(r)
            
                    if not len(country):
                        code = 4242
                        message = 'Invalid Country Code.'
                        raise Exception
                    if len(str(phoneNumber)) != country[0]['telMaxLength']:
                        code = 4252
                        message = 'Invalid Phone Number.'
                        raise Exception('phoneNumber')
                    else:
                        phoneNumber = int(str(countryCode) + str(phoneNumber))
                except Exception as e:
                    if not len(message):
                        code = 4210
                        template = "Exception: {0}. Argument: {1!r}"
                        message = template.format(type(e).__name__, e.args)
                    raise Exception
                mOtp = self.request.arguments.get('otp')
                code, message = Validate.i(
                    mOtp,
                    'otp',
                    notNull=True,
                    notEmpty=True,
                    dataType=int
                )
                if code != 4100:
                    raise Exception
                mhash = self.request.arguments.get('hash')
                code, message = Validate.i(
                    mhash,
                    'hash',
                    notNull=True,
                    notEmpty=True,
                    dataType=str
                )
                if code != 4100:
                    raise Exception
                mhash = FN_DECRYPT(mhash)
                if type(mhash) is bytes:
                    mhash = mhash.decode('utf-8')
                try:
                    mhash = ObjectId(mhash)
                except:
                    message = 'Invalid Argument - [ hash ]'
                    code = 4888
                    raise Exception
                account = await self.account.find_one(
                    {
                        'contact.1.value': phoneNumber
                    },
                    {
                        '_id': 1
                    }
                )
                if account:
                    findOtp = await self.oneTimePassword.find_one(
                        {
                            '_id': mhash,
                            'value': mOtp
                        }
                    )
                    profileId = findOtp.get('profileId')
                    if findOtp:
                        profileQ = await self.profile.find_one(
                            {
                                '_id': profileId
                            },
                            {
                                'applicationId' : 1
                            }
                        )
                        print("profileQ", profileQ)
                        await self.oneTimePassword.delete_one(
                            {
                                '_id': mhash,
                                'otp': mOtp
                            }
                        )
                        createSession = await self.signedSession.insert_one(
                            {
                                'createdOn': datetime.now(),
                                'accountId': account['_id'],
                                'profileId': profileId,
                                'entityId': entity[0]['_id'],
                                'applicationId': profileQ['applicationId'],
                                'createdAt': timeNow(),
                                'createdBy': findOtp.get('_id'),
                                'clientHeaders': self.request.headers
                            },
                        )
                        if createSession.inserted_id:
                            xToken = FN_ENCRYPT(str(createSession.inserted_id), encode=True)
                            if type(xToken) is bytes:
                                xToken = xToken.decode()
                            result.append(xToken)
                            status = True
                            code = 2000
                            message = 'Sign In Successful, Welcome Back to {}.'.format(
                                CONFIG['name']
                            )
                    else:
                        code = 4935
                        message = 'Invalid Credentials.'
                        raise Exception
                else:
                    code = 4210
                    message = 'Phone Number is not registered.'         
            else:
                code = 4110
                message = 'Sign In method not supported.'
                raise Exception
        except Exception as e:
            status = False
            # self.set_status(400)
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(json.loads(bdumps(response)))
            await self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(json.loads(bdumps(response)))
            await self.finish()

