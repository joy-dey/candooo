import calendar
import datetime
import json
import os
import re
import sys
import mimetypes
import requests
import pandas as pd
import io

from abc import ABCMeta
from bson import ObjectId
from build_config import CONFIG
from lib.lib import Validate
from lib.xen_protocol import xenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log
from util.time_util import timeNow
from bson.json_util import dumps as bdumps
from lib.element_mixer import ElementMixer
from util.file_util import FileUtil


@xenSecureV2
class DashboardDateFilterHandler(ElementMixer,  MongoMixin, metaclass=ABCMeta):

    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]

    loanApplication = MongoMixin.userDb[
        CONFIG['database'][0]['table'][13]['name']
    ]

    district = MongoMixin.userDb[
        CONFIG['database'][0]['table'][14]['name']
    ]

    componentId = ObjectId('63d38614458b78fdf4cf6bfa')

    async def get(self):
        code = 4000
        status = False
        message = ''
        result = []

        try:
            mAccountInfo = await self.account.find_one(
                {
                    '_id': self.accountId
                }
            )
            if not mAccountInfo:
                code = 4057
                message = 'Account Not Found'
                raise Exception

            pipeline = [
                    {
                        '$project': {
                            '_id': {
                                '$toString': '$_id'
                            },
                            'onlineSubmissionDate': '$data.onlineSubmissionDate',
                        }
                    },
                    {
                        '$sort': {
                            '_id': 1
                        }
                    }
                ]
                
            mFindRecord = self.loanApplication.aggregate(pipeline)

            dates = []
            yearMonth = []
            async for i in mFindRecord:
                date = i['onlineSubmissionDate']
                dates.append(date)

            for date in dates:
                vDate = str(datetime.datetime.fromtimestamp(date/1000000).strftime('%Y-%m'))
                yearMonth.append(datetime.datetime.strptime(vDate, '%Y-%m'))
            
            yearQ = {}
            for year in yearMonth:
                month_name = calendar.month_name[year.month]
                if year.year in yearQ:
                    if month_name not in yearQ[year.year]:
                        yearQ[year.year].append(month_name)
                else:
                    yearQ[year.year] = [month_name]

            result.append(yearQ)
            if len(result):
                code = 2000
                status = True
                message = 'Dates Found.'
            else:
                code = 4069
                message = 'Data not Found'
                raise Exception

        except Exception as e:
            status = False
            if not len(message):
                # self.set_status(503)
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(bdumps(response))
            await self.finish()
            return

        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            # self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return