import json
import os
import re
import sys
import mimetypes
from datetime import datetime

import requests
import pandas as pd
import io

from abc import ABCMeta
from bson import ObjectId
from build_config import CONFIG
from lib.lib import Validate
from lib.xen_protocol import xenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log
from util.time_util import timeNow
from bson.json_util import dumps as bdumps
from lib.element_mixer import ElementMixer
from util.file_util import FileUtil


@xenSecureV2
class StatusWiseLoanApplicationHandler(ElementMixer, MongoMixin, metaclass=ABCMeta):
    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]

    loanApplication = MongoMixin.userDb[
        CONFIG['database'][0]['table'][13]['name']
    ]

    loanAppStatusLog = MongoMixin.userDb[
        CONFIG['database'][0]['table'][18]['name']
    ]

    auditInfo = MongoMixin.userDb[
        CONFIG['database'][0]['table'][19]['name']
    ]

    componentId = ObjectId('63d39988458b78fdf4cf6c0d')

    async def get(self):
        code = 4000
        status = False
        message = ''
        result = []

        try:

            try:
                vMethod = int(self.get_argument('method'))
                code, message = Validate.i(
                    vMethod,
                    'method',
                    dataType=int,
                    notEmpty=True,
                    enums=[0, 1]
                )
                if code != 4100:
                    raise Exception
            except:
                code = 4059
                message = 'Invalid argument - [ method ]'
                raise Exception

            try:
                year = self.get_argument('year')
                if year:
                    code, message = Validate.i(
                        year,
                        'Year',
                        datType=str,
                        notEmpty=True
                    )
                    if code != 4100:
                        raise Exception
                else:
                    raise Exception
            except:
                year = None

            if year:
                try:
                    sYear = year.split('-')[0]
                    code, message = Validate.i(
                        sYear,
                        'Start Year',
                        datType=int,
                        notEmpty=True
                    )
                    if code != 4100:
                        raise Exception
                except:
                    code = 7656
                    message = 'Start Year Required'
                    raise Exception

                try:
                    eYear = year.split('-')[1]
                    code, message = Validate.i(
                        eYear,
                        'End Year',
                        datType=int,
                        notEmpty=True
                    )
                    if code != 4100:
                        raise Exception
                except:
                    code = 7657
                    message = 'End Year Required'
                    raise Exception

                sYear = datetime(int(sYear), 4, 1, 0, 0, 0)
                sYear = sYear.strftime("%Y-%m-%d")

                eYear = datetime(int(eYear), 3, 31, 23, 59, 59)
                eYear = eYear.strftime("%Y-%m-%d")

                sYear = int(datetime.strptime(sYear, "%Y-%m-%d").timestamp()) * 1000000
                eYear = int(datetime.strptime(eYear, "%Y-%m-%d").timestamp()) * 1000000

                if sYear > eYear:
                    code = 5643
                    message = 'End Year Should Be Greater Than Start Year'
                    raise Exception

            mAccountInfo = await self.account.find_one(
                {
                    '_id': self.accountId
                }
            )
            if not mAccountInfo:
                code = 4057
                message = 'Account Not Found'
                raise Exception

            mDistrictsAllotted = None
            if mAccountInfo.get('role') == 'Auditor':
                mDistrictsAllotted = mAccountInfo.get('districts')

            xTotalDisbursedAmount = 0
            if vMethod == 0:
                pipeline = [
                    {
                        '$match': {
                            'data.onlineSubmissionDate': {'$gte': sYear, '$lte': eYear} if year else {'$exists': True},
                            'data.unitDistrict': {'$in': mDistrictsAllotted} if mDistrictsAllotted else {'$exists': True}
                        }
                    },
                    {
                        '$group': {
                            '_id': None,
                            'totalApplications': {
                                '$sum': 1
                            }
                        }
                    },
                    {
                        '$addFields': {
                            'status': '$_id'
                        }
                    },
                    {
                        '$project': {
                            '_id': 0,
                            'status': 'Total Applicants',
                            'totalApplications': 1
                        }
                    }
                ]

                # if mDistrictsAllotted:
                #     pipeline.insert(0, {
                #         '$match': {
                #             'data.unitDistrict': {
                #                 '$in': mDistrictsAllotted
                #             }
                #         }
                #     })
                mFindRecord = self.loanApplication.aggregate(pipeline)
                async for i in mFindRecord:
                    result.append(i)
            elif vMethod == 1:
                pipeline = [
                    {
                        '$match': {
                            'data.onlineSubmissionDate': {'$gte': sYear, '$lte': eYear} if year else {'$exists': True}
                        }
                    },
                    {
                        '$group': {
                            '_id': '$data.currentStatus',
                            'totalApplications': {'$sum': 1},
                            'totalSanctionedAmount': {'$sum': '$data.totalSanctionedAmountByBank'}
                        }
                    },
                    {
                        '$addFields': {
                            'status': '$_id'
                        }
                    },
                    {
                        '$project': {
                            '_id': 0,
                            'status': 1,
                            'totalApplications': 1,
                            'totalSanctionedAmount': 1,
                        }
                    }
                ]

                if mDistrictsAllotted:
                    pipeline.insert(0, {
                        '$match': {
                            'data.unitDistrict': {
                                '$in': mDistrictsAllotted
                            }
                        }
                    })

                rejected_pipe = [
                    {
                        '$match': {
                            'data.onlineSubmissionDate': {'$gte': sYear, '$lte': eYear} if year else {'$exists': True}
                        }
                    },
                    {
                        '$match': {
                            'data.currentStatus': 'Rejected/Returned'
                        }
                    },
                    {
                        '$group': {
                            '_id': '$data.rejectedByBank',
                            'totalApplicants': {'$sum': 1}
                        }
                    }
                ]
                if mDistrictsAllotted:
                    rejected_pipe.insert(0, {
                        '$match': {
                            'data.unitDistrict': {
                                '$in': mDistrictsAllotted
                            }
                        }
                    })

                submission_pipe = [
                    {
                        '$match': {
                            'data.onlineSubmissionDate': {'$gte': sYear, '$lte': eYear} if year else {'$exists': True}
                        }
                    },
                    {
                        '$match': {
                            'data.currentStatus': 'Online Submitted'
                        }
                    },
                ]
                underProcessAtBankQ = [
                    {
                        '$match': {
                            'data.onlineSubmissionDate': {'$gte': sYear, '$lte': eYear} if year else {'$exists': True}
                        }
                    },
                    {
                        '$match': {
                            'data.currentStatus': 'Under Process (At Bank)'
                        }
                    }
                ]

                if mDistrictsAllotted:
                    underProcessAtBankQ.insert(0, {
                        '$match': {
                            'data.unitDistrict': {
                                '$in': mDistrictsAllotted
                            }
                        }
                    })
                underProcessAtAgencyQ = [
                    {
                        '$match': {
                            'data.onlineSubmissionDate': {'$gte': sYear, '$lte': eYear} if year else {'$exists': True}
                        }
                    },
                    {
                        '$match': {
                            'data.currentStatus': 'Under Process (At Agency)'
                        }
                    }
                ]

                if mDistrictsAllotted:
                    underProcessAtAgencyQ.insert(0, {
                        '$match': {
                            'data.unitDistrict': {
                                '$in': mDistrictsAllotted
                            }
                        }
                    })

                disbursement_pipe = [
                    {
                        '$lookup': {
                            'from': 'loanApplication',
                            'localField': 'loanApplicationId',
                            'foreignField': '_id',
                            'as': 'loanAppInfo'
                        }
                    },
                    {
                        '$match': {
                            'loanAppInfo.data.onlineSubmissionDate': {'$gte': sYear, '$lte': eYear} if year else {
                                '$exists': True},
                            'loanAppInfo.data.unitDistrict': {'$in': mDistrictsAllotted} if mDistrictsAllotted else {'$exists': True}
                        }
                    },
                    {
                        '$unwind': '$disbursed'
                    },
                    {
                        '$unwind': '$disbursed.disbursedInfo'
                    },
                    {
                        '$group': {
                            '_id': None,
                            'totalDisbursedAmount': {'$sum': '$disbursed.disbursedInfo.amount'}
                        }
                    },
                    {
                        '$project': {
                            '_id': 0,
                            'totalDisbursedAmount': 1
                        }
                    }
                ]
                results = await self.loanApplication.aggregate(pipeline).to_list(length=None)

                # dateToBankCount = 0
                # async for i in self.loanApplication.aggregate(submission_pipe):
                #     onlineSub = i.get('onlineSubmissionDate')
                #     forwardDate = i.get('forwardingDateToBank', None)
                #     if onlineSub and (not forwardDate or forwardDate == '-'):
                #         dateToBankCount += 1

                underProcessAtBankCount = 0
                async for i in self.loanApplication.aggregate(underProcessAtBankQ):
                    underProcessAtBankCount += 1
                
                underProcessAtAgencyCount = 0
                async for i in self.loanApplication.aggregate(underProcessAtAgencyQ):
                    underProcessAtAgencyCount += 1

                xRejectedByBank = 0
                xRejectedByDIC = 0
                async for i in self.loanApplication.aggregate(rejected_pipe):
                    if i.get('_id'):
                        xRejectedByBank = i.get('totalApplicants')
                    else:
                        xRejectedByDIC = i.get('totalApplicants')

                xTotalDisbursedAmount = 0
                async for i in self.loanAppStatusLog.aggregate(disbursement_pipe):
                    xTotalDisbursedAmount = i.get('totalDisbursedAmount')

                pipelineC = [
                    {
                        '$lookup': {
                            'from': self.loanApplication.name,
                            'localField': 'loanId',
                            'foreignField': '_id',
                            'as': 'loanAppInfo'
                        }
                    },
                    {
                        '$match': {
                            'constructionStatus': 'complete',
                            'loanAppInfo.data.onlineSubmissionDate': {
                                '$exists': True
                            },
                            'loanAppInfo.data.currentStatus':{'$in': ['Loan Sanctioned', 'Disbursed']},
                        }
                    },
                    {
                        '$unwind': '$loanAppInfo'
                    },
                    {
                        '$match': {
                            'loanAppInfo.data.onlineSubmissionDate': (
                                {'$gte': sYear, '$lte': eYear} if year else {'$exists': True}
                            )
                        }
                    },
                    {
                        '$count': 'count'
                    }
                ]
                
                if mDistrictsAllotted:
                    pipelineC.insert(1, {
                        '$match': {
                            'loanAppInfo.data.unitDistrict': {
                                '$in': mDistrictsAllotted
                            }
                        }
                    })

                count = 0
                async for i in self.auditInfo.aggregate(pipelineC):
                    count = i.get('count', 0)


                pipelineI = [
                    {
                        '$lookup': {
                            'from': self.loanApplication.name,
                            'localField': 'loanId',
                            'foreignField': '_id',
                            'as': 'loanAppInfo'
                        }
                    },
                    {
                        '$match': {
                            'constructionStatus': 'Incomplete',
                            'loanAppInfo.data.onlineSubmissionDate': {
                                '$exists': True
                            },
                            'loanAppInfo.data.currentStatus':{'$in': ['Loan Sanctioned', 'Disbursed']},
                        }
                    },
                    {
                        '$unwind': '$loanAppInfo'
                    },
                    {
                        '$match': {
                            'loanAppInfo.data.onlineSubmissionDate': (
                                {'$gte': sYear, '$lte': eYear} if year else {'$exists': True}
                            )
                        }
                    },
                    {
                        '$count': 'count'
                    }
                ]
                
                inCompleteCount = 0
                async for i in self.auditInfo.aggregate(pipelineI):
                    inCompleteCount = i.get('count', 0)

                result = [
                    {
                        'status': 'Rejected By Bank',
                        'totalApplications': xRejectedByBank
                    },
                    {
                        'status': 'Rejected By DIC',
                        'totalApplications': xRejectedByDIC
                    },
                    {
                        'status': 'Under Process (At Agency)',
                        'totalApplications': underProcessAtAgencyCount
                    },
                    {
                        'status': 'Under Process (At Bank)',
                        'totalApplications': underProcessAtBankCount
                    },
                    {
                        'status': 'Loan Sanctioned',
                        'totalApplications': 0
                    },
                    {
                        'status': 'Disbursed',
                        'totalApplications': 0,
                        'totalDisbursedAmount': xTotalDisbursedAmount
                    },
                    {
                        'status': 'Copayment',
                        'totalApplications': 0
                    },
                    {
                        'status': 'Onhold/Discontinued',
                        'totalApplications': 0
                    },
                    {
                        'status': 'Homestays Completed',
                        'totalApplications': count
                    },
                    {
                        'status': 'Homestays Pending',
                        'totalApplications': inCompleteCount
                    }
                ]

                xTotalSanctionedAmount = 0
                xLoanSanctionedCount = 0
                for i in results:
                    if i.get('status') in ['Disbursed', 'Loan Sanctioned']:
                        xLoanSanctionedCount += i.get('totalApplications', 0)
                        xTotalSanctionedAmount += i.get('totalSanctionedAmount', 0)

                    for v in result:
                        if v.get('status') == i.get('status'):
                            v['totalApplications'] = i.get('totalApplications')
                            if v.get('status') == 'Disbursed':
                                v['totalDisbursedAmount'] = xTotalDisbursedAmount
                            if v.get('status') == 'Loan Sanctioned':
                                v['totalSanctionedAmount'] = xTotalSanctionedAmount

                for v in result:
                    if v.get('status') == 'Loan Sanctioned':
                        v['totalApplications'] = xLoanSanctionedCount
                        v['totalSanctionedAmount'] = xTotalSanctionedAmount
                

            if len(result):
                code = 2000
                status = True
            else:
                code = 4108
                message = 'Data not Found'
                raise Exception
        except Exception as e:
            status = False
            if not len(message):
                # self.set_status(503)
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(bdumps(response))
            await self.finish()
            return

        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            # self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return
