import datetime
import json
import os
import re
import sys
import mimetypes
import requests
import io

from abc import ABCMeta
from bson import ObjectId
from build_config import CONFIG
from lib.lib import Validate
from lib.xen_protocol import xenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log
from util.time_util import timeNow
from bson.json_util import dumps as bdumps
from lib.element_mixer import ElementMixer
from util.file_util import FileUtil


@xenSecureV2
class PerformanceWiseHomestayHandler(ElementMixer,  MongoMixin, metaclass=ABCMeta):

    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]

    auditInfo = MongoMixin.userDb[
        CONFIG['database'][0]['table'][19]['name']
    ]

    loanStatusLog = MongoMixin.userDb[
        CONFIG['database'][0]['table'][18]['name']
    ]

    loanApplication = MongoMixin.userDb[
        CONFIG['database'][0]['table'][13]['name']
    ]

    componentId = ObjectId('63d39988458b78fdf4cf6c0d')

    async def get(self):
        code = 4000
        status = False
        message = ''
        result = []

        try:
            try:
                year = self.get_argument('year')
                if year:
                    code, message = Validate.i(
                        year,
                        'Year',
                        datType=str,
                        notEmpty=True
                    )
                    if code != 4100:
                        raise Exception
                else:
                    raise Exception
            except:
                year = None

            if year:
                try:
                    sYear = year.split('-')[0]
                    code, message = Validate.i(
                        sYear,
                        'Start Year',
                        datType=int,
                        notEmpty=True
                    )
                    if code != 4100:
                        raise Exception
                except:
                    code = 7656
                    message = 'Start Year Required'
                    raise Exception

                try:
                    eYear = year.split('-')[1]
                    code, message = Validate.i(
                        eYear,
                        'End Year',
                        datType=int,
                        notEmpty=True
                    )
                    if code != 4100:
                        raise Exception
                except:
                    code = 7657
                    message = 'End Year Required'
                    raise Exception

                sYear = datetime.datetime(int(sYear), 4, 1, 0, 0, 0)
                sYear = sYear.strftime("%Y-%m-%d")

                eYear = datetime.datetime(int(eYear), 3, 31, 23, 59, 59)
                eYear = eYear.strftime("%Y-%m-%d")

                sYear = int(datetime.datetime.strptime(sYear, "%Y-%m-%d").timestamp()) * 1000000
                eYear = int(datetime.datetime.strptime(eYear, "%Y-%m-%d").timestamp()) * 1000000

                if sYear > eYear:
                    code = 5643
                    message = 'End Year Should Be Greater Than Start Year'
                    raise Exception

            mAccountInfo = await self.account.find_one(
                {
                    '_id': self.accountId
                }
            )
            if not mAccountInfo:
                code = 4057
                message = 'Account Not Found'
                raise Exception
            
            mDistrictsAllotted = None
            if mAccountInfo.get('role') == 'Auditor':
                mDistrictsAllotted = mAccountInfo.get('districts')
            
            pipeline = [
                {
                        '$match': {
                            'data.currentStatus': 'Disbursed'
                        }
                },
                {
                    '$match': {
                        'data.onlineSubmissionDate': {'$gte': sYear, '$lte': eYear} if year else {'$exists': True}
                    }
                },
                    {
                        '$lookup': {
                            'from': self.auditInfo.name,
                            'localField': '_id',
                            'foreignField': 'loanId',
                            'as': 'auditInfo',
                            'pipeline': [
                                {
                                    '$addFields': {
                                        'stage1': '$auditData.stage1.stageStatus',
                                        'stage2': '$auditData.stage2.stageStatus',
                                        'stage3': '$auditData.stage3.stageStatus',
                                        'stage4': '$auditData.stage4.stageStatus',
                                        'stage5': '$auditData.stage5.stageStatus',
                                        'stage6': '$auditData.stage6.stageStatus',
                                    }
                                },
                                {
                                    '$addFields': {
                                        'stageOne': {
                                            '$cond': {
                                                'if': {
                                                    '$eq': ['$stage1', 'complete']
                                                },
                                                'then': 1,
                                                'else': 0
                                            }
                                        },
                                        'stageTwo': {
                                            '$cond': {
                                                'if': {
                                                    '$eq': ['$stage2', 'complete']
                                                },
                                                'then': 1,
                                                'else': 0
                                            }
                                        },
                                        'stageThree': {
                                            '$cond': {
                                                'if': {
                                                    '$eq': ['$stage3', 'complete']
                                                },
                                                'then': 1,
                                                'else': 0
                                            }
                                        },
                                        'stageFour': {
                                            '$cond': {
                                                'if': {
                                                    '$eq': ['$stage4', 'complete']
                                                },
                                                'then': 1,
                                                'else': 0
                                            }
                                        },
                                        'stageFive': {
                                            '$cond': {
                                                'if': {
                                                    '$eq': ['$stage5', 'complete']
                                                },
                                                'then': 1,
                                                'else': 0
                                            }
                                        },
                                        'stageSix': {
                                            '$cond': {
                                                'if': {
                                                    '$eq': ['$stage6', 'complete']
                                                },
                                                'then': 1,
                                                'else': 0
                                            }
                                        }
                                    }
                                },
                                {
                                    '$project': {
                                        '_id': {
                                            '$toString': '$_id'
                                        },
                                        'stageOne': 1,
                                        'stageTwo': 1,
                                        'stageThree': 1,
                                        'stageFour': 1,
                                        'stageFive': 1,
                                        'stageSix': 1,
                                        'stage1date': 1,
                                        'stage2date': 1,
                                        'stage3date': 1,
                                        'stage4date': 1,
                                        'stage5date': 1,
                                        'stage6date': 1
                                    }
                                }
                            ]
                        }
                    },
                    {
                        '$unwind': '$auditInfo'
                    },
                    {
                        '$lookup': {
                            'from': self.loanStatusLog.name,
                            'localField': '_id',
                            'foreignField': 'loanApplicationId',
                            'as': 'disbursementInfo',
                            'pipeline': [
                                {
                                    '$addFields': {
                                        'disbursementDetails': {
                                            '$first': '$disbursed'
                                        }
                                    }
                                },
                                {
                                    '$addFields': {
                                        'disbursedDate': {
                                            '$first': '$disbursementDetails.disbursedInfo.date'
                                        }
                                    }
                                },
                                {
                                    '$project': {
                                        '_id': {
                                            '$toString': '$_id'
                                        },
                                        'disbursedDate': 1
                                    }
                                }
                            ]
                        }
                    },
                    {
                        '$unwind': '$disbursementInfo'
                    },
                    {
                        '$project': {
                            '_id': {
                                '$toString': '$_id'
                            },
                            'auditInfo': 1,
                            'disbursementInfo': 1

                        }
                    }
                    ,{'$sort': {'_id': -1}}
                ]
                  
            xCurrentDate = datetime.datetime.fromtimestamp(timeNow() / 1000 / 1000)
            xCurrentDate = xCurrentDate.strftime('%Y-%m-%d')
            xCurrentDate = datetime.datetime.strptime(xCurrentDate, '%Y-%m-%d')

            xGreenStage = 0
            xYellowStage = 0
            xRedStage = 0

            if mDistrictsAllotted:
                pipeline.insert(0, {
                    '$match': {
                        'data.unitDistrict': {
                            '$in': mDistrictsAllotted
                        }
                    }
                })
            mFindApplication = self.loanApplication.aggregate(pipeline)
            async for i in mFindApplication:
                if i.get('auditInfo') and i.get('disbursementInfo').get('disbursedDate'):
                    xTotalStages = i.get('auditInfo').get('stageOne') + i.get('auditInfo').get('stageTwo') + i.get('auditInfo').get('stageThree') + i.get('auditInfo').get('stageFour') + i.get('auditInfo').get('stageFive') + i.get('auditInfo').get('stageSix')
                    xDisbursedDate = datetime.datetime.fromtimestamp(i.get('disbursementInfo').get('disbursedDate') / 1000 / 1000)
                    xDisbursedDate = xDisbursedDate.strftime('%Y-%m-%d')
                    xDisbursedDate = datetime.datetime.strptime(xDisbursedDate, '%Y-%m-%d')
                    year_diff = xCurrentDate.year - xDisbursedDate.year
                    month_diff = xCurrentDate.month - xDisbursedDate.month

                    if xCurrentDate.day < xDisbursedDate.day:
                        month_diff -= 1
                    xMonthDifference = year_diff * 12 + month_diff
                    if xTotalStages:
                        if xMonthDifference <= xTotalStages * 2 or xTotalStages == 6:
                            xGreenStage += 1
                        elif xMonthDifference > xTotalStages * 2 and xMonthDifference <= xTotalStages * 2 + 2 and xTotalStages != 6:
                            xYellowStage += 1
                        elif xMonthDifference > xTotalStages * 2 + 2 and xTotalStages != 6:
                            xRedStage += 1
                
            result = [
                {
                    'Green': xGreenStage,
                    'Yellow': xYellowStage,
                    'Red': xRedStage
                }
            ]
            if len(result):
                code = 2000
                status = True
            else: 
                code = 4060
                message = 'Data not found'
                raise Exception


        except Exception as e:
            status = False
            if not len(message):
                # self.set_status(503)
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(bdumps(response))
            await self.finish()
            return

        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            # self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return