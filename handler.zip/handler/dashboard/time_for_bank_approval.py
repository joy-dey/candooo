import datetime
import json
import os
import re
import sys
import mimetypes
import requests
import io

from abc import ABCMeta
from bson import ObjectId
from build_config import CONFIG
from lib.lib import Validate
from lib.xen_protocol import xenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log
from util.time_util import timeNow
from bson.json_util import dumps as bdumps
from lib.element_mixer import ElementMixer
from util.file_util import FileUtil


@xenSecureV2
class TimeForBankApprovalHandler(ElementMixer,  MongoMixin, metaclass=ABCMeta):

    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]

    loanApplication = MongoMixin.userDb[
        CONFIG['database'][0]['table'][13]['name']
    ]

    componentId = ObjectId('63d39988458b78fdf4cf6c0d')

    async def get(self):
        code = 4000
        status = False
        message = ''
        result = []

        try:
            try:
                vStatus = self.get_argument('status')
                if vStatus:
                    if vStatus == 'Loan Sanctioned':
                        code, message = Validate.i(
                            vStatus,
                            'status',
                            datType=str,
                            notEmpty=True
                        )
                        if code != 4100:
                            raise Exception
                    else:
                        vStatus = None
                else:
                    raise Exception
            except:
                vStatus = None

            try:
                year = self.get_argument('year')
                if year:
                    code, message = Validate.i(
                        year,
                        'Year',
                        datType=str,
                        notEmpty=True
                    )
                    if code != 4100:
                        raise Exception
                else:
                    raise Exception
            except:
                year = None

            if year:
                try:
                    sYear = year.split('-')[0]
                    code, message = Validate.i(
                        sYear,
                        'Start Year',
                        datType=int,
                        notEmpty=True
                    )
                    if code != 4100:
                        raise Exception
                except:
                    code = 7656
                    message = 'Start Year Required'
                    raise Exception

                try:
                    eYear = year.split('-')[1]
                    code, message = Validate.i(
                        eYear,
                        'End Year',
                        datType=int,
                        notEmpty=True
                    )
                    if code != 4100:
                        raise Exception
                except:
                    code = 7657
                    message = 'End Year Required'
                    raise Exception

                sYear = datetime.datetime(int(sYear), 4, 1, 0, 0, 0)
                sYear = sYear.strftime("%Y-%m-%d")

                eYear = datetime.datetime(int(eYear), 3, 31, 23, 59, 59)
                eYear = eYear.strftime("%Y-%m-%d")

                sYear = int(datetime.datetime.strptime(sYear, "%Y-%m-%d").timestamp()) * 1000000
                eYear = int(datetime.datetime.strptime(eYear, "%Y-%m-%d").timestamp()) * 1000000

                if sYear > eYear:
                    code = 5643
                    message = 'End Year Should Be Greater Than Start Year'
                    raise Exception

            distQ = await self.account.find_one(
                {
                    '_id':self.accountId
                }
            )
            if not distQ:
                code = 3823
                message = 'Account not found'
                raise Exception
            
            role = distQ.get('role')
            dist = False
            if role != 'Admin':
                distV = distQ.get('districts')
                if distV != [] or distV != None:
                    dist = True
            pipeline = [
                {
                    '$match': {
                                'data.unitDistrict': {'$in': distV} if dist else { '$exists': True },
                                'data.onlineSubmissionDate': {'$gte': sYear, '$lte': eYear} if year else {'$exists': True}
                            
                    }
                },
                {
                    '$project':{
                        'data.forwardingDateToBank': 1,
                        'data.sanctionedDateByBank': 1,
                        'data.dateOfDocumentReceivedAtBank': 1
                    }
                }
            ]
            if not vStatus:
                pass
            elif vStatus == 'Loan Sanctioned':
                vFilter = {'$match': {'data.currentStatus': {'$in':['Loan Sanctioned', 'Disbursed']}}}
                pipeline.insert(0, vFilter)
            else:
                vFilter = {'$match': {'data.currentStatus': vStatus}}
                pipeline.insert(0, vFilter)
                    
            mFindRecord = self.loanApplication.aggregate(pipeline)

            v = {
                '2 Weeks': 0,
                '4 Weeks': 0,
                '2 Months': 0,
                '3-6 Months': 0,
                '> 6 Months': 0
            }  
            z = {
                '2 Weeks': 0,
                '4 Weeks': 0,
                '2 Months': 0,
                '3-6 Months': 0,
                '> 6 Months': 0
            }
    
            async for i in mFindRecord:
                try:
                    forwardingDate = datetime.datetime.fromtimestamp(int(i.get('data').get('forwardingDateToBank')) / 1000 / 1000)
                    documentReceived = datetime.datetime.fromtimestamp(int(i.get('data').get('dateOfDocumentReceivedAtBank')) / 1000 / 1000)
                except:
                    forwardingDate = None
                    documentReceived = None

                try:
                    sanctionedDate = datetime.datetime.fromtimestamp(int(i.get('data').get('sanctionedDateByBank')) / 1000 / 1000)
                except:
                    sanctionedDate = None

                if documentReceived and forwardingDate:
                    mForwardingToBankReceived = (documentReceived - forwardingDate).days
                    if mForwardingToBankReceived <= 14:
                        v['2 Weeks'] = v.get('2 Weeks') + 1
                    elif mForwardingToBankReceived > 14 and mForwardingToBankReceived <= 28:
                        v['4 Weeks'] = v.get('4 Weeks') + 1
                    elif mForwardingToBankReceived > 28 and mForwardingToBankReceived <= 60:
                        v['2 Months'] = v.get('2 Months') + 1
                    elif mForwardingToBankReceived > 60 and mForwardingToBankReceived <= 180:
                        v['3-6 Months'] = v.get('3-6 Months') + 1
                    elif mForwardingToBankReceived > 180:
                        v['> 6 Months'] = v.get('> 6 Months') + 1
                
                if documentReceived and sanctionedDate:
                    mBankReceivedToSanctioned = (sanctionedDate - documentReceived).days
                    if mBankReceivedToSanctioned <= 14:
                        z['2 Weeks'] = z.get('2 Weeks') + 1
                    elif mBankReceivedToSanctioned > 14 and mBankReceivedToSanctioned <= 28:
                        z['4 Weeks'] = z.get('4 Weeks') + 1
                    elif mBankReceivedToSanctioned > 28 and mBankReceivedToSanctioned <= 60:
                        z['2 Months'] = z.get('2 Months') + 1
                    elif mBankReceivedToSanctioned > 60 and mBankReceivedToSanctioned <= 180:
                        z['3-6 Months'] = z.get('3-6 Months') + 1
                    elif mBankReceivedToSanctioned > 180:
                        z['> 6 Months'] = z.get('> 6 Months') + 1
                
            result.append(
                {
                    'forwardingToBankReceived': v
                }
            )
            result.append(
                {
                    'bankReceivedToSanctioned': z
                }
            )

            if len(result):
                code = 2000
                status = True
            else:
                code = 4085
                message = 'Data not found'
                raise Exception

        except Exception as e:
            status = False
            if not len(message):
                # self.set_status(503)
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(bdumps(response))
            await self.finish()
            return

        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            # self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return