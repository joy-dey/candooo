import datetime
import json
import os
import re
import sys
import mimetypes
import requests
import io

from abc import ABCMeta
from bson import ObjectId
from build_config import CONFIG
from lib.lib import Validate
from lib.xen_protocol import xenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log
from util.time_util import timeNow
from bson.json_util import dumps as bdumps
from lib.element_mixer import ElementMixer


@xenSecureV2
class TrainingInfoHandler(ElementMixer,  MongoMixin, metaclass=ABCMeta):

    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]

    loanApplication = MongoMixin.userDb[ 
        CONFIG['database'][0]['table'][13]['name']
    ]

    trainingStatus = MongoMixin.userDb[
        CONFIG['database'][0]['table'][21]['name']
    ]

    componentId = ObjectId('63d39988458b78fdf4cf6c0d')

    async def get(self):
        code = 4000
        status = False
        message = ''
        result = []

        try:
            try:
                year = self.get_argument('year')
                if year:
                    code, message = Validate.i(
                        year,
                        'Year',
                        datType=str,
                        notEmpty=True
                    )
                    if code != 4100:
                        raise Exception
                else:
                    raise Exception
            except:
                year = None

            if year:
                try:
                    sYear = year.split('-')[0]
                    code, message = Validate.i(
                        sYear,
                        'Start Year',
                        datType=int,
                        notEmpty=True
                    )
                    if code != 4100:
                        raise Exception
                except:
                    code = 7656
                    message = 'Start Year Required'
                    raise Exception

                try:
                    eYear = year.split('-')[1]
                    code, message = Validate.i(
                        eYear,
                        'End Year',
                        datType=int,
                        notEmpty=True
                    )
                    if code != 4100:
                        raise Exception
                except:
                    code = 7657
                    message = 'End Year Required'
                    raise Exception

                sYear = datetime.datetime(int(sYear), 4, 1, 0, 0, 0)
                sYear = sYear.strftime("%Y-%m-%d")

                eYear = datetime.datetime(int(eYear), 3, 31, 23, 59, 59)
                eYear = eYear.strftime("%Y-%m-%d")

                sYear = int(datetime.datetime.strptime(sYear, "%Y-%m-%d").timestamp()) * 1000000
                eYear = int(datetime.datetime.strptime(eYear, "%Y-%m-%d").timestamp()) * 1000000

                if sYear > eYear:
                    code = 5643
                    message = 'End Year Should Be Greater Than Start Year'
                    raise Exception
            
            distQ = await self.account.find_one(
                {
                    '_id':self.accountId
                }
            )
            if not distQ:
                code = 3823
                message = 'Account not found'
                raise Exception
            
            role = distQ.get('role')
            dist = False
            if role != 'Admin':
                distV = distQ.get('districts')
                if distV != [] or distV != None:
                    dist = True
            
            pipeline = [
                        {
                            '$lookup': {
                                'from': self.loanApplication.name,
                                'localField': 'loanApplicationId',
                                'foreignField': '_id',
                                'as': 'loanAppInfo',
                                'pipeline': [
                                    {'$match': {
                                        'data.onlineSubmissionDate': {'$gte': sYear, '$lte': eYear} if year else {
                                            '$exists': True}
                                    }}
                                            ]
                            }
                        },
                        {
                            '$match': {
                                'loanAppInfo': {
                                    '$elemMatch': {
                                        'data.unitDistrict': {'$in': distV} if dist else { '$exists': True }
                                    }
                                }
                            }
                        },
                    {
                        '$group': {
                            '_id': '$trainingStatus',
                            'totalApplications': {
                                '$sum': 1
                            }
                        }
                    },
                    {
                        '$addFields': {
                            'status': '$_id'
                        }
                    },
                    {
                        '$project': {
                            'status': 1,
                            'totalApplications': 1
                        }
                    }
                ]

            result = [
                {
                    'status': 'Training Pending',
                    'totalApplications': 0
                },
                {
                    'status': 'Training Completed',
                    'totalApplications': 0
                }
            ]
            mTrainingFind = self.trainingStatus.aggregate(pipeline)
            async for i in mTrainingFind:
                for v in result:
                    if i.get('status') == 'Pending':
                        if v.get('status') == 'Training Pending':
                            v['totalApplications'] = i.get('totalApplications')

                    if i.get('status') == 'Completed':
                        if v.get('status') == 'Training Completed':
                            v['totalApplications'] = i.get('totalApplications')

            if len(result):
                code = 2000
                status = True
            else:
                code = 4080
                message = 'Data not found'
                raise Exception

        except Exception as e:
            status = False
            if not len(message):
                # self.set_status(503)
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(bdumps(response))
            await self.finish()
            return

        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            # self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return