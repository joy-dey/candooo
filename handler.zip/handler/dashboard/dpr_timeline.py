#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
    Description: AccommodationProviderGrievanceHandler
    Purpose: GET, POST Grievance
"""

import datetime
import sys
import tornado.web
from bson import ObjectId

from build_config import CONFIG
from lib.element_mixer import ElementMixer
from lib.xen_protocol import xenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log
from bson.json_util import dumps as bdumps

from util.time_util import timeNow


@xenSecureV2
class DPRTimelineHandler(ElementMixer, MongoMixin):

    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]
    
    profile = MongoMixin.userDb[
        CONFIG['database'][0]['table'][2]['name']
    ]

    loanApplication = MongoMixin.userDb[
        CONFIG['database'][0]['table'][13]['name']
    ]

    componentId = ObjectId('63d39988458b78fdf4cf6c0d')

    async def get(self):
        code = 4000
        message = ''
        status = False
        result = []
    
        try:
            distQ = await self.account.find_one(
                {
                    '_id':self.accountId
                }
            )
            if not distQ:
                code = 3823
                message = 'Account not found'
                raise Exception
            
            pipeline = [
                {
                    '$match': {
                        'architectDetails': {
                            '$ne': None
                        }
                    }
                },
                 {
                        '$match': {
                            'data.currentStatus': {
                                '$in': ['Loan Sanctioned', 'Onhold/Discontinued', 'Disbursed', 'Copayment', 'Construction Completed']
                            }
                        }
                    },
                {
                    '$project': {
                        'architectDetails': 1   
                    }
                }
            ]
            if distQ.get('designation') == 'Architect':
                pipeline.append(
                    {
                        '$match': {
                            'architectDetails.architectAssigned': self.accountId
                        }
                    }
                )
            xTimeStamp = timeNow()
            xGreen = 0
            xGrey = 0
            xRed = 0
            xApplicationFind = self.loanApplication.aggregate(pipeline)
            async for i in xApplicationFind:
                xAssignedTime = datetime.datetime.fromtimestamp(int(i.get('architectDetails').get('assignedAt') / 1000 / 1000))
                xTimeNow = datetime.datetime.fromtimestamp(int(xTimeStamp) / 1000 / 1000)
                duration = xTimeNow - xAssignedTime
                totalDays = duration.days

                if totalDays <= 30 and i.get('architectDetails').get('dprSubmitted'):
                    xGreen += 1
                elif totalDays <= 30 and not i.get('architectDetails').get('dprSubmitted'):
                    xGrey += 1
                elif totalDays > 30 and i.get('architectDetails').get('dprSubmitted'):
                    xGreen += 1
                elif totalDays > 30 and not i.get('architectDetails').get('dprSubmitted'):
                    xRed += 1

            result.append(
                {
                    'Uploaded': xGreen,
                    'Pending': xGrey,
                    'Timeline Missed': xRed
                }
            )
            code = 2000
            status = True

        except Exception as e:
            status = False
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(bdumps(response))
            await self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return