import datetime
import json
import os
import re
import sys
import mimetypes
import requests
import pandas as pd
import io

from abc import ABCMeta
from bson import ObjectId
from build_config import CONFIG
from lib.lib import Validate
from lib.xen_protocol import xenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log
from util.time_util import timeNow
from bson.json_util import dumps as bdumps
from lib.element_mixer import ElementMixer
from util.file_util import FileUtil


@xenSecureV2
class YearWiseApplicationRejectedReturnedHandler(ElementMixer,  MongoMixin, metaclass=ABCMeta):

    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]

    loanApplication = MongoMixin.userDb[
        CONFIG['database'][0]['table'][13]['name']
    ]

    componentId = ObjectId('63d39988458b78fdf4cf6c0d')

    async def get(self):
        code = 4000
        status = False
        message = ''
        result = []

        try:
            startDate = datetime.datetime(2020, 4, 1, 0, 0)
            startDate = int(startDate.timestamp() * 1000000)
            
            endDate = datetime.datetime(2025, 3, 31, 23, 59)
            endDate = int(endDate.timestamp() * 1000000)
            IST_OFFSET = 19800 * 1000

            pipeline = [
                {
                    '$match': {
                        'data.onlineSubmissionDate': {
                            '$gte': startDate,
                            '$lte': endDate
                        },
                        'data.currentStatus': 'Rejected/Returned'
                    }
                },
                {
                    '$addFields': {
                        'onlineSubmissionDateYear': {
                            '$year': {
                                '$toDate': {
                                    '$toLong': {'$add': [
                                    { '$divide': ['$data.onlineSubmissionDate', 1000] },
                                    IST_OFFSET 
                                ]
                                    }
                                }
                            }
                        },
                        'onlineSubmissionDateMonth': {
                            '$month': {
                                '$toDate': {
                                    '$toLong': {'$add': [
                                    { '$divide': ['$data.onlineSubmissionDate', 1000] },
                                    IST_OFFSET 
                                ]
                                    }
                                }
                            }
                        }
                    }
                },
                {
                    '$addFields': {
                        'financialYear': {
                            '$cond': {
                                'if': { '$lt': ['$onlineSubmissionDateMonth', 4] },
                                'then': { '$subtract': ['$onlineSubmissionDateYear', 1] },
                                'else': '$onlineSubmissionDateYear'
                            }
                        }
                    }
                },
                {
                    '$addFields': {
                        'financialYearRange': {
                            '$concat': [
                                { '$toString': '$financialYear' },
                                '-',
                                { '$toString': { '$add': ['$financialYear', 1] } }
                            ]
                        }
                    }
                },
                {
                    '$facet': {
                        'Rejected By Bank': [
                            {
                                '$match': {
                                    'data.rejectedByBank': True
                                }
                            },
                            {
                                '$group': {
                                    '_id': '$financialYearRange',
                                    'total': { '$sum': 1 }
                                }
                            },
                            {
                                '$sort': {
                                    '_id': 1
                                }
                            }
                        ],
                        'Rejected By DIC': [
                            {
                                '$match': {
                                    'data.rejectedByBank': False
                                }
                            },
                            {
                                '$group': {
                                    '_id': '$financialYearRange',
                                    'total': { '$sum': 1 }
                                }
                            },
                            {
                                '$sort': {
                                    '_id': 1
                                }
                            }
                        ]
                    }
                }
            ]

            years = ["2020-2021", "2021-2022", "2022-2023", "2023-2024", "2024-2025"]
            appQ = self.loanApplication.aggregate(pipeline)
            async for app in appQ:
                byBankD = []
                byDicD = []
                for bank in app.get('Rejected By Bank', []):
                    bank['year'] = bank['_id']
                    del bank['_id']
                    bank['status'] = 'Rejected By Bank'
                    byBankD.append(bank)
                
                for dic in app.get('Rejected By DIC', []):
                    dic['year'] = dic['_id']
                    del dic['_id']
                    dic['status'] = 'Rejected By DIC'
                    byDicD.append(dic)

            yearsPresentBank = {entry['year'] for entry in byBankD}
            yearsPresentDic = {entry['year'] for entry in byDicD}
            
            for y in years:
                if y not in yearsPresentBank:
                    byBankD.append({'year': y, 'total': 0, 'status': 'RejectedByBank'})
            
            for y in years:
                if y not in yearsPresentDic:
                    byDicD.append({'year': y, 'total': 0, 'status': 'RejectedByDIC'})

            byBankD.sort(key=lambda x: x['year'])
            byDicD.sort(key=lambda x: x['year'])
            
            result.append({
                'rejectedByBank': byBankD,
                'rejectedByDIC': byDicD
            })        
            if len(result):
                code = 2000
                status = True
                message = 'Data Found'
            else:
                code = 4071
                message = 'Data not Found'
                raise Exception

        except Exception as e:
            status = False
            if not len(message):
                # self.set_status(503)
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(json.loads(bdumps(response)))
            await self.finish()
            return

        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            # self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return