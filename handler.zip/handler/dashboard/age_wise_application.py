import json
import os
import re
import sys
import mimetypes
from datetime import datetime

import requests
import pandas as pd
import io

from abc import ABCMeta
from bson import ObjectId
from build_config import CONFIG
from lib.lib import Validate
from lib.xen_protocol import xenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log
from util.time_util import timeNow
from bson.json_util import dumps as bdumps
from lib.element_mixer import ElementMixer
from util.file_util import FileUtil


@xenSecureV2
class AgeWiseLoanApplicationHandler(ElementMixer,  MongoMixin, metaclass=ABCMeta):

    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]

    loanApplication = MongoMixin.userDb[
        CONFIG['database'][0]['table'][13]['name']
    ]

    componentId = ObjectId('63d39988458b78fdf4cf6c0d')

    async def get(self):
        code = 4000
        status = False
        message = ''
        result = []

        try:
            try:
                vStatus = self.get_argument('status')
                if vStatus:
                    if vStatus == 'Loan Sanctioned':
                        code, message = Validate.i(
                            vStatus,
                            'status',
                            datType=str,
                            notEmpty=True
                        )
                        if code != 4100:
                            raise Exception
                    else:
                        vStatus = None
                else:
                    raise Exception
            except:
                vStatus = None

            try:
                year = self.get_argument('year')
                if year:
                    code, message = Validate.i(
                        year,
                        'Year',
                        datType=str,
                        notEmpty=True
                    )
                    if code != 4100:
                        raise Exception
                else:
                    raise Exception
            except:
                year = None

            if year:
                try:
                    sYear = year.split('-')[0]
                    code, message = Validate.i(
                        sYear,
                        'Start Year',
                        datType=int,
                        notEmpty=True
                    )
                    if code != 4100:
                        raise Exception
                except:
                    code = 7656
                    message = 'Start Year Required'
                    raise Exception

                try:
                    eYear = year.split('-')[1]
                    code, message = Validate.i(
                        eYear,
                        'End Year',
                        datType=int,
                        notEmpty=True
                    )
                    if code != 4100:
                        raise Exception
                except:
                    code = 7657
                    message = 'End Year Required'
                    raise Exception

                sYear = datetime(int(sYear), 4, 1, 0, 0, 0)
                sYear = sYear.strftime("%Y-%m-%d")

                eYear = datetime(int(eYear), 3, 31, 23, 59, 59)
                eYear = eYear.strftime("%Y-%m-%d")

                sYear = int(datetime.strptime(sYear, "%Y-%m-%d").timestamp()) * 1000000
                eYear = int(datetime.strptime(eYear, "%Y-%m-%d").timestamp()) * 1000000

                if sYear > eYear:
                    code = 5643
                    message = 'End Year Should Be Greater Than Start Year'
                    raise Exception

            distQ = await self.account.find_one(
                {
                    '_id':self.accountId
                }
            )
            if not distQ:
                code = 3823
                message = 'Account not found'
                raise Exception
            
            role = distQ.get('role')
            dist = False
            if role != 'Admin':
                distV = distQ.get('districts')
                if distV != [] or distV != None:
                    dist = True
            pipeline = [
                {
                    '$match': {
                                'data.unitDistrict': {'$in': distV} if dist else { '$exists': True },
                                'data.onlineSubmissionDate': {'$gte': sYear, '$lte': eYear} if year else {'$exists': True}
                            
                    }
                },
                {
                    '$group': {
                        '_id': '$data.age',
                        'totalApplications': {
                            '$sum': 1
                        }
                    }                       
                },
                {
                    '$project': {
                        '_id': {
                            '$toString': '$_id'
                        },
                        'totalApplications': 1
                    }
                }
            ]
            if not vStatus:
                pass
            elif vStatus == 'Loan Sanctioned':
                vFilter = {'$match': {'data.currentStatus': {'$in':['Loan Sanctioned', 'Disbursed']}}}
                pipeline.insert(0, vFilter)
            else:
                vFilter = {'$match': {'data.currentStatus': vStatus}}
                pipeline.insert(0, vFilter)


            v = {}
            v['underTwenty'] = {
                'totalApplications': 0
            }
            v['twentyoneToThirty'] = {
                'totalApplications': 0
            }
            v['thirtyoneToFourty'] = {
                'totalApplications': 0
            }
            v['fourtyoneToFifty'] = {
                'totalApplications': 0
            }
            v['aboveFifty'] = {
                'totalApplications': 0
            }

            mFindRecord = self.loanApplication.aggregate(pipeline)
            async for i in mFindRecord:
                try:
                    i['_id'] = int(i.get('_id'))
                except:
                    continue
                if i.get('_id') <= 20:
                    v['underTwenty'] = {
                        'totalApplications': int(v.get('underTwenty').get('totalApplications')) + i.get('totalApplications')
                    }
                elif i.get('_id') <= 30 and i.get('_id') > 20:
                    v['twentyoneToThirty'] = {
                        'totalApplications': int(v.get('twentyoneToThirty').get('totalApplications')) + i.get('totalApplications')
                    }
                elif i.get('_id') <= 40 and i.get('_id') > 30:
                    v['thirtyoneToFourty'] = {
                        'totalApplications': int(v.get('thirtyoneToFourty').get('totalApplications')) + i.get('totalApplications')
                    }
                elif i.get('_id') <= 50 and i.get('_id') > 40:
                    v['fourtyoneToFifty'] = {
                        'totalApplications': int(v.get('fourtyoneToFifty').get('totalApplications')) + i.get('totalApplications')
                    }
                elif i.get('_id') > 50:
                    v['aboveFifty'] = {
                        'totalApplications': int(v.get('aboveFifty').get('totalApplications')) + i.get('totalApplications')
                    }
            
            result.append(v)

            if len(result):
                code = 2000
                status = True
            else:
                code = 4071
                message = 'Data not Found'
                raise Exception

        except Exception as e:
            status = False
            if not len(message):
                # self.set_status(503)
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(bdumps(response))
            await self.finish()
            return

        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            # self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return