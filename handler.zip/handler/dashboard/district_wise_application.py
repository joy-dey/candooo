
import sys
from datetime import datetime

from abc import ABCMeta
from bson import ObjectId
from build_config import CONFIG
from lib.lib import Validate
from lib.xen_protocol import xenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log
from bson.json_util import dumps as bdumps
from lib.element_mixer import ElementMixer


@xenSecureV2
class DistrictWiseLoanApplicationHandler(ElementMixer,  MongoMixin, metaclass=ABCMeta):

    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]

    loanApplication = MongoMixin.userDb[
        CONFIG['database'][0]['table'][13]['name']
    ]

    district = MongoMixin.userDb[
        CONFIG['database'][0]['table'][14]['name']
    ]

    componentId = ObjectId('63d39988458b78fdf4cf6c0d')

    async def get(self):
        code = 4000
        status = False
        message = ''
        result = []

        try:
            try:
                vStatus = self.get_argument('status')
                if vStatus:
                    if vStatus == 'Loan Sanctioned':
                        code, message = Validate.i(
                            vStatus,
                            'status',
                            datType=str,
                            notEmpty=True
                        )
                        if code != 4100:
                            raise Exception
                    else:
                        vStatus = None
                else:
                    raise Exception
            except:
                vStatus = None

            try:
                year = self.get_argument('year')
                if year:
                    code, message = Validate.i(
                        year,
                        'Year',
                        datType=str,
                        notEmpty=True
                    )
                    if code != 4100:
                        raise Exception
                else:
                    raise Exception
            except:
                year = None

            if year:
                try:
                    sYear = year.split('-')[0]
                    code, message = Validate.i(
                        sYear,
                        'Start Year',
                        datType=int,
                        notEmpty=True
                    )
                    if code != 4100:
                        raise Exception
                except:
                    code = 7656
                    message = 'Start Year Required'
                    raise Exception

                try:
                    eYear = year.split('-')[1]
                    code, message = Validate.i(
                        eYear,
                        'End Year',
                        datType=int,
                        notEmpty=True
                    )
                    if code != 4100:
                        raise Exception
                except:
                    code = 7657
                    message = 'End Year Required'
                    raise Exception

                sYear = datetime(int(sYear), 4, 1, 0, 0, 0)
                sYear = sYear.strftime("%Y-%m-%d")

                eYear = datetime(int(eYear), 3, 31, 23, 59, 59)
                eYear = eYear.strftime("%Y-%m-%d")

                sYear = int(datetime.strptime(sYear, "%Y-%m-%d").timestamp())*1000000
                eYear = int(datetime.strptime(eYear, "%Y-%m-%d").timestamp())*1000000

                if sYear > eYear:
                    code = 5643
                    message = 'End Year Should Be Greater Than Start Year'
                    raise Exception

            mAccountInfo = await self.account.find_one(
                {
                    '_id': self.accountId
                }
            )
            if not mAccountInfo:
                code = 4057
                message = 'Account Not Found'
                raise Exception
            
            mDistrictsAllotted = None
            if mAccountInfo.get('role') == 'Auditor':
                mDistrictsAllotted = mAccountInfo.get('districts')

            pipeline = [
                    {
                        '$group': {
                            '_id': '$data.unitDistrict',
                            'totalApplications': {
                                '$sum': 1
                            }
                        }
                        
                    },
                    {
                        '$lookup': {
                            'from': self.district.name,
                            'localField': '_id',
                            'foreignField': '_id',
                            'as': 'districtDetails',
                            'pipeline': [
                                {
                                    '$project': {
                                        '_id': 0,
                                        'districtName': 1
                                    }
                                }
                            ]
                        }
                    },
                    {
                        '$addFields': {
                            'districtInfo': {
                                '$first': '$districtDetails'
                            }
                        }
                    },
                    {
                        '$addFields': {
                            'districtName': '$districtInfo.districtName'
                        }
                    },
                    {
                        '$project': {
                            '_id': {
                                '$toString': '$_id'
                            },
                            'totalApplications': 1,
                            'districtName': 1
                        }
                    },
                    {
                        '$sort': {
                            '_id': 1
                        }
                    }
                ]

            if year:
                vYearFilter0 = {'$match': {'data.onlineSubmissionDate': {'$gte': sYear, '$lte': eYear}}}
                pipeline.insert(0, vYearFilter0)

            if not vStatus:
                pass
            elif vStatus == 'Loan Sanctioned':
                vFilter = {'$match': {'data.currentStatus': {'$in': [vStatus, 'Disbursed']}}}
                pipeline.insert(0, vFilter)
            else:
                vFilter = {'$match': {'data.currentStatus': {'$in': vStatus}}}
                pipeline.insert(0, vFilter)

            if mDistrictsAllotted:
                pipeline.insert(0, {'$match': {'data.unitDistrict': {'$in': mDistrictsAllotted}}})

            mFindRecord = self.loanApplication.aggregate(pipeline)
            async for i in mFindRecord:
                result.append(i)

            if len(result):
                code = 2000
                status = True
            else:
                code = 4069
                message = 'Data not Found'
                raise Exception

        except Exception as e:
            status = False
            if not len(message):
                # self.set_status(503)
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(bdumps(response))
            await self.finish()
            return

        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            # self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return