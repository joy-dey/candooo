#!/usr/bin/VtsAdminSignInHandler
# -*- coding: utf-8 -*-

import json
import os
import re
import sys
import mimetypes
import requests
import pandas as pd
import io

import datetime
from handler.methods.age_calculator import age_calculate
from handler.methods.find_one_data import findData

import tornado.web
from abc import ABCMeta
from bson import ObjectId
from build_config import CONFIG
from lib.lib import Validate
from lib.xen_protocol import xenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log
from util.time_util import timeNow
from bson.json_util import dumps as bdumps
from lib.element_mixer import ElementMixer
from util.file_util import FileUtil


@xenSecureV2
class DefaultersHandler(ElementMixer, MongoMixin, metaclass=ABCMeta):


    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]

    profile = MongoMixin.userDb[
        CONFIG['database'][0]['table'][2]['name']
    ]

    uploadFileDetails = MongoMixin.userDb[
        CONFIG['database'][0]['table'][16]['name']
    ]

    loanApplication = MongoMixin.userDb[
        CONFIG['database'][0]['table'][13]['name']
    ]
    
    state = MongoMixin.userDb[
        CONFIG['database'][0]['table'][6]['name']
    ]

    block = MongoMixin.userDb[
        CONFIG['database'][0]['table'][15]['name']
    ]

    district = MongoMixin.userDb[
        CONFIG['database'][0]['table'][14]['name']
    ]

    loanStatusLog = MongoMixin.userDb[
        CONFIG['database'][0]['table'][18]['name']
    ]
    
    auditInfo = MongoMixin.userDb[
        CONFIG['database'][0]['table'][19]['name']
    ]

    trainingStatus = MongoMixin.userDb[
        CONFIG['database'][0]['table'][21]['name']
    ]

    rejectionReasons = MongoMixin.userDb[
        CONFIG['database'][0]['table'][11]['name']
    ]

    bankBranch = MongoMixin.userDb[
        CONFIG['database'][0]['table'][22]['name']
    ]

    jointApplication = MongoMixin.userDb[
        CONFIG['database'][0]['table'][23]['name']
    ]

    componentId = ObjectId('63d39988458b78fdf4cf6c0d')

    async def get(self):
        code = 4000
        status = False
        message = ''
        result = []

        try:
            try:
                year = self.get_argument('year')
                code, message = Validate.i(
                    year,
                    'year',
                    notNull=True,
                    dataType=str
                )
                if code != 4100:
                    raise Exception

            except Exception as e:
                year = None
            if year:
                try:
                    sYear = year.split('-')[0]
                    code, message = Validate.i(
                        sYear,
                        'Start Year',
                        datType=int,
                        notEmpty=True
                    )
                    if code != 4100:
                        raise Exception
                except:
                    code = 7656
                    message = 'Start Year Required'
                    raise Exception

                try:
                    eYear = year.split('-')[1]
                    code, message = Validate.i(
                        eYear,
                        'End Year',
                        datType=int,
                        notEmpty=True
                    )
                    if code != 4100:
                        raise Exception
                except:
                    code = 7657
                    message = 'End Year Required'
                    raise Exception

                sYear = datetime.datetime(int(sYear), 4, 1, 0, 0, 0)
                sYear = sYear.strftime("%Y-%m-%d")

                eYear = datetime.datetime(int(eYear), 3, 31, 23, 59, 59)
                eYear = eYear.strftime("%Y-%m-%d")

                sYear = int(datetime.datetime.strptime(sYear, "%Y-%m-%d").timestamp()) * 1000000
                eYear = int(datetime.datetime.strptime(eYear, "%Y-%m-%d").timestamp()) * 1000000

                if sYear > eYear:
                    code = 5643
                    message = 'End Year Should Be Greater Than Start Year'
                    raise Exception
            
            distQ = await self.account.find_one(
                {
                    '_id': self.accountId
                }
            )

            if not distQ:
                code = 3523
                message = 'Account Not Found'
                raise Exception

            try:    
                method = self.get_argument('method')
                method = json.loads(method)
                code, message = Validate.i(
                    method,
                    'method',
                    notNull=True,
                    dataType=int
                )
                if code != 4100:
                    raise Exception
            except Exception as e:
                method = None

            pipeline = [
                {
                    '$match': {
                        'data.onlineSubmissionDate': {'$gte': sYear, '$lte': eYear} if year else {'$exists': True},
                        'isDefaulter': True
                    }
                },
                {
                    '$count': 'defaulters'
                },
                {
                    '$project': {
                        '_id': 0,
                        'defaulters': 1
                    }
                }
            ]

            pipelineQ = [
                {                
                    '$match': {
                        'data.onlineSubmissionDate': {'$gte': sYear, '$lte': eYear} if year else {'$exists': True},
                        'isDefaulter': True
                    }
                },
                {
                    '$lookup': {
                        'from': self.state.name,
                        'localField': 'data.state',
                        'foreignField': '_id',
                        'as': 'stateInfo',
                        'pipeline': [
                            {
                                '$project': {
                                    '_id': {
                                        '$toString': '$_id'
                                    },
                                    'name': 1
                                }
                            }
                        ]
                    }
                },
                {
                    '$lookup': {
                        'from': self.district.name,
                        'localField': 'data.unitDistrict',
                        'foreignField': '_id',
                        'as': 'districtInfo',
                        'pipeline': [
                            {
                                '$project': {
                                    '_id': {
                                        '$toString': '$_id'
                                    },
                                    'districtName': 1
                                }
                            }
                        ]
                    }
                },
                {
                    '$lookup': {
                        'from': self.block.name,
                        'localField': 'data.talukblock',
                        'foreignField': '_id',
                        'as': 'blockInfo',
                        'pipeline': [
                            {
                                '$project': {
                                    '_id': {
                                        '$toString': '$_id'
                                    },
                                    'blockName': 1
                                }
                            }
                        ]
                    }
                },
                {
                    '$lookup': {
                        'from': self.loanStatusLog.name,
                        'localField': '_id',
                        'foreignField': 'loanApplicationId',
                        'as': 'statusInfo',
                        'pipeline': [
                            {
                                '$lookup': {
                                    'from': self.account.name,
                                    'localField': 'recommendation.modifiedBy',
                                    'foreignField': '_id',
                                    'as': 'recommendationAccountInfo',
                                    'pipeline': [
                                        {
                                            '$project': {
                                                '_id': {
                                                    '$toString': '$_id'
                                                },
                                                'firstName': 1,
                                                'lastName': 1
                                            }
                                        }
                                    ]
                                }
                            }
                        ]
                    }
                },
                {
                    '$lookup': {
                        'from': self.loanStatusLog.name,
                        'localField': '_id',
                        'foreignField': 'loanApplicationId',
                        'as': 'disbursementInfo',
                        'pipeline': [
                            {
                                '$addFields': {
                                    'disbursementDetails': {
                                        '$first': '$disbursed'
                                    }
                                }
                            },
                            {
                                '$addFields': {
                                    'disbursedDate': {
                                        '$first': '$disbursementDetails.disbursedInfo.date'
                                    }
                                }
                            },
                            {
                                '$addFields': {
                                    'disbursedAmounts': '$disbursed.disbursedInfo.amount'
                                }
                            },
                            {
                                '$project': {
                                    '_id': {
                                        '$toString': '$_id'
                                    },
                                    'disbursedDate': 1,
                                    'disbursedAmounts': 1,
                                    "rejected.reason": 1
                                }
                            }
                        ]
                    }
                },
                {
                    '$unwind': {
                        'path': '$disbursementInfo',
                        'preserveNullAndEmptyArrays': True
                    }
                },
                {
                    '$project': {
                        '_id': {
                            '$toString': '$_id'
                        },
                        'totalCount': 1,
                        'isDefaulter': 1,
                        'data.currentStatus': 1,
                        'data.rejectedByBank': 1,
                        'applicantId': 1,
                        'data.applicantName': 1,
                        'data.mobileNo': 1,
                        'data.alternativeMobileNo': 1,
                        'data.gender': 1,
                        'data.category': 1,
                        'data.totalSanctionedAmountByBank': 1,
                        'data.isUnknownBlock': 1,
                        'data.isUnknownBranch': 1,
                        'data.isRecommended': 1,
                        'defaulter.accountNumber':1,
                        'defaulter.overdueAmount':1,
                        'defaulter.remarks':1,
                        'defaulter.date':1,
                        'defaulter.updatedBy':{
                            '$toString': '$_id'
                        },
                        'createdAt': 1,
                        'disbursementInfo': 1,
                        'inspectionReportSubmitted': 1,
                        'data.sanctionedDateByBank': 1,
                        'createdBy': {
                            '$toString': '$createdBy'
                        },
                        'modifiedBy': {
                            '$toString': '$modifiedBy'
                        },
                        'modifiedAt': 1,
                        'blockInfo': {
                            '$last': '$blockInfo'
                        },
                        'districtInfo': {
                            '$last': '$districtInfo'
                        },
                        'stateInfo': {
                            '$last': '$stateInfo'
                        },
                        'statusInfo': {
                            'recommendation': 1,
                            'recommendationAccountInfo': 1
                        },
                        'disbursedAmounts': 1
                    }
                },
                {
                    '$sort': {
                        '_id': -1
                    }
                }
            ]

            if method is not None and method != 1:
                message = 'Invalid Method.'
                code = 4548
                raise Exception

            if method is not None and method == 1:
                fileQ = self.loanApplication.aggregate(pipelineQ)
                async for i in fileQ:
                    statusInfo = i.get('statusInfo', [])
                    if statusInfo and statusInfo[0].get('recommendation'):
                        for j, recommendation in enumerate(statusInfo[0].get('recommendation', [])):
                            recommendation['modifiedBy'] = str(recommendation.get('modifiedBy'))
                            recommendation['modifiedTo'] = str(recommendation.get('modifiedTo'))
                            for k, account in enumerate(statusInfo[0].get('recommendationAccountInfo', [])):
                                if recommendation['modifiedBy'] == account.get('_id'):
                                    recommendation['accountInfo'] = account
                    del statusInfo[0]['recommendationAccountInfo']
                    if not statusInfo or not statusInfo[0].get('recommendation'):
                        i['statusInfo'] = 'NA'
                    if not i.get('rejectionInfo'):
                        i['rejectionInfo'] = 'NA'
                    if not i.get('isDefaulter'):
                        i['isDefaulter'] = False

                    result.append(i)

            if method is None:
                fileW = self.loanApplication.aggregate(pipeline)
                try:
                    async for i in fileW:
                        result.append(
                            {
                            'status':'Defaulters',
                            'totalApplications': i.get('defaulters', 0)
                            }
                        )
                        print(i)
                except Exception as e:
                    result.append({
                        'status':'Defaulters',
                        'totalApplications': 0
                    })

                if not result:
                    result.append({
                        'status':'Defaulters',
                        'totalApplications': 0
                    })

            if not len(result):
                message = 'No data found.'
                code = 4082
                raise Exception(message)
            else:
                message = 'Data found.'
                code = 2000
                status = True

        except Exception as e:
            status = False
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(bdumps(response))
            await self.finish()
            return

        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return

    async def post(self):
        code = 4000
        status = False
        message = ''
        result = []

        try:
            try:
                # Converts the request body to JSON
                self.request.arguments = json.loads(self.request.body)
            except Exception as e:
                code = 4100
                message = 'Expected request type JSON.'
                raise Exception

            permissionQ = self.profile.aggregate(
                [
                    {
                        '$match': {
                            'accountId': self.accountId
                        }
                    }, {
                        '$project': {
                            '_id': 0, 
                            'permissions': 1
                        }
                    }
                ]
            )
            permission = []
            async for i in permissionQ:
                permission = i.get('permissions', [])

            if not permission:
                code = 4030
                message = 'Unauthorized Access.'
                raise Exception
            
            defPermission = '3311872f-2dec-43ea-9a3e-2a423febd1f3'

            if defPermission not in permission:
                code = 4030
                message = 'You are not able to mark application defaulter.'
                raise Exception

            loanApplicationId = self.request.arguments.get('loanApplicationId')
            code, message = Validate.i(
                loanApplicationId,
                'loanApplicationId',
                notNull=True,
                notEmpty=True,
                dataType=str
            )
            if code != 4100:
                raise Exception
            
            try:
                loanApplication = ObjectId(loanApplicationId)
            except Exception as e:
                code = 4562
                message = 'Loan Application Id is not valid.'
                raise Exception
            
            loanApplicationQ = await self.loanApplication.find_one(
                {'_id': loanApplication}
            )
            if not loanApplicationQ:
                code = 4024
                message = 'Loan Application Not Found'
                raise Exception
            
            # Check if the application is disburesd or not
            disbursedQ = self.loanApplication.find_one(
                {
                    '_id': loanApplication,
                    'disbursed': {'$exists': True},
                }
            )
            
            if disbursedQ is None:
                code = 4561
                message = 'Loan Application is not disbursed.'
                raise Exception
            
            defaulterQ =await self.loanApplication.find_one(
                {
                    '_id': loanApplication,
                    'isDefaulter': True
                }
            )

            if defaulterQ:
                code = 456
                message = 'Loan application is already defaulter.'
                raise Exception
            
            accountNumber = self.request.arguments.get('accountNumber')
            code, message = Validate.i(
                accountNumber,
                'accountNumber',
                dataType=str
            )
            if code != 4100:
                raise Exception
            overdueAmount = self.request.arguments.get('overdueAmount')
            code, message = Validate.i(
                overdueAmount,
                'overdueAmount',
                notNull=True,
                notEmpty=True,
                dataType=int
            )
            if code != 4100:
                raise Exception
            
            if overdueAmount <= 0:
                code = 456
                message = 'Overdue amount should be greater than 0.'
                raise Exception
            
            remarks = self.request.arguments.get('remarks')
            code, message = Validate.i(
                remarks,
                'remarks',
                notNull=True,
                notEmpty=True,
                dataType=str
            )
            if code != 4100:
                raise Exception
            
            applicationQ = await self.loanApplication.find_one(
                {'_id': loanApplication}
            )
            if applicationQ is None:
                code = 4024
                message = 'Loan application not found'
                raise Exception

            totalSanctionedAmountByBankQ = applicationQ['data']['totalSanctionedAmountByBank']

            if totalSanctionedAmountByBankQ <= overdueAmount:
                code = 456
                message = 'Overdue amount exceeds sanction amaount'
                raise Exception

            defaultersQ = await self.loanApplication.update_one(
                {
                    '_id': loanApplication
                },
                {
                    '$set': {
                        'isDefaulter': True,
                        'defaulter':{
                            'accountNumber': accountNumber,
                            'overdueAmount': overdueAmount,
                            'remarks': remarks,
                            'date':timeNow(),
                            'updatedBy': self.accountId
                        }
                    }
                }
            )

            if defaultersQ.modified_count == 0:
                code = 4563
                message = 'Defaulters not updated.'
                raise Exception
            else:
                code = 2000
                status = True
                message = 'Defaulters updated successfully.'

        except Exception as e:
            status = False
            if not message:
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))

        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(response)
            await self.finish()
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
