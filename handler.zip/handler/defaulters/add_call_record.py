#!/usr/bin/VtsAdminSignInHandler
# -*- coding: utf-8 -*-

import json
import os
import re
import sys
import mimetypes
import requests
import pandas as pd
import io

import datetime
from handler.methods.age_calculator import age_calculate
from handler.methods.find_one_data import findData

import tornado.web
from abc import ABCMeta
from bson import ObjectId
from build_config import CONFIG
from lib.lib import Validate
from lib.xen_protocol import xenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log
from util.time_util import timeNow
from bson.json_util import dumps as bdumps
from lib.element_mixer import ElementMixer
from util.file_util import FileUtil

@xenSecureV2
class AddCallRecordHandler(ElementMixer, MongoMixin, metaclass=ABCMeta):

    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]

    profile = MongoMixin.userDb[
        CONFIG['database'][0]['table'][2]['name']
    ]

    uploadFileDetails = MongoMixin.userDb[
        CONFIG['database'][0]['table'][16]['name']
    ]

    loanApplication = MongoMixin.userDb[
        CONFIG['database'][0]['table'][13]['name']
    ]
    
    state = MongoMixin.userDb[
        CONFIG['database'][0]['table'][6]['name']
    ]

    block = MongoMixin.userDb[
        CONFIG['database'][0]['table'][15]['name']
    ]

    callRecord = MongoMixin.userDb[
        CONFIG['database'][0]['table'][27]['name']
    ]

    componentId = ObjectId('63d39988458b78fdf4cf6c0d')


    async def post(self):
        code = 4000
        message = ''
        status = False
        result = []
        try:
            try:
                # converts hte body into JSON
                self.request.arguments = json.loads(self.request.body)
            except Exception as e:
                code = 4100
                message = 'Expected request type JSON.'
                raise Exception
            
            try:
                statusC = self.request.arguments.get('status')
                code, message = Validate.i(
                    statusC,
                    "status",
                    notNull = True,
                    notEmpty = True,
                    dataType = str
                )   
                if code != 4100:
                    raise Exception
            except Exception as e:
                code = 4100
                message = 'status field is required.'
                raise Exception
            
            try:
                mId = self.request.arguments.get('id')
                code, message = Validate.i(
                    mId,
                    'id',
                    notNull = True,
                    dataType = str
                )
                if code != 4100:
                    raise Exception
            except Exception as e:
                code = 4100
                message = 'id field is required.'
                raise Exception
            
            try:
                Oid = ObjectId(mId)
            except Exception as e:
                message = 'Please Enter valid ID.' 
                code = 4568
                raise Exception
            

            try:
                applicationQ = await self.loanApplication.find_one(
                    {'_id': Oid}
                )

                if applicationQ is None:
                    code = 4028
                    message = 'Loan application not found'
                    raise Exception
                applicationId = applicationQ.get('applicantId')
                
            except Exception as e:
                code = 4568
                message = 'Please enter valid ID.' 
                raise Exception

            try:
                remarks = self.request.arguments.get('remarks')
                code, message = Validate.i(
                    remarks,
                    'remarks',
                    notNull = True,
                    notEmpty = True,
                    dataType = str
                )
                if code != 4100:
                    raise Exception
            except Exception as e:
                code = 4100
                message = 'Remarks field is required.'
                raise Exception
            

            dataQ = {
                'applicationId': applicationId,
                'dateTime': timeNow(),
                'status': statusC,
                'remarks': remarks,
                'createdBy': self.accountId
            }

            try:
                await self.callRecord.insert_one(dataQ)
                status = True
                message = 'Call record added successfully.'
                code  = 2000
            except Exception:
                status = False
                message = 'Internal error. Please contact the support team.'
                code  = 5010

        except Exception as e:
            status = False
            if not message:
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))

        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(response)
            await self.finish()
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()

    async def get(self):
        code = 4000
        status = False
        message = ''
        result = []

        try:
            try:
                applicationId = self.get_argument('applicationId')
                print(applicationId)
                code, message = Validate.i(
                    applicationId,
                    'applicationid',
                    dataType = str,
                    notNull = True,
                    notEmpty = True
                )

                if code != 4100:
                    raise Exception
            except Exception as e:
                message = 'Invalid Application Id.'
                code = 5487
                raise Exception
            
            pipelineQ = [
                        {
                        '$match': {
                            'applicationId': applicationId
                                }
                            },
                            {
                                '$lookup': {
                                    'from': self.account.name, 
                                    'localField': 'createdBy', 
                                    'foreignField': '_id', 
                                    'as': 'accountInfo', 
                                    'pipeline': [
                                        {
                                            '$project': {
                                                '_id': {
                                                    '$toString': '$_id'
                                                }, 
                                                'firstName': 1, 
                                                'lastName': 1
                                            }
                                        }
                                    ]
                                }
                            }, {
                                '$project': {
                                    '_id': {
                                        '$toString': '$_id'
                                    }, 
                                    'applicationId': 1, 
                                    'accountInfo': 1, 
                                    'dateTime': 1, 
                                    'remarks': 1, 
                                    'status': 1
                                }
                            }
                        ]
            
            try:

                applicationQ = self.callRecord.aggregate(pipelineQ)
            except Exception as e:
                message = 'Internal Error Please contact the support team.'
                code = 5488
                raise Exception
            
            if not applicationQ:
                code = 4763
                message = 'Application not found with this application ID.'
                raise Exception
            
            if applicationQ:
                async for i in applicationQ:
                    result.append(i)

            if len(result):
                message = 'Data Found'
                code = 2000
                status = True
            else:
                message = 'Data not found.'
                code = 4976
                status = False
            
        except Exception as e:
            status = False
            if not message:
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                    str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))

        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(response)
            await self.finish()
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
