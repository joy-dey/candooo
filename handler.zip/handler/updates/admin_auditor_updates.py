#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
    Description: AccommodationProviderGrievanceHandler
    Purpose: GET, POST Grievance
"""
import json
import mimetypes
import os
import sys

import tornado.web
from bson import ObjectId

from build_config import CONFIG
from lib.element_mixer import ElementMixer
from lib.lib import Validate
from lib.xen_protocol import xenSecureV2
from util.conn_util import MongoMixin
from util.file_util import FileUtil
from util.log_util import Log
from bson.json_util import dumps as bdumps

from util.time_util import timeNow


@xenSecureV2
class RURALAdminAuditorUpdatesHandler(ElementMixer, MongoMixin):

    fu = FileUtil()

    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]

    comments = MongoMixin.userDb[
        CONFIG['database'][0]['table'][20]['name']
    ]

    serviceAccount = MongoMixin.userDb[
        CONFIG['database'][0]['table'][14]['name']
    ]
    
    profile = MongoMixin.userDb[
        CONFIG['database'][0]['table'][2]['name']
    ]
    
    app = MongoMixin.userDb[
        CONFIG['database'][0]['table'][1]['name']
    ]

    componentId = ObjectId('63d38614458b78fdf4cf6bfa')

    async def get(self):
        code = 4000
        message = ''
        status = False
        result = []

        try:
            try:
                vId = self.get_argument('loanId')
                if not vId:
                    message = 'Missing argument [id].'
                    code = 2194
                    raise Exception
                vId = ObjectId(vId)
            except:
                message = 'Invalid Argument - [ loanId ].'
                code = 4056
                raise Exception
            try:
                f_limit = int(self.get_argument('limit'))
                f_skip = int(self.get_argument('skip'))
            except:
                f_limit = 0
                f_skip = 0

            updatePipeline = [
                    {
                        '$match': {
                            'entityId': self.entityId,
                            'convId': vId
                        },
                    },
                    {
                        '$lookup': {
                            'from': self.account.name,
                            'localField': 'createdBy.accountId',
                            'foreignField': '_id',
                            'as': 'accountInfo',
                            'pipeline': [
                                {
                                    '$match': {
                                        '_id': {
                                            '$ne': self.accountId
                                        }
                                    }
                                },
                                {
                                    '$project': {
                                        '_id': 0,
                                        'firstName': 1,
                                        'lastName': 1
                                    }
                                }
                            ]
                        }
                    },
                    {
                        '$project': {
                            '_id': {
                                '$toString': '$_id'
                            },
                            'title': 1,
                            'creatorRole' : 1,
                            'description': 1,
                            'convId': {
                                '$toString': '$convId'
                            },
                            'entityId': {
                                '$toString': '$entityId'
                            },
                            'document': 1,
                            'createdBy': {
                                'at': 1
                            },
                            'accountInfo': 1
                        }
                    },
                    {
                        '$sort': {
                            '_id': -1
                        }
                    },
                    {
                        '$skip': f_skip
                    }
                ]
            if f_limit:
                updatePipeline.append(
                    {
                        '$limit': f_limit
                    }
                )
            findUpdatesQ = self.comments.aggregate(
                updatePipeline
            )
            async for update in findUpdatesQ:
                result.append(update)

            if not len(result):
                message = 'No data found.'
                code = 4043
            else:
                message = ''
                code = 2000
                status = True
        except Exception as e:
            status = False
            # self.set_status(503)
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(bdumps(response))
            await self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            # self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return

    async def post(self):
        code = 4000
        message = ''
        status = False
        result = []
        try:
            vApp = await self.app.find_one(
                {
                    '_id': self.applicationId
                },
                {
                    'title': 1
                }
            )
            role = vApp.get('title')
            try:
                file_dic = {}
                arg_dic = {}
                b = self.request.headers.get('Content-Type')
                tornado.httputil.parse_body_arguments(
                    b, self.request.body, arg_dic, file_dic)
            except:
                code = 4323
                message = 'Expected request type form-data.'
                raise Exception

            try:
                vConvId = str(self.request.arguments['convId'][0].decode())
                if not vConvId:
                    raise Exception
                vConvId = ObjectId(vConvId)
            except:
                message = 'Invalid Argument - [ convId ].'
                code = 4142
                raise Exception

            try:
                vComment = str(self.request.arguments['title'][0].decode())
            except:
                vComment = None

            code, message = Validate.i(
                vComment,
                'title',
                notNull=True,
                notEmpty=True,
                dataType=str,
                minLength=5,
                maxLength=500
            )
            if code != 4100:
                raise Exception

            try:
                vDes = str(self.request.arguments['description'][0].decode())
                if not vDes:
                    raise Exception
            except:
                vDes = ''
            if vDes:
                code, message = Validate.i(
                    vDes,
                    'description',
                    dataType=str,
                    minLength=5,
                    maxLength=500
                )
                if code != 4100:
                    raise Exception

            fileName = None
            timeGlobal = timeNow()
            try:
                vfile = file_dic.get('attachment')
                vfile = vfile[0]
                vfileExt = vfile['content_type']
                ext = mimetypes.guess_extension(vfileExt)
                if ext not in ['.jpg', '.jpeg', '.png']:
                    message = 'File should be in jpg or png or jpeg format.'
                    code = 6997
                    raise Exception

                fileName = str(timeGlobal) + ext
                vfileList = {
                    'time': timeGlobal,
                    'mimeType': ext
                }

            except:
                vfileList = None

            updateObj = await self.comments.insert_one(
                {
                    'convId': vConvId,
                    'time': timeGlobal,
                    'entityId': self.entityId,
                    'title': vComment,
                    'description': vDes,
                    'document': vfileList,
                    'creatorRole' : role,
                    'createdBy': {
                        'accountId': self.accountId,
                        'profileId': self.profileId,
                        'at': timeGlobal
                    },
                    'lastModifiedBy': {
                        'accountId': self.accountId,
                        'profileId': self.profileId,
                        'at': timeGlobal
                    }
                }
            )
            if updateObj.inserted_id:
                message = 'New update has been submitted.'
                code = 2000
                status = True
                if vfileList:
                    uPath = self.fu.uploads + 'rc-homestay'
                    if not os.path.exists(uPath):
                        os.system('mkdir -p ' + uPath)
                        os.system('chmod 755 -R ' + uPath)

                    uPath = uPath + '/auditinfo/'
                    if not os.path.exists(uPath):
                        os.system('mkdir -p ' + uPath)
                        os.system('chmod 755 -R ' + uPath)

                    orgFile = open(uPath + fileName, 'wb')
                    orgFile.write(vfile['body'])
                    orgFile.close()

        except Exception as e:
            status = False
            # self.set_status(503)
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(bdumps(response))
            await self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            # self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return
