import json
from bson import ObjectId
from lib.xen_protocol import noXenSecureV2
import tornado.web
from util.conn_util import MongoMixin
from util.log_util import Log
from build_config import CONFIG
import sys

@noXenSecureV2
class CheckUpdateHandler(tornado.web.RequestHandler, MongoMixin):

    SUPPORTED_METHODS = ('GET','OPTIONS','POST')

    applications = MongoMixin.userDb[
                    CONFIG['database'][0]['table'][1]['name']
                ]

    entity = MongoMixin.userDb[
                    CONFIG['database'][0]['table'][4]['name']
                ]
    def options(self):
        self.set_status(200)
        self.write({})
        self.finish()
        return

    async def get(self):

        status = False
        code = 4000
        result = []
        message = ''

        try:
            # TODO: this need to be moved in a global class
            entityQ = self.entity.find(
                                {
                                    '_id': self.entityId
                                },
                                limit=1
                            )
            entity = []
            async for i in entityQ:
                entity.append(i)
            if not len(entity):
                code = 4003
                message = 'You are not Authorized.'
                self.set_status(401)
                raise Exception
            try:
                Id = str(self.request.arguments['id'][0].decode())
                if Id is not None:
                    try:
                        Id = ObjectId(Id)
                    except:
                        raise Exception
                else:
                    raise Exception
            except:
                code == 4310
                message = 'Invalid Argument - [ id ].'
                raise Exception
            applicationQ = self.applications.find(
                            {
                                '_id': Id,
                                'disabled': False
                            },
                            limit=1
                    )
            application = []
            async for i in applicationQ:
                application.append(i)
            if len(application):
                status = True
                code = 2000
                message = 'Version Code Found.'
                result.append(
                            application[0]['versionCode']
                        )
            else:
                status = False
                code = 4201
                message = 'Application Not Found.'
        except Exception as e:
            status = False
            result = []
            #self.set_status(400)
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response =  {
                    'code': code,
                    'status': status,
                    'message': message
                }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(response)
            self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response =  {
                    'code': code,
                    'status': status,
                    'message': message
                }
            self.write(response)
            self.finish()
            return
        
    async def post(self):

        status = False
        code = 4000
        result = []
        message = ''

        try:
            # TODO: this need to be moved in a global class
            entityQ = self.entity.find(
                                {
                                    '_id': self.entityId
                                },
                                limit=1
                            )
            entity = []
            async for i in entityQ:
                entity.append(i)
            if not len(entity):
                code = 4003
                message = 'You are not Authorized.'
                self.set_status(401)
                raise Exception
            try:
                self.request.arguments = json.loads(self.request.body.decode())
            except:
                code = 3465
                message = 'Expected Request Type JSON.'
                raise Exception
            try:
                Id = str(self.request.arguments.get('id'))
                vCode = int(self.request.arguments.get('versionCode'))
                if Id is not None and vCode is not None:
                    try:
                        Id = ObjectId(Id)
                    except:
                        raise Exception
                else:
                    raise Exception
            except:
                code == 4310
                message = 'Invalid Argument - [ id , versionCode].'
                raise Exception
            applicationQ = self.applications.find(
                            {
                                '_id': Id,
                                'disabled': False
                            },
                            limit=1
                    )
            application = []
            async for i in applicationQ:
                application.append(i)
            if len(application):
                count = await self.applications.update_one({'_id':Id}, {'$set': {'versionCode': vCode}})
                if count.modified_count:
                    status = True
                    code = 4280
                    message = 'Version Code Updated'
                else:
                    status = False
                    code = 4281
                    message = 'Version Code Not Updated'
            else:
                status = False
                code = 4201
                message = 'Application Not Found.'
        except Exception as e:
            status = False
            result = []
            #self.set_status(400)
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response =  {
                    'code': code,
                    'status': status,
                    'message': message
                }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(response)
            self.finish()
            return

        except Exception as e:
            status = False
            result = []
            #self.set_status(400)
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response =  {
                    'code': code,
                    'status': status,
                    'message': message
                }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(response)
            self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response =  {
                    'code': code,
                    'status': status,
                    'message': message
                }
            self.write(response)
            self.finish()
            return

