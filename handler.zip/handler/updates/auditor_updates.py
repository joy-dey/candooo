#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
    Description: AccommodationProviderGrievanceHandler
    Purpose: GET, POST Grievance
"""
import json
import mimetypes
import os
import sys

import tornado.web
from bson import ObjectId

from build_config import CONFIG
from lib.element_mixer import ElementMixer
from lib.lib import Validate
from lib.xen_protocol import xenSecureV2
from util.conn_util import MongoMixin
from util.file_util import FileUtil
from util.log_util import Log
from bson.json_util import dumps as bdumps

from util.time_util import timeNow


@xenSecureV2
class RURALAuditorUpdatesHandler(ElementMixer, MongoMixin):

    fu = FileUtil()

    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]

    app = MongoMixin.userDb[
        CONFIG['database'][0]['table'][1]['name']
    ]

    comments = MongoMixin.userDb[
        CONFIG['database'][0]['table'][20]['name']
    ]

    loanApplication = MongoMixin.userDb[
        CONFIG['database'][0]['table'][13]['name']
    ]

    componentId = ObjectId('63d39988458b78fdf4cf6c0d')

    async def get(self):
        code = 4000
        message = ''
        status = False
        result = []

        try:
            
            try:
                vId = str(self.request.arguments['id'][0].decode())
                if vId:
                    vId = ObjectId(vId)
                else:
                    message = 'Missing argument [id].'
                    code = 2194
                    raise Exception
            except:
                message = 'Invalid argument id.'
                code = 4094
                raise Exception
            
            loanFind = await self.loanApplication.find_one(
                {
                    '_id': vId
                },
                {
                    '_id': 1
                }
            )
            if not loanFind:
                message = 'Loan Application not found.'
                code = 4194
                raise Exception
            
            loanId = loanFind.get('_id')
            
            Log.i(loanId)

            
            try:
                f_limit = int(self.get_argument('limit'))
                f_skip = int(self.get_argument('skip'))
            except:
                f_limit = 0
                f_skip = 0

            updatePipeline = [
                    {
                        '$match': {
                            'entityId': self.entityId,
                            'convId': loanId
                        },
                    },
                    {
                        '$lookup': {
                            'from': self.account.name,
                            'localField': 'createdBy.accountId',
                            'foreignField': '_id',
                            'as': 'accountInfo',
                            'pipeline': [
                                {
                                    '$match': {
                                        '_id': {
                                            '$ne': self.accountId
                                        }
                                    }
                                },
                                {
                                    '$project': {
                                        '_id': 0,
                                        'firstName': 1,
                                        'lastName': 1
                                    }
                                }
                            ]
                        }
                    },
                    {
                        '$project': {
                            '_id': {
                                '$toString': '$_id'
                            },
                            'title': 1,
                            'description': 1,
                            'creatorRole' : 1,
                            'convId': {
                                '$toString': '$convId'
                            },
                            'entityId': {
                                '$toString': '$entityId'
                            },
                            'createdBy': {
                                'at': 1
                            },
                            'document': 1,
                            'accountInfo': 1
                        }
                    },
                    {
                        '$sort': {
                            '_id': -1
                        }
                    },
                    {
                        '$skip': f_skip
                    }
                ]
            if f_limit:
                updatePipeline.append(
                    {
                        '$limit': f_limit
                    }
                )


            findUpdatesQ = self.comments.aggregate(updatePipeline)

            async for update in findUpdatesQ:
                result.append(update)

            if not len(result):
                message = 'No data found.'
                code = 4043
            else:
                message = ''
                code = 2000
                status = True
        except Exception as e:
            status = False
            # self.set_status(503)
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(bdumps(response))
            await self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            # self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return

    async def post(self):
        code = 4000
        message = ''
        status = False
        result = []
        try:
            
            try:
                file_dic = {}
                arg_dic = {}
                b = self.request.headers.get('Content-Type')
                tornado.httputil.parse_body_arguments(
                    b, self.request.body, arg_dic, file_dic)
            except:
                code = 4323
                message = 'Expected request type form-data.'
                raise Exception
            
            try:
                vId = str(self.request.arguments['id'][0].decode())
                if vId:
                    vId = ObjectId(vId)
                else:
                    message = 'Missing argument [id].'
                    code = 2194
                    raise Exception
            except:
                message = 'Invalid argument id.'
                code = 4094
                raise Exception
            
            vApp = await self.app.find_one(
                {
                    '_id': self.applicationId
                },
                {
                    'title': 1
                }
                )
            role = vApp.get('title')
            
            loanFind = await self.loanApplication.find_one(
                {
                    '_id': vId
                },
                {
                    '_id': 1
                }
            )
            if not loanFind:
                message = 'Loan Application not found.'
                code = 4194
                raise Exception
            
            loanId = loanFind.get('_id')

            try:
                vComment = str(self.request.arguments['title'][0].decode())
            except:
                vComment = None

            code, message = Validate.i(
                vComment,
                'title',
                notNull=True,
                notEmpty=True,
                dataType=str,
                minLength=5,
                maxLength=500
            )
            if code != 4100:
                raise Exception

            fileName = None
            timeGlobal = timeNow()
            try:
                vfile = file_dic.get('attachment')
                vfile = vfile[0]
                vfileExt = vfile['content_type']
                ext = mimetypes.guess_extension(vfileExt)
                if ext not in ['.jpg', '.jpeg', '.png']:
                    message = 'File should be in jpg or png or jpeg format.'
                    code = 6997
                    raise Exception

                fileName = str(timeGlobal) + ext
                vfileList = {
                    'time': timeGlobal,
                    'mimeType': ext
                }
            except:
                vfileList = None

            updateObj = await self.comments.insert_one(
                {
                    'convId': loanId,
                    'time': timeGlobal,
                    'entityId': self.entityId,
                    'title': vComment,
                    'document': vfileList,
                    'creatorRole' : role,
                    'createdBy': {
                        'accountId': self.accountId,
                        'profileId': self.profileId,
                        'at': timeGlobal
                    },
                    'lastModifiedBy': {
                        'accountId': self.accountId,
                        'profileId': self.profileId,
                        'at': timeGlobal
                    }
                }
            )
            if updateObj.inserted_id:
                message = 'New comment has been sent.'
                code = 2000
                status = True
                if vfileList:
                    uPath = self.fu.uploads + 'rc-homestay'
                    if not os.path.exists(uPath):
                        os.system('mkdir -p ' + uPath)
                        os.system('chmod 755 -R ' + uPath)

                    uPath = uPath + '/auditinfo/'
                    if not os.path.exists(uPath):
                        os.system('mkdir -p ' + uPath)
                        os.system('chmod 755 -R ' + uPath)

                    orgFile = open(uPath + fileName, 'wb')
                    orgFile.write(vfile['body'])
                    orgFile.close()

        except Exception as e:
            status = False
            # self.set_status(503)
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(bdumps(response))
            await self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            # self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return
