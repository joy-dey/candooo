#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
from lib.lib import Validate

import tornado

from build_config import CONFIG
from lib.xen_protocol import xenSecureV2, noXenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log
from bson import ObjectId


@xenSecureV2
class RejectedReasonHandler(tornado.web.RequestHandler, MongoMixin):

    SUPPORTED_METHODS = ('GET')

    applications = MongoMixin.userDb[
        CONFIG['database'][0]['table'][1]['name']
    ]

    profile = MongoMixin.userDb[
        CONFIG['database'][0]['table'][2]['name']
    ]

    entity = MongoMixin.userDb[
        CONFIG['database'][0]['table'][4]['name']
    ]

    rejectionReasons = MongoMixin.userDb[
        CONFIG['database'][0]['table'][11]['name']
    ]

    async def get(self):

        status = False
        code = 4000
        result = []
        message = ''

        try:

            try:
                mSearchWith = self.get_argument('rejectedBy')
            except:
                code = 3939
                message = 'Missing Argument - [ rejectedBy ].'
                raise Exception
            
            code, message = Validate.i(
                mSearchWith,
                'Rejected By',
                dataType=str,
                notNull = True,
                notEmpty = True,
                noSymbol = True
            )
            if code != 4100:
                raise Exception

            if mSearchWith == 'Rejected By Bank':
                search = 'bank'
            elif mSearchWith == 'Rejected By DIC':
                search = 'dic'
            else:
                code = 3839
                message = 'Invalid Argument - [ rejectedBy ].'
                raise Exception
            
            mReasonFind = self.rejectionReasons.find(
                {
                    'rejectedBy' : search
                }
            )

            async for i in mReasonFind:
                i['_id'] = str(i.get('_id'))
                reas = i.get('reason')
                if i['rejectedBy'] == 'bank' and reas == 'Other':
                    continue
                if 'Intrest' in str(reas):
                    i['reason'] = i['reason'].replace('Intrest', 'Interest')
                result.append(i)
                
            if len(result):
                code = 2000
                status = True
            else:
                code = 4253
                message = 'Data not Found'
                raise Exception             

        except Exception as e:
            status = False
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(response)
            self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            self.finish()
            return

    async def delete(self):

        status = False
        code = 4000
        result = []
        message = ''

        try:

            mIds = self.get_argument('ids')
            code, message = Validate.i(
                mIds,
                'ids',
                dataType=list,
                notEmpty=True
            )
            if code != 4100:
                raise Exception

            allIds = []            
            if mIds:
                for i in mIds:
                    try:
                        i = ObjectId(i)
                        allIds.append(i)
                    except:
                        code = 4126
                        message = 'Invalid Id of no. {}'.format(i+1)
                        raise Exception
            


            mReasonFind = await self.rejectionReasons.find(
                {
                    '_id': {
                        '$in': allIds
                    }
                }
            )
            if mReasonFind.deleted_count:
                code = 2000
                message = 'Data Deleted'
                status = True
            else:
                code = 4053
                message = 'Data not Deleted'
                raise Exception            

        except Exception as e:
            status = False
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(response)
            self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            self.finish()
            return