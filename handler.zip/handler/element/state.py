#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys

import tornado

from build_config import CONFIG
from lib.xen_protocol import xenSecureV2, noXenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log


@noXenSecureV2
class StateHandler(tornado.web.RequestHandler, MongoMixin):

    SUPPORTED_METHODS = ('GET')

    applications = MongoMixin.userDb[
        CONFIG['database'][0]['table'][1]['name']
    ]

    profile = MongoMixin.userDb[
        CONFIG['database'][0]['table'][2]['name']
    ]

    entity = MongoMixin.userDb[
        CONFIG['database'][0]['table'][4]['name']
    ]

    phoneCountry = MongoMixin.userDb[
        CONFIG['database'][0]['table'][5]['name']
    ]

    state = MongoMixin.userDb[
        CONFIG['database'][0]['table'][6]['name']
    ]

    async def get(self):

        status = False
        code = 4000
        result = []
        message = ''

        try:

            try:
                limit = int(self.get_arguments('limit')[0])
            except:
                limit = 0

            try:
                skip = int(self.get_arguments('skip')[0])
            except:
                skip = 0

            stateQ = self.state.find(
                {
        
                },
                limit=limit,
                skip=skip
            )

            async for i in stateQ:

                i['_id'] = str(i['_id'])

                result.append(i)


            if len(result):
                message = 'Data Found'
                code = 2000
                status = True
            else:
                code = 3030
                message = 'No data Found.'

        except Exception as e:
            status = False
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(response)
            self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            self.finish()
            return
