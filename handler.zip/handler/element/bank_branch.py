#!/usr/bin/ApplicationHandler
# -*- coding: utf-8 -*-

"""
"""
import json
import sys

from bson import ObjectId
from lib.xen_protocol import xenSecureV2
import tornado.web
from abc import ABCMeta

from build_config import CONFIG
from lib.element_mixer import ElementMixer
from util.conn_util import MongoMixin
from util.log_util import Log



@xenSecureV2
class BankBranchHandler(tornado.web.RequestHandler, MongoMixin, metaclass=ABCMeta):

    SUPPORTED_METHODS = ('GET')

    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]

    bankBranch = MongoMixin.userDb[
        CONFIG['database'][0]['table'][22]['name']
    ]

    async def get(self):

        code = 4000
        status = False
        message = ''
        result = []

        try:
            try:
                district = self.get_arguments('district')[0]
            except:
                district = None

            if district:
                try:
                    district = ObjectId(district)
                except:
                    code = 3738
                    message = 'Invalid argument - [ district ].'
                    raise Exception
                
                mFindBranch = self.bankBranch.find(
                    {
                        'district': ObjectId(district)
                    }
                )
            else:
                mFindBranch = self.bankBranch.find({})

            async for i in mFindBranch:
               if i.get('branchName') != 'Unknown Branch':
                i['_id'] = str(i.get('_id'))
                i['district'] = str(i.get('district'))

                result.append(i)

            if len(result):
                code = 2000
                status = True
            else:
                code = 4049
                message = 'Data not Found'
                raise Exception
            
        except Exception as e:
            status = False
            self.set_status(503)

            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))

        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)

        try:
            self.set_header('Content-Type', 'application/json')
            response['result'] = result
            self.write(json.dumps(response))
            await self.finish()
            return

        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return