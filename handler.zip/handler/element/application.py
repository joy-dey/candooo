#!/usr/bin/ApplicationHandler
# -*- coding: utf-8 -*-

"""
"""
import json
import sys
import tornado.web
from abc import ABCMeta

from bson import ObjectId
from bson.json_util import dumps as bdumps

from build_config import CONFIG
from lib.element_mixer import ElementMixer
from lib.lib import Validate
from lib.xen_protocol import noXenSecureV2, xenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log


@noXenSecureV2
class ApplicationHandler(tornado.web.RequestHandler, MongoMixin, metaclass=ABCMeta):

    SUPPORTED_METHODS = ('GET')

    applications = MongoMixin.userDb[
        CONFIG['database'][0]['table'][1]['name']
    ]

    async def get(self):

        code = 4000
        status = False
        message = ''
        result = []

        try:
            applicationQ = self.applications.find(
                {

                },
                {
                    '_id': 1,
                    'title': 1
                }
            )
            async for i in applicationQ:
                result.append(i)

            if len(result):
                code = 2000
                status = True
            else:
                code = 4091
                message = 'Account not found.'

        except Exception as e:
            if code != 4000:
                status = False
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5011
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
                response = {
                    'code': code,
                    'status': status,
                    'message': message
                }
                self.write(response)
                await self.finish()
                return

        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        response['result'] = result
        self.write(bdumps(response))
        await self.finish()

