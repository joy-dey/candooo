#!/usr/bin/ApplicationHandler
# -*- coding: utf-8 -*-

"""
"""
import json
import sys
import tornado.web
from abc import ABCMeta
import datetime
from util.time_util import timeNow
from lib.lib import Validate

from bson import ObjectId
from bson.json_util import dumps as bdumps

from build_config import CONFIG
from lib.element_mixer import ElementMixer
from lib.lib import Validate
from lib.xen_protocol import noXenSecureV2, xenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log
from pymongo import ASCENDING


@noXenSecureV2
class DistrictInfoHandler(tornado.web.RequestHandler, MongoMixin, metaclass=ABCMeta):

    SUPPORTED_METHODS = ('GET')

    districts = MongoMixin.userDb[
        CONFIG['database'][0]['table'][14]['name']
    ]

    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]

    async def get(self):

        code = 4000
        status = False
        message = ''
        result = []

        try:
            try:
                vId = self.get_query_argument('id')
                if not vId:
                    raise Exception
            except:
                vId = None
            
            if vId is not None:    
                try:
                    vId = ObjectId(vId)
                except:
                    message =  "Invalid argument - [id]"
                    code = 4914
                    status = False
                    raise Exception 
                sId = {
                    '_id' : vId
                }
            else:
                sId = None
            
            try:
                mAccountId = self.get_argument('accountId')
                if not mAccountId:
                    raise Exception
                mAccountId = ObjectId(mAccountId)
            except:
                mAccountId = None
                
            try:
                stateC = self.get_query_argument('stateCode')
                if not stateC:
                    raise Exception
            except:
                stateC = None
                
            if stateC is not None:
                code = {
                    'stateCode' : stateC
                }
            else:
                code = None
                          
            pipeline = []

            if sId is not None:
                pipeline.append({
                    '$match': sId
                })
                
            if code is not None:
                pipeline.append({
                    '$match': code
                })
                
            pipeline.extend([
                {
                    '$project': {
                        'districtName': 1,
                        'code': 1,
                        'stateCode' : 1
                    }
                },
                {
                    '$sort': {
                        'Name': ASCENDING  
                    }
                }
            ])

            if mAccountId:
                accountQ = await self.account.find_one(
                    {
                        '_id': mAccountId
                    },
                    {
                        'role': 1
                    }
                )
                if accountQ:
                    if accountQ.get('role') == 'Auditor':
                        accountFind = self.account.aggregate(
                            [
                                {
                                    '$match': {
                                        '_id': mAccountId
                                    }
                                },
                                {
                                    '$lookup': {
                                        'from': self.districts.name,
                                        'localField': 'districts',
                                        'foreignField': '_id',
                                        'as': 'districtInfo',
                                        'pipeline': [
                                            {
                                                '$project': {
                                                    '_id': {
                                                        '$toString': '$_id'
                                                    },
                                                    'code': 1,
                                                    'districtName': 1,
                                                    'stateCode' : 1
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    '$project':{
                                        '_id': {
                                            '$toString': '$_id'
                                        },
                                        'firstName': 1,
                                        'lastName': 1,
                                        'role': 1,
                                        'designation': 1,
                                        'districtInfo': 1
                                    }
                                }
                            ]
                        )
                        async for i in accountFind:
                            result.append(i)
                        
                        if len(result):
                            code = 2000
                            message = 'District Found'
                            status = True
                        else:
                            code = 4156
                            status = False
                            message = 'Account has no allotted districts'

                    else:
                        districtQ = self.districts.aggregate(pipeline)
                        async for i in districtQ:
                            i['_id'] = str(i.get('_id'))
                            result.append(i)

                        if len(result):
                            code = 2000
                            message = 'District Found'
                            status = True
                        else:
                            code = 4091
                            status = False
                            message = 'District not found.'

                else:
                    code = 4196
                    message = 'Account not found'
                    raise Exception
            else:
                districtQ = self.districts.aggregate(pipeline)
                async for i in districtQ:
                    i['_id'] = str(i.get('_id'))
                    result.append(i)

                if len(result):
                    code = 2000
                    message = 'District Found'
                    status = True
                else:
                    code = 4204
                    status = False
                    message = 'District not found.'
                    
        except Exception as e:
            status = False
            self.set_status(503)

            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))

        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)

        try:
            self.set_header('Content-Type', 'application/json')
            response['result'] = result
            self.write(bdumps(response))
            await self.finish()
            return

        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return