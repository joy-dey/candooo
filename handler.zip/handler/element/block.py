#!/usr/bin/ApplicationHandler
# -*- coding: utf-8 -*-

"""
"""
import json
import sys
import tornado.web
from abc import ABCMeta
import datetime
from util.time_util import timeNow
from lib.lib import Validate

from bson import ObjectId
from bson.json_util import dumps as bdumps

from build_config import CONFIG
from lib.element_mixer import ElementMixer
from lib.lib import Validate
from lib.xen_protocol import noXenSecureV2, xenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log
from pymongo import ASCENDING


@noXenSecureV2
class BlockInfoHandler(tornado.web.RequestHandler, MongoMixin, metaclass=ABCMeta):

    SUPPORTED_METHODS = ('GET')

    block = MongoMixin.userDb[
        CONFIG['database'][0]['table'][15]['name']
    ]

    districts = MongoMixin.userDb[
        CONFIG['database'][0]['table'][14]['name']
    ]

    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]

    async def get(self):

        code = 4000
        status = False
        message = ''
        result = []

        try:
            dId = {}
            try:
                vId = self.get_query_argument('id')
                if not vId:
                    raise Exception
            except:
                vId = None
            
            if vId is not None:    
                try:
                    vId = ObjectId(vId)
                except:
                    message =  "Invalid argument - [id]"
                    code = 4914
                    status = False
                    raise Exception 
                dId['_id'] = vId
            else:
                dId = None

            try:
                districtC = str(self.get_query_argument('code'))
                if not districtC:
                    raise Exception
            except:
                districtC = None
            
            try:
                mDistrict = self.get_argument('districtId')
                if not mDistrict:
                    raise Exception
                code, message = Validate.i(
                    mDistrict,
                    'districtId',
                    dataType=str,
                    notEmpty=True
                )
                if code != 4100:
                    raise Exception
                mDistrict = ObjectId(mDistrict)
            except:
                mDistrict = None

            if mDistrict:
                distFind = await self.districts.find_one(
                    {
                        '_id': mDistrict
                    }
                )
                if distFind:
                    districtC = distFind.get('code')
                else:
                    code = 4111
                    message = 'District not found'
                    raise Exception
                      
            try:
                mAccountId = self.get_argument('accountId')
                if not mAccountId:
                    raise Exception
                mAccountId = ObjectId(mAccountId)
            except:
                mAccountId = None
          
            dCode = {}   
            if districtC:
                dCode['districtCode'] = districtC
            else:
                dCode = None
                          
            pipeline = []
            if dId:
                pipeline.append({
                    '$match': dId
                })
                
            if dCode:
                pipeline.append({
                    '$match': dCode
                })
                
            pipeline.extend([
                {
                    '$project': {
                        'blockName': 1,
                        'code': 1,
                        'districtCode' : 1
                    }
                },
                {
                    '$sort': {
                        'Name': ASCENDING  
                    }
                }
            ])

            if mAccountId:
                accountQ = await self.account.find_one(
                    {
                        '_id': mAccountId
                    },
                    {
                        'role': 1
                    }
                )
                if accountQ:
                    if accountQ.get('role') == 'Auditor':
                        accountFind = self.account.aggregate(
                            [
                                {
                                    '$match': {
                                        '_id': mAccountId
                                    }
                                },
                                {
                                    '$lookup': {
                                        'from': self.districts.name,
                                        'localField': 'districts',
                                        'foreignField': '_id',
                                        'as': 'districtInfo',
                                        'pipeline': [
                                            {
                                                '$lookup': {
                                                    'from': self.block.name,
                                                    'localField': 'code',
                                                    'foreignField': 'districtCode',
                                                    'as': 'blockInfo',
                                                    'pipeline': [
                                                        {
                                                            '$project': {
                                                                '_id': {
                                                                    '$toString': '$_id'
                                                                },
                                                                'blockName': 1,
                                                                'districtCode': 1
                                                            }
                                                        }
                                                    ]
                                                }
                                            },
                                            {
                                                '$project': {
                                                    '_id': {
                                                        '$toString': '$_id'
                                                    },
                                                    'districtName': 1,
                                                    'blockInfo': 1
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    '$project':{
                                        '_id': {
                                            '$toString': '$_id'
                                        },
                                        'firstName': 1,
                                        'lastName': 1,
                                        'role': 1,
                                        'designation': 1,
                                        'districtInfo': 1
                                    }
                                }
                            ]
                        )
                        async for i in accountFind:
                            result.append(i)
            
                        if len(result):
                            code = 2000
                            message = 'Block Found'
                            status = True
                        else:
                            code = 4156
                            status = False
                            message = 'Account has no allotted Blocks'

                    else:
                        blockQ = self.block.aggregate(pipeline)
                        async for i in blockQ:
                            result.append(i)

                        if len(result):
                            code = 2000
                            message = 'Block Found'
                            status = True
                        else:
                            code = 4213
                            status = False
                            message = 'Block not found.'

                else:
                        
                    code = 4219
                    status = False
                    message = 'Account not found'
                    raise Exception

            else:
                    blockQ = self.block.aggregate(pipeline)
                    async for i in blockQ:
                        result.append(i)

                    if len(result):
                        code = 2000
                        message = 'Block Found'
                        status = True
                    else:
                        code = 4234
                        status = False
                        message = 'Block not found.'

        except Exception as e:
            status = False
            self.set_status(503)

            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))

        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)

        try:
            self.set_header('Content-Type', 'application/json')
            response['result'] = result
            self.write(bdumps(response))
            await self.finish()
            return

        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return