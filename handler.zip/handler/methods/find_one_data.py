import sys

from util.log_util import Log


async def findData(dataBase, FieldName, FieldValue):
    code = 4000
    status = False
    message = ''
    result = []

    try:
        xFind = dataBase.aggregate(
            [
                {
                    '$addFields': {
                        FieldName: {
                            '$toLower': '${}'.format(FieldName)
                        }
                    }
                },
                {
                    '$match': {
                        FieldName: FieldValue.strip().lower()
                    }
                },
                {
                     '$project': {
                          '_id': 1,
                          FieldName: 1
                     }
                }
            ]
        )
    
        findQ = []
        async for i in xFind:
            findQ.append(i)
        
        if len(findQ):
            return findQ[0]
        else:
            return False
    except Exception as e:
            status = False
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            Log.d('RSP', response)
