import asyncio
import io
import os
import sys
import tempfile
import fitz
from util.file_util import FileUtil
from util.log_util import Log
from util.time_util import timeNow
import datetime


fu = FileUtil()
def insert_training_details(pdfPath, mApplicantName, mCertificateIssueDate):
    try:
        existingPDF = fitz.open(pdfPath)
        mCertificateIssueDate = int(mCertificateIssueDate / 1000 / 1000)
        mCertificateIssueDate = datetime.datetime.strftime(datetime.datetime.fromtimestamp(mCertificateIssueDate), '%d/%m/%Y')
        for page_num in range(existingPDF.page_count):
            page = existingPDF[page_num]
            page.insert_text((350, 308), mApplicantName, fontname='times-italic', fontsize=13, color=(0, 0, 0))
            page.insert_text((370, 425), mApplicantName, fontname='times-italic', fontsize=13, color=(0, 0, 0))
            page.insert_text((150, 505), mCertificateIssueDate, fontname='times-italic', fontsize=15, color=(0, 0, 0))
                        
        mPdfPath = io.BytesIO()        
        existingPDF.save(mPdfPath)
        existingPDF.close()
        return mPdfPath
    
    except Exception as e:
        status = False
        template = 'Exception: {0}. Argument: {1!r}'
        code = 5011
        # self.set_status(503)
        iMessage = template.format(type(e).__name__, e.args)
        message = 'Internal Error, Please Contact the Support Team.'
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = exc_tb.tb_frame.f_code.co_filename
        Log.w('EXC', iMessage)
        Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))