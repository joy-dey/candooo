import datetime
from util.log_util import Log
from util.time_util import timeNow


def age_calculate(dateOfBirth):
    try:
        mCurrentDate = int(timeNow() / 1000 / 1000)
        mDateOfBirth = int(dateOfBirth / 1000 / 1000)
        mCurrentDate = datetime.datetime.fromtimestamp(mCurrentDate)
        mDateOfBirth = datetime.datetime.fromtimestamp(mDateOfBirth)

        duration = int((mCurrentDate - mDateOfBirth).total_seconds())
        mAge = int(duration // (365.25 * 24 * 3600))

        return mAge
    except Exception as e:
        Log.i(e)