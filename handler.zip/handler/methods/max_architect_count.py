import math
import sys
from build_config import CONFIG
from util.conn_util import MongoMixin
from util.log_util import Log


account = MongoMixin.userDb[
    CONFIG['database'][0]['table'][0]['name']
]

profile = MongoMixin.userDb[
    CONFIG['database'][0]['table'][2]['name']
]

loanApplication = MongoMixin.userDb[
    CONFIG['database'][0]['table'][13]['name']
]

async def maxArchitectCount():
    code = 4000
    message = ''
    status = False

    try:
        totalApplications = await loanApplication.count_documents(
            {
                'data.currentStatus': {
                    '$in': ['Loan Sanctioned', 'Onhold/Discontinued', 'Disbursed', 'Copayment', 'Construction Completed']
                }
            }
        )
        
        totalArchitectFind = account.aggregate(
            [
                {
                    '$match': {
                        'designation': 'Architect'
                    }
                },
                {
                    '$lookup': {
                        'from': profile.name,
                        'localField': '_id',
                        'foreignField': 'accountId',
                        'as': 'profileInfo',
                        'pipeline': [
                            {
                                '$project': {
                                    '_id': {
                                        '$toString': '$_id'
                                    },
                                    'status': 1
                                }
                            }
                        ]
                    }
                },
                {
                    '$match':{
                        'profileInfo.status': 1
                    }
                },
                {
                    '$project': {
                        '_id': 1
                    }
                }
            ]
        )
        totalArchitects = 0
        async for i in totalArchitectFind:
            totalArchitects += 1
        try:
            maxArchitectCount = math.ceil(totalApplications/totalArchitects)
            return maxArchitectCount
        except:
            return False

    except Exception as e:
        status = False
        if not len(message):
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5010
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                    str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
