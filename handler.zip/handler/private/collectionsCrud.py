import json
import sys
import tornado.web
from bson import ObjectId
from bson.json_util import dumps as bdumps
from build_config import CONFIG
from lib.element_mixer import ElementMixer
from lib.lib import Validate
from lib.xen_protocol import xenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log

@xenSecureV2
class CollectionsHandler( ElementMixer, MongoMixin):

    account = MongoMixin.userDb[
                    CONFIG['database'][0]['table'][0]['name']
                ]

    applications = MongoMixin.userDb[
                    CONFIG['database'][0]['table'][1]['name']
                ]

    profile = MongoMixin.userDb[
                    CONFIG['database'][0]['table'][2]['name']
                ]

    entity = MongoMixin.userDb[
                    CONFIG['database'][0]['table'][5]['name']
                ]
    
    collections = CONFIG['database'][0]['table']         
    Db = MongoMixin.userDb
    
    componentId = ObjectId('63d38614458b78fdf4cf6bfa')
    
    async def post(self):

        status = False
        code = 4000
        result = []
        message = ''

        try:
            
            try:
                # CONVERTS BODY INTO JSON
                self.request.arguments = json.loads(self.request.body.decode())
            except Exception as e:
                Log.i(e)
                code = 4100
                message = 'Expected Request Type JSON.'
                raise Exception
            
            name = str(self.request.arguments.get("collectionName"))
            code, message = Validate.i(
                            name,
                            'collectionName',
                            notEmpty=True,
                            notnull=True,
                            dataType=str
                        )
            if code != 4100:
                raise Exception
            
            body = str(self.request.arguments.get("data"))
            code, message = Validate.i(
                            body,
                            'data',
                            notEmpty=True,
                            notnull=True,
                        )
            
            body = body.replace("'", "\"")
            body = body.replace("False", "false")
            body = body.replace("True", "true")
            body = json.loads(body)
            for k, v in body.items():
                if type(v) == str and 'ObjectId' in v:
                    body[k] = ObjectId(v.split('ObjectId(')[1].split(')')[0])
                elif type(v) == list:
                    for i in range(len(v)):
                        if 'ObjectId' in v[i]:
                            v[i] = ObjectId(v[i].split('ObjectId(')[1].split(')')[0])
                elif type(v) == dict:
                    for k2, v2 in v.items():
                        if 'ObjectId' in v2:
                            v[k2] = ObjectId(v2.split('ObjectId(')[1].split(')')[0])
            found = False
            for vName in self.collections:
                n = vName['name']
                if name == n:
                    found = True
                    break

            if found == True:
                try:
                    data = await self.Db[name].insert_one(body)
                    if data:
                        message = 'Data Added successfully.'
                        code = 4930
                        status = True
                    else:
                        code = 8654
                        message = 'No Data is present in the collection..'
                        raise Exception
                except Exception as e:
                    code = 4210
                    message = 'Internal error: ' + str(e)
                    raise Exception
            else:
                message = 'Collection not found.'
                code = 4949
                raise Exception
                
        except Exception as e:
            status = False
            #self.set_status(400)
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response =  {
                    'code': code,
                    'status': status,
                    'message': message
                }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(bdumps(response))
            self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response =  {
                    'code': code,
                    'status': status,
                    'message': message
                }
            self.write(response)
            self.finish()
            return
    
    async def delete(self):

        status = False
        code = 4000
        result = []
        message = ''

        try:                
            try: 
                method = int(self.request.arguments.get("method")[0].decode())
            except:
                code = 7898
                message = 'Argument missing - [ method ].'
                raise Exception
            
            code, message = Validate.i(
                            method,
                            'method',
                            notEmpty=True,
                            notnull=True,
                            dataType=int
                        )
            if code != 4100:
                raise Exception
            
            if method not in [1,2]:
                message = 'Invalid method.'
                code = 9392
                raise Exception

            if method == 1:
                name = str(self.request.arguments.get("collectionName")[0].decode())
                code, message = Validate.i(
                                name,
                                'collectionName',
                                notEmpty=True,
                                notnull=True,
                                dataType=str
                            )
                if code != 4100:
                    raise Exception
                
                found = False
                for vName in self.collections:
                    n = vName['name']
                    if name == n:
                        found = True
                        break

                if found == True:
                    try:
                        await self.Db[name].drop()
                        status = True
                        code = 2000
                        message = 'Collection has been deleted.'
                    except :
                        code = 4210
                        message = 'Collection could not be deleted: ' + str(e)
                        raise Exception
                else:
                    message = 'Collection not found.'
                    code = 4949
                    raise Exception
                
            elif method == 2:
                try:
                    vId = self.request.arguments.get("id")[0].decode()
                    try:
                        vId = ObjectId(vId)
                    except:
                        message = 'Invalid id.'
                        code = 9867
                        raise Exception
                except:
                    message = 'Please enter id.'
                    code = 8673
                    raise Exception
                
                code, message = Validate.i(
                                vId,
                                'id',
                                notEmpty=True,
                                notnull=True,
                                dataType=str
                )
                
                try:
                    name = self.request.arguments.get("collectionName")[0].decode()
                except:
                    code = 7897
                    message = 'Please enter collection name.'
                    raise Exception
                
                code, message = Validate.i(
                                name,
                                'collectionName',
                                notEmpty=True,
                                notnull=True,
                                dataType=str
                            )
                if code != 4100:
                    raise Exception
                
                found = False
                for vName in self.collections:
                    n = vName['name']
                    if name == n:
                        found = True
                        break
                    
                if found == True:
                    if name == 'profile':
                        try:
                            doc = await self.Db[name].find_one({"_id":ObjectId(vId)})         
                            if doc != None:
                                accId = doc.get('accountId')
                                deleteDoc = await self.Db[name].delete_one({"_id":ObjectId(vId)})
                                if deleteDoc.deleted_count > 0:
                                    deleteAccDoc = await self.account.delete_one({"_id":ObjectId(accId)})
                                    status = True
                                    code = 2000
                                    message = 'Document for the given Collection has been deleted.'
                                else:
                                    code = 4210
                                    message = 'Document could not be deleted.'
                                    raise Exception
                            else:
                                message = 'Document not found.'
                                code = 4949
                                raise Exception
                        except Exception as e:
                            code = 4210
                            message = 'Internal error: ' + str(e)
                            raise Exception
                        
                    elif name == 'account':
                        try:
                            doc = await self.Db[name].find_one({"_id":ObjectId(vId)})
                            if doc != None:
                                proId = doc.get('_id')
                                deleteDoc = await self.Db[name].delete_one({"_id":ObjectId(vId)})
                                if deleteDoc.deleted_count > 0:
                                    deleteProDoc = await self.profile.delete_one({"accountId":ObjectId(proId)})
                                    status = True
                                    code = 2000
                                    message = 'Document for the given Collection has been deleted.'
                                else:
                                    code = 4210
                                    message = 'Document could not be deleted.'
                                    raise Exception
                            else:
                                message = 'Document not found.'
                                code = 4949
                                raise Exception
                        except Exception as e:
                            code = 4210
                            message = 'Internal error: ' + str(e)
                            raise Exception
                    else:
                        try:
                            doc = await self.Db[name].find_one({"_id":ObjectId(vId)})
                            if doc != None:
                                deleteDoc = await self.Db[name].delete_one({"_id":ObjectId(vId)})
                                if deleteDoc.deleted_count > 0:
                                    status = True
                                    code = 2000
                                    message = 'Document for the given Collection has been deleted.'
                                else:
                                    code = 4210
                                    message = 'Document could not be deleted.'
                                    raise Exception
                            else:
                                message = 'Document not found.'
                                code = 4949
                                raise Exception
                        except Exception as e:
                            code = 4210
                            message = 'Internal error: ' + str(e)
                            raise Exception
                else:
                    message = 'Collection not found.'
                    code = 4949
                    raise Exception  
        except Exception as e:
            status = False
            #self.set_status(400)
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response =  {
                    'code': code,
                    'status': status,
                    'message': message
                }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(response)
            self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response =  {
                    'code': code,
                    'status': status,
                    'message': message
                }
            self.write(response)
            self.finish()
            return

    async def get(self):

        status = False
        code = 4000
        result = []
        message = ''

        try:
                        
            name = str(self.request.arguments.get("collectionName")[0].decode())
            code, message = Validate.i(
                            name,
                            'collectionName',
                            notEmpty=True,
                            notnull=True,
                            dataType=str
                        )
            if code != 4100:
                raise Exception
            
            try:
                vId = str(self.request.arguments.get("id")[0].decode())
            except:
                vId = None
                
            if vId != None:
                try:
                    vId = ObjectId(vId)
                except:
                    message = 'Invalid id.'
                    code = 9867
                    raise Exception
            
            code, message = Validate.i(
                            vId,
                            'id',
                            notEmpty=True,
                            notnull=True,
                            dataType=str
            )
            
            found = False
            for vName in self.collections:
                n = vName['name']
                if name == n:
                    found = True
                    break

            if found == True:
                try:
                    coll = self.Db[name]
                    if vId != None:
                        doc = await self.Db[name].find_one({"_id":vId})
                        if doc != None:
                            result.append(doc)
                            status = True
                            code = 2000
                            message = 'Document for the given Collection has been found.'
                        else:
                            message = 'Document not found.'
                            code = 4949
                            raise Exception
                    else:
                        data = coll.find({})
                        if data:
                            async for document in data:
                                result.append(document)
                        else:
                            code = 8654
                            message = 'No Data is present in the collection..'
                            raise Exception
                
                except Exception as e:
                    code = 4210
                    message = 'Internal error: ' + str(e)
                    raise Exception
            else:
                message = 'Collection not found.'
                code = 4949
                raise Exception
            
            if len(result):
                status = True
                code = 2000
                message = 'Collection Details has been found.'
            else:
                message = 'Collection Details could not be found.'
                code = 9642
                raise Exception

        except Exception as e:
            status = False
            #self.set_status(400)
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response =  {
                    'code': code,
                    'status': status,
                    'message': message
                }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(bdumps(response))
            self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response =  {
                    'code': code,
                    'status': status,
                    'message': message
                }
            self.write(response)
            self.finish()
            return