
import sys

from bson import ObjectId
from build_config import CONFIG
from lib.xen_protocol import xenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log
from bson.json_util import dumps as bdumps
from lib.element_mixer import ElementMixer

@xenSecureV2
class LogApiHandler(ElementMixer, MongoMixin):
    
    SUPPORTED_METHODS = ('DELETE', 'OPTIONS', 'GET', 'POST', 'PUT')

    account = MongoMixin.userDb[
                    CONFIG['database'][0]['table'][0]['name']
                ]

    applications = MongoMixin.userDb[
                    CONFIG['database'][0]['table'][1]['name']
                ]

    profile = MongoMixin.userDb[
                    CONFIG['database'][0]['table'][2]['name']
                ]

    entity = MongoMixin.userDb[
                    CONFIG['database'][0]['table'][5]['name']
                ]
    
    componentId = ObjectId('63d38614458b78fdf4cf6bfa')
    
    async def get(self):
        
        status = False
        code = 4000
        result = []
        message = ''
        
        try:
            log_path = './log/run.log'
            try:
                with open(log_path, 'r') as file:
                    # Read the last 500 lines
                    lines = file.readlines()
                    lines = lines[-500:]

                    result.append(lines)
                    status = True
                    code = 6789
                    message = 'Logs Found.'

            except FileNotFoundError:
                message = f"Error: File '{log_path}' not found."
                code = 7784
                raise Exception

            except Exception as e:
                message = f"Error reading file: {str(e)}"
                code = 6454
                raise Exception
                            
        except Exception as e:
            status = False
            #self.set_status(400)
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response =  {
                    'code': code,
                    'status': status,
                    'message': message
                }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(bdumps(response))
            self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response =  {
                    'code': code,
                    'status': status,
                    'message': message
                }
            self.write(response)
            self.finish()
            return