#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
    Description: AccommodationProviderGrievanceInfoHandler
    Purpose: GET, POST Grievance
"""
import json
import mimetypes
import os
import sys

import tornado.web
from bson import ObjectId

from build_config import CONFIG
from lib.element_mixer import ElementMixer
from lib.lib import Validate
from lib.xen_protocol import xenSecureV2
from util.conn_util import MongoMixin
from util.file_util import FileUtil
from util.log_util import Log
from bson.json_util import dumps as bdumps

from util.time_util import timeNow

@xenSecureV2
class AccommodationAuditorGrievanceInfoHandler(ElementMixer, MongoMixin):

    grConversation = MongoMixin.userDb[
        CONFIG['database'][0]['table'][17]['name']
    ]

    componentId = ObjectId('63d39988458b78fdf4cf6c0d')

    async def get(self):
        code = 4000
        message = ''
        status = False
        result = []

        try:
            try:
                convId = str(self.request.arguments.get('id')[0].decode())
                if not convId:
                    message = 'Missing Argument - [ id ].'
                    code = 4047
                    raise Exception
                convId = ObjectId(convId)
            except Exception as e:
                message = 'Invalid Argument - [ id ].'
                code = 4052
                raise Exception

            getIssueQ = self.grConversation.aggregate(
                [
                    {
                        '$match': {
                                '_id': convId
                            }
                    },
                    {
                        '$lookup': {
                                'from': CONFIG['database'][0]['table'][0]['name'],
                                'localField': 'createdBy',
                                'foreignField': '_id',
                                'as': 'accountInfo'
                            }
                    },
                    {
                         '$lookup': {
                                 'from': CONFIG['database'][0]['table'][0]['name'],
                                 'localField': 'modifiedBy',
                                 'foreignField': '_id',
                                 'as': 'adminInfo'
                         }
                    },
                    {
                         '$project': {
                             'title': 1,
                             'time': 1,
                             'description': 1,
                             'msg': 1,
                             'activity': 1,
                             'attachmentInfo': 1,
                             'comments': 1,
                             'accountInfo': {
                                 'firstName': 1,
                                 'lastName': 1
                             },
                             'adminInfo': {
                                 'firstName': 1,
                                 'lastName': 1
                             }
                         }
                     }
                 ]
            )
            async for i in getIssueQ:
                i['id'] = str(i.get('_id'))
                del i['_id']
                result.append(i)
            if len(result):
                message = 'Data found.'
                code = 2000
                status = True
            else:
                message = 'No data found.'
                code = 4001

        except Exception as e:
            status = False
            # self.set_status(503)
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(bdumps(response))
            await self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            # self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return