#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
    Description: AccommodationProviderGrievanceHandler
    Purpose: GET, POST Grievance
"""
import json
import mimetypes
import os
import sys

import tornado.web
from bson import ObjectId

from build_config import CONFIG
from lib.element_mixer import ElementMixer
from lib.lib import Validate
from lib.xen_protocol import xenSecureV2
from util.conn_util import MongoMixin
from util.file_util import FileUtil
from util.log_util import Log
from bson.json_util import dumps as bdumps
import base36

from util.time_util import timeNow

@xenSecureV2
class AccommodationAuditorGrievanceHandler(ElementMixer, MongoMixin):

    fu = FileUtil()

    grConversation = MongoMixin.userDb[
        CONFIG['database'][0]['table'][17]['name']
    ]

    componentId = ObjectId('63d39988458b78fdf4cf6c0d')

    async def get(self):
        code = 4000
        message = ''
        status = False
        result = []

        try:
            try:
                mActivityId = int(self.get_arguments('activityId')[0])
                if mActivityId is None or mActivityId == '':
                    raise Exception
            except:
                message = 'Missing Argument - [ activityId ].'
                code = 4053
                raise Exception
            code, message = Validate.i(
                mActivityId,
                'activityId',
                dataType=int
            )
            if code != 4100:
                raise Exception

            getIssueQ = self.grConversation.aggregate(
                [
                    {
                        '$match': {
                            'createdBy': self.accountId,
                        }
                    },
                    {
                        '$lookup': {
                            'from': CONFIG['database'][0]['table'][0]['name'],
                            'localField': 'createdBy',
                            'foreignField': '_id',
                            'as': 'accountInfo'
                        }
                    },
                    {
                        '$project': {
                            'title': 1,
                            'time': 1,
                            'description': 1,
                            'msg': 1,
                            'attachmentInfo': 1,
                            'comments': 1,
                            'activity': 1,
                            'lastActivity': {
                                '$arrayElemAt': ["$activity", -1]
                            }
                        }
                    },
                    {
                        '$match': {
                            'lastActivity.id': mActivityId
                        }
                    },
                    {
                        '$sort': {
                            '_id': -1
                        }
                    }
                ]
            )
            async for i in getIssueQ:
                i['id'] = str(i.get('_id'))
                del i['_id']
                i['grivId'] = base36.dumps(i.get('time')).upper()
                result.append(i)
                for res in result:
                    if len(res['attachmentInfo']):
                        for docx in res['attachmentInfo']:
                            docx['link'] = str(self.fu.serverUrl) + '/uploads/' \
                                           + 'rc-homestay' \
                                           + '/grievance/' + str(res['id']) + '/' + str(docx['time']) + docx['mimeType']
            if len(result):
                message = 'Data found.'
                code = 2000
                status = True
            else:
                message = 'No data found.'
                code = 4001

        except Exception as e:
            status = False
            # self.set_status(503)
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(bdumps(response))
            await self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            # self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return

    async def post(self):
        code = 4000
        message = ''
        status = False
        result = []
        try:
            try:
                file_dic = {}
                arg_dic = {}
                b = self.request.headers.get('Content-Type')
                tornado.httputil.parse_body_arguments(b, self.request.body, arg_dic, file_dic)
            except:
                code = 4323
                message = 'Expected request type form-data.'
                raise Exception

            vtitle = self.get_arguments('title')
            if not len(vtitle):
                message = 'Missing Argument - [ title ].'
                code = 4138
                raise Exception
            vtitle = vtitle[0]
            code, message = Validate.i(
                vtitle,
                'title',
                notNull=True,
                notEmpty=True,
                dataType=str
            )
            if code != 4100:
                raise Exception

            vdesc = self.get_arguments('description')
            if not len(vdesc):
                message = 'Missing Argument - [ description ].'
                code = 4138
                raise Exception
            vdesc = vdesc[0]
            code, message = Validate.i(
                vdesc,
                'description',
                notNull=True,
                notEmpty=True,
                dataType=str,
                maxLength=500
            )
            if code != 4100:
                raise Exception

            fileName = None
            modifiedAt = timeNow()
            try:
                vfile = file_dic.get('attachment')
                vfile = vfile[0]
                vfileExt = vfile['content_type']
                ext = mimetypes.guess_extension(vfileExt)
                if ext not in ['.jpg', '.jpeg', '.png']:
                    message = 'Image file should be in jpg or png or jpeg format.'
                    code = 6997
                    raise Exception

                vfileSize = len(vfile['body'])
                size = (vfileSize / (1024 * 1024))
                if size > 2:
                    message = 'Maximum size of the attachment should be 2Mb.'
                    code = 5433
                    raise Exception
                file = timeNow()
                fileName = str(file) + ext
                vfileList = [
                    {
                    'time': file,
                    'mimeType': ext,
                    'comment': modifiedAt
                    }
                ]
            except:
                vfileList = []

            timeGlobal = timeNow()
            insertMsgQ = await self.grConversation.insert_one(
                {
                    'title': vtitle,
                    'description': vdesc,
                    'time': timeGlobal,
                    'createdBy': self.accountId,
                    'modifiedBy': None,
                    'modifiedAt': timeGlobal,
                    'entityId': self.entityId,
                    'activity': [{
                        'time': timeGlobal,
                        'id': 0
                    }],
                    'totalAttachments': len(vfileList),
                    'comments': [],
                    'lastUpdatedTime': timeNow(),
                    'attachmentInfo': vfileList,
                }
            )
            vConvId = insertMsgQ.inserted_id
            if insertMsgQ.inserted_id:
                message = 'Ticket has been submitted.'
                code = 2000
                status = True
                if len(vfileList):
                    uPath = self.fu.uploads + '/' + 'rc-homestay'
                    if not os.path.exists(uPath):
                        os.system('mkdir -p ' + uPath)
                        os.system('chmod 755 -R ' + uPath)

                    uPath = uPath + '/grievance/'
                    if not os.path.exists(uPath):
                        os.system('mkdir -p ' + uPath)
                        os.system('chmod 755 -R ' + uPath)

                    uPath = uPath + str(vConvId) + '/'
                    if not os.path.exists(uPath):
                        os.system('mkdir -p ' + uPath)
                        os.system('chmod 755 -R ' + uPath)

                    orgFile = open(uPath + fileName, 'wb')
                    orgFile.write(vfile['body'])
                    orgFile.close()

        except Exception as e:
            status = False
            # self.set_status(503)
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(bdumps(response))
            await self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            # self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return