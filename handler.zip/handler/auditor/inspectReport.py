
import json
import mimetypes
import os
import sys
from abc import ABCMeta
from bson import ObjectId
import tornado.httputil
from build_config import CONFIG
from lib.lib import Validate
from lib.xen_protocol import xenSecureV2
from util.conn_util import MongoMixin
from util.file_util import FileUtil
from util.log_util import Log
from util.time_util import timeNow
from lib.element_mixer import ElementMixer
from bson.json_util import dumps
from PIL import Image
from lib.sendNotification import SendNotification
@xenSecureV2
class InspectionReportHandler(ElementMixer,  MongoMixin, metaclass=ABCMeta):

    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]

    loanApplication = MongoMixin.userDb[
        CONFIG['database'][0]['table'][13]['name']
    ]

    jointApplication = MongoMixin.userDb[
        CONFIG['database'][0]['table'][23]['name']
    ]
    
    district = MongoMixin.userDb[
        CONFIG['database'][0]['table'][14]['name']
    ]
    
    token = MongoMixin.userDb[
        CONFIG['database'][0]['table'][25]['name']
    ]

    fu = FileUtil()
    componentId = ObjectId('63d39988458b78fdf4cf6c0d')

    async def post(self):
        code = 4000
        message = ''
        status = False
        result = []
        try:
            
            try:
                file_dic = {}
                arg_dic = {}
                b = self.request.headers.get('Content-Type')
                tornado.httputil.parse_body_arguments(b, self.request.body, arg_dic, file_dic)
                meth = json.loads(arg_dic['method'][0])
                applicantId = json.loads(arg_dic['applicantId'][0])
            except:
                code = 4323
                message = 'Invalid body arguments.'
                raise Exception
            
            code, message = Validate.i(
                applicantId,
                'Applicant Id',
                dataType=str,
                notNull=True,
                noSpace=True,
                notEmpty=True,
            )
            if code != 4100:
                raise Exception
            
            applicantQ = await self.loanApplication.find_one(
                {
                    'applicantId' : applicantId
                }
            )
            if not applicantQ:
                code = 6575
                message = 'Applicant not found'
                raise Exception
            
            inspectQ = await self.jointApplication.find_one(
                {
                    'applicantId' : applicantId
                }
            )
                 
            code, message = Validate.i(
                meth,
                'Method',
                dataType = int,
                notNull=True,
                notEmpty=True,
            )
            if code != 4100:
                raise Exception
            
            if meth not in [1,2]:
                message = 'Not a valid value for argument method'
                code = 5783
                raise Exception
                
            if meth == 1:
                try:
                    geoCoordinates = json.loads(arg_dic['geoCoordinatesData'][0])
                except:
                    code = 4645
                    message = 'Invalid body arguments.'
                    raise Exception
                
                code, message = Validate.i(
                    geoCoordinates,
                    'Geo Coordinates Data',
                    dataType=dict,
                    notNull=True,
                    notEmpty=True
                )
                if code != 4100:
                    raise Exception
                
                geoCoordinates = geoCoordinates.get("geoCoordinates")
                code, message = Validate.i(
                    geoCoordinates,
                    'Geo Coordinates',
                    dataType = dict,
                    notNull=True,
                    notEmpty=True
                )
                
                lat = geoCoordinates.get("latitude")
                code, message = Validate.i(
                    lat,
                    'Latitude',
                    dataType = float,
                    notNull=True,
                    notEmpty=True
                )
                if code != 4100:
                    raise Exception
                
                long = geoCoordinates.get("longitude")
                code, message = Validate.i(
                    long,
                    'Longitude',
                    dataType = float,
                    notNull=True,
                    notEmpty=True
                )
                if code != 4100:
                    raise Exception
                
                
                address = geoCoordinates.get("address")
                code, message = Validate.i(
                    address,
                    'Address',
                    dataType = str,
                    notNull=True,
                    notEmpty=True
                )
                if code != 4100:
                    raise Exception
            else:
                ids = []
                recieverIds = []
                try:
                    inspectionForm = json.loads(arg_dic['inspectionFormData'][0])
                except:
                    code = 8763
                    message = 'Invalid body arguments.'
                    raise Exception
                
                inspectedBy = inspectionForm.get('inspectedBy')
                code, message = Validate.i(
                    inspectedBy,
                    'Inspected By',
                    dataType=list,
                    notNull=True,
                    notEmpty=True
                )
                if code != 4100:
                    raise Exception
                
                for data in inspectedBy:
                    
                    id = data.get('_id')
                    code, message = Validate.i(
                        id,
                        'Id',
                        dataType = str,
                        notNull=True,
                        notEmpty=True,
                        allSpace=True,
                        noSymbol=True,
                        noSpecial=True
                    )
                    if code != 4100:
                        raise Exception
                    
                    try:
                        id = ObjectId(id)
                    except:
                        code = 6523
                        message = 'Invalid argument Id'
                        raise Exception
                    
                    if id in ids:
                        code = 5484
                        message = 'Same Inspector cannot be selected multiple times'
                        raise Exception
                    
                    ids.append(id)
                    if id != self.accountId:
                        recieverIds.append(id)
                    data['_id'] = ObjectId(id)
                    if data['_id'] == self.accountId:
                        data['approved'] = True
                    else:
                        data['approved'] = False
                    name = data.get('name')
                    code, message = Validate.i(
                        name,
                        'Name',
                        dataType = str,
                        notNull=True,
                        notEmpty=True,
                        allSpace=True,
                        noSymbol=True,
                        noSpecial=True
                    )
                    if code != 4100:
                        raise Exception
                    
                    designation = data.get('designation')
                    code, message = Validate.i(
                        designation,
                        'Designation',
                        dataType = str,
                        notNull=True,
                        notEmpty=True,
                        allSpace=True,
                        noSymbol=True,
                        noSpecial=True
                    )
                    if code != 4100:
                        raise Exception
                    
                    phoneNumber = data.get('phoneNumber')
                    code, message = Validate.i(
                        phoneNumber,
                        'Phone Number',
                        dataType = int,
                        notNull=True,
                        notEmpty=True,
                    )
                    if code != 4100:
                        raise Exception
                    
                inspectionInfo = inspectionForm.get('inspectionInfo')
                code, message = Validate.i(
                    inspectionInfo,
                    'Inspection Info',
                    dataType=dict,
                    notNull=True,
                    notEmpty=True
                )
                if code != 4100:
                    raise Exception
                
                inspectDate = inspectionInfo.get("inspectionDate")
                code, message = Validate.i(
                    inspectDate,
                    'Inspection Date',
                    dataType = int,
                    notNull=True,
                    notEmpty=True
                )
                if code != 4100:
                    raise Exception
                
                district = inspectionInfo.get("district")
                code, message = Validate.i(
                    district,
                    'District',
                    dataType = str,
                    notNull=True,
                    notEmpty=True,
                    noSpace=True,
                    noSymbol=True,
                    noSpecial=True
                )
                if code != 4100:
                    raise Exception
                
                try:
                    district = ObjectId(district)
                except:
                    code = 4079
                    message = 'Invalid Argument - [ district ]'
                    raise Exception
                
                inspectionInfo['district'] = district
                districtF = await self.district.find_one(
                    {
                        '_id': district
                    }
                )
                if not districtF:
                    code = 4080
                    message = 'District Not Found'
                    raise Exception
                
                department = inspectionInfo.get("department")
                code, message = Validate.i(
                    department,
                    'Department',
                    dataType = list,
                    notNull=True,
                    notEmpty=True,
                )
                if code != 4100:
                    raise Exception
                
                for data in department:
                    data = data.lower()
                    if data not in ['commerce & industries', 'tourism', 'bank']:
                        code = 2345
                        message = 'Not a valid value for [ Department ]'
                        raise Exception
                    
                locationAccess = inspectionInfo.get("locationAccess")
                code, message = Validate.i(
                    locationAccess,
                    'Location Access',
                    dataType = str,
                    notNull=True,
                    noSpace=True,
                    notEmpty=True,
                    noSymbol=True,
                    noSpecial=True,
                )
                if code != 4100:
                    raise Exception
                
                locationAccess = locationAccess.lower()
                if locationAccess not in ['easy', 'medium', 'difficult']:
                    code = 2984
                    message = 'Not a valid value for [ Location Access ]'
                    raise Exception
                
                vehicleAccess = inspectionInfo.get("vehicleAccess")
                code, message = Validate.i(
                    vehicleAccess,
                    'Vehicle Access',
                    dataType = str,
                    notNull=True,
                    noSpace=True,
                    notEmpty=True,
                    noSymbol=True,
                    noSpecial=True,
                )
                if code != 4100:
                    raise Exception
                
                vehicleAccess = vehicleAccess.lower()
                if vehicleAccess not in ['yes', 'no']:
                    code = 4299
                    message = 'Not a valid value for [ Vehicle Access ]'
                    raise Exception
                
                propertyArea = inspectionInfo.get("propertyArea")
                code, message = Validate.i(
                    propertyArea,
                    'Property Area',
                    dataType = int,
                    notNull=True,
                    notEmpty=True,
                )
                if code != 4100:
                    raise Exception
                
                propertyUnit = inspectionInfo.get("propertyUnit")
                code, message = Validate.i(
                    propertyUnit,
                    'Property Unit',
                    dataType = str,
                    notNull=True,
                    allSpace=True,
                    notEmpty=True,
                    noSymbol=True,
                    noSpecial=True,
                )
                if code != 4100:
                    raise Exception
                
                waterAvailable = inspectionInfo.get("waterAvailability")
                code, message = Validate.i(
                    waterAvailable,
                    'Water Availability',
                    dataType = str,
                    notNull=True,
                    noSpace=True,
                    notEmpty=True,
                    noSymbol=True,
                    noSpecial=True,
                )
                if code != 4100:
                    raise Exception
                
                waterAvailable = waterAvailable.lower()
                if waterAvailable not in ['yes', 'no']:
                    code = 4892
                    message = 'Not a valid value for [ Water Availability ]'
                    raise Exception
                
                otherSource = None
                if waterAvailable == 'yes':
                    waterSource = inspectionInfo.get("waterSource")
                    code, message = Validate.i(
                        waterSource,
                        'Water Source',
                        dataType = list,
                        notEmpty = True,
                        notNull = True
                    )
                    if code != 4100:
                        raise Exception
                    
                    for source in waterSource:
                        source = source.lower()
                        if source not in ['supply', 'well', 'rainwater harvest', 'other']:
                            code = 4535
                            message = 'Not a valid value for [ Water Source ]'
                            raise Exception
                    
                        if waterSource == 'other':
                            otherSource = inspectionInfo.get("otherWaterSource")
                            code, message = Validate.i(
                                otherSource,
                                'Other Water Source',
                                dataType = str,
                                notNull=True,
                                noSpace=True,
                                notEmpty=True,
                                noSymbol=True,
                                noSpecial=True,
                                maxLength=200
                            )
                            if code != 4100:
                                raise Exception
                    
                electricAvailability = inspectionInfo.get("electricityAvailability")
                code, message = Validate.i(
                    electricAvailability,
                    'Electricity Availability',
                    dataType = str,
                    notNull=True,
                    noSpace=True,
                    notEmpty=True,
                    noSymbol=True,
                    noSpecial=True,
                )
                if code != 4100:
                    raise Exception
                
                electricAvailability = electricAvailability.lower()
                if electricAvailability not in ['yes', 'no']:
                    code = 5876
                    message = 'Not a valid value for [ Electricity Availability ]'
                    raise Exception
                
                existingStructures = inspectionInfo.get("existingStructures")
                code, message = Validate.i(
                    existingStructures,
                    'Existing Structures',
                    dataType = str,
                    notNull=True,
                    noSpace=True,
                    notEmpty=True,
                    noSymbol=True,
                    noSpecial=True,
                )
                if code != 4100:
                    raise Exception
                
                existingStructures = existingStructures.lower()
                if existingStructures not in ['yes', 'no']:
                    code = 5876
                    message = 'Not a valid value for [ Existing Structures ]'
                    raise Exception
                
                otherAmenities = inspectionInfo.get("otherAmenitiesAvailable")
                code, message = Validate.i(
                    otherAmenities,
                    'Other Amenities Available',
                    dataType = list,
                    notNull=True,
                    notEmpty=True,
                )
                if code != 4100:
                    raise Exception

                viableForHomestay = inspectionInfo.get("viableHomestay")
                code, message = Validate.i(
                    viableForHomestay,
                    'Viable Homestay',
                    dataType = str,
                    notNull=True,
                    noSpace=True,
                    notEmpty=True,
                    noSymbol=True,
                    noSpecial=True,
                )
                if code != 4100:
                    raise Exception
                
                viableForHomestay = viableForHomestay.lower()
                if viableForHomestay not in ['yes', 'no']:
                    code = 9868
                    message = 'Not a valid value for [ Viable Homestay ]'
                    raise Exception
                
                try:
                    remarks = inspectionInfo.get("remarks")
                except:
                    remarks = ""
                
                if remarks == "":
                    remarks = None
                    inspectionInfo['remarks'] = remarks
                if remarks != None:
                    code, message = Validate.i(
                        remarks,
                        'Remarks',
                        dataType = str,
                        notNull=True,
                        allSpace=True,
                        notEmpty=True,
                        maxLength=100
                    )
                    if code != 4100:
                        raise Exception
                
                try:
                    existingStructureRemarks = inspectionInfo.get("existingStructureRemarks")
                except:
                    existingStructureRemarks = ""
                
                if existingStructureRemarks == "":
                    existingStructureRemarks = None
                    inspectionInfo['existingStructureRemarks'] = existingStructureRemarks
                if existingStructureRemarks != None:
                    code, message = Validate.i(
                        existingStructureRemarks,
                        'Existing Structure Remarks',
                        dataType = str,
                        notNull=True,
                        allSpace=True,
                        notEmpty=True,
                        maxLength=100
                    )
                    if code != 4100:
                        raise Exception
                
                try:
                    electricityRemarks = inspectionInfo.get("electricityRemarks")
                except:
                    electricityRemarks = ""
                
                if electricityRemarks == "":
                    electricityRemarks = None
                    inspectionInfo['electricityRemarks'] = electricityRemarks
                if electricityRemarks != None:
                    code, message = Validate.i(
                        electricityRemarks,
                        'Electricity Remarks',
                        dataType = str,
                        notNull=True,
                        allSpace=True,
                        notEmpty=True,
                        maxLength=100
                    )
                    if code != 4100:
                        raise Exception
                    
                try:
                    vehicleRemarks = inspectionInfo.get("vehicleRemarks")
                except:
                    vehicleRemarks = ""
                
                if vehicleRemarks == "":
                    vehicleRemarks = None
                    inspectionInfo['vehicleRemarks'] = vehicleRemarks
                if vehicleRemarks != None:
                    code, message = Validate.i(
                        vehicleRemarks,
                        'Vehicle Remarks',
                        dataType = str,
                        notNull=True,
                        allSpace=True,
                        notEmpty=True,
                        maxLength=100
                    )
                    if code != 4100:
                        raise Exception
                    
                try:
                    images = file_dic.get('images')
                except:
                    images = None
                
                if images == None:
                    images = []
                if images != []:
                    code,message,Validate.i(
                        images,
                        "Images",
                        notNull = True,
                        notEmpty = True,
                        dataType = list
                    )
                    if code != 4100:
                        raise Exception
                
                uPath = self.fu.uploads
                uPath =  uPath + 'rc-homestay/inspectionReport/images/'
                vImages = []
                if len(images) > 0:
                    for idx, image in enumerate(images):
                        if idx == 4:
                            code = 9292
                            message = 'Maximum 4 images can be uploaded.'
                            raise Exception(code, message)
                        
                        try:
                            extension = image['content_type']
                            ext = mimetypes.guess_extension(extension)
                        except Exception as e:
                            message = 'Please upload a valid image.'
                            code = 6997
                            raise Exception(code, message)
                        
                        if ext not in ['.jpg', '.jpeg', '.png']:
                            message = 'Image file should be in jpg or png or jpeg format.'
                            code = 6997
                            raise Exception(code, message)
                        
                        saveTime = timeNow()
                        filename = f"inspectionReport_image_{saveTime}{ext}"
                        filenamewithoutext = f"inspectionReport_image_{saveTime}"
                        v = {
                            'imageName': filenamewithoutext,
                            'mimeType': ext
                        }
                        
                        vImages.append(v)
                        if inspectQ is None:
                            if not os.path.exists(uPath):
                                os.makedirs(uPath)
                                os.chmod(uPath, 0o755)
                                Log.i('File directory created {}'.format(uPath))
                            
                            with open(os.path.join(uPath, filename), 'wb') as f:
                                f.write(image.body)
                            
                            img_path = os.path.join(uPath, filename)
                            img = Image.open(img_path)
                            if img.width < 600 or img.height < 600:
                                os.remove(img_path)
                                code = 3256
                                message = 'Image dimensions must be at least 600x600 pixels.'
                                raise Exception
                            
                            img = img.resize((600, 600), Image.ANTIALIAS)
                            if img.mode == 'RGBA':
                                img = img.convert('RGB')
                            img.save(img_path)
                            
                        else:
                            imgQ = inspectQ.get('images', None)
                            if imgQ is not None:
                                for img in imgQ:
                                    path = os.path.join(uPath, str(img['imageName']) + str(img['mimeType']))
                                    if os.path.exists(path):
                                        os.remove(path)
                            
                            if not os.path.exists(uPath):
                                os.makedirs(uPath)
                                os.chmod(uPath, 0o755)
                            
                            with open(os.path.join(uPath, filename), 'wb') as f:
                                f.write(image.body)
                            
                            img_path = os.path.join(uPath, filename)
                            img = Image.open(img_path)
                            if img.width < 600 or img.height < 600:
                                os.remove(img_path)
                                code = 9632
                                message = 'Image dimensions must be at least 600x600 pixels.'
                                raise Exception
                            img = img.resize((600, 600), Image.ANTIALIAS)
                            if img.mode == 'RGBA':
                                img = img.convert('RGB')
                            img.save(img_path)
                else:
                    if inspectQ is not None:
                        imgQ = inspectQ.get('images', None)
                        if imgQ is not None:
                            for img in imgQ:
                                path = os.path.join(uPath, str(img['imageName']) + str(img['mimeType']))
                                if os.path.exists(path):
                                    os.remove(path)
                    vImages = None
            if inspectQ != None:
                putData = {
                        'modifiedBy': self.accountId,
                        'modifiedAt': timeNow(),
                    }
                if meth == 1:
                    putData['geoLocation'] = geoCoordinates
                else:
                    vInspectors = []
                    nInspectors = []
                    existInspectors = inspectQ.get('inspectedBy', None)
                    if existInspectors != None:
                        for inspector in existInspectors:
                            if inspector['_id'] != self.accountId:
                                vInspectors.append(inspector['_id'])
                    for reciever in recieverIds:
                        if reciever not in vInspectors:
                            nInspectors.append(reciever)
                    putData['inspectionInformaton'] = inspectionInfo
                    putData['inspectedBy'] = inspectedBy
                    putData['images'] = vImages
                updaetQ = await self.jointApplication.update_one(
                    {
                        'applicantId': applicantId
                    },
                    {
                        '$set': putData
                    }
                )
                if updaetQ.modified_count > 0:
                    if meth != 1:
                        await self.loanApplication.update_one(
                                {
                                    'applicantId': applicantId
                                },
                                {
                                    '$set': {
                                        'inspectionReportSubmitted': True,
                                        'pdfUploaded' : False
                                    }
                                }
                            )
                    code = 2000
                    if meth == 1:
                        message = 'Location Updated'
                    else:
                        message = 'Inspection Report Updated'
                    status = True
                else:
                    code = 5000
                    if meth == 1:
                        message = 'Failed to Update Location'
                    else:
                        message = 'Failed to Update Inspection Report'
                    raise Exception
                
                if status == True:
                    if meth != 1:
                        notIds = [str(id) for id in nInspectors if await self.token.find_one({'accountId': ObjectId(id)}) is not None]
                        notificationData = {
                            "method": 1,
                            "notification": {"title" : "Inspection Report Updated", "body" : f"An Inspection Report has been updated for applicant : {applicantId}, kindly validate your presence."},
                            "reciever_Ids": notIds,
                            "applicantId": applicantId,
                            "accountId": str(self.accountId)
                        }
                        resp = await SendNotification.sendNotification( self, notificationData, self.application, self.request)
                
            else:
                addData = {
                        'applicantId': applicantId,
                        'createdBy': self.accountId,
                        'createdAt' : timeNow(),
                        'modifiedBy': self.accountId,
                        'modifiedAt': timeNow(),
                    }
                if meth == 1:
                    addData['geoLocation'] = geoCoordinates
                    addData['inspectionInformaton'] = None
                    addData['inspectedBy'] = None
                    addData['images'] = None
                else:
                    addData['geoLocation'] = None
                    addData['inspectionInformaton'] = inspectionInfo
                    addData['inspectedBy'] = inspectedBy
                    addData['images'] = vImages
                    
                submitQ = await self.jointApplication.insert_one(addData)
                if submitQ.inserted_id:
                    if meth != 1:
                        await self.loanApplication.update_one(
                            {
                                'applicantId': applicantId
                            },
                            {
                                '$set': {
                                    'inspectionReportSubmitted': True,
                                    'pdfUploaded' : False
                                }
                            }
                        )
                    code = 2000
                    if meth == 1:
                        message = 'Location Submitted'
                    else:
                        message = 'Inspection Report Submitted'
                    status = True
                    result.append({'inspectionreportId': str(submitQ.inserted_id)})
                else:
                    code = 5000
                    if meth == 1:
                        message = 'Failed to Submit Location'
                    else:
                        message = 'Failed to Submit Inspection Report'
                    raise Exception
                
                if status == True:
                    if meth != 1:
                        notIds = [str(id) for id in recieverIds if await self.token.find_one({'accountId': ObjectId(id)}) is not None]
                        notificationData = {
                            "method": 1,
                            "notification": {"title" : "Inspection Report Submitted", "body" : f"An Inspection Report has been submitted for applicant : {applicantId}, kindly validate your presence."},
                            "reciever_Ids": notIds,
                            "applicantId": applicantId,
                            "status": None,
                            "accountId": str(self.accountId)
                        }
                        resp = await SendNotification.sendNotification(self, notificationData, self.application, self.request)
            
        except Exception as e:
            status = False
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(json.loads(dumps(response)))
            await self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            # self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return
        
    async def get(self):
        code = 4000
        message = ''
        status = False
        result = []
        try:

            try:
                applicantId = self.request.arguments.get('applicantId')[0].decode()
            except:
                code = 6543
                message = 'Missing argument - [ applicantId ]'
                raise Exception
            
            code, message = Validate.i(
                applicantId,
                'Applicant Id',
                dataType=str,
                notNull=True,
                noSpace=True,
                notEmpty=True,
            )
            if code != 4100:
                raise Exception
            
            applicantQ = await self.loanApplication.find_one(
                {
                    'applicantId' : applicantId
                }
            )
            if not applicantQ:
                code = 6575
                message = 'Applicant not found'
                raise Exception
            
            inspectQ = await self.jointApplication.find_one(
                {
                    'applicantId' : str(applicantId)
                }
            )
            if inspectQ == None:
                code = 4365
                message = 'Inspection Report not found'
                raise Exception

            inspectInfo = inspectQ.get('inspectionInformaton', None)
            images = inspectQ.get('images', None)
            if images != None:
                for img in images:
                    name = img['imageName']
                    mType = img['mimeType']
                    img['link'] = self.fu.serverUrl + '/uploads/rc-homestay/inspectionReport/images/'+f"{name}{mType}"
                inspectQ['images'] = images
            inspectors = inspectQ.get('inspectedBy')
            if inspectors != None:
                for i in inspectors:
                    i['_id'] = str(i['_id'])
            result.append(inspectQ)
            result.append({'auditorId' : str(self.accountId)})
            if len(result):
                code = 2000
                if inspectInfo != None:
                    message = 'Inspection Report Found'
                else:
                    message = 'Inspection Report not Found'
                status = True
            else:
                code = 5000
                message = 'Inspection Report not Found'
                raise Exception
            
        except Exception as e:
            status = False
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(json.loads(dumps(response)))
            await self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            # self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return