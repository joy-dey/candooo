#!/usr/bin/AdminListHandler
# -*- coding: utf-8 -*-

"""
    Description: AdminHandler
    Purpose: Get user list, add new user
"""
import json
import sys
import tornado.web
from abc import ABCMeta
from bson import ObjectId
from bson.json_util import dumps as bdumps
from build_config import CONFIG
from lib.element_mixer import ElementMixer
from lib.fernet_crypto import FN_DECRYPT, FN_ENCRYPT
from lib.lib import Validate
from lib.xen_protocol import noXenSecureV2, xenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log
from util.time_util import timeNow


@xenSecureV2
class AuditorListHandler(ElementMixer, MongoMixin, metaclass=ABCMeta):

    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]

    applications = MongoMixin.userDb[
        CONFIG['database'][0]['table'][1]['name']
    ]

    profile = MongoMixin.userDb[
        CONFIG['database'][0]['table'][2]['name']
    ]

    state = MongoMixin.userDb[
        CONFIG['database'][0]['table'][6]['name']
    ]

    countries = MongoMixin.userDb[
        CONFIG['database'][0]['table'][7]['name']
    ]

    phoneCountry = MongoMixin.userDb[
        CONFIG['database'][0]['table'][5]['name']
    ]


    componentId = ObjectId('63d39988458b78fdf4cf6c0d')

    async def get(self):

        code = 4000
        status = False
        message = ''
        result = []

        try:
            try:
                f_limit = int(self.get_argument('limit'))
                f_skip = int(self.get_argument('skip'))
            except:
                f_limit = 0
                f_skip = 0
            
            acc = await self.account.find_one({'_id' : self.accountId})
            result.append({'_id' : str(acc['_id']), 'name' : str(acc['firstName']) + ' ' + str(acc['lastName']), 'designation' : acc.get('designation', None), 'phoneNumber' : acc['contact'][1]['phoneNumber']})
            accountQ = self.account.find({'role' : 'Auditor','designation' : {'$in' : ['DIC', 'Tourist Officer', 'Bank Officials']} ,'_id' : {'$ne' : self.accountId}}).skip(f_skip).limit(f_limit)
            async for acc in accountQ:
                result.append({'_id' : str(acc['_id']), 'name' : str(acc['firstName']) + ' ' + str(acc['lastName']), 'designation' : acc.get('designation', None), 'phoneNumber' : acc['contact'][1]['phoneNumber']})
            if len(result):
                message = 'Data found.'
                code = 2000
                status = True
            else:
                code = 4091
                message = 'Account not found.'
        except Exception as e:
            status = False
            self.set_status(503)

            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))

        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)

        try:
            response['result'] = result
            self.write(response)
            await self.finish()
            return

        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return