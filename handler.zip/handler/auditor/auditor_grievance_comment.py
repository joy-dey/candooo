#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
    Description: AccommodationProviderGrievanceCommentHandler
    Purpose: GET, POST Grievance
"""
import json
import mimetypes
import os
import sys

import tornado.web
from bson import ObjectId

from build_config import CONFIG
from lib.element_mixer import ElementMixer
from lib.lib import Validate
from lib.xen_protocol import xenSecureV2
from util.conn_util import MongoMixin
from util.file_util import FileUtil
from util.log_util import Log
from util.time_util import timeNow

@xenSecureV2
class AccommodationAuditorGrievanceCommentHandler(ElementMixer, MongoMixin):
    fu = FileUtil()

    grConversation = MongoMixin.userDb[
        CONFIG['database'][0]['table'][17]['name']
    ]

    componentId = ObjectId('63d39988458b78fdf4cf6c0d')

    async def post(self):
        code = 4000
        message = ''
        status = False
        result = []
        try:
            try:
                file_dic = {}
                arg_dic = {}
                b = self.request.headers.get('Content-Type')
                tornado.httputil.parse_body_arguments(b, self.request.body, arg_dic, file_dic)
            except:
                code = 4323
                message = 'Expected request type form-data.'
                raise Exception

            vconvId = self.get_arguments('convId')
            if not len(vconvId):
                message = 'Missing Argument - [ convId ].'
                code = 4138
                raise Exception
            vconvId = vconvId[0]
            code, message = Validate.i(
                vconvId,
                'convId',
                notNull=True,
                notEmpty=True,
                dataType=str
            )
            if code != 4100:
                raise Exception
            vconvId = ObjectId(vconvId)

            vcomment = self.get_arguments('comment')
            if not len(vcomment):
                message = 'Missing Argument - [ comment ].'
                code = 4176
                raise Exception

            vcomment = vcomment[0]
            code, message = Validate.i(
                vcomment,
                'comment',
                notNull=True,
                notEmpty=True,
                dataType=str,
                minLength=5,
                maxLength=500
            )
            if code != 4100:
                raise Exception

            modifiedAt = timeNow()
            try:
                vfile = file_dic.get('attachment')
            except:
                vfile = None

            if vfile != None:
                vfile = vfile[0]
                vfileExt = vfile['content_type']
                ext = mimetypes.guess_extension(vfileExt)
                if ext not in ['.jpg', '.jpeg', '.png']:
                    message = 'Image file should be in jpg or png or jpeg format.'
                    code = 6997
                    raise Exception

                vfileSize = len(vfile['body'])
                size = (vfileSize / (1024 * 1024))
                if size > 2:
                    message = 'Maximum size of the attachment should be 2Mb.'
                    code = 5433
                    raise Exception
                fileName = str(modifiedAt) + ext
                vfileList = [
                    {
                        'time': modifiedAt,
                        'mimeType': ext,
                    }
                ]
                uPath = self.fu.uploads + '/' + 'rc-homestay'
                if not os.path.exists(uPath):
                    os.system('mkdir -p ' + uPath)
                    os.system('chmod 755 -R ' + uPath)

                uPath = uPath + '/grievance/'
                if not os.path.exists(uPath):
                    os.system('mkdir -p ' + uPath)
                    os.system('chmod 755 -R ' + uPath)

                uPath = uPath + str(vconvId) + '/'
                if not os.path.exists(uPath):
                    os.system('mkdir -p ' + uPath)
                    os.system('chmod 755 -R ' + uPath)

                orgFile = open(uPath + fileName, 'wb')
                orgFile.write(vfile['body'])
                orgFile.close()
            else:
                vfileList = []

            findMsg = await self.grConversation.find_one(
                {
                    '_id': vconvId
                },
                {
                    '_id': 1,
                    'activity': 1
                }
            )
            if findMsg:
                actLen = len(findMsg['activity'])
                if (findMsg['activity'][actLen - 1]['id']) == 1:
                    code = 4209
                    message = 'Grievance conversation is closed.'
                    raise Exception

                pushObject = {
                    'comments': {
                        'text': vcomment,
                        'time': modifiedAt,
                        'attachmentInfo': vfileList
                    }
                }
                updateMsgQ = await self.grConversation.update_one(
                    {
                        '_id': vconvId
                    },
                    {
                        '$set': {
                            'lastUpdatedTime': timeNow(),
                            'modifiedBy': self.accountId,
                            'modifiedAt': modifiedAt
                        },
                        '$push': pushObject,
                        '$inc': {
                            'totalAttachments': len(vfileList)
                        }
                    }
                )
                if updateMsgQ.modified_count:
                    message = 'Comment has been posted.'
                    code = 2000
                    status = True
            else:
                message = 'Invalid Argument - [ convId ].'
                code = 4004

        except Exception as e:
            status = False
            if not len(message):
                # self.set_status(503)
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(response)
            self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            # self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            self.finish()
            return