
import json
import sys
from abc import ABCMeta
from bson import ObjectId
from build_config import CONFIG
from lib.lib import Validate
from lib.xen_protocol import xenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log
from bson.json_util import dumps as bdumps
from lib.element_mixer import ElementMixer
from lib.lib import Validate
from lib.sendNotification import SendNotification

@xenSecureV2
class InspectorApprovalHandler(ElementMixer,  MongoMixin, metaclass=ABCMeta):

    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]
    
    loanApplication = MongoMixin.userDb[
        CONFIG['database'][0]['table'][13]['name']
    ]
    
    jointApplication = MongoMixin.userDb[
        CONFIG['database'][0]['table'][23]['name']
    ]
    
    notification = MongoMixin.userDb[
        CONFIG['database'][0]['table'][26]['name']
    ]

    componentId = ObjectId('63d39988458b78fdf4cf6c0d')

    async def post(self):
        code = 4000
        status = False
        message = ''
        result = []

        try:
            try:
                self.request.arguments = json.loads(self.request.body.decode())
            except:
                code = 3465
                message = 'Expected Request Type JSON.'
                raise Exception
            
            mAccountFind = await self.account.find_one(
                {
                    '_id': self.accountId
                }
            )
            if not mAccountFind:
                code = 4082
                message = 'Account not Found'
                raise Exception
            
            try:
                applicantId = self.request.arguments.get('applicantId')
            except:
                code = 6543
                message = 'Missing argument - [ applicantId ]'
                raise Exception
            
            code, message = Validate.i(
                applicantId,
                'Applicant Id',
                dataType=str,
                notNull=True,
                noSpace=True,
                notEmpty=True,
            )
            
            try:
                notificationId = self.request.arguments.get('notificationId')
            except:
                code = 6543
                message = 'Missing argument - [ notificationId ]'
                raise Exception
            
            code, message = Validate.i(
                notificationId,
                'Notification Id',
                dataType=str,
                notNull=True,
                noSpace=True,
                notEmpty=True,
            )
            
            try:
                notificationId = ObjectId(notificationId)
            except:
                code = 4654
                message = 'Invalid argument - [ notificationId ]'
                raise Exception
            
            try:
                method = self.request.arguments.get('method')
            except:
                code = 4644
                message = 'Missing argument - [ method ]'
                raise Exception
            
            code, message = Validate.i(
                method,
                'method',
                dataType=int,
                notNull=True,
                notEmpty=True,
            )
            
            if method not in [1,2,3,4]:
                message = 'Not a valid value for argument - [ method ]'
                code = 7654
                raise Exception
            
            applicantQ = await self.loanApplication.find_one(
                {
                    'applicantId' : applicantId
                }
            )
            if not applicantQ:
                code = 6575
                message = 'Applicant not found'
                raise Exception
            
            notificationQ = await self.notification.find_one(
                {
                    '_id' : notificationId
                }
            )
            nId = None
            if notificationQ:
                nId = notificationQ.get('_id')
            
            inspectQ = await self.jointApplication.find_one(
                {
                    'applicantId' : applicantId
                }
            )
            if not inspectQ:
                code = 4655
                message = 'Inspection Report not found'
                raise Exception
            
            inspectedBy = inspectQ.get('inspectedBy', None)
            updated = False
            selfInspect = False
            if inspectedBy != None:
                for i in inspectedBy:
                    if i['_id'] == self.accountId:
                        selfInspect = True
                        if method == 1:
                            findInspect = await self.jointApplication.find_one(
                                {
                                    'inspectedBy._id' : self.accountId,'applicantId' : applicantId
                                },
                                {
                                    'inspectedBy.$' : 1,   
                                }
                            )
                            modified = None
                            if findInspect:
                                modified = findInspect.get('inspectedBy')[0].get('modified')
                            if modified == True:
                                app = findInspect.get('inspectedBy')[0].get('approved')
                                # if app == True:
                                #     code = 3564
                                #     message = 'Already approved'
                                #     raise Exception
                                # else:
                                #     code = 2134
                                #     message = 'Already rejected'
                                #     raise Exception
                                
                            updateQ1 = await self.jointApplication.update_one(
                                {
                                    'inspectedBy._id' : self.accountId,'applicantId' : applicantId
                                },
                                {
                                    '$set' : {
                                        'inspectedBy.$.approved' : True,
                                        'inspectedBy.$.modified' : True
                                    }
                                }
                            )
                            if updateQ1.modified_count > 0:
                                if nId != None:
                                    notiUpdate = await self.notification.update_one(
                                        {
                                            'recievedBy.reciever': self.accountId, 
                                            'applicantId': applicantId, 
                                            '_id': nId
                                        },
                                        {
                                            '$set': {'recievedBy.$[elem].status': 'approved'}
                                        },
                                        array_filters=[{'elem.reciever': self.accountId}]
                                    )

                                    updated = True
                                    notificationData = await self.notification.find_one({'_id': nId})
                                    receiverId = [str(notificationData['sentBy'])]
                                    senderId = str(self.accountId)
                                    inspectorName = f"{mAccountFind.get('firstName')} {mAccountFind.get('lastName')}"
                                    notificationData = {
                                        "method": 1,
                                        "methodNotification":method,
                                        "notificationType": 2,
                                        "notification": {
                                            "title": "Inspection Report Update",
                                            "body": f"An Inspection for applicant: {applicantId} has been approved by Inspector: {inspectorName}"
                                        },
                                        "reciever_Ids": receiverId,
                                        "applicantId": applicantId,
                                        "accountId": senderId,
                                        'notificationStatus' : 'Ok'
                                    }

                                    resp = await SendNotification.sendNotification(self, notificationData, self.application, self.request)
                                else:
                                    code = 3564
                                    message = 'Notification not found'
                                    raise Exception

                        elif method == 2:
                            rejectReason = self.request.arguments.get('rejectReason')
                            rejectDetails = {
                                'rejectReason' : rejectReason
                            }

                            if rejectReason is None:
                                code = 6543
                                message = 'Missing argument - [ rejectReason ]'
                                raise Exception
                            
                            if rejectReason is not None and rejectReason == 'Others' or rejectReason == 'Other':
                                rejectRemarks = self.request.arguments.get('rejectRemark')
                                rejectDetails = {
                                    'rejectReason' : rejectReason,
                                    'rejectRemarks' : rejectRemarks 
                                }
                                if rejectRemarks is None:
                                    code = 6543
                                    message = 'Missing argument - [ rejectRemarks ]'
                                    raise Exception
                            findInspect = await self.jointApplication.find_one(
                                {
                                    'inspectedBy._id' : self.accountId,'applicantId' : applicantId
                                },
                                {
                                 
                                    'inspectedBy.$' : 1,
                                    
                                }
                            )
                            modified = None
                            if findInspect:
                                modified = findInspect.get('inspectedBy')[0].get('modified')
                            if modified == True:
                                app = findInspect.get('inspectedBy')[0].get('approved')
                                if app == True:
                                    code = 3564
                                    message = 'Already approved'
                                    raise Exception
                                else:
                                    code = 2134
                                    message = 'Already rejected'
                                    raise Exception
                                
                            updateQ1 = await self.jointApplication.update_one(
                                {
                                    'inspectedBy._id' : self.accountId,'applicantId' : applicantId
                                },
                                {
                                    '$set' : {
                                        'inspectedBy.$.modified' : True
                                    }
                                }
                            )
                            if updateQ1.modified_count > 0:
                                if nId != None:
                                    rejectDetails = {}
                                    rejectRemarks = None
                                    notiUpdate = await self.notification.update_one(
                                    {
                                        'recievedBy.reciever' : self.accountId,'applicantId' : applicantId, '_id' : nId
                                    },
                                    {
                                            '$set': {'recievedBy.$[elem].status': 'rejected'}
                                        },
                                        array_filters=[{'elem.reciever': self.accountId}]
                                    )

                                    updated = True
                                    notificationDataQ = await self.notification.find_one({'_id': nId})
                                    receiverId = [str(notificationDataQ['sentBy'])]
                                    senderId = str(self.accountId)
                                    inspectorName = f"{mAccountFind.get('firstName')} {mAccountFind.get('lastName')}"
                                    
                                    notificationData = {
                                        "method": 1,
                                        "notificationType": 2,
                                        "methodNotification":method,
                                        "notification": {
                                            "title": "Inspection Report Update",
                                            "body": f"An Inspection for applicant: {applicantId}, has been rejected by Inspector: {inspectorName}"
                                        },
                                        "reciever_Ids": receiverId,
                                        "applicantId": applicantId,
                                        "accountId": senderId,
                                        'notificationStatus' : 'Pending',
                                        'rejectDetails' : rejectDetails
                                    }
                                    if rejectRemarks:
                                        notificationData['reason'] = rejectRemarks
                                    else:
                                        notificationData['reason'] = 'Absent'

                                    resp = await SendNotification.sendNotification(self, notificationData, self.application, self.request)
                        elif method == 3:
                            if nId != None:
                                notificationQ = await self.notification.find_one({'_id': nId})
                                if notificationQ is not None:
                                    notificationUpQ = await self.notification.update_one(
                                        {
                                            '_id': nId,
                                            'applicantId': applicantId
                                        },
                                        {
                                            '$set': {
                                                'notificationStatus': 'Accepted'
                                            }
                                        }
                                    )
                                    if notificationUpQ.matched_count > 0:
                                        code  = 2000
                                        status = True
                                        message = 'Notification Status updated successfully.'
                                    else:
                                        code  = 4521
                                        status = False
                                        message = 'Notification Status not updated.'
                                code = 2000
                                status = True
                        elif method == 4:
                            if nId != None:
                                try:
                                    rejectRemarks = self.request.arguments.get('rejectRemark')
                                except:
                                    rejectRemarks = None
                                if rejectRemarks is None:
                                    code = 6543
                                    message = 'Missing argument - [ rejectRemarks ]'
                                    raise Exception
                                findInspect = await self.jointApplication.find_one(
                                    {
                                        'inspectedBy._id' : self.accountId,'applicantId' : applicantId
                                    },
                                    {
                                    
                                        'inspectedBy.$' : 1,
                                        
                                    }
                                )
                                modified = None
                                if findInspect:
                                    modified = findInspect.get('inspectedBy')[0].get('modified')
                                if modified == True:
                                    app = findInspect.get('inspectedBy')[0].get('approved')
                                    if app == True:
                                        code = 3564
                                        message = 'Already approved'
                                        raise Exception
                                    else:
                                        code = 2134
                                        message = 'Already rejected'
                                        raise Exception
                                    
                                updateQ1 = await self.jointApplication.update_one(
                                    {
                                        'inspectedBy._id' : self.accountId,'applicantId' : applicantId
                                    },
                                    {
                                        '$set' : {
                                            'inspectedBy.$.approved' : True,
                                            'inspectedBy.$.modified' : True
                                        }
                                    }
                                )
                                if updateQ1.modified_count > 0:
                                    if nId != None:
                                        notificationData = await self.notification.find_one({'_id': nId})
                                        receiverId = [str(notificationData['sentBy'])]
                                        senderId = str(notificationData.get('recievedBy'))
                                        auditorName = f"{mAccountFind.get('firstName')} {mAccountFind.get('lastName')}"
                                        notificationData = {
                                            "method": 1,
                                            "notificationType": 1,
                                            "methodNotification":1,
                                            "notification": {
                                                "title": "Inspection Report Reassigned",
                                                "body" : f"An Inspection for applicant: {applicantId} has been reassigned. Update from Auditor: {auditorName}. Kindly validate your presence. Remarks : {rejectRemarks}."
                                            },
                                            "reciever_Ids": receiverId,
                                            "applicantId": applicantId,
                                            "accountId": senderId,
                                        }
                                        resp = await SendNotification.sendNotification( self, notificationData, self.application, self.request)
                                        notificationQ = await self.notification.find_one({'_id': nId})
                                        if notificationQ is not None:
                                            await self.notification.update_one(
                                                {
                                                '_id' : nId 
                                                },   
                                                {
                                                    '$set' : {
                                                        'notificationStatus' : 'Reassigned'
                                                    }
                                                }
                                            )
                                    code = 2000
                                    status = True
                                    message = 'Inspection Reassigned.'
                        else:
                            message = 'Not a valid value for argument - [ method ]'
                            code = 7654
                            raise Exception      

            else:
                code = 8393
                message = 'No Inspectors found'
                raise Exception
            
            if selfInspect == False:
                code = 4645
                message = 'You are not an Inspector for this report'
                raise Exception
            
            if method == 1 and updated == True:
                message = 'Inspection Approved.'
                code = 2000
                status = True
                
            elif method == 2 and updated == True:
                message = 'Inspection Rejected.'
                code = 2000
                status = True

            # else:
            #     message = 'Status already updated.'
            #     code = 3454
            #     status = False
            #     raise Exception

        except Exception as e:
            status = False
            if not len(message):
                # self.set_status(503)
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(bdumps(response))
            await self.finish()
            return

        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            # self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return
