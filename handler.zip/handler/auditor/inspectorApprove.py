
import json
import sys
from abc import ABCMeta
from bson import ObjectId
from build_config import CONFIG
from lib.lib import Validate
from lib.xen_protocol import xenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log
from bson.json_util import dumps as bdumps
from lib.element_mixer import ElementMixer
from lib.lib import Validate

@xenSecureV2
class InspectorApprovalHandler(ElementMixer,  MongoMixin, metaclass=ABCMeta):

    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]
    
    loanApplication = MongoMixin.userDb[
        CONFIG['database'][0]['table'][13]['name']
    ]
    
    jointApplication = MongoMixin.userDb[
        CONFIG['database'][0]['table'][23]['name']
    ]
    
    notification = MongoMixin.userDb[
        CONFIG['database'][0]['table'][26]['name']
    ]

    componentId = ObjectId('63d39988458b78fdf4cf6c0d')

    async def post(self):
        code = 4000
        status = False
        message = ''
        result = []

        try:
            try:
                self.request.arguments = json.loads(self.request.body.decode())
            except:
                code = 3465
                message = 'Expected Request Type JSON.'
                raise Exception
            
            mAccountFind = await self.account.find_one(
                {
                    '_id': self.accountId
                }
            )
            if not mAccountFind:
                code = 4082
                message = 'Account not Found'
                raise Exception
            
            try:
                applicantId = self.request.arguments.get('applicantId')
            except:
                code = 6543
                message = 'Missing argument - [ applicantId ]'
                raise Exception
            
            code, message = Validate.i(
                applicantId,
                'Applicant Id',
                dataType=str,
                notNull=True,
                noSpace=True,
                notEmpty=True,
            )
            if code != 4100:
                raise Exception
            
            try:
                notificationId = self.request.arguments.get('notificationId')
            except:
                code = 6543
                message = 'Missing argument - [ notificationId ]'
                raise Exception
            
            code, message = Validate.i(
                notificationId,
                'Notification Id',
                dataType=str,
                notNull=True,
                noSpace=True,
                notEmpty=True,
            )
            if code != 4100:
                raise Exception
            
            try:
                notificationId = ObjectId(notificationId)
            except:
                code = 4654
                message = 'Invalid argument - [ notificationId ]'
                raise Exception
            
            try:
                method = self.request.arguments.get('method')
            except:
                code = 4644
                message = 'Missing argument - [ method ]'
                raise Exception
            
            code, message = Validate.i(
                method,
                'method',
                dataType=int,
                notNull=True,
                notEmpty=True,
            )
            if code != 4100:
                raise Exception
            
            if method not in [1,2]:
                message = 'Not a valid value for argument - [ method ]'
                code = 7654
                raise Exception
            
            applicantQ = await self.loanApplication.find_one(
                {
                    'applicantId' : applicantId
                }
            )
            if not applicantQ:
                code = 6575
                message = 'Applicant not found'
                raise Exception
            
            notificationQ = await self.notification.find_one(
                {
                    '_id' : notificationId
                }
            )
            nId = None
            if notificationQ:
                nId = notificationQ.get('_id')
            
            inspectQ = await self.jointApplication.find_one(
                {
                    'applicantId' : applicantId
                }
            )
            if not inspectQ:
                code = 4655
                message = 'Inspection Report not found'
                raise Exception
            
            inspectedBy = inspectQ.get('inspectedBy', None)
            updated = False
            selfInspect = False
            if inspectedBy != None:
                for i in inspectedBy:
                    if i['_id'] == self.accountId:
                        selfInspect = True
                        if method == 1:
                            findInspect = await self.jointApplication.find_one(
                                {
                                    'inspectedBy._id' : self.accountId,'applicantId' : applicantId
                                },
                                {
                                 
                                    'inspectedBy.$' : 1,
                                    
                                }
                            )
                            modified = None
                            if findInspect:
                                print(findInspect, 'findInspect')
                                modified = findInspect.get('inspectedBy')[0].get('modified')
                            if modified == True:
                                app = findInspect.get('inspectedBy')[0].get('approved')
                                if app == True:
                                    code = 3564
                                    message = 'Already approved'
                                    raise Exception
                                else:
                                    code = 2134
                                    message = 'Already rejected'
                                    raise Exception
                                
                            updateQ1 = await self.jointApplication.update_one(
                                {
                                    'inspectedBy._id' : self.accountId,'applicantId' : applicantId
                                },
                                {
                                    '$set' : {
                                        'inspectedBy.$.approved' : True,
                                        'inspectedBy.$.modified' : True
                                    }
                                }
                            )
                            if updateQ1.modified_count > 0:
                                if nId != None:
                                    notiUpdate = await self.notification.update_one(
                                    {
                                        'recievedBy' : self.accountId,'applicantId' : applicantId, '_id' : nId
                                    },
                                    {
                                        '$set':{'status' : 'approved'}
                                    }
                                    )
                                    updated = True
                        else:
                            findInspect = await self.jointApplication.find_one(
                                {
                                    'inspectedBy._id' : self.accountId,'applicantId' : applicantId
                                },
                                {
                                 
                                    'inspectedBy.$' : 1,
                                    
                                }
                            )
                            modified = None
                            if findInspect:
                                modified = findInspect.get('inspectedBy')[0].get('modified')
                            if modified == True:
                                app = findInspect.get('inspectedBy')[0].get('approved')
                                if app == True:
                                    code = 3564
                                    message = 'Already approved'
                                    raise Exception
                                else:
                                    code = 2134
                                    message = 'Already rejected'
                                    raise Exception
                                
                            updateQ1 = await self.jointApplication.update_one(
                                {
                                    'inspectedBy._id' : self.accountId,'applicantId' : applicantId
                                },
                                {
                                    '$set' : {
                                        'inspectedBy.$.modified' : True
                                    }
                                }
                            )
                            if updateQ1.modified_count > 0:
                                if nId != None:
                                    notiUpdate = await self.notification.update_one(
                                    {
                                        'recievedBy' : self.accountId,'applicantId' : applicantId, '_id' : nId
                                    },
                                    {
                                        '$set':{'status' : 'rejected'}
                                    }
                                    )
                                    updated = True
            else:
                code = 8393
                message = 'No Inspectors found'
                raise Exception
            
            if selfInspect == False:
                code = 4645
                message = 'You are not an Inspector for this report'
                raise Exception
            
            if updated == True:
                message = 'Status updated successfully.'
                code = 2000
                status = True

            # else:
            #     message = 'Status already updated.'
            #     code = 3454
            #     status = False
            #     raise Exception

        except Exception as e:
            status = False
            if not len(message):
                # self.set_status(503)
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(bdumps(response))
            await self.finish()
            return

        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            # self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return
