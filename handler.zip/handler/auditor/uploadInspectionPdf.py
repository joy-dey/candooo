
import json
import mimetypes
import os
import sys
from abc import ABCMeta
from bson import ObjectId
import tornado.httputil
from build_config import CONFIG
from lib.lib import Validate
from lib.xen_protocol import xenSecureV2
from util.conn_util import MongoMixin
from util.file_util import FileUtil
from util.log_util import Log
from util.time_util import timeNow
from lib.element_mixer import ElementMixer
from bson.json_util import dumps

@xenSecureV2
class InspectionReportUploadPdfHandler(ElementMixer,  MongoMixin, metaclass=ABCMeta):

    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]

    loanApplication = MongoMixin.userDb[
        CONFIG['database'][0]['table'][13]['name']
    ]

    jointApplication = MongoMixin.userDb[
        CONFIG['database'][0]['table'][23]['name']
    ]
    
    district = MongoMixin.userDb[
        CONFIG['database'][0]['table'][14]['name']
    ]

    fu = FileUtil()
    componentId = ObjectId('63d39988458b78fdf4cf6c0d')

    async def post(self):
        code = 4000
        message = ''
        status = False
        result = []
        try:
            
            try:
                file_dic = {}
                arg_dic = {}
                b = self.request.headers.get('Content-Type')
                tornado.httputil.parse_body_arguments(b, self.request.body, arg_dic, file_dic)
                applicantId = json.loads(arg_dic['applicantId'][0])
                try:
                    inspectionReportPdf = file_dic['inspectionReportPdf'][0]
                except:
                    message = 'Missing Inspection Report Pdf'
                    code = 2347
                    status = False
                    raise Exception
            except:
                code = 4323
                message = 'Invalid body arguments.'
                raise Exception
            
            code, message = Validate.i(
                applicantId,
                'Applicant Id',
                dataType=str,
                notNull=True,
                noSpace=True,
                notEmpty=True,
            )
            if code != 4100:
                raise Exception
            
            applicantQ = await self.loanApplication.find_one(
                {
                    'applicantId' : applicantId
                }
            )
            if not applicantQ:
                code = 6575
                message = 'Applicant not found'
                raise Exception
                
            inspectQ = await self.jointApplication.find_one(
                {
                    'applicantId' : applicantId
                }
            )
            
            try:
                inspectionReportType = inspectionReportPdf['content_type']
                inspectionReportType = mimetypes.guess_extension(
                    inspectionReportType,
                    strict=True
                )
                time = timeNow()
                if str(inspectionReportType) in ['.pdf']:
                    fName = inspectionReportPdf.filename
                    fName1 = fName.split('.pdf')[0]
                    fName1 = fName1 + '_' + str(time)
                    fRaw = inspectionReportPdf['body']
                    # fp = './../uploads/' + '/rc-tenders/'
                    fp = self.fu.uploads + 'rc-homestay/inspectionReport/pdf/'
                    if inspectQ:
                        doc =  inspectQ.get('document', None)
                        if doc == None:
                            uPath = fp 
                            if not os.path.exists(uPath):
                                os.system('mkdir -p ' + uPath)
                                os.system('chmod 755 -R ' + uPath)
                                os.system('chmod 755 -R ' + uPath + '*')
                            path = os.path.join(uPath, fName1 + inspectionReportType)
                            with open(path, 'wb') as f:
                                f.write(fRaw)
                                f.close()
                        else:
                            uPath = fp
                            existFileName = inspectQ['document'][0]['fileName']
                            existFileType = inspectQ['document'][0]['mimeType']
                            existFile =  str(existFileName)+str(existFileType)
                            path = os.path.join(uPath, str(existFile))
                            if os.path.exists(path):
                                os.remove(path)
                                path = os.path.join(uPath, fName1 + inspectionReportType)
                            else:
                                os.system('mkdir -p ' + uPath)
                                os.system('chmod 755 -R ' + uPath)
                                os.system('chmod 755 -R ' + uPath + '*')
                                path = os.path.join(uPath, fName1 + inspectionReportType)
                            with open(path, 'wb') as f:
                                f.write(fRaw)
                                f.close()
                    else:
                        uPath = fp 
                        if not os.path.exists(uPath):
                            os.system('mkdir -p ' + uPath)
                            os.system('chmod 755 -R ' + uPath)
                            os.system('chmod 755 -R ' + uPath + '*')
                        path = os.path.join(uPath, fName1 + inspectionReportType)
                        with open(path, 'wb') as f:
                            f.write(fRaw)
                            f.close()
                        
                else:
                    message = 'Invalid File Type for Inspection Report'
                    code = 4011
                    raise Exception
                
            except Exception as e:
                if not len(message):
                    code = 8894
                    status = False
                    message = str(e)
                raise Exception
            
            if inspectQ != None:
                    
                updaetQ = await self.jointApplication.update_one(
                    {
                        'applicantId': applicantId
                    },
                    {
                        '$set': {
                            'document' : [
                                {
                                    'fileName' : fName1,
                                    'mimeType' : inspectionReportType
                                }
                            ],
                            'modifiedBy': self.accountId,
                            'modifiedAt': timeNow(),
                        }
                    }
                )
                if updaetQ.modified_count > 0:
                    await self.loanApplication.update_one(
                        {
                            'applicantId': applicantId
                        },
                        {
                            '$set': {
                                'inspectionReportSubmitted': True,
                                'pdfUploaded': True
                            }
                        }
                    )
                    code = 2000
                    message = 'Inspection Report Updated'
                    status = True
                else:
                    code = 5000
                    message = 'Failed to Update Inspection Report'
                    raise Exception
                
            else:
                    
                submitQ = await self.jointApplication.insert_one(
                    {
                        'applicantId': applicantId,
                        'createdBy': self.accountId,
                        'createdAt' : timeNow(),
                        'modifiedBy': self.accountId,
                        'modifiedAt': timeNow(),
                        'inspectionInformaton' : None,
                        'inspectedBy' : None,
                        'geoLocation' : None,
                        'document' : [
                                {
                                    'fileName' : fName1,
                                    'mimeType' : inspectionReportType
                                }
                            ]
                    }
                )
                if submitQ.inserted_id:
                    await self.loanApplication.update_one(
                        {
                            'applicantId': applicantId
                        },
                        {
                            '$set': {
                                'inspectionReportSubmitted': True,
                                'pdfUploaded': True
                            }
                        }
                    )
                    code = 2000
                    message = 'Inspection Report Submitted'
                    status = True
                    result.append({'inspectionreportId': str(submitQ.inserted_id)})
                else:
                    code = 5000
                    message = 'Failed to Submit Inspection Report'
                    raise Exception
            
        except Exception as e:
            status = False
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(response)
            await self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            # self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return
        