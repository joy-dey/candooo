import json
import sys
import os
import mimetypes
import tornado.web
import piexif

from PIL import Image
from abc import ABCMeta
from bson import ObjectId
from build_config import CONFIG
from lib.lib import Validate
from lib.xen_protocol import xenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log
from util.time_util import timeNow
from bson.json_util import dumps as bdumps
from lib.element_mixer import ElementMixer
from util.file_util import FileUtil
from lib.gis_data import GISDataExtractor
from util.file_util import FileUtil


@xenSecureV2
class AuditDetailsHandler(ElementMixer, tornado.web.RequestHandler, MongoMixin, metaclass=ABCMeta):

    fu = FileUtil()
    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]

    applications = MongoMixin.userDb[
        CONFIG['database'][0]['table'][1]['name']
    ]

    auditInfo = MongoMixin.userDb[
        CONFIG['database'][0]['table'][19]['name']
    ]
    
    loanApplication = MongoMixin.userDb[
        CONFIG['database'][0]['table'][13]['name']
    ]
    
    componentId = ObjectId('63d39988458b78fdf4cf6c0d')
    
    gisExtractor = GISDataExtractor()
    
    async def get(self):
        code = 4000
        status = False
        message = ''
        result = []

        try:
            try:
                vFileDtlsId = str(self.get_argument('id'))  
                try:
                    vFileDtlsId = ObjectId(vFileDtlsId)
                except:
                    message = 'Invalid argument [id].'
                    code =  7098
                    raise Exception        
            except:
                message = 'Missing argument [id].'
                code =  7198
                raise Exception
            
            method = int(self.get_argument('method'))
            if not method :
                message = 'Missing argument method.'
                code = 5182
                status = False
                raise Exception
            
            if method == 1:
                auditQ = await self.auditInfo.find_one(
                    {
                        'loanId' : vFileDtlsId
                    }
                )
                if auditQ:
                    result.append(auditQ)                  
                    empty = auditQ.get('auditData')
                    if empty != None:
                        for stage_key, stage_data in auditQ["auditData"].items():
                            for sub_key, sub_data in stage_data.items():
                                if isinstance(sub_data, dict):
                                    if 'images' not in sub_data or not isinstance(sub_data['images'], list):
                                        sub_data['images'] = [] 
                            modified_data_list = stage_data.get("modifiedData", [])
                            modified_by_list = []
                            for modifiedData in reversed(modified_data_list):
                                modifiedBy = modifiedData.get("modifiedBy")
                                modifiedAt = modifiedData.get("modifiedAt")

                                existing_entry = next(
                                    (
                                        entry
                                        for entry in modified_by_list
                                        if entry["modifiedBy"] == modifiedBy and entry["modifiedAt"] == modifiedAt
                                    ),
                                    None,
                                )
                                if not existing_entry:
                                    names = self.account.find({"_id": modifiedBy}, {'firstName': 1, 'lastName': 1})
                                    modifiedByDetails = {'fName': None, 'lName': None}
                                    async for name in names:
                                        modifiedByDetails['fName'] = name.get('firstName')
                                        modifiedByDetails['lName'] = name.get('lastName')

                                    modified_by_list.append({
                                        'fName': modifiedByDetails['fName'],
                                        'lName': modifiedByDetails['lName'],
                                        'modifiedAt': modifiedAt,
                                        'modifiedBy': modifiedBy
                                    })

                            modified_by_list.sort(key=lambda x: x['modifiedAt'])
                            result.append({'stageName': stage_key, 'modifiedByList': modified_by_list}) 
                        
            else:
                message = 'Invalid argument [method].'
                code =  3998
                raise Exception  
            
            if not len(result):
                message = 'No data found.'
                code = 4082

            else:
                message = 'Data found.'
                code = 2000
                status = True

        except Exception as e:
            status = False
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(bdumps(response))
            await self.finish()
            return

        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return
    
    async def post(self):
        code = 4000
        message = ''
        status = False
        result = []
        try:
            try:
                file_dic = {}
                arg_dic = {}
                b = self.request.headers.get('Content-Type')
                tornado.httputil.parse_body_arguments(b, self.request.body, arg_dic, file_dic)
                meth = json.loads(arg_dic['method'][0])
                Id = json.loads(arg_dic['id'][0])
            except:
                code = 4323
                message = 'Invalid body arguments.'
                raise Exception
            try:
                fieldId = Id.get('id')
                fieldId = ObjectId(fieldId)
            except:
                code = 4169
                message = 'Invalid Argument - [ id ].'
                status = False  
                raise Exception  
            
            code, message = Validate.i(
                meth,
                notNull=True,
                notEmpty=True,
                dataType=int
            )
            if code != 4100:
                raise Exception
            
            appQ = await self.loanApplication.find_one(
                {
                    '_id' : fieldId
                },
                {
                    '_id' : 1
                }
                )
            if not appQ:
                message = 'Loan File not found.'
                code = 7474
                raise Exception
            
            if meth not in (1,2):
                message = 'Invalid Argument - [ method ].'
                code = 4114
                raise Exception
            
            time=timeNow()
            find_imageQ = await self.auditInfo.find_one({'loanId': appQ.get('_id')})
            findAuditDtlQ = self.auditInfo.find(
                {
                    'loanId': fieldId
                }
            )
                
            findAuditDetails = []
            async for i in findAuditDtlQ:
                findAuditDetails.append(i)
                
            if meth == 1:
                try:
                    manualGis = json.loads(arg_dic['manualGis'][0])
                except:
                    code = 4323
                    message = 'Invalid body arguments.'
                    raise Exception
                
                address = manualGis.get('address')
                if not address:
                    message = 'address in Gis not found.'
                    code = 4747
                    raise Exception
                
                code, message = Validate.i(
                    address,
                    notNull=True,
                    notEmpty=True,
                    dataType=str
                )
                if code != 4100:
                    raise Exception
                
                lat = manualGis.get('latitude')
                if not lat:
                    message = 'latitude in Gis not found.'
                    code = 4225
                    raise Exception
                
                code, message = Validate.i(
                    lat,
                    notNull=True,
                    notEmpty=True,
                    dataType=str
                )
                if code != 4100:
                    raise Exception
                
                long = manualGis.get('longitude')
                if not long:
                    message = 'longitude in Gis not found.'
                    code = 4523
                    raise Exception
                
                code, message = Validate.i(
                    long,
                    notNull=True,
                    notEmpty=True,
                    dataType=str
                )
                if code != 4100:
                    raise Exception
                
                manGis = {
                'latitude' : lat,
                'longitude' : long,
                'address' : address
                }
            
            elif meth == 2:
                stageData = {}
                stageNames = ['stage1', 'stage2', 'stage3', 'stage4', 'stage5', 'stage6']

                for stageName in stageNames:
                    if stageName in arg_dic:
                        stageData[stageName] = json.loads(arg_dic[stageName][0])
                    else:
                        code = 9657 
                        message = (f"Stage '{stageName}' is missing in the request.")
                        raise Exception
                    
                _data = {'stage1': {}, 'stage2': {}, 'stage3': {}, 'stage4': {}, 'stage5': {}, 'stage6': {}}
                
                fieldNames = {
                    'stage1': ['earthWork', 'steelWork', 'plintWall', 'plinthBeam', 'earthFillFloor','forceComplete'],
                    'stage2': ['roofBeam', 'colUpToRoof','forceComplete'],
                    'stage3': ['brickWork', 'WinAndDoorFrame', 'falseCeiling','forceComplete'],
                    'stage4': ['plastering', 'doorAndWindowComp', 'TilingFloorBathroom', 'plumbing','forceComplete'],
                    'stage5': ['sanitaryFitting', 'internWiringAndAmp', 'painting','forceComplete'],
                    'stage6': ['furniture', 'kitchenEquipment', 'curtain', 'powerAndWaterConn','forceComplete']
                }

                uPath = self.fu.uploads
                uPath = uPath + 'rc-homestay' + '/images/'
                if not os.path.exists(uPath):
                    os.system('mkdir -p ' + uPath)
                    os.system('chmod 755 -R ' + uPath)
                    Log.i('File directory created {}'.format(uPath))
                
                stageIndex = 0
                green = 0
                for stageName, fieldNames in fieldNames.items():
                    if stageName in stageData:
                        stage = stageData[stageName]
                        _data[stageName] = {}
                        stageColor = None
                        hasOneOrThree = False
                        hasZero = False
                        allZero = True
                        one = 0
                        three = 0

                        for fieldName in fieldNames:
                            if fieldName in stage and fieldName == 'forceComplete':
                                fcVal = stage[fieldName]
                                code, message = Validate.i(
                                    value,
                                    fieldName,
                                    notNull=True,
                                    notEmpty=True,
                                    dataType=int
                                )
                                if code != 4100:
                                    raise Exception
                                
                            elif fieldName in stage and fieldName != 'forceComplete':
                                value = stage[fieldName]
                                code, message = Validate.i(
                                    value,
                                    fieldName,
                                    notNull=True,
                                    notEmpty=True,
                                    dataType=int
                                )
                                if code != 4100:
                                    raise Exception

                            else:
                                code = 9343
                                message = (f"Field '{fieldName}' is missing in the '{stageName}' JSON object.")
                                raise Exception
                        
                            dataEntry = {fieldName: value}
                            if stageName not in _data:
                                _data[stageName] = {}
                            if fieldName not in _data[stageName]:
                                _data[stageName][fieldName] = {}

                            _data[stageName][fieldName].update(dataEntry)

                            images = file_dic.get(fieldName)
                            vImages = []
                            vGis = []

                            if images is not None and len(images) > 0:
                                code, message = Validate.i(
                                    images,
                                    stageName,
                                    notNull=False,
                                    notEmpty=False,
                                    dataType=list
                                )
                                if code != 4100:
                                    raise Exception
                                time = timeNow()
                                imgIndex = 1
                                vImages = []
                                vGis = []

                                if find_imageQ:
                                    stage_data = find_imageQ.get('auditData', {}).get(stageName, {})
                                    field_data = stage_data.get(fieldName, {}).get('images', [])
                                    for image in field_data:
                                        imagename = image['imagename']
                                        if imagename:
                                            extn = image['mimeType']
                                            full_image_path_name = imagename + extn
                                            filepath = os.path.join(uPath, full_image_path_name)
                                            if os.path.exists(filepath):
                                                os.remove(filepath)
                                    resultQ = await self.auditInfo.update_one(
                                        {'loanId': appQ.get('_id')},
                                        {
                                            '$set': {
                                                f'auditData.{stageName}.{fieldName}.images': []
                                            }
                                        }
                                    )
                                  
                                for img in images:
                                    extImg = mimetypes.guess_extension(img['content_type'])
                                    size = len(img['body']) / (1024 * 1024)
                                    filename = f"{fieldId}_{fieldName}_{time}_image_{imgIndex}{extImg}"
                                    filenamewithoutext = f"{fieldId}_{fieldName}_{time}_image_{imgIndex}"

                                    v = {
                                        'imagename': filenamewithoutext,
                                        'mimeType': extImg
                                    }
                                    await self.auditInfo.update_one(
                                        {'loanId': appQ.get('_id')},
                                        {
                                            '$push': {
                                                f'auditData.{stageName}.{fieldName}.images': v,
                                            }
                                        }
                                    )

                                    filepath = os.path.join(uPath,  filenamewithoutext + extImg)
                                    with open(filepath, 'wb') as save_file:
                                        save_file.write(img['body'])

                                    im = Image.open(filepath)
                                    exif_data = im.info.get('exif')

                                    if exif_data is not None:
                                        try:
                                            exif_dict = piexif.load(exif_data)
                                            if exif_dict.get('GPS', {}):
                                                exif_dict = self.gisExtractor.exif_to_tag(exif_dict)
                                                vGis.append(exif_dict['GPS'])
                                        except Exception as e:
                                            Log.i(f"Error processing EXIF data: {e}")

                                    vImages.append(v)
                                    
                                    imgIndex += 1

                                _data[stageName][fieldName]['images'] = vImages
                                _data[stageName][fieldName]['Gis'] = vGis

                            else:
                                if findAuditDetails:
                                    if 'auditData' in findAuditDetails[0]:
                                        stage_data = findAuditDetails[0]['auditData'].get(stageName, {})
                                        
                                        if isinstance(stage_data, dict):
                                            field_data = stage_data.get(fieldName, {})
                                            
                                            if isinstance(field_data, dict):
                                                find_image = field_data.get('images', [])
                                                
                                                if find_image:
                                                    for image in find_image:
                                                        image_full_name = image['imagename'] + image['mimeType']
                                                        full_file_path = os.path.join(uPath, image_full_name)
                                                        
                                                        if os.path.isfile(full_file_path):
                                                            os.remove(full_file_path)

                                                _data[stageName][fieldName]['images'] = []
                                                _data[stageName][fieldName]['Gis'] = []

                            if value == 2:
                                stageColor = 'red'
                            elif value == 0:
                                hasZero = True
                            elif value in [1, 3]:
                                if value == 1:
                                    one += 1
                                elif value == 3:
                                    three += 1
                                hasOneOrThree = True
                                allZero = False
                            else:
                                allZero = False
                        
                        if stageColor is None:
                            if allZero:
                                stageColor = 'white'
                            elif hasZero:
                                stageColor = 'purple'
                            elif hasOneOrThree:
                                if one >= 1 and three == 0:
                                    stageColor = 'green'
                                elif three == len(fieldNames):
                                    stageColor = 'red'
                                elif one == 0 and three >= 1:
                                    stageColor = 'white'
                                else:
                                    stageColor = 'green'
                            else:
                                stageColor = 'white' 
                        _data[stageName]['modifiedAt'] = timeNow()
                        _data[stageName]['modifiedBy'] = self.accountId
                        if fcVal == 1:
                            _data[stageName]['color'] = 'green'
                            _data[stageName]['forceComplete'] = fcVal
                            _data[stageName]['stageStatus'] = 'complete'
                        else:
                            _data[stageName]['forceComplete'] = fcVal
                            _data[stageName]['color'] = stageColor
                            if stageColor == 'green' : 
                                _data[stageName]['stageStatus'] = 'complete'
                            else:
                                _data[stageName]['stageStatus'] = 'Incomplete'
                        
                    stageIndex += 1
                    if _data[stageName]['color'] == 'green':
                        green += 1
                
                if stageIndex == green:
                    constructionStatus = 'complete'
                else:
                    constructionStatus = 'Incomplete'   
                
            CompletedImages = []
            if len(findAuditDetails):
                if meth == 2:
                    if constructionStatus == 'complete':
                        Cimages = file_dic.get('completedImages')
                        if Cimages is not None and len(Cimages) > 0:
                            code, message = Validate.i(
                                Cimages,
                                'Completed Images',
                                notNull=False,
                                notEmpty=False,
                                dataType=list
                            )
                            if code != 4100:
                                raise Exception

                            time = timeNow()
                            imgIndex = 1
                            if find_imageQ:
                                cImagesData = find_imageQ['completedImages']
                                for images in cImagesData:
                                    imageName = images['imagename']
                                    if imageName:
                                        extn = images['mimeType']
                                        cImagesPath = imageName + extn
                                        filepath = os.path.join(uPath, cImagesPath)
                                        if os.path.exists(filepath):
                                            os.remove(filepath)
                            for img in Cimages:
                                extImg = mimetypes.guess_extension(img['content_type'])
                                fileName = img['filename'].split(".")[0]
                                size = len(img['body']) / (1024 * 1024)
                                filename = f"{fileName}_{time}_image_{imgIndex}{extImg}"
                                filenamewithoutext = f"{fileName}_{time}_image_{imgIndex}"
                                v = {
                                    'imagename': filenamewithoutext,
                                    'mimeType': extImg,
                                    'modifiedAt': timeNow(),
                                    'modifiedBy': self.accountId
                                }

                                CompletedImages.append(v)

                                with open(uPath + filename, 'wb') as save_file:
                                    save_file.write(img['body'])

                                full_image_path = uPath + filename
                                im = Image.open(full_image_path)
                                exif_data = im.info.get('exif')
                                try:
                                    exif_dict = piexif.load(exif_data)
                                    
                                    if exif_dict.get('GPS', {}) != {}:
                                        exif_dict = self.gisExtractor.exif_to_tag(exif_dict)
                                        vGis.append(exif_dict['GPS'])
                                except Exception as e:
                                    Log.i(f"Error processing EXIF data: {e}")
                                imgIndex += 1

                        else:
                            existing_files = os.listdir(uPath)
                            for image_name in findAuditDetails[0]['completedImages']:
                                image_full_name = image_name['imagename'] + image_name['mimeType']
                                full_file_path = os.path.join(uPath, image_full_name)
                                if os.path.isfile(full_file_path):
                                    os.remove(full_file_path)

                    for stageName, stageFields in _data.items():
                        existingData = findAuditDetails[0].get('auditData', {}).get(stageName, {}).get("modifiedData", [])
                        if 'modifiedData' not in _data[stageName]:
                            _data[stageName]['modifiedData'] = []
                        for fieldName, fieldData in stageFields.items():
                            if fieldName in ["forceComplete", "modifiedData", "stageStatus", "color", "modifiedAt", "modifiedBy"]:
                                continue
                            db_data = findAuditDetails[0].get('auditData', {}).get(stageName, {}).get(fieldName)
                            if isinstance(db_data, dict) and db_data.get(fieldName) != fieldData.get(fieldName):
                                modified_entry = {'modifiedBy': self.accountId, 'modifiedAt': time, 'field' : fieldName}
                                existingData.append(modified_entry)
                        _data[stageName]['modifiedData'] = existingData

                    auditDict = {'auditData': _data}
                    updateAuditDtlQ = await self.auditInfo.update_one(
                        {
                            '_id': findAuditDetails[0]['_id'], 'loanId': appQ.get('_id')
                        },
                        {
                            '$set': {
                                'modifiedAt': time,
                                'modifiedBy': self.accountId,
                                'constructionStatus': constructionStatus,
                                'auditData': _data,
                                'completedImages': CompletedImages
                            }
                        }
                    )
                    if updateAuditDtlQ.modified_count:
                        message = 'Audit Details updated.'
                        code = 2215
                        status = True
                    else:
                        message = 'Audit Details could not be submitted.'
                        code = 4242
                        status = False
                    
                else:
                    updateAuditDtlQ = await self.auditInfo.update_one(
                        {
                            '_id': findAuditDetails[0]['_id'], 'loanId' : appQ.get('_id')
                        },
                        {
                            '$set': {
                                'modifiedAt': time,
                                'modifiedBy' : self.accountId,
                                'manualGis' : manGis
                            }
                        }
                    )
                    if updateAuditDtlQ.modified_count:
                        message = 'Location updated.'
                        code = 2715
                        status = True
                    else:
                        message = 'Location could not submitted.'
                        code = 4892
                        status = False
            else:
                if meth == 2:
                    if constructionStatus == 'complete':
                        CompletedImages = []
                        Cimages = file_dic.get('completedImages')
                        if Cimages is not None and len(Cimages) > 0:
                                
                                code, message = Validate.i(
                                    Cimages,
                                    'Completed Images',
                                    notNull=False,
                                    notEmpty=False,
                                    dataType=list
                                )
                                if code != 4100:
                                    raise Exception
                                time=timeNow()
                                imgIndex = 1
                                if find_imageQ:
                                    cImagesData = find_imageQ['completedImages']
                                    if cImagesData:
                                        imagename = cImagesData['imagename']
                                        if imagename:
                                            extn = cImagesData['mimeType']
                                            full_image_path_name = imagename + extn
                                            filepath = os.path.join(uPath, full_image_path_name)
                                            if os.path.exists(filepath):
                                                os.remove(filepath)
                                for img in Cimages:
                                    extImg = mimetypes.guess_extension(img['content_type'])
                                    fileName = img['filename'].split(".")[0]
                                    size = len(img['body']) / (1024 * 1024)
                                    filename = f"{fileName}_{time}_image_{imgIndex}{extImg}"
                                    filenamewithoutext = f"{fileName}_{time}_image_{imgIndex}"
                                    v = {
                                        'imagename': filenamewithoutext,
                                        'mimeType': extImg,
                                        'modifiedAt': timeNow(),
                                        'modifiedBy': self.accountId
                                    }

                                    CompletedImages.append(v)

                                    save_file = open(uPath + filename, 'wb')
                                    save_file.write(img['body'])
                                    save_file.close()
                                    filename = uPath + filename

                                    im = Image.open(filename)
                                    exif_data = im.info.get('exif')
                                    if exif_data is not None:
                                        exif_dict = piexif.load(exif_data)
                                        if exif_dict['GPS'] != {}:
                                            exif_dict = self.gisExtractor.exif_to_tag(exif_dict)
                                            vGis.append(exif_dict['GPS'])
                                    imgIndex = imgIndex + 1


                    for stageName, stageFields in _data.items():
                        if 'modifiedData' not in _data[stageName]:
                            _data[stageName]['modifiedData'] = []

                        for fieldName, fieldData in stageFields.items():
                            if fieldName in ["forceComplete", "modifiedData", "stageStatus", "color","modifiedAt", "modifiedBy"]:
                                continue
                            modified_entry = {'modifiedBy': self.accountId, 'modifiedAt': time, 'field' : fieldName}
                            _data[stageName]['modifiedData'].append(modified_entry)
                            
                    auditDict = {'auditData' : _data}
                    insertAuditDtlQ = await self.auditInfo.insert_one(
                        {
                            'createdAt': timeNow(),
                            'createdBy': self.accountId,
                            'loanId' : appQ.get('_id'),
                            'constructionStatus' : constructionStatus,
                            **auditDict,
                            'completedImages': CompletedImages
                        }
                    )
                    auditDetailsId = insertAuditDtlQ.inserted_id
                    if auditDetailsId:
                        message = 'Audit Details has been submitted.'
                        code = 2294
                        status = True
                    else:
                        message = 'Audit Details already submitted.'
                        code = 2298
                        status = False
                        
                else:
                    insertAuditDtlQ = await self.auditInfo.insert_one(
                        {
                            'createdAt': timeNow(),
                            'createdBy': self.accountId,
                            'loanId' : appQ.get('_id'),
                            'manualGis' : manGis
                        }
                    )
                    auditDetailsId = insertAuditDtlQ.inserted_id
                    if auditDetailsId:
                        message = 'Location has been submitted.'
                        code = 2054
                        status = True
                    else:
                        message = 'Location already submitted.'
                        code = 1911
                        status = False
        except Exception as e:
            status = False
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(response)
            await self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            # self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' + str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return