import json
import os
import re
import sys
import mimetypes
import requests
import pandas as pd
import io

import datetime 
import tornado.web
from abc import ABCMeta
from bson import ObjectId
from build_config import CONFIG
from lib.lib import Validate
from lib.xen_protocol import xenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log
from util.time_util import timeNow
from bson.json_util import dumps as bdumps
from lib.element_mixer import ElementMixer
from util.file_util import FileUtil


@xenSecureV2
class JointApplicationCountHandler(ElementMixer,  MongoMixin, metaclass=ABCMeta):

    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]
    
    block = MongoMixin.userDb[
        CONFIG['database'][0]['table'][15]['name']
    ]

    district = MongoMixin.userDb[
        CONFIG['database'][0]['table'][14]['name']
    ]
    loanApplication = MongoMixin.userDb[
        CONFIG['database'][0]['table'][13]['name']
    ]

    componentId = ObjectId('63d39988458b78fdf4cf6c0d')

    async def get(self):
        code = 4000
        status = False
        message = ''
        result = []

        try:

            mAccountFind = await self.account.find_one(
                {
                    '_id': self.accountId
                }
            )
            if not mAccountFind:
                code = 4082
                message = 'Account not Found'
                raise Exception
            
            try:
                mDistrict = self.get_argument('district')
            except:
                message = 'Missing argument [district].'
                code =  7018
                raise Exception
            
            try:
                mDistrict = ObjectId(mDistrict)
            except:
                message = 'Invalid argument [district].'
                code =  7548
                raise Exception

            try:
                mBlock = self.get_argument('block')
            except:
                mBlock = ""

            if mBlock == "":
                mBlock = None
            if mBlock != None:
                try:
                    mBlock = ObjectId(mBlock)
                except:
                    message = 'Invalid argument [block].'
                    code =  7948
                    raise Exception
            
            pipeline = [
                {
                    '$match': {
                        'data.unitDistrict': mDistrict
                    },
                    
                },
                {
                        "$match": {
                            "$expr": {
                                "$in": [
                                    {
                                        "$toLower": "$data.currentStatus"
                                    },
                                    [
                                        "online submitted",
                                        "rejected/returned",
                                        "under process (at agency)",
                                        "under process (at bank)"
                                    ]
                                ]
                            }
                        }
                    },
                {
                    '$facet': {
                        'pending': [
                            {
                                '$match': {
                                    'inspectionReportSubmitted': {'$exists': False}
                                }
                            },
                            {
                                '$group': {
                                    '_id': None,
                                    'count': {'$sum': 1}
                                }
                            }
                        ],
                        'total': [
                            {
                                '$group': {
                                    '_id': None,
                                    'count': {'$sum': 1}
                                }
                            }
                        ]
                    }
                }
            ]
            if mBlock:
                pipeline[0]['$match']['data.talukblock'] = mBlock
            fileQ = await self.loanApplication.aggregate(pipeline).to_list(None)

            pending = fileQ[0]['pending'][0]['count'] if fileQ[0]['pending'] else 0
            total = fileQ[0]['total'][0]['count'] if fileQ[0]['total'] else 0
            
            result.append({'total': total, 'pending' : pending})
            if not len(result):
                message = 'No data found.'
                code = 4082

            else:
                message = 'Data found.'
                code = 2000
                status = True

        except Exception as e:
            status = False
            if not len(message):
                # self.set_status(503)
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(bdumps(response))
            await self.finish()
            return

        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            # self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return
