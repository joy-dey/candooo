import json
import os
import re
import sys
import mimetypes
import requests
import pandas as pd
import io

import datetime 
import tornado.web
from abc import ABCMeta
from bson import ObjectId
from build_config import CONFIG
from lib.lib import Validate
from lib.xen_protocol import xenSecureV2
from util.conn_util import MongoMixin
from util.log_util import Log
from util.time_util import timeNow
from bson.json_util import dumps as bdumps
from lib.element_mixer import ElementMixer
from util.file_util import FileUtil


@xenSecureV2
class AuditorLoanApplicationDataHandler(ElementMixer,  MongoMixin, metaclass=ABCMeta):

    account = MongoMixin.userDb[
        CONFIG['database'][0]['table'][0]['name']
    ]

    uploadFileDetails = MongoMixin.userDb[
        CONFIG['database'][0]['table'][16]['name']
    ]

    loanApplication = MongoMixin.userDb[
        CONFIG['database'][0]['table'][13]['name']
    ]

    state = MongoMixin.userDb[
        CONFIG['database'][0]['table'][6]['name']
    ]

    block = MongoMixin.userDb[
        CONFIG['database'][0]['table'][15]['name']
    ]

    district = MongoMixin.userDb[
        CONFIG['database'][0]['table'][14]['name']
    ]
    
    auditInfo = MongoMixin.userDb[
        CONFIG['database'][0]['table'][19]['name']
    ]
    
    loanStatusLog = MongoMixin.userDb[
        CONFIG['database'][0]['table'][18]['name']
    ]

    rejectionReasons = MongoMixin.userDb[
        CONFIG['database'][0]['table'][11]['name']
    ]
    
    bankBranch = MongoMixin.userDb[
        CONFIG['database'][0]['table'][22]['name']
    ]
    
    jointApplication = MongoMixin.userDb[
        CONFIG['database'][0]['table'][23]['name']
    ]

    componentId = ObjectId('63d39988458b78fdf4cf6c0d')

    async def get(self):
        code = 4000
        status = False
        message = ''
        result = []

        try:
            try:
                f_limit = int(self.get_argument('limit'))
                f_skip = int(self.get_argument('skip'))
            except:
                f_limit = 10000
                f_skip = 0

            mAccountFind = await self.account.find_one(
                {
                    '_id': self.accountId
                }
            )
            if not mAccountFind:
                code = 4082
                message = 'Account not Found'
                raise Exception

            mDistrictsAllotted = None
            if mAccountFind.get('role') == 'Auditor':
                mDistrictsAllotted = mAccountFind.get('districts')
            
            try:
                method = self.get_argument('method')
                if not method :
                    message = 'Invalid argument method.'
                    code = 5182
                    status = False
                    raise Exception
                
                else:
                   meth = int(method)
            except:
                method = None

            if method == None:
                meth = None
                
            try:
                vFileDtlsId = str(self.get_argument('id'))
                if vFileDtlsId:
                    try:
                        vFileDtlsId = ObjectId(vFileDtlsId)
                    except:
                        message = 'Invalid argument [id].'
                        code =  7098
                        raise Exception
                else:
                    message = 'Missing argument [id].'
                    code =  7198
                    raise Exception
            except:
                vFileDtlsId = None

            try:
                mHomestayPerformance = self.get_argument('homestayPerformance')
                code, message = Validate.i(
                    mHomestayPerformance,
                    'homestayPerformance',
                    dataType = str,
                    notEmpty = True,
                    enums = ['Red', 'Yellow', 'Green']
                )
                if code != 4100:
                    raise Exception
            except:
                mHomestayPerformance = None

            try:
                vSearchWith = self.get_query_argument('searchWith')
                if not vSearchWith:
                    message = 'Invalid argument [searchWith].'
                    code =  7448
                    raise Exception
                vSearchWith = vSearchWith.lower()
            except:
                vSearchWith = None
            
            filterObj = {}    
            if vSearchWith:
                nApplicationId = {
                    'applicantId': {
                        '$regex': vSearchWith,
                        '$options': 'ism'
                    }
                }

                mApplicantName = {
                    'data.applicantName': {
                        '$regex': vSearchWith,
                        '$options': 'ism'
                    }
                }

                filterObj['$or'] = [nApplicationId, mApplicantName]
            
            try:
                mDistrict = str(self.get_argument('district'))
                if mDistrict:
                    try:
                        mDistrict = ObjectId(mDistrict)
                    except:
                        message = 'Invalid argument [district].'
                        code =  7548
                        raise Exception
                else:
                    message = 'Missing argument [district].'
                    code =  7018
                    raise Exception
            except:
                mDistrict = None
                
            try:
                mStatus = str(self.get_argument('status'))
                if not mStatus:
                    message = 'Invalid argument [status].'
                    code =  4566
                    raise Exception
            except:
                mStatus = None
            
            try:
                mBlock = str(self.get_argument('block'))
                if mBlock:
                    try:
                        mBlock = ObjectId(mBlock)
                    except:
                        message = 'Invalid argument [block].'
                        code =  7948
                        raise Exception
                else:
                    message = 'Missing argument [block].'
                    code =  7318
                    raise Exception
            except:
                mBlock = None

            try:
                mState = str(self.get_argument('state'))
                if mState:
                    try:
                        mState = ObjectId(mState)
                    except:
                        message = 'Invalid argument [state].'
                        code =  7958
                        raise Exception
                else:
                    message = 'Missing argument [state].'
                    code =  7479
                    raise Exception
            except:
                mState = ObjectId('5fda17c1adfeecf7e9dd96ce')

            mLocfilter = {}
            if mDistrict:                
                mLocfilter['data.unitDistrict'] = mDistrict

            if mBlock:                
                mLocfilter['data.talukblock'] = mBlock

            if mState:                
                mLocfilter['data.state'] = mState                  

            vLocfilter = {
                '$match': mLocfilter
            }
            
            try:
                mIsRecommended = self.get_argument('isRecommended')
                mIsRecommended = json.loads(mIsRecommended)
                code, message = Validate.i(
                    mIsRecommended,
                    'isRecommended',
                    dataType=bool
                )
                if code != 4100:
                    raise Exception
            except:
                mIsRecommended = False
            
            filterQ = {
                '$match' : filterObj
            } 
            addFieldsStage = {
                '$addFields': {
                    'currentStatusLower': {
                        '$toLower': {
                            '$reduce': {
                                'input': {
                                    '$split': ['$data.currentStatus', ' ']
                                },
                                'initialValue': '',
                                'in': {
                                    '$concat': ['$$value', '$$this']
                                }
                            }
                        }
                    },
                    'mStatusLower': {
                        '$toLower': {
                            '$reduce': {
                                'input': {
                                    '$split': [mStatus, ' ']
                                },
                                'initialValue': '',
                                'in': {
                                    '$concat': ['$$value', '$$this']
                                }
                            }
                        }
                    }
                }
            }

            matchStage = {
                '$match': {
                    '$expr': {
                        '$or': [
                            {'$eq': ['$currentStatusLower', '$mStatusLower']},
                            {'$and': [
                                {'$eq': ['$mStatusLower', 'loansanctioneddisbursed']},
                                {'$in': ['$data.currentStatus', ['Loan Sanctioned', 'Disbursed']]}
                            ]}
                        ]
                    }
                }
            }
            pipeline = [
                            {
                        '$lookup': {
                            'from': self.state.name,
                            'localField': 'data.state',
                            'foreignField': '_id',
                            'as': 'stateInfo'
                        }
                        },
                        {
                            '$lookup': {
                                'from': self.district.name,
                                'localField': 'data.unitDistrict',
                                'foreignField': '_id',
                                'as': 'districtInfo'
                            }
                        },
                        {
                            '$lookup': {
                                'from': self.block.name,
                                'localField': 'data.talukblock',
                                'foreignField': '_id',
                                'as': 'blockInfo'
                            }
                        },
                        {
                            '$lookup': {
                                'from': self.loanStatusLog.name,
                                'localField': '_id',
                                'foreignField': 'loanApplicationId',
                                'as': 'statusInfo',
                                'pipeline': [
                                    {
                                        '$lookup': {
                                            'from': self.account.name,
                                            'localField': 'recommendation.modifiedBy',
                                            'foreignField': '_id',
                                            'as': 'recommendationAccountInfo',
                                            'pipeline': [
                                                {
                                                    '$project': {
                                                        '_id': {
                                                            '$toString': '$_id'
                                                        },
                                                        'firstName': 1,
                                                        'lastName': 1
                                                    }
                                                }
                                            ]
                                        }
                                    }
                                ]
                            }
                        },
                        {
                            '$lookup': {
                                'from': self.rejectionReasons.name,
                                'localField': 'data.bankRemarks',
                                'foreignField': '_id',
                                'as': 'rejectionInfo',
                                'pipeline': [
                                    {
                                        '$project': {
                                            '_id': {
                                                '$toString': '$_id'
                                            },
                                            'reason': 1
                                        }
                                    }
                                ]
                            }
                        },
                        {
                            '$project': { 
                                'data.currentStatus' : 1, 
                                'data.underProcessRejectionByAgencyReason' : 1, 
                                'data.officeName':1, 
                                'data.agencyType':1,
                                'data.state': {
                                    '$toString': '$data.state'
                                }, 
                                'applicantId':1, 
                                'data.applicantName':1,	
                                'data.applicantAddress':1, 
                                'data.mobileNo':1,
                                'data.alternativeMobileNo':1,	
                                'data.email':1,
                                'data.legalStatus':1, 
                                'data.gender':1 , 
                                'data.category':1,	
                                'data.qualification':1,	
                                'data.dateOfBirth':1,	
                                'data.age':1,
                                'data.unitLocation':1,	
                                'data.unitAddress':1,	
                                'data.talukblock': {
                                    '$toString': '$data.talukblock'
                                }, 
                                'data.unitDistrict': {
                                    '$toString': '$data.unitDistrict'
                                },	
                                'data.productDescactivity':1,
                                'data.proposedProjectCost':1, 
                                'data.financingBranchIfscCode':1,	
                                'data.financingBranchAddress':1,	
                                'data.onlineSubmissionDate':1,
                                'data.forwardingDateToBank':1,	
                                'data.bankRemarks': {
                                    '$toString': '$data.bankRemarks'
                                },	
                                'data.dateOfDocumentReceivedAtBank':1,
                                'data.totalProjectCostApprovedByBank':1,	
                                'data.sanctionedDateByBank':1,	
                                'data.totalSanctionedAmountByBank':1,		
                                'data.dateOfDepositOwnContribution':1, 
                                'data.ownContributionAmountDeposited':1, 
                                'data.coveredUnderCgtsi':1,	
                                'data.dateOfLoanRelease':1,	
                                'data.loanReleaseAmount':1,	
                                'data.remarksForMmProcessAtPmegpcomumbai':1,
                                'data.mmReleaseAmount':1, 
                                'data.edpTrainingCenterName':1,	
                                'data.trainingStartDate':1,
                                'data.trainingEndDate':1,	
                                'data.durationOfTraining':1,	
                                'data.certificateIssueDate':1,
                                'data.physicalVerificationConductedDate': 1,
                                'data.physicalVerificationStatus': 1,
                                'data.isUnknownBlock': 1,
                                'createdAt':1, 
                                'createdBy':1, 
                                'modifiedBy':1, 
                                'modifiedAt':1,
                                'blockInfo' : 1,
                                'districtInfo' : 1,
                                'stateInfo' : 1,
                                'statusInfo': {
                                    'recommendation': 1,
                                    'recommendationAccountInfo': 1
                                },
                                'rejectionInfo': 1,
                                'inspectionReportSubmitted':1
                            }
                        }
                        ]
            
            pipelineQ = [
                        {
                        '$lookup': {
                            'from': self.state.name,
                            'localField': 'data.state',
                            'foreignField': '_id',
                            'as': 'stateInfo'
                        }
                        },
                        {
                            '$lookup': {
                                'from': self.district.name,
                                'localField': 'data.unitDistrict',
                                'foreignField': '_id',
                                'as': 'districtInfo'
                            }
                        },
                        {
                            '$lookup': {
                                'from': self.block.name,
                                'localField': 'data.talukblock',
                                'foreignField': '_id',
                                'as': 'blockInfo'
                            }
                        },
                        {
                            '$lookup': {
                                'from': self.auditInfo.name,
                                'localField': '_id',
                                'foreignField': 'loanId',
                                'as': 'auditInfo'
                            }
                        },
                        {
                            '$lookup': {
                                'from': self.loanStatusLog.name,
                                'localField': '_id',
                                'foreignField': 'loanApplicationId',
                                'as': 'statusInfo',
                                'pipeline': [
                                    {
                                        '$lookup': {
                                            'from': self.account.name,
                                            'localField': 'recommendation.modifiedBy',
                                            'foreignField': '_id',
                                            'as': 'recommendationAccountInfo',
                                            'pipeline': [
                                                {
                                                    '$project': {
                                                        '_id': {
                                                            '$toString': '$_id'
                                                        },
                                                        'firstName': 1,
                                                        'lastName': 1
                                                    }
                                                }
                                            ]
                                        }
                                    }
                                ]
                            }
                        },
                        {
                            '$lookup': {
                                'from': self.loanStatusLog.name,
                                'localField': '_id',
                                'foreignField': 'loanApplicationId',
                                'as': 'disbursementInfo',
                                'pipeline': [
                                    {
                                        '$addFields': {
                                            'disbursementDetails': {
                                                '$first': '$disbursed'
                                            }
                                        }
                                    },
                                    {
                                        '$addFields': {
                                            'disbursedDate': {
                                                '$first': '$disbursementDetails.disbursedInfo.date'
                                            }
                                        }
                                    },
                                    {
                                        '$project': {
                                            '_id': {
                                                '$toString': '$_id'
                                            },
                                            'disbursedDate': 1
                                        }
                                    }
                                ]
                            }
                        },
                        {
                            '$unwind': '$disbursementInfo'
                        },
                        {
                            '$project': { 
                                'data.totalSanctionedAmountByBank' : 1,
                                'data.currentStatus' : 1,  
                                'applicantId':1, 
                                'data.applicantName':1,	
                                'data.mobileNo':1,
                                'data.alternativeMobileNo':1,	
                                'data.gender':1 , 
                                'data.category':1,
                                'data.isUnknownBlock': 1,
                                'data.isUnknownBranch': 1,
                                'data.isRecommended': 1,
                                'createdAt':1, 
                                'createdBy':1, 
                                'modifiedBy':1, 
                                'modifiedAt':1,
                                'blockInfo' : 1,
                                'districtInfo' : 1,
                                'stateInfo' : 1,
                                'disbursementInfo': 1,
                                'inspectionReportSubmitted':1,
                                'statusInfo': {
                                    'recommendation': 1,
                                    'recommendationAccountInfo': 1
                                },
                                'auditInfo.stage1': {
                                '$ifNull': [
                                    { '$arrayElemAt': ['$auditInfo.auditData.stage1.stageStatus', 0] },
                                    ''
                                ]
                                },
                                'auditInfo.stage2': {
                                '$ifNull': [
                                    { '$arrayElemAt': ['$auditInfo.auditData.stage2.stageStatus', 0] },
                                    ''
                                ]
                                },
                                'auditInfo.stage3': {
                                '$ifNull': [
                                    { '$arrayElemAt': ['$auditInfo.auditData.stage3.stageStatus', 0] },
                                    ''
                                ]
                                },
                                'auditInfo.stage4': {
                                '$ifNull': [
                                    { '$arrayElemAt': ['$auditInfo.auditData.stage4.stageStatus', 0] },
                                    ''
                                ]
                                },
                                'auditInfo.stage5': {
                                '$ifNull': [
                                    { '$arrayElemAt': ['$auditInfo.auditData.stage5.stageStatus', 0] },
                                    ''
                                ]
                                },
                                'auditInfo.stage6': {
                                '$ifNull': [
                                    { '$arrayElemAt': ['$auditInfo.auditData.stage6.stageStatus', 0] },
                                    ''
                                ]
                                },
                                'auditInfo.constructionStatus': {
                                '$ifNull': [
                                    { '$arrayElemAt': ['$auditInfo.constructionStatus', 0] },
                                    ''
                                ]
                            }
                            }
                        }
                    ]
            
            vSkip = {
                '$skip': f_skip
            }
            vLimit = {
                '$limit': f_limit
            }

            if meth is not None and meth == 1:
                if mHomestayPerformance:
                    pipelineQ.insert(0, {
                        '$match': {
                            'data.currentStatus': 'Disbursed',
                            'data.unitDistrict': {
                                '$in': mDistrictsAllotted
                            }
                        }
                    })
                elif mDistrictsAllotted:
                    pipelineQ.insert(0, {
                        '$match': {
                            'data.unitDistrict': {
                                '$in': mDistrictsAllotted
                            }
                        }
                    })

                if vFileDtlsId is not None:
                    matchQ = {
                        '$match' : {
                            '_id' : vFileDtlsId
                        }
                    }
                    pipelineQ.insert(0,matchQ)
                if filterObj:
                    pipelineQ.insert(1, filterQ)
                pipelineQ.insert(4, vLocfilter)     
                if mStatus is not None:
                    pipelineQ.insert(1, addFieldsStage)
                    pipelineQ.insert(2, matchStage)   
                if mIsRecommended:
                    pipelineQ.insert(2, {
                        '$match': {
                            'data.isRecommended': mIsRecommended
                        }
                    })          
                pipelineQ.append(vSkip)
                pipelineQ.append(vLimit)
                fileQ = self.loanApplication.aggregate(pipelineQ)
                            
            elif meth is not None and meth == 2:
                matchMeth2 = {
                        'data.unitDistrict' : mDistrict
                    }
                if mBlock!= None:
                    matchMeth2['data.talukblock'] = mBlock
                pipelineQ.insert(0, {
                    '$match': matchMeth2})
                pipelineQ.insert(1, 
                    {
                        "$match": {
                            "$expr": {
                                "$in": [
                                    {
                                        "$toLower": "$data.currentStatus"
                                    },
                                    [
                                        "online submitted",
                                        "rejected/returned",
                                        "under process (at agency)",
                                        "under process (at bank)"
                                    ]
                                ]
                            }
                        }
                    }

                )
                if filterObj:
                    pipelineQ.insert(2, filterQ)
                fileQ = self.loanApplication.aggregate(pipelineQ)
            elif meth is None:
                if mHomestayPerformance:
                    pipelineQ.insert(0, {
                        '$match': {
                            'data.currentStatus': 'Disbursed',
                            'data.unitDistrict': {
                                '$in': mDistrictsAllotted
                            }
                        }
                    })
                elif mDistrictsAllotted:
                    pipelineQ.insert(0, {
                        '$match': {
                            'data.unitDistrict': {
                                '$in': mDistrictsAllotted
                            }
                        }
                    })
                if vFileDtlsId is not None:
                    matchQ = {
                        '$match' : {
                            '_id' : vFileDtlsId
                        }
                    }
                    pipeline.insert(0,matchQ)
                if filterObj:
                    pipeline.insert(3, filterQ)
                pipeline.insert(4, vLocfilter) 
                if mStatus is not None:
                    pipelineQ.insert(1, addFieldsStage)
                    pipelineQ.insert(2, matchStage)
                pipeline.append(vSkip)
                pipeline.append(vLimit)
                fileQ = self.loanApplication.aggregate(pipeline)

            xCurrentDate = datetime.datetime.fromtimestamp(timeNow() / 1000 / 1000)
            xCurrentDate = xCurrentDate.strftime('%Y-%m-%d')
            xCurrentDate = datetime.datetime.strptime(xCurrentDate, '%Y-%m-%d')
            
            if meth == None:
                async for i in fileQ:
                    i['inspectionReportSubmitted'] = i.get('inspectionReportSubmitted',False)
                    if i.get('statusInfo')[0].get('recommendation'):
                        for j, recommendation in enumerate(i.get('statusInfo')[0].get('recommendation')):
                            i['statusInfo'][0]['recommendation'][j]['modifiedBy'] = str(recommendation.get('modifiedBy'))
                            i['statusInfo'][0]['recommendation'][j]['modifiedTo'] = str(recommendation.get('modifiedTo'))
                            for k, account in enumerate(i.get('statusInfo')[0].get('recommendationAccountInfo')):
                                if i['statusInfo'][0]['recommendation'][j]['modifiedBy'] == account.get('_id'):
                                    i['statusInfo'][0]['recommendation'][j]['accountInfo'] = account
                    del i['statusInfo'][0]['recommendationAccountInfo']
                    if not i.get('statusInfo')[0].get('recommendation'):
                        i['statusInfo'] = 'NA'
                    if not i.get('rejectionInfo'):
                        i['rejectionInfo'] = 'NA'
   
                    result.append(i)
            elif meth == 2:
                async for i in fileQ:
                    if i.get('inspectionReportSubmitted',False) == True:
                        # selfInspect = False
                        approveQ = await self.jointApplication.find_one(
                            {
                                'applicantId' : i['applicantId']
                            },
                            {
                                'inspectedBy': 1
                            }
                        )
                        if approveQ:
                            inspectors = approveQ.get('inspectedBy')    
                            appCount = 0
                            totCount = 0
                            if inspectors is not None:
                                for inspector in inspectors:
                                    totCount += 1
                                    # if inspector.get('_id') == self.accountId:
                                    #     selfInspect = True
                                    if inspector.get('approved') == True:
                                        appCount += 1 
                                if appCount != totCount:
                                    i['inspectionReportApproved'] = False
                                else:
                                    i['inspectionReportApproved'] = True
                                # if selfInspect == False:
                                #     i['inspectionReportSubmitted'] = False
                            else:
                                i['inspectionReportApproved'] = True
                                i['inspectionReportSubmitted'] = True
                        else:
                            i['inspectionReportSubmitted'] = False
                            i['inspectionReportApproved'] = None

                    if i.get('inspectionReportSubmitted',False) == False:
                        i['inspectionReportApproved'] = None
                    
                    # i['inspectionReportSubmitted'] = i.get('inspectionReportSubmitted',False)  
                    result.append(i)
            elif meth == 1:
                if mHomestayPerformance:
                    async for i in fileQ:
                        xTotalStages = 0
                        if i.get('statusInfo')[0].get('recommendation'):
                            for j, recommendation in enumerate(i.get('statusInfo')[0].get('recommendation')):
                                i['statusInfo'][0]['recommendation'][j]['modifiedBy'] = str(recommendation.get('modifiedBy'))
                                i['statusInfo'][0]['recommendation'][j]['modifiedTo'] = str(recommendation.get('modifiedTo'))
                                for k, account in enumerate(i.get('statusInfo')[0].get('recommendationAccountInfo')):
                                    if i['statusInfo'][0]['recommendation'][j]['modifiedBy'] == account.get('_id'):
                                        i['statusInfo'][0]['recommendation'][j]['accountInfo'] = account
                        del i['statusInfo'][0]['recommendationAccountInfo']
                        if not i.get('statusInfo')[0].get('recommendation'):
                            i['statusInfo'] = 'NA'

                        if len(i.get('auditInfo')):
                                if i.get('auditInfo')[0].get('stage1') == 'complete':
                                    xTotalStages += 1
                                if i.get('auditInfo')[0].get('stage2') == 'complete':
                                    xTotalStages += 1
                                if i.get('auditInfo')[0].get('stage3') == 'complete':
                                    xTotalStages += 1
                                if i.get('auditInfo')[0].get('stage4') == 'complete':
                                    xTotalStages += 1
                                if i.get('auditInfo')[0].get('stage5') == 'complete':
                                    xTotalStages += 1
                                if i.get('auditInfo')[0].get('stage6') == 'complete':
                                    xTotalStages += 1

                        if i.get('auditInfo') and i.get('disbursementInfo').get('disbursedDate'):
                            xDisbursedDate = datetime.datetime.fromtimestamp(i.get('disbursementInfo').get('disbursedDate') / 1000 / 1000)
                            xDisbursedDate = xDisbursedDate.strftime('%Y-%m-%d')
                            xDisbursedDate = datetime.datetime.strptime(xDisbursedDate, '%Y-%m-%d')
                            year_diff = xCurrentDate.year - xDisbursedDate.year
                            month_diff = xCurrentDate.month - xDisbursedDate.month

                            if xCurrentDate.day < xDisbursedDate.day:
                                month_diff -= 1
                            xMonthDifference = year_diff * 12 + month_diff

                            if xTotalStages:
                                if mHomestayPerformance == 'Green':
                                    if xMonthDifference <= xTotalStages * 2 or xTotalStages == 6:
                                        result.append(i)
                                elif mHomestayPerformance == 'Yellow':
                                    if xMonthDifference > xTotalStages * 2 and xMonthDifference <= xTotalStages * 2 + 2 and xTotalStages != 6:
                                        result.append(i)
                                elif mHomestayPerformance == 'Red':
                                    if xMonthDifference > xTotalStages * 2 + 2 and xTotalStages != 6:
                                        result.append(i)

                else:
                    async for i in fileQ:
                        if i.get('statusInfo')[0].get('recommendation'):
                            for j, recommendation in enumerate(i.get('statusInfo')[0].get('recommendation')):
                                i['statusInfo'][0]['recommendation'][j]['modifiedBy'] = str(recommendation.get('modifiedBy'))
                                i['statusInfo'][0]['recommendation'][j]['modifiedTo'] = str(recommendation.get('modifiedTo'))
                        if not i.get('statusInfo')[0].get('recommendation'):
                            i['statusInfo'] = 'NA'
                        
                        result.append(i)

            if not len(result):
                message = 'No data found.'
                code = 4082

            else:
                print('len is : ',len(result))
                message = 'Data found.'
                code = 2000
                status = True

        except Exception as e:
            status = False
            if not len(message):
                # self.set_status(503)
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(bdumps(response))
            await self.finish()
            return

        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            # self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return

    async def put(self):
        code = 4000
        message = ''
        status = False
        result = []
        try:
            try:
                # CONVERTS BODY INTO JSON
                self.request.arguments = json.loads(self.request.body.decode())
            except Exception as e:
                code = 4002
                message = 'Expected Request Type JSON.'
                raise Exception
            
            mId = self.request.arguments.get('id')
            code, message = Validate.i(
                mId,
                'id',
                dataType=str,
                notEmpty=True
            )
            if code != 4100:
                raise Exception
            
            try:
                mId = ObjectId(mId)
            except:
                code = 4079
                message = 'Invalid Argument - [ id ]'
                raise Exception

            mFindApplication = await self.loanApplication.find_one(
                {
                    '_id': mId
                }
            )
            if not mFindApplication:
                code = 4028
                message = 'Application Not Found'
                raise Exception
            
            mMethod = self.request.arguments.get('method')
            if mMethod:
                code, message = Validate.i(
                    mMethod,
                    'method',
                    dataType=int,
                    notEmpty=True,
                    enums=[1, 2]
                )
                if code != 4100:
                    raise Exception
            else:
                raise Exception
          
            if mMethod:
                if mMethod == 1:
                    mBranchId = self.request.arguments.get('branchId')
                    code, message = Validate.i(
                        mBranchId,
                        'branchId',
                        dataType=str,
                        notEmpty=True
                    )
                    if code != 4100:
                        raise Exception
                    try:
                        mBranchId = ObjectId(mBranchId)
                    except:
                        code = 4907
                        message = 'Invalid Argument - [ branchId ]'
                        raise Exception
                    
                    mBranchFind = await self.bankBranch.find_one(
                        {
                            '_id': mBranchId
                        }
                    )
                    if not mBranchFind:
                        code = 4917
                        message = 'Bank Branch not Found'
                        raise Exception
                    
                    mBranchUpdate = await self.loanApplication.update_one(
                        {
                            '_id': mId
                        },
                        {
                            '$set': {
                                'data.bankBranch': mBranchId,
                                'data.isUnknownBranch': False
                            }
                        }
                    )
                    if mBranchUpdate.modified_count:
                        code = 2000
                        status = True
                        message = 'Branch Updated'
                    else:
                        code = 4937
                        message = 'Branch Not Updated'
                        raise Exception

                elif mMethod == 2:
                    mBlockId = self.request.arguments.get('blockId')
                    code, message = Validate.i(
                        mBlockId,
                        'blockId',
                        dataType=str,
                        notEmpty=True
                    )
                    if code != 4100:
                        raise Exception
                    try:
                        mBlockId = ObjectId(mBlockId)
                    except:
                        code = 4954
                        message = 'Invalid Argument - [ blockId ]'
                        raise Exception
                    
                    mBlockFind = await self.block.find_one(
                        {
                            '_id': mBlockId
                        }
                    )
                    if not mBlockFind:
                        code = 4964
                        message = 'Block Not Found'
                        raise Exception
                    
                    mBlockUpdate = await self.loanApplication.update_one(
                        {
                            '_id': mId
                        },
                        {
                            '$set': {
                                'data.talukblock': mBlockId,
                                'data.isUnknownBlock': False
                            }
                        }
                    )
                    if mBlockUpdate.modified_count:
                        code = 2000
                        status = True
                        message = 'Block Updated'
                    else:
                        code = 4133
                        message = 'Block Not Updated'
                        raise Exception

        except Exception as e:
            status = False
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            response['result'] = result
            self.write(response)
            await self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            # self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return