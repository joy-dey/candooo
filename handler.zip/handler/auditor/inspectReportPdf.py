import datetime
import sys
from abc import ABCMeta
from bson import ObjectId
from build_config import CONFIG
from lib.xen_protocol import xenSecureV2
from util.file_util import FileUtil
from util.conn_util import MongoMixin
from util.log_util import Log
from lib.element_mixer import ElementMixer
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib import colors
from reportlab.lib.units import inch
from reportlab.lib.pagesizes import letter
from reportlab.lib.utils import ImageReader
from reportlab.pdfgen import canvas
import io

@xenSecureV2
class InspectionReportPDFHandler(ElementMixer,  MongoMixin, metaclass=ABCMeta):

    jointApplication = MongoMixin.userDb[
        CONFIG['database'][0]['table'][23]['name']
    ]

    district = MongoMixin.userDb[
        CONFIG['database'][0]['table'][14]['name']
    ]
    
    loanApplication = MongoMixin.userDb[
        CONFIG['database'][0]['table'][13]['name']
    ]
    
    componentId = ObjectId('63d39988458b78fdf4cf6c0d')
    fu = FileUtil()
    
    async def get(self):
        code = 4000
        message = ''
        status = False
        result = []
        pdfContent = None
        try:

            try:
                applicantId =  self.get_argument('applicantId')
            except:
                code = 4566
                message = 'Missing argument Applicant Id'
                raise Exception
            
            names = []
            report = await self.jointApplication.find_one(
                {'applicantId': applicantId}
            )
            if not report:
                code = 6731
                message = 'Inspection Report not found, please re-upload the report'
                raise Exception
            
            applicantQ = await self.loanApplication.find_one(
                {
                    'applicantId' : applicantId
                }
            ) 
            if not applicantQ:
                code = 4056
                message = 'Applicant not found'
                raise Exception
                        
            pdfPath = []
            pdfUpload = applicantQ.get('pdfUploaded', None)
            if pdfUpload == True:
                doc = report.get('document')
                for d in doc:
                    name = d['fileName']
                    mType = d['mimeType']
                    pdfPath.append(self.fu.uploads + 'rc-homestay/inspectionReport/pdf/'+f"{name}{mType}")
                with open(pdfPath[0], 'rb') as f:
                    pdfContent = f.read()
                    f.close()
            else:
                inspectors = report.get('inspectedBy')    
                appCount = 0
                totCount = 0
                for inspector in inspectors:
                    totCount += 1
                    if inspector.get('approved') == True:
                        appCount += 1 
                        
                if appCount != totCount:
                    code = 3534
                    message = 'Download restricted due to remaining inspector approval'
                    raise Exception
            
                applicantName = applicantQ['data']['applicantName']
                applicantAddress = applicantQ['data']['applicantAddress']
                projectCost = applicantQ['data']['proposedProjectCost']
                bank = f"{applicantQ['data']['financingBranchAddress']}({applicantQ['data']['financingBranchIfscCode']})"
                if not report:
                    code = 4057
                    message = 'Inspection Report not found'
                    raise Exception
                
                images = report.get('images')
                inspectInfo = report.get('inspectionInformaton')
                inspectedBy = report.get('inspectedBy')
                
                for user in inspectedBy:
                    approved = user.get('approved')
                    if approved == True:
                        name = f"{user.get('name')}({user.get('designation')})"
                        names.append(name)
                    
                date = inspectInfo.get('inspectionDate')/1000000
                date = datetime.datetime.fromtimestamp(date).strftime('%d-%m-%Y %H:%M:%S')
                
                districtQ = inspectInfo.get('district')
                districtQ = await self.district.find_one({'_id': ObjectId(districtQ)})
                districtQ = districtQ.get('districtName')
                department = inspectInfo.get('department')
                locationAccess = inspectInfo.get('locationAccess')
                vehicleAccess = inspectInfo.get('vehicleAccess')
                propertyArea = inspectInfo.get('propertyArea')
                propertyUnit = inspectInfo.get('propertyUnit')
                waterAvailability = inspectInfo.get('waterAvailability')
                waterSource = inspectInfo.get('waterSource')
                otherWaterSource = None
                if 'Other' in waterSource:
                    otherWaterSource = inspectInfo.get('otherWaterSource')
                electricityAvailability = inspectInfo.get('electricityAvailability')
                existingStructures = inspectInfo.get('existingStructures')
                otherAmenitiesAvailable = inspectInfo.get('otherAmenitiesAvailable')
                viableHomestay = inspectInfo.get('viableHomestay')
                remarks = inspectInfo.get('remarks')
                structRemarks = inspectInfo.get('existingStructureRemarks')
                vRemarks = inspectInfo.get('electricityRemarks')
                eRemarks = inspectInfo.get('vehicleRemarks')
                
                currTime =  datetime.datetime.now().strftime('%d-%m-%Y %H:%M:%S')
                
                data = {
                    'Date of Joint Inspection': date,
                    'District': districtQ,
                    'Department': ', '.join(department) if type(department) == list else department,
                    'Access of the location': locationAccess,
                    'Access by motor vehicle' : vehicleAccess,
                    'Property Area' : str(propertyArea) + ' ' + str(propertyUnit),
                    'Availability of water' : waterAvailability,
                    'Source Of Water' : ', '.join(waterSource) if type(waterSource) == list else waterSource,
                    'Availability of electricity' : electricityAvailability,
                    'Already existing structures' : existingStructures,
                    'Other Amenities available' : ', '.join(otherAmenitiesAvailable) if type(otherAmenitiesAvailable) == list else otherAmenitiesAvailable,
                    'Does the property look viable for Homestay?' : viableHomestay,
                    'Inspected By' : ', '.join(names),
                }
                appliData = {
                    'Applicant Name' : applicantName,
                    'Applicant Address' : applicantAddress,
                    'Bank' : bank,
                    'Proposed Project Cost' : 'INR ' + str(projectCost)
                }
                if vRemarks is not None:
                    index = list(data.keys()).index('Access by motor vehicle')
                    existValue = data['Access by motor vehicle']
                    newValue = f"{existValue}, {vRemarks}" if existValue else vRemarks
                    data = dict(list(data.items())[:index] + [('Access by motor vehicle', newValue)] + list(data.items())[index+1:])
                    
                if eRemarks is not None:
                    index = list(data.keys()).index('Availability of electricity')
                    existValue = data['Availability of electricity']
                    newValue = f"{existValue}, {eRemarks}" if existValue else eRemarks
                    data = dict(list(data.items())[:index] + [('Availability of electricity', newValue)] + list(data.items())[index+1:])
                    
                if structRemarks is not None:
                    index = list(data.keys()).index('Already existing structures')
                    existValue = data['Already existing structures']
                    newValue = f"{existValue}, {structRemarks}" if existValue else structRemarks
                    data = dict(list(data.items())[:index] + [('Already existing structures', newValue)] + list(data.items())[index+1:])
                    
                if remarks is not None:
                    index = list(data.keys()).index('Does the property look viable for Homestay?')
                    existValue = data['Does the property look viable for Homestay?']
                    newValue = f"{existValue}, {remarks}" if existValue else remarks
                    data = dict(list(data.items())[:index] + [('Does the property look viable for Homestay?', newValue)] + list(data.items())[index+1:])
                    
                if otherWaterSource is not None:
                    index = list(data.keys()).index('Source Of Water')
                    data = dict(list(data.items())[:index+1] + [('Other Source Of Water', otherWaterSource)] + list(data.items())[index+1:])

                    
                HEADER_STYLE = {
                    'font': 'Helvetica-Bold',
                    'fontSize': 16,
                    'textColor': colors.black,
                }
                buffer = io.BytesIO()
                
                style = getSampleStyleSheet()
                style_table = style["BodyText"]
                style_table.wordWrap = 'CJK'
                style_table.alignment = 1
                style_table.spaceBefore = 10
                style_table.valign = 'TOP'
                pdf = canvas.Canvas(buffer, pagesize=letter)

                logo1 = 'reportLogos/ic_launcher_foreground.png'
                logo2 = 'reportLogos/logo_v1.png'
                logo3 = 'reportLogos/xlayer_logo_v2.png'
                logo1 = ImageReader(logo1)
                logo2 = ImageReader(logo2)
                logo3 = ImageReader(logo3)
                pdf.drawImage(logo1, x=10, y=700, width=100, height=100, mask='auto')
                pdf.drawImage(logo2, x=450, y=670, width=150, height=150, mask='auto')

                pdf.setFont(HEADER_STYLE['font'], 20)
                pdf.setFillColor(colors.green)
                headerText = "HOMESTAY SCHEME"
                pdf.drawString(200, 730, headerText)
                
                pdf.line(15, 710, 595, 710)
                
                pdf.setFont(HEADER_STYLE['font'], HEADER_STYLE['fontSize'])
                pdf.setFillColor(HEADER_STYLE['textColor'])
                headerText = "INSPECTION REPORT"
                headerWidth = pdf.stringWidth(headerText, HEADER_STYLE['font'], HEADER_STYLE['fontSize'])
                pdf.drawString(230, 687, headerText)
                pdf.line(230, 684, 230 + headerWidth, 684)
                
                pdf.setFillColor(colors.white)
                pdf.rect( x=30, y=527, width=550, height=148, stroke=1, fill=1)
                
                pdf.setFont('Helvetica-Bold', 15)
                pdf.setFillColor(colors.black)
                pdf.drawString(267, 656, "Applicant Details")
                pdf.line(30, 646, 580, 646)
                
                y_position = 635
                for key, value in appliData.items():
                    pdf.setFont('Helvetica-Bold', 9)
                    text = f"{key}  :  {value}"
                    text_width = pdf.stringWidth(text, 'Helvetica-Bold', 9)
                    if text_width > 490:
                        lines = []
                        current_line = ""
                        words = text.split()
                        for word in words:
                            if pdf.stringWidth(current_line + " " + word, 'Helvetica-Bold', 9) <= 490:
                                current_line += " " + word
                            else:
                                lines.append(current_line)
                                current_line = word
                        lines.append(current_line)
                        for line in lines:
                            pdf.drawString(60, y_position, line.strip())
                            y_position -= 17
                    else:
                        pdf.drawString(60, y_position, text)
                        y_position -= 17

                x = 30
                y = 500
                maxKeyWidth = max(pdf.stringWidth(key) for key in data.keys())
                maxWidth = 330
                lineHeight = 20
                lineSpacing = 5

                maxKeyWidth = max(pdf.stringWidth(key) for key in data.keys())
                for key, value in data.items():
                    pdf.drawString(x, y, f"{key}")
                    pdf.drawString(x + maxKeyWidth + 10, y, ":")

                    if pdf.stringWidth(str(value)) > maxWidth:
                        lines = []
                        text = str(value)
                        while pdf.stringWidth(text) > maxWidth:
                            index = int((maxWidth / pdf.stringWidth(text)) * len(text))
                            sub_text = text[:index]
                            lines.append(sub_text)
                            text = text[index:]
                        lines.append(text)
                        for line in lines:
                            pdf.drawString(x + maxKeyWidth + 20, y, line)
                            if line != lines[-1]:
                                y -= lineSpacing + 6
                            else:
                                y -= lineHeight
                    else:
                        pdf.drawString(x + maxKeyWidth + 20, y, str(value))
                        y -= lineHeight
                
                pdf.line(15, 710, 15, 130)
                pdf.line(594, 710, 594, 130)
                pdf.line(15, 130, 595, 130)
                
                pdf.setFont(HEADER_STYLE['font'], 13)
                pdf.setFillColor(colors.black)
                footer1 = "DATE  OF  DOWNLOAD"
                headerWidth = pdf.stringWidth(footer1, HEADER_STYLE['font'], HEADER_STYLE['fontSize'])
                pdf.drawString(20, 110, footer1)
                pdf.line(20, 107, 167, 107)
                pdf.drawString(20, 87, currTime)
                
                footer3 = "POWERED  BY"
                headerWidth = pdf.stringWidth(footer3, HEADER_STYLE['font'], HEADER_STYLE['fontSize'])
                pdf.drawString(200, 35, footer3)
                pdf.line(300, 55, 300, 20)
                pdf.drawImage(logo3, x=300, y=20, width=80, height=40, mask='auto')
                        
                pdf.save()
                try:
                    buffer.seek(0)
                    pdfContent = buffer.getvalue()
                    buffer.close()
                    
                    status = True
                    code = 2000
                    message = 'Inspection Report Generated Successfully'
                except Exception as e:
                    status = False
                    code = 5000
                    message = 'Inspection Report Generation Failed'
                    raise Exception
            
        except Exception as e:
            status = False
            self.set_status(500)
            if not len(message):
                template = 'Exception: {0}. Argument: {1!r}'
                code = 5010
                iMessage = template.format(type(e).__name__, e.args)
                message = 'Internal Error, Please Contact the Support Team.'
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = exc_tb.tb_frame.f_code.co_filename
                Log.w('EXC', iMessage)
                Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                      str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
        response = {
            'code': code,
            'status': status,
            'message': message
        }
        Log.d('RSP', response)
        try:
            if self._status_code == 200:
                self.write(pdfContent)
            else:
                self.write(response)
            await self.finish()
            return
        except Exception as e:
            status = False
            template = 'Exception: {0}. Argument: {1!r}'
            code = 5011
            # self.set_status(503)
            iMessage = template.format(type(e).__name__, e.args)
            message = 'Internal Error, Please Contact the Support Team.'
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = exc_tb.tb_frame.f_code.co_filename
            Log.w('EXC', iMessage)
            Log.d('EX2', 'FILE: ' + str(fname) + ' LINE: ' +
                  str(exc_tb.tb_lineno) + ' TYPE: ' + str(exc_type))
            response = {
                'code': code,
                'status': status,
                'message': message
            }
            self.write(response)
            await self.finish()
            return