# Demo Blog

---

Digital Building Logbooks are common digital data repositories capturing, integrating and storing building data from across the construction market value chain. This all-in-one information tool is meant to encourage data transparency and availability and simplify decision-making for stakeholders across the buildings value chain.
